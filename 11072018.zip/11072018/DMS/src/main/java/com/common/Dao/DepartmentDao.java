package com.common.Dao;

import java.util.List;
import com.common.models.Department;

public interface DepartmentDao {
	public List<Department> getDepartments();

	public Department getDepartmentById(int deptid);
}
