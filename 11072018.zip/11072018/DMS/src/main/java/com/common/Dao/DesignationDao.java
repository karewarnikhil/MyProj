package com.common.Dao;

import java.util.List;

import com.common.models.Designation;

public interface DesignationDao {
	public List<Designation> getDesignation();

	public Designation getDesignationById(int desgId);
}
