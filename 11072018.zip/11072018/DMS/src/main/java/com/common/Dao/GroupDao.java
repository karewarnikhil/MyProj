package com.common.Dao;

import java.util.List;

import com.common.models.Group;

public interface GroupDao {
  public List<Group> getGroup();
  public Group getGroupById(int grpId);
}
