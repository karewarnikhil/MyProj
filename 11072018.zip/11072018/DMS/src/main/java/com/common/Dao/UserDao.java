package com.common.Dao;

import java.util.List;

import com.common.models.User;
import com.common.models.User;

public interface UserDao {
 
	public List<User> getUsers();
	public User getUser(String emailId, String upw1);
	public void createUser(User user);
	public void updateUser(User user);
	public User getUserById(long id);
}
