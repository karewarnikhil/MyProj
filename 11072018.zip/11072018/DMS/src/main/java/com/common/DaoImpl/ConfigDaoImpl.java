package com.common.DaoImpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.common.Dao.ConfigDao;
import com.common.models.Config;


@Repository
@Transactional
public class ConfigDaoImpl implements ConfigDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	public List<Config> getLevel(){
		return sessionFactory.getCurrentSession().createQuery("FROM Config ").list();
	}
	public Config getConfigById(String userLevel) {
		return (Config) sessionFactory.getCurrentSession().
				createQuery("FROM Config where sk='"+userLevel+"'")
			    .uniqueResult();
	}
}
