package com.common.DaoImpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.common.Dao.DepartmentDao;
import com.common.models.Department;

@Repository
@Transactional
public class DepartmentDaoImpl implements DepartmentDao{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public List<Department> getDepartments(){
		return sessionFactory.getCurrentSession().createQuery("FROM Department").list();
	}
	
	public Department getDepartmentById(int deptid) {
		return (Department) sessionFactory.getCurrentSession().
				createQuery("FROM Department where deptid='"+deptid+"'")
			    .uniqueResult();
	}
}
