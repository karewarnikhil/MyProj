package com.common.DaoImpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.common.Dao.HintQuestionDao;
import com.common.models.HintQuestion;

@Repository
@Transactional
public class HintQuestionDaoImpl implements HintQuestionDao{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	 public List<HintQuestion> getQuestions(){
		 return sessionFactory.getCurrentSession().createQuery("FROM HintQuestion").list();
	 }

}
