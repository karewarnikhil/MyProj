package com.common.DaoImpl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.common.Dao.UserDao;
import com.common.models.User;


@Repository
@Transactional
public class UserDaoImpl implements UserDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	public List<User> getUsers(){
		Query query=sessionFactory.getCurrentSession().createQuery("from User u order by userId");
		List<User> list=(List<User>)query.list();
		return list;
}
	
	public User getUser(String emailId, String upw1) {
		return (User) sessionFactory.getCurrentSession()
				.createQuery("from User where emailid='"+emailId+"' and upw1='"+upw1+"'")
				.uniqueResult();
	}
	
	public void createUser(User user) {
		sessionFactory.getCurrentSession().save(user);
	}
	
	public void updateUser(User user) {
		String sql = "UPDATE User set address='"+user.getAddress()+"',mobNo='"+user.getMobNo()+"',department='"+user.getDepartment().getDeptid()+"',designation='"+user.getDesignation().getDesgid()+"',userLevel='"+user.getUserLevel()+"',loginStatus='"+user.getLoginStatus()+"' where userId='"+user.getUserId()+"'";
		Query query=sessionFactory.getCurrentSession().createQuery(sql);
		int result = query.executeUpdate();
		
	}
	public User getUserById(long id) {
		User user= (User) sessionFactory.getCurrentSession().createQuery("from User where userId='"+ id+"'").uniqueResult();
		return user;
	}
}
