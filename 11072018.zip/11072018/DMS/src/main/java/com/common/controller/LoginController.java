package com.common.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.common.Dao.UserDao;
import com.common.models.Login;
import com.common.models.User;

@Controller
@SessionAttributes("userObj")
public class LoginController {
	
    @Autowired
    private UserDao userDao;
    
	  @RequestMapping("login")
	  public ModelAndView loginEmployee(@ModelAttribute("login") Login login) {
	        return new ModelAndView("login");
	    }
	  @RequestMapping("loginUser")
	  public String loginUser(@ModelAttribute("login") Login login,@RequestParam String emailId,
			  @RequestParam String upw1,Model model)throws Exception{
		  User userObj=userDao.getUser(emailId, upw1);
		  if(userObj!=null && userObj.getEmailId()!=null & userObj.getUpw1()!=null) {
			  
			  if(emailId.equals(userObj.getEmailId())&& upw1.equals(userObj.getUpw1())) {
				  model.addAttribute("userObj", userObj);
				  List<User> userList=userDao.getUsers();
				  model.addAttribute("userList", userList);
				  return "Home";
			  }
			  
			  else {
				  model.addAttribute("message","Login failed, Try again");
				 return "login";
			  }
		  }
		  else {
			    model.addAttribute("message","Login failed, Try again");
				 return "login";
		    }
	  }
	  
	  /*@RequestMapping(value="/logout",method = RequestMethod.GET)
      public String logout(HttpSession session,Model model){
          session.invalidate();
          List<User> userList=userDao.getUsers();
		  model.addAttribute("userList", userList);
          return "Home";
      }*/
	  
}
