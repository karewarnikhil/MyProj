package com.common.controller;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.common.Dao.ConfigDao;
import com.common.Dao.DepartmentDao;
import com.common.Dao.DesignationDao;
import com.common.Dao.GroupDao;
import com.common.Dao.HintQuestionDao;
import com.common.Dao.UserDao;
import com.common.models.Config;
import com.common.models.Department;
import com.common.models.Designation;
import com.common.models.Group;
import com.common.models.HintQuestion;
import com.common.models.User;


@Controller
public class RegistrationController {
	@Autowired
	private DepartmentDao departmentDao;  
	
	@Autowired
	private DesignationDao designationDao;
	
    @Autowired
	private ConfigDao configDao;

    @Autowired
	private HintQuestionDao hintQuestionDao;
    
    @Autowired
    private GroupDao groupDao;
    
	 @Autowired
	 private UserDao userDao;
  
	@RequestMapping("Register")
	public String getRegisterPage(@ModelAttribute("user") User user, Model model) {
		 List<Department> departmentList=departmentDao.getDepartments();
		 List<Designation> designationList=designationDao.getDesignation();
		 List<Config> levelList= configDao.getLevel();
		 List<HintQuestion> questionList= hintQuestionDao.getQuestions();
		 List<Group> groupList=groupDao.getGroup();
		  model.addAttribute("departmentList", departmentList);
		  model.addAttribute("designationList", designationList);
		  model.addAttribute("levelList", levelList);
		  model.addAttribute("questionList",questionList);
		  model.addAttribute("groupList", groupList);
		 return "Registration";
	}
	
	@RequestMapping("newRegisterUser")
	public String createUser(@ModelAttribute("user") User user, Model model,
			@RequestParam("deptId") int deptid, @RequestParam("desgId") int desgId, @RequestParam("grpId")int grpId,
			HttpSession session) throws Exception{
	      User userSess= (User) session.getAttribute("userObj");
	      if(userSess!=null) {
		  Department dept=departmentDao.getDepartmentById(deptid);
		  Designation desig=designationDao.getDesignationById(desgId);
		  Group group=groupDao.getGroupById(grpId);
		  String name=user.getUserName().substring(0,4);
		  String email=user.getEmailId().substring(0, 2);
		  BigDecimal number=user.getMobNo();
		  String mobno=number.toString().substring(8);
		  String pass=name+email+"#"+mobno;
	      String createdBy=userSess.getUserName();
		  Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		  
		  user.setMobNo(number);
		  user.setDepartment(dept);
		  user.setDesignation(desig);
		  user.setGroup(group);
		  user.setUpw1(pass);
		  user.setUpw2(null);
		  user.setUpw3(null);
		  user.setCreatedBy(createdBy);
		  user.setCreationDate(timestamp);
		  user.setLoginStatus("A");
		  user.setOtp(null);
		  userDao.createUser(user);
	      }
	      else {
	    	  model.addAttribute("AddMessage","Login First");
	      }
		  List<User> userList=userDao.getUsers();
		  model.addAttribute("userList", userList);
		  return "Home";
	     
	}
	
	@RequestMapping("ListOfUser")
	public String getUsers(Model model) {
		 List<User> userList=userDao.getUsers();
		  model.addAttribute("userList", userList);
          return "Home";

	}
	 @RequestMapping("editUser")
	 public String getUser(@ModelAttribute("user") User user, Model model,HttpSession session,@RequestParam long id) {
		 user=userDao.getUserById(id);
		 List<Department> departmentList=departmentDao.getDepartments();
		 List<Designation> designationList=designationDao.getDesignation();
		 List<Config> levelList= configDao.getLevel();
		 model.addAttribute("user",user);
		 model.addAttribute("departmentList", departmentList);
		 model.addAttribute("designationList", designationList);
		 model.addAttribute("levelList", levelList);
		 return "UpdateUser";
	 }
	 @RequestMapping("updateUser")
	 public String updateUser(@ModelAttribute("user") User user, Model model,
			@RequestParam("deptId") int deptid, @RequestParam("desgId") int desgId,@RequestParam("userId") int id,
			HttpSession session)throws Exception{
		 
		  User userSess= (User) session.getAttribute("userObj");
	      if(userSess!=null) {
	    	  Department dept=departmentDao.getDepartmentById(deptid);
			  Designation desig=designationDao.getDesignationById(desgId);
			  String pass=user.getUpw1();
			  user.setUpw1(pass);
			  user.setDepartment(dept);
			  user.setDesignation(desig);
			  userDao.updateUser(user);
	      }
	      else {
	    	  model.addAttribute("AddMessage","Login First");
	      }
	      List<User> userList=userDao.getUsers();
		  model.addAttribute("userList", userList);
          return "Home";
	 }
}
