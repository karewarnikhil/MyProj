package com.common.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "config",  schema = "public")
public class Config implements Serializable{
	
	  private static final long serialVersionUID = 1L;

	  @Id
	  @GeneratedValue(strategy = GenerationType.IDENTITY)	
	  private String pk;
	  
	  @Id
	  @GeneratedValue(strategy = GenerationType.IDENTITY)
	  private String sk;
	  
	  @Column(name="ds")
	  private String ds;
	  
	  @Column(name="value")
	  private String value;
	  
	  public Config() {
		 
	  }
	
	 public Config(String pk, String sk, String ds, String value) {
		super();
		this.pk = pk;
		this.sk = sk;
		this.ds = ds;
		this.value = value;
	}
	
	public String getPk() {
		return pk;
	}
	
	public void setPk(String pk) {
		this.pk = pk;
	}
	
	public String getSk() {
		return sk;
	}
	
	public void setSk(String sk) {
		this.sk = sk;
	}
	
	public String getDs() {
		return ds;
	}
	
	public void setDs(String ds) {
		this.ds = ds;
	}
	
	public String getValue() {
		return value;
	}
	
	public void setValue(String value) {
		this.value = value;
	}
}
