package com.common.models;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "deptmst")
public class Department implements Serializable {
   
	private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int deptid;
	
	@Column(name="deptnm")
	private String deptnm;
	
	@Column(name="shrtnm")
	private String shrtnm;
	
	@Column(name="creationdt")
    private Timestamp creationdt;
	
	@Column(name="status")
    private String status;
    
    public Department() {
    }
	public Department(int deptid, String deptnm, String shrtnm, Timestamp creationdt, String status) {
		super();
		this.deptid = deptid;
		this.deptnm = deptnm;
		this.shrtnm = shrtnm;
		this.creationdt = creationdt;
		this.status = status;
	}
	
	public int getDeptid() {
		return deptid;
	}
	public void setDeptid(int deptid) {
		this.deptid = deptid;
	}
	public String getDeptnm() {
		return deptnm;
	}
	public void setDeptnm(String deptnm) {
		this.deptnm = deptnm;
	}
	public String getShrtnm() {
		return shrtnm;
	}
	public void setShrtnm(String shrtnm) {
		this.shrtnm = shrtnm;
	}
	public Timestamp getCreationdt() {
		return creationdt;
	}
	public void setCreationdt(Timestamp creationdt) {
		this.creationdt = creationdt;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
    
    
}
