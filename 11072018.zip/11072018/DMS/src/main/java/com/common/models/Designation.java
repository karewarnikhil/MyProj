package com.common.models;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "desigmst")
public class Designation implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int desgid;
	
	@Column(name="desgnm")
	private String desgnm;
	
	@Column(name="shrtnm")
	private String shrtnm;
	
	@Column(name="creationdt")
    private Timestamp creationdt;
	
	@Column(name="status")
    private String status;

	public Designation() {
	}

	public Designation(int desgid, String desgnm, String shrtnm, Timestamp creationdt, String status) {
		super();
		this.desgid = desgid;
		this.desgnm = desgnm;
		this.shrtnm = shrtnm;
		this.creationdt = creationdt;
		this.status = status;
	}

	public int getDesgid() {
		return desgid;
	}

	public void setDesgid(int desgid) {
		this.desgid = desgid;
	}

	public String getDesgnm() {
		return desgnm;
	}

	public void setDesgnm(String desgnm) {
		this.desgnm = desgnm;
	}

	public String getShrtnm() {
		return shrtnm;
	}

	public void setShrtnm(String shrtnm) {
		this.shrtnm = shrtnm;
	}

	public Timestamp getCreationdt() {
		return creationdt;
	}

	public void setCreationdt(Timestamp creationdt) {
		this.creationdt = creationdt;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
