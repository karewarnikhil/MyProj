package com.common.models;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "GroupMst")
public class Group implements Serializable{
  
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int grpid;
	
	@Column(name="grpnm")
	private String grpnm;
	
	@Column(name="shrtnm")
	private String shrtnm;
	
	@Column(name="createddate")
	private Timestamp createddate;
	
	@Column(name="status")
	private String status;
	
	public Group() {
		
	}

	public Group(int grpid, String grpnm, String shrtnm, Timestamp createddate, String status) {
		super();
		this.grpid = grpid;
		this.grpnm = grpnm;
		this.shrtnm = shrtnm;
		this.createddate = createddate;
		this.status = status;
	}

	public int getGrpid() {
		return grpid;
	}

	public void setGrpid(int grpid) {
		this.grpid = grpid;
	}

	public String getGrpnm() {
		return grpnm;
	}

	public void setGrpnm(String grpnm) {
		this.grpnm = grpnm;
	}

	public String getShrtnm() {
		return shrtnm;
	}

	public void setShrtnm(String shrtnm) {
		this.shrtnm = shrtnm;
	}

	public Timestamp getCreateddate() {
		return createddate;
	}

	public void setCreateddate(Timestamp createddate) {
		this.createddate = createddate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
