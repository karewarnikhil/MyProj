package com.common.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "hintquestionmst")
public class HintQuestion implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int hintid;
	
	@Column(name="hintquestion")
	private String hintquestion;
	
	public HintQuestion() {}

	public HintQuestion(int hintid, String hintquestion) {
		super();
		this.hintid = hintid;
		this.hintquestion = hintquestion;
	}

	public int getHintid() {
		return hintid;
	}

	public void setHintid(int hintid) {
		this.hintid = hintid;
	}

	public String getHintquestion() {
		return hintquestion;
	}

	public void setHintquestion(String hintquestion) {
		this.hintquestion = hintquestion;
	}
	

}
