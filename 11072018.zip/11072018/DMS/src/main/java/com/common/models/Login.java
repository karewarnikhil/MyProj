package com.common.models;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "UserMst")
public class Login implements Serializable{

	private static final long serialVersionUID = 1L;
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long userId;
	
	@Column(name="emailId")
	private String emailId;
	
	@Column(name="userName")
	private String userName;
	
	@Column(name="address")
	private String address;
	
	@Column(name="mobNo")
	private BigDecimal mobNo;
	
	@Column(name="deptId")
    @JoinColumn(name="deptId")
	private int deptId ;
	
	@Column(name="desgId")
	private int desgId ;
	
	@Column(name="grpId")
	private int grpId ;
	
	@Column(name="userLevel")
	private int userLevel ;
	
	@Column(name="upw1")
	private String upw1 ;
	
	@Column(name="upw2")
	private String upw2 ;
	
	@Column(name="upw3")
	private String upw3 ;
	
	@Column(name="createdBy")
	private String createdBy ;
	
	@Column(name="creationDate")
	private Timestamp creationDate;
	
	@Column(name="loginStatus")
	private String loginStatus;
	
	@Column(name="hintId")
	private int hintId ;
	
	@Column(name="hintAns")
	private String hintAns ;
	
	@Column(name="otp")
	private String otp ;
	
	public Login() {
	}
	public Login(Long userId, String emailId, String userName, String address, BigDecimal mobNo, int deptId, int desgId,
			int grpId, int userLevel, String upw1, String upw2, String upw3, String createdBy, Timestamp creationDate,
			String loginStatus, int hintId, String hintAns, String otp) 
	{
		super();
		this.userId = userId;
		this.emailId = emailId;
		this.userName = userName;
		this.address = address;
		this.mobNo = mobNo;
		this.deptId = deptId;
		this.desgId = desgId;
		this.grpId = grpId;
		this.userLevel = userLevel;
		this.upw1 = upw1;
		this.upw2 = upw2;
		this.upw3 = upw3;
		this.createdBy = createdBy;
		this.creationDate = creationDate;
		this.loginStatus = loginStatus;
		this.hintId = hintId;
		this.hintAns = hintAns;
		this.otp = otp;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public BigDecimal getMobNo() {
		return mobNo;
	}
	public void setMobNo(BigDecimal mobNo) {
		this.mobNo = mobNo;
	}
	public int getDeptId() {
		return deptId;
	}
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}
	public int getDesgId() {
		return desgId;
	}
	public void setDesgId(int desgId) {
		this.desgId = desgId;
	}
	public int getGrpId() {
		return grpId;
	}
	public void setGrpId(int grpId) {
		this.grpId = grpId;
	}
	public int getUserLevel() {
		return userLevel;
	}
	public void setUserLevel(int userLevel) {
		this.userLevel = userLevel;
	}
	public String getUpw1() {
		return upw1;
	}
	public void setUpw1(String upw1) {
		this.upw1 = upw1;
	}
	public String getUpw2() {
		return upw2;
	}
	public void setUpw2(String upw2) {
		this.upw2 = upw2;
	}
	public String getUpw3() {
		return upw3;
	}
	public void setUpw3(String upw3) {
		this.upw3 = upw3;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = creationDate;
	}
	public String getLoginStatus() {
		return loginStatus;
	}
	public void setLoginStatus(String loginStatus) {
		this.loginStatus = loginStatus;
	}
	public int getHintId() {
		return hintId;
	}
	public void setHintId(int hintId) {
		this.hintId = hintId;
	}
	public String getHintAns() {
		return hintAns;
	}
	public void setHintAns(String hintAns) {
		this.hintAns = hintAns;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}

}
