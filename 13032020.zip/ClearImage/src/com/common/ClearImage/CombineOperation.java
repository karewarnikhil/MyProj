package com.common.ClearImage;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import ClearImageJNI.CiException;
import ClearImageJNI.CiServer;
import ClearImageJNI.EBoolean;
import ClearImageJNI.EBorderExtractAlgorithm;
import ClearImageJNI.EBorderExtractFlags;
import ClearImageJNI.EFileFormat;
import ClearImageJNI.ELineDirection;
import ClearImageJNI.ESmoothType;
import ClearImageJNI.ICiImage;
import ClearImageJNI.ICiRepair;
import ClearImageJNI.ICiServer;

public class CombineOperation extends JFrame implements ActionListener
{
	protected static ICiServer Ci = null;
	protected static ICiImage Image = null;
	protected static boolean useFullIo = true;
	 
	private static final long serialVersionUID = 1L;
	JFrame jf;
	JTextField t1,t2,t3,t4,t5,t6,tr,tq;
	JCheckBox checkbox1,checkbox2,checkbox3,checkbox4,checkbox5,checkbox6,checkbox7,
	checkbox8,checkbox9,checkbox10,checkbox11,checkbox12,checkbox13,checkbox14;
	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14;
	JButton b0,b1,b2;
	Font f;
  
	
	
	DefaultTableModel model = new DefaultTableModel();
    JTable tabGrid = new JTable(model);
    JScrollPane scrlPane = new JScrollPane(tabGrid);

    public  CombineOperation()
	{
		jf=new JFrame();
		f = new Font("Times New Roman",Font.BOLD,20);
		jf.setLayout(null);

	    l6=new JLabel("MIX OPERATIONS");
	    l6.setFont(new Font("Times New Roman",Font.BOLD,25));
	    l6.setBounds(320,20,300,40);l6.setForeground(Color.blue);
	    jf.add(l6);

		l1= new JLabel("Folder Path :");
		//l1.setFont(f);
		l1.setBounds(120,80,130,25);
	    jf.add(l1);

		t1=new JTextField(20);
		t1.setBounds(320,80,300,25);t1.setToolTipText("Enter Folder Path");
		jf.add(t1);
		
		l2= new JLabel("Select Operations :");
		l2.setBounds(120,150,300,25);
	    jf.add(l2);
	    
		checkbox1 = new JCheckBox("Auto Deskew");    
        checkbox1.setBounds(320,120,300,25);    
        jf.add(checkbox1);
        
        checkbox2 = new JCheckBox("Auto Rotate");    
        checkbox2.setBounds(320,140,300,25);
        jf.add(checkbox2);
        
        checkbox3 = new JCheckBox("Remove Halftone");    
        checkbox3.setBounds(320,160,300,25);
        jf.add(checkbox3);
        
        checkbox4 = new JCheckBox("Remove Punchholes");    
        checkbox4.setBounds(320,180,300,25);
        jf.add(checkbox4);
        
        l3= new JLabel("Select Border Extract Pattern :");
		l3.setBounds(120,250,300,25);
	    jf.add(l3);
        
        checkbox5 = new JCheckBox("Borders");    
        checkbox5.setBounds(320,220,300,25);
        jf.add(checkbox5);
        
        checkbox6 = new JCheckBox("Borders & Deskew");    
        checkbox6.setBounds(320,240,300,25);
        jf.add(checkbox6);
        
        checkbox7 = new JCheckBox("Deskew & Crop");    
        checkbox7.setBounds(320,260,300,25);
        jf.add(checkbox7);
        
        checkbox8 = new JCheckBox("Border,Deskew & Crop");    
        checkbox8.setBounds(320,280,300,25);
        jf.add(checkbox8);
        
		/*
		 * checkbox9 = new JCheckBox("None Of Above");
		 * checkbox9.setBounds(320,300,300,25); jf.add(checkbox9);
		 */        
        
        l4= new JLabel("Select Line Remove Pattern :");
		l4.setBounds(120,350,300,25);
	    jf.add(l4);
	    
        checkbox10 = new JCheckBox("Horizontal Lines");    
        checkbox10.setBounds(320,330,300,25);
        jf.add(checkbox10);
        
        checkbox11 = new JCheckBox("Vertical Lines");    
        checkbox11.setBounds(320,350,300,25);
        jf.add(checkbox11);
        
        checkbox12 = new JCheckBox("Horizonal & Vertical Lines");    
        checkbox12.setBounds(320,370,300,25);
        jf.add(checkbox12);
        
        
        l11= new JLabel("Select Smooth Char Repair Pattern :");
		l11.setBounds(110,420,300,25);
	    jf.add(l11);
	    
        checkbox13 = new JCheckBox("Dark Edges");    
        checkbox13.setBounds(320,410,300,25);
        jf.add(checkbox13);
        
        checkbox14 = new JCheckBox("Light Edges");    
        checkbox14.setBounds(320,430,300,25);
        jf.add(checkbox14);
        
        
        l5= new JLabel("Auto Crop :");
		l5.setBounds(150,470,300,25);
	    jf.add(l5);
	    
	    
	    l7 = new JLabel("Left Size Crop :");
		//l2.setFont(f);
        l7.setBounds(320,470,170,25);
		jf.add(l7);

		t2=new JTextField(20);
		t2.setBounds(420,470,100,25);t2.setToolTipText("Enter Left Size For Crop");
		jf.add(t2);

		l8 = new JLabel("Right Size Crop :");
		//l3.setFont(f);
        l8.setBounds(540,470,170,25);
		jf.add(l8);

		t3=new JTextField(20);
		t3.setBounds(650,470,100,25);t3.setToolTipText("Enter Right Size For Crop");
		jf.add(t3);

		l9 = new JLabel("Top Size Crop :");
		//l4.setFont(f);
        l9.setBounds(320,500,170,25);
		jf.add(l9);

		t4=new JTextField(20);
		t4.setBounds(420,500,100,25);t4.setToolTipText("Enter Top Size For Crop");
		jf.add(t4);

		l10 = new JLabel("Bottom Size Crop :");
		//l5.setFont(f);
        l10.setBounds(540,500,170,25);
		jf.add(l10);

		t5=new JTextField(20);
		t5.setBounds(650,500,100,25);t5.setToolTipText("Enter Bottom Size For Crop");
		jf.add(t5);
		
		
		l12=new JLabel("* Applies only for GrayScale and Color Images.");
	    l12.setBounds(320,520,300,40);l12.setForeground(Color.red);
	    jf.add(l12);

		l13=new JLabel("* 30% is Recomended.");
		l13.setBounds(450,560,300,25);l13.setForeground(Color.red);
		jf.add(l13);
		    
		l14 = new JLabel("Remove Background Value :"); //l2.setFont(f);
	    l14.setBounds(150,560,170,25); jf.add(l14);
		  
		t6=new JTextField(20);
		t6.setBounds(320,560,100,25);t6.setToolTipText("Enter value in percentage.");
		jf.add(t6);

		/*
		 * l2 = new JLabel("Left Size Crop*"); //l2.setFont(f);
		 * l2.setBounds(150,160,170,25); jf.add(l2);
		 * 
		 * t2=new JTextField(20);
		 * t2.setBounds(320,160,100,25);t2.setToolTipText("Enter Left Size For Crop");
		 * jf.add(t2);
		 * 
		 * l3 = new JLabel("Right Size Crop*"); //l3.setFont(f);
		 * l3.setBounds(150,200,170,25); jf.add(l3);
		 * 
		 * t3=new JTextField(20);
		 * t3.setBounds(320,200,100,25);t3.setToolTipText("Enter Right Size For Crop");
		 * jf.add(t3);
		 * 
		 * l4 = new JLabel("Top Size Crop*"); //l4.setFont(f);
		 * l4.setBounds(150,240,170,25); jf.add(l4);
		 * 
		 * t4=new JTextField(20);
		 * t4.setBounds(320,240,100,25);t4.setToolTipText("Enter Top Size For Crop");
		 * jf.add(t4);
		 * 
		 * l5 = new JLabel("Bottom Size Crop*"); //l5.setFont(f);
		 * l5.setBounds(150,280,170,25); jf.add(l5);
		 * 
		 * t5=new JTextField(20);
		 * t5.setBounds(320,280,100,25);t5.setToolTipText("Enter Bottom Size For Crop");
		 * jf.add(t5);
		 */

	    b0 = new JButton("Save",new ImageIcon("images//save.png"));
        b0.setBounds(150,600,110,35);b0.setToolTipText("click to save remove lines operation");
		jf.add(b0);b0.addActionListener(this);

		b1 = new JButton("Clear",new ImageIcon("images//clear.png"));
		b1.setBounds(300,600,110,35);b1.setToolTipText("click to clear all textfilds");
	    jf.add(b1); b1.addActionListener(this);
	    
	    b2 = new JButton("Close",new ImageIcon("images//clear.png"));
		b2.setBounds(450,600,110,35);b2.setToolTipText("click to Close Window");
	    jf.add(b2); b2.addActionListener(this);
	    
	    jf.setTitle("Combine Operation");
	    jf.setSize(900,700);
		jf.setLocation(20,20);
		jf.setResizable(true);
		jf.getContentPane().setBackground(Color.WHITE);
	    jf.setVisible(true);
     
	}

public void actionPerformed(ActionEvent ae)
	{
	if(ae.getSource()==b0)
	 {
	 	    String fileIn = t1.getText();
	       	
	    	if((((t1.getText()).equals(""))))
	        {
		    JOptionPane.showMessageDialog(this,"* Detail are Missing !","Warning!!!",JOptionPane.WARNING_MESSAGE);
	        }
			else
			{
			  try
			  	 {
					
				  File directory = new File(fileIn); //get all the files from a directory
				  File[] fList = directory.listFiles();
				  
				  System.out.println("Number of files in folders:"+fList.length);
			      
			     
			      String fileOut = fileIn+"/OutputFiles/";
				 
				  //ICiRepair iCiRepair; 
				  try { 
				  CiServer objCi = new CiServer(); 
				  Ci = objCi.getICiServer();
				  ICiRepair repair = Ci.CreateRepair();
				   for (File file : fList)
				   {   
					   if (file.isFile()){
						   repair.getImage().Open(fileIn+file.getName(), 1);
						   if(checkbox1.isSelected())  
						   {  
							   repair.AutoDeskew();
							   System.out.println("Auto Deskew");
						   }  
						   if(checkbox2.isSelected())  
						   {  
							   repair.AutoRotate();
							   System.out.println("Auto Rotate");
						   }  
						   if(checkbox3.isSelected())  
						   {  
							   repair.RemoveHalftone();
							   System.out.println("Remove Halftone");
						   }
						   if(checkbox4.isSelected())  
						   {  
							   repair.RemovePunchHoles();
							   System.out.println("Remove PunchHoles");
						   }
						   if(checkbox5.isSelected())  
						   {  
							   System.out.println("Border Remove");
							   repair.BorderExtract(EBorderExtractFlags.ciBexBorder, EBorderExtractAlgorithm.ciBeaCleaner);
						   }  
						   if(checkbox6.isSelected())  
						   {  
							   System.out.println("BorderDeskew");
							   repair.BorderExtract(EBorderExtractFlags.ciBexBorderDeskew, EBorderExtractAlgorithm.ciBeaCleaner);
						   }  
						   if(checkbox7.isSelected())  
						   {  
							   System.out.println("DeskewCrop");
							   repair.BorderExtract(EBorderExtractFlags.ciBexDeskewCrop, EBorderExtractAlgorithm.ciBeaCleaner);
						   } 
						   if(checkbox8.isSelected())  
						   {  
							   System.out.println("DeskewBorderCrop");
							   repair.BorderExtract(EBorderExtractFlags.ciBexBorderDeskewCrop, EBorderExtractAlgorithm.ciBeaCleaner);
						   } 
						   
						   if(checkbox10.isSelected())  
						   {  
							   System.out.println("Horizontle Lines");
							   repair.DeleteLines(ELineDirection.ciLineHorz, EBoolean.ciFalse);
						   }  
						   if(checkbox11.isSelected())  
						   {  
							   System.out.println("Verticle Lines");
							   repair.DeleteLines(ELineDirection.ciLineVert, EBoolean.ciFalse);
						   }  
						   if(checkbox12.isSelected())  
						   {  
							   System.out.println("Both Lines");
							   repair.DeleteLines(ELineDirection.ciLineVertAndHorz, EBoolean.ciFalse);
						   }  
						   if(checkbox13.isSelected())  
						   {  
							   System.out.println("Darken Edges");
							   repair.SmoothCharacters(ESmoothType.ciSmoothDarkenEdges);
						   }  
						   if(checkbox14.isSelected())  
						   {  
							   System.out.println("Light Edges");
							   repair.SmoothCharacters(ESmoothType.ciSmoothLightenEdges);
						   }  
                           if( !((t2.getText().isEmpty()) &&  (t3.getText().isEmpty()) &&  (t4.getText().isEmpty()) &&  (t5.getText().isEmpty()))){
                        	   System.out.println("AutoCrop");
                        	   repair.AutoCrop(-(Integer.parseInt(t2.getText())),-(Integer.parseInt(t3.getText())),-(Integer.parseInt(t4.getText())),-(Integer.parseInt(t5.getText())));
                           }
                           
                           if( !((t6.getText().isEmpty()))){
                        	   System.out.println("removeBackground");   
                        	   repair.ClearBackground(Double.parseDouble(t6.getText()));
                           }
						   repair.getImage().SaveAs(fileOut+file.getName(), EFileFormat.ciEXT);
						   System.out.println("Completed File Name:"+file.getName()); 
				       }else if(file.isDirectory()) {
				    	   
				       }
				  }
				  
				   System.out.println("Total process completed successfully:");
				  } catch (CiException e) { // TODO Auto-generated catch block
				  e.printStackTrace(); }
				 
				 int reply=JOptionPane.showConfirmDialog(null,"Applied Operation Done Successfully.Do you want continue more?","Done Operations",JOptionPane.YES_NO_OPTION);
	             if (reply == JOptionPane.YES_OPTION)
	   			{
	   		       jf.setVisible(false);
	   		       new CombineOperation();
	   		    }
	   		  else if (reply == JOptionPane.NO_OPTION)
	   			{
	   			  jf.setVisible(false);
		        }
	          }
  catch(Exception e)
  {
    System.out.println(e);
    JOptionPane.showMessageDialog(null,"Error:"+e);
  }
 }
}
  else if(ae.getSource()==b1)
     {//clear
          t1.setText("");
          t2.setText("");
          t3.setText("");
          t4.setText("");
          t5.setText("");
          t6.setText("");
      }
    else if(ae.getSource()==b2)
    {
    	jf.setVisible(false);
	}
 }
}

