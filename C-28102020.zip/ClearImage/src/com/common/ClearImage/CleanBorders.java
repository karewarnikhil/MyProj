package com.common.ClearImage;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import ClearImageJNI.CiException;
import ClearImageJNI.CiServer;
import ClearImageJNI.EBorderExtractAlgorithm;
import ClearImageJNI.EBorderExtractFlags;
import ClearImageJNI.EFileFormat;
import ClearImageJNI.ICiImage;
import ClearImageJNI.ICiRepair;
import ClearImageJNI.ICiServer;

public class CleanBorders extends JFrame implements ActionListener
{
	protected static ICiServer Ci = null;
	protected static ICiImage Image = null;
	protected static boolean useFullIo = true;
	 
	private static final long serialVersionUID = 1L;
	JFrame jf;
	JTextField t1,t2,t3,t4,t5,tr,tq;
	JCheckBox checkbox1,checkbox2,checkbox3,checkbox4;
	JLabel l1,l2,l3,l4,l5,l6;
	JButton b0,b1,b2;
	Font f;
  
	
	
	DefaultTableModel model = new DefaultTableModel();
    JTable tabGrid = new JTable(model);
    JScrollPane scrlPane = new JScrollPane(tabGrid);

    public  CleanBorders()
	{
		jf=new JFrame();
		f = new Font("Times New Roman",Font.BOLD,20);
		jf.setLayout(null);

	    l6=new JLabel("CLEAN BORDERS");
	    l6.setFont(new Font("Times New Roman",Font.BOLD,25));
	    l6.setBounds(320,50,300,40);l6.setForeground(Color.blue);
	    jf.add(l6);

		l1= new JLabel("Folder Path :");
		//l1.setFont(f);
		l1.setBounds(150,120,130,25);
	    jf.add(l1);

		t1=new JTextField(20);
		t1.setBounds(320,120,300,25);t1.setToolTipText("Enter Folder Path");
		jf.add(t1);
		
		l2= new JLabel("Select Extract Pattern :");
		l2.setBounds(150,200,300,25);
	    jf.add(l2);

		/*
		 * l2 = new JLabel("Left Size Crop*"); //l2.setFont(f);
		 * l2.setBounds(150,160,170,25); jf.add(l2);
		 * 
		 * t2=new JTextField(20);
		 * t2.setBounds(320,160,100,25);t2.setToolTipText("Enter Left Size For Crop");
		 * jf.add(t2);
		 * 
		 * l3 = new JLabel("Right Size Crop*"); //l3.setFont(f);
		 * l3.setBounds(150,200,170,25); jf.add(l3);
		 * 
		 * t3=new JTextField(20);
		 * t3.setBounds(320,200,100,25);t3.setToolTipText("Enter Right Size For Crop");
		 * jf.add(t3);
		 * 
		 * l4 = new JLabel("Top Size Crop*"); //l4.setFont(f);
		 * l4.setBounds(150,240,170,25); jf.add(l4);
		 * 
		 * t4=new JTextField(20);
		 * t4.setBounds(320,240,100,25);t4.setToolTipText("Enter Top Size For Crop");
		 * jf.add(t4);
		 * 
		 * l5 = new JLabel("Bottom Size Crop*"); //l5.setFont(f);
		 * l5.setBounds(150,280,170,25); jf.add(l5);
		 * 
		 * t5=new JTextField(20);
		 * t5.setBounds(320,280,100,25);t5.setToolTipText("Enter Bottom Size For Crop");
		 * jf.add(t5);
		 */

	    b0 = new JButton("Save",new ImageIcon("images//save.png"));
        b0.setBounds(150,300,110,35);b0.setToolTipText("click to save remove borders operation");
		jf.add(b0);b0.addActionListener(this);

		b1 = new JButton("Clear",new ImageIcon("images//clear.png"));
		b1.setBounds(300,300,110,35);b1.setToolTipText("click to clear all textfilds");
	    jf.add(b1); b1.addActionListener(this);
	    
	    b2 = new JButton("Close",new ImageIcon("images//clear.png"));
		b2.setBounds(450,300,110,35);b2.setToolTipText("click to Close Window");
	    jf.add(b2); b2.addActionListener(this);
	    
	    
	    checkbox1 = new JCheckBox("Borders");    
        checkbox1.setBounds(320,180,300,25);    
        jf.add(checkbox1);
        
        checkbox2 = new JCheckBox("Borders & Deskew");    
        checkbox2.setBounds(320,200,300,25);
        jf.add(checkbox2);
        
        checkbox3 = new JCheckBox("Deskew & Crop");    
        checkbox3.setBounds(320,220,300,25);
        jf.add(checkbox3);
        
        checkbox4 = new JCheckBox("Border,Deskew & Crop");    
        checkbox4.setBounds(320,240,300,25);
        jf.add(checkbox4);
	    
	    jf.setTitle("CLEAN BORDERS");
	    jf.setSize(900,500);
		jf.setLocation(20,20);
		jf.setResizable(false);
		jf.getContentPane().setBackground(Color.WHITE);
	    jf.setVisible(true);
     
	}

public void actionPerformed(ActionEvent ae)
	{
	if(ae.getSource()==b0)
	 {
	 	    String fileIn = t1.getText();
	       	
	    	if((((t1.getText()).equals(""))))
	        {
		    JOptionPane.showMessageDialog(this,"* Detail are Missing !","Warning!!!",JOptionPane.WARNING_MESSAGE);
	        }
			else
			{
			  try
			  	 {
				  	
				  File directory = new File(fileIn); //get all the files from a directory
				  File[] fList = directory.listFiles();
				  
				  System.out.println("Number of files in folders:"+fList.length);
			      
			     
			      String fileOut = fileIn+"/OutputFiles/";
				 
				  //ICiRepair iCiRepair; 
				  try { 
				  CiServer objCi = new CiServer(); 
				  Ci = objCi.getICiServer();
				  ICiRepair repair = Ci.CreateRepair();
				   for (File file : fList)
				   {   
					   if (file.isFile()){
						   repair.getImage().Open(fileIn+file.getName(), 1);
						   if(checkbox1.isSelected())  
						   {  
							  // System.out.println("Border Remove");
							   repair.BorderExtract(EBorderExtractFlags.ciBexBorder, EBorderExtractAlgorithm.ciBeaCleaner);
						   }  
						   if(checkbox2.isSelected())  
						   {  
							   //System.out.println("BorderDeskew");
							   repair.BorderExtract(EBorderExtractFlags.ciBexBorderDeskew, EBorderExtractAlgorithm.ciBeaCleaner);
						   }  
						   if(checkbox3.isSelected())  
						   {  
							  // System.out.println("DeskewCrop");
							   repair.BorderExtract(EBorderExtractFlags.ciBexDeskewCrop, EBorderExtractAlgorithm.ciBeaCleaner);
						   } 
						   if(checkbox4.isSelected())  
						   {  
							  // System.out.println("DeskewBorderCrop");
							   repair.BorderExtract(EBorderExtractFlags.ciBexBorderDeskewCrop, EBorderExtractAlgorithm.ciBeaCleaner);
						   } 
						   repair.getImage().SaveAs(fileOut+file.getName(), EFileFormat.ciEXT);
						   System.out.println("Completed File Name:"+file.getName()); 
				       }else if(file.isDirectory()) {
				    	   
				       }
				  }
				  
				   System.out.println("Total process completed successfully:");
				  } catch (CiException e) { // TODO Auto-generated catch block
				  e.printStackTrace(); }
				 
				 int reply=JOptionPane.showConfirmDialog(null,"Remove Borders Operation Done Successfully.Do you want continue more?","Done Remove Borders",JOptionPane.YES_NO_OPTION);
	             if (reply == JOptionPane.YES_OPTION)
	   			{
	   		       jf.setVisible(false);
	   		       new CleanBorders();
	   		    }
	   		  else if (reply == JOptionPane.NO_OPTION)
	   			{
	   			  jf.setVisible(false);
		        }
	          }
  catch(Exception e)
  {
    System.out.println(e);
    JOptionPane.showMessageDialog(null,"Error:"+e);
  }
 }
}
  else if(ae.getSource()==b1)
     {//clear
          t1.setText("");
          //t2.setText("");
          //t3.setText("");
         // t4.setText("");
        //  t5.setText("");
      }
    else if(ae.getSource()==b2)
    {
    	jf.setVisible(false);
	}
 }
	/*
	 * public static void main(String args[]) { new CleanBorders(); }
	 */
}

