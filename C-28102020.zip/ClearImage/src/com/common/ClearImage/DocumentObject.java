package com.common.ClearImage;

import java.io.Serializable;


public class DocumentObject implements Serializable{
	
	private static final long serialVersionUID = 1L;
    private String fileName;
    
    private String filePath;
    
    private int pageCnt; 
    
 
    private int a0Size; 
    
   
    private int a1Size; 
    
   
    private int a2Size; 
    
  
    private int a3Size; 
    
   
    private int a4Size; 
    
	public int getPageCnt() {
		return pageCnt;
	}

	public void setPageCnt(int pageCnt) {
		this.pageCnt = pageCnt;
	}

	public DocumentObject() {
		super();
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public int getA0Size() {
		return a0Size;
	}

	public void setA0Size(int a0Size) {
		this.a0Size = a0Size;
	}

	public int getA1Size() {
		return a1Size;
	}

	public void setA1Size(int a1Size) {
		this.a1Size = a1Size;
	}

	public int getA2Size() {
		return a2Size;
	}

	public void setA2Size(int a2Size) {
		this.a2Size = a2Size;
	}

	public int getA3Size() {
		return a3Size;
	}

	public void setA3Size(int a3Size) {
		this.a3Size = a3Size;
	}

	public int getA4Size() {
		return a4Size;
	}

	public void setA4Size(int a4Size) {
		this.a4Size = a4Size;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	

	
	

	
	
	
	

	

	
	
    
	

	

		
		
		
		

		
        
		
		

		

}
