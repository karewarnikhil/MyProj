package com.common.ClearImage;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfReader;

import ClearImageJNI.ICiImage;
import ClearImageJNI.ICiServer;

public class PageCount extends JFrame implements ActionListener
{
	protected static ICiServer Ci = null;
	protected static ICiImage Image = null;
	protected static boolean useFullIo = true;
	 
	private static final long serialVersionUID = 1L;
	JFrame jf,jf1;
	JTable  jtable;
	JTextField t1,t2,t3,t4,t5,tr,tq;
	JLabel l1,l2,l3,l4,l5,l6;
	JButton b0,b1,b2;
	Font f;
	JScrollPane jScrollPane;

    public  PageCount()
	{
		jf=new JFrame();
		f = new Font("Times New Roman",Font.BOLD,20);
		jf.setLayout(null);

	    l6=new JLabel("PAGE COUNT");
	    l6.setFont(new Font("Times New Roman",Font.BOLD,25));
	    l6.setBounds(320,50,300,40);l6.setForeground(Color.blue);
	    jf.add(l6);

		l1= new JLabel("Folder Path :");
		//l1.setFont(f);
		l1.setBounds(150,120,130,25);
	    jf.add(l1);

		t1=new JTextField(20);
		t1.setBounds(320,120,300,25);t1.setToolTipText("Enter Folder Path");
		jf.add(t1);

		/*
		 * l2 = new JLabel("Left Size Crop*"); //l2.setFont(f);
		 * l2.setBounds(150,160,170,25); jf.add(l2);
		 * 
		 * t2=new JTextField(20);
		 * t2.setBounds(320,160,100,25);t2.setToolTipText("Enter Left Size For Crop");
		 * jf.add(t2);
		 * 
		 * l3 = new JLabel("Right Size Crop*"); //l3.setFont(f);
		 * l3.setBounds(150,200,170,25); jf.add(l3);
		 * 
		 * t3=new JTextField(20);
		 * t3.setBounds(320,200,100,25);t3.setToolTipText("Enter Right Size For Crop");
		 * jf.add(t3);
		 * 
		 * l4 = new JLabel("Top Size Crop*"); //l4.setFont(f);
		 * l4.setBounds(150,240,170,25); jf.add(l4);
		 * 
		 * t4=new JTextField(20);
		 * t4.setBounds(320,240,100,25);t4.setToolTipText("Enter Top Size For Crop");
		 * jf.add(t4);
		 * 
		 * l5 = new JLabel("Bottom Size Crop*"); //l5.setFont(f);
		 * l5.setBounds(150,280,170,25); jf.add(l5);
		 * 
		 * t5=new JTextField(20);
		 * t5.setBounds(320,280,100,25);t5.setToolTipText("Enter Bottom Size For Crop");
		 * jf.add(t5);
		 */

	    b0 = new JButton("Save",new ImageIcon("images//save.png"));
        b0.setBounds(150,170,110,35);b0.setToolTipText("click to save page count operation");
		jf.add(b0);b0.addActionListener(this);

		b1 = new JButton("Clear",new ImageIcon("images//clear.png"));
		b1.setBounds(300,170,110,35);b1.setToolTipText("click to clear all textfilds");
	    jf.add(b1); b1.addActionListener(this);
	    
	    b2 = new JButton("Close",new ImageIcon("images//clear.png"));
		b2.setBounds(450,170,110,35);b2.setToolTipText("click to Close Window");
	    jf.add(b2); b2.addActionListener(this);
	   
	    jf.setTitle("Page Count");
	    jf.setSize(900,500);
		jf.setLocation(20,20);
		jf.setResizable(false);
		jf.getContentPane().setBackground(Color.WHITE);
	    jf.setVisible(true);
     
	}

public void actionPerformed(ActionEvent ae)
	{
	if(ae.getSource()==b0)
	 {
	 	    String fileIn = t1.getText();
	    	if((((t1.getText()).equals(""))))
	        {
		    JOptionPane.showMessageDialog(this,"* Detail are Missing !","Warning!!!",JOptionPane.WARNING_MESSAGE);
	        }
			else
			{
			  try
			  	 {
				  //jf.setVisible(false);
				  File directory = new File(fileIn); //get all the files from a directory
				  File[] fList = directory.listFiles();
				  
				  System.out.println("Number of files in folders:"+fList.length);
				  ArrayList<DocumentObject> arrayListDocument = getDifferntPageSize(fList);
							/*
							 * try { PdfReader reader = new PdfReader(new
							 * ByteArrayInputStream(multipartFile.getBytes()));
							 * 
							 * System.out.println(reader.getNumberOfPages());
							 * documentObject.setPageCnt(reader.getNumberOfPages()); reader.close(); } catch
							 * (IOException e1) { e1.printStackTrace(); }
							 */
						  // System.out.println("Completed File Name:"+file.getName()); 
				          System.out.println("Total process completed successfully:");
				          jf.setVisible(false);
				          new ReportTable(arrayListDocument,directory);
				      //   jf1=new JFrame();
				          
					/*
					 * String data[][]={ {"101","Amit","670000"}, {"102","Jai","780000"},
					 * {"101","Sachin","700000"}}; String column[]={"ID","NAME","SALARY"};
					 */       
					 
					
					 
					 //jtable.setModel(defaultTableModel);					
				     // jtable.setBounds(10,10,10,10);  
					 
					 
		              // JTable jt=new JTable(data,column);    
					  // JTable jt=new JTable(data,column);    
					  // jtable.setBounds(30,40,500,400);          
					  // JScrollPane sp=new JScrollPane(jtable);    
					  // jScrollPane.setViewportView(jtable);
					  //  jf1.setLayout(new BorderLayout());
					  //  jf1.add(new JScrollPane(jtable), BorderLayout.CENTER);
					  // jf1.add(jtable.getTableHeader(), BorderLayout.NORTH);
					  //   jf1.add(sp);
					  // jf1.setVisible(true);
					  //jf1.setSize(700,700);
				 
					/*
					 * int reply=JOptionPane.showConfirmDialog(
					 * null,"Page Count Operation Done Successfully.Do you want continue more?"
					 * ,"Done Page Count",JOptionPane.YES_NO_OPTION); if (reply ==
					 * JOptionPane.YES_OPTION) { jf.setVisible(false); new PageCount(); } else if
					 * (reply == JOptionPane.NO_OPTION) { jf.setVisible(false); }
					 */
	          }
  catch(Exception e)
  {
    System.out.println(e);
    JOptionPane.showMessageDialog(null,"Error:"+e);
  }
  finally {
	  System.gc();
  }
 }
}
  else if(ae.getSource()==b1)
     {//clear
          t1.setText("");
          //t2.setText("");
          //t3.setText("");
          //t4.setText("");
         // t5.setText("");
      }
    else if(ae.getSource()==b2)
    {
    	jf.setVisible(false);
	}
 }


private ArrayList<DocumentObject>  getDifferntPageSize(File[] fList) {
	 ArrayList<DocumentObject> arrayListDocument = new ArrayList<DocumentObject>();
	 // 96 dpi
	 //double pixelToInch = 0.0104166667;
	 
	 // 72 dpi
	 double pixelToInch = 0.0138888888;
	 
	// 200 dpi
	 //double pixelToInch = 0.005;
	 double pageWidth = 0.0;
	 double pageSizeForCalculation = 0.0;
	 double percentageForTolerance = 8;
	
	 double a3Size = 8.27+(8.27*(percentageForTolerance/100));
	 double a2Size = 11.69+(11.69*(percentageForTolerance/100));
	 double a1Size = 16.54+(16.54*(percentageForTolerance/100));
	 double a0Size = 23.39+(23.39*(percentageForTolerance/100));
	 
	 a3Size = Math.round(a3Size * 100.0) / 100.0;
	 a2Size = Math.round(a2Size * 100.0) / 100.0;
	 a1Size = Math.round(a1Size * 100.0) / 100.0;
	 a0Size = Math.round(a0Size * 100.0) / 100.0;
	 
	 System.out.println(a3Size+""+a2Size+""+a1Size+""+a0Size);
	 
	readFilesAndFolders(fList, arrayListDocument, pixelToInch, a3Size, a2Size, a1Size, a0Size);
	return arrayListDocument;
}

private void readFilesAndFolders(File[] fList, ArrayList<DocumentObject> arrayListDocument, double pixelToInch,
		double a3Size, double a2Size, double a1Size, double a0Size) {
	try {
		 for (File file : fList)
		   {   
			 if (file.isDirectory()) {
				 readFilesAndFolders(file.listFiles(), arrayListDocument, pixelToInch, a3Size, a2Size, a1Size, a0Size);
			 }
			 
			 if (file.isFile() && file.getName().contains("pdf")) {
				   readOnlyPdf(arrayListDocument, pixelToInch, a3Size, a2Size, a1Size, a0Size, file);
			 }
	}
	
	} catch (IOException e1) {
		e1.printStackTrace();
	}
}

private void readOnlyPdf(ArrayList<DocumentObject> arrayListDocument, double pixelToInch, double a3Size, double a2Size,
		double a1Size, double a0Size, File file) throws IOException {
		double pageWidth;
		double pageSizeForCalculation;
		int A0=0,A1=0,A2=0,A3=0,A4=0;
	   DocumentObject documentObject = new DocumentObject();
	   System.out.println("File Name........."+file.getName());
	   
			 PdfReader reader = new PdfReader(file.getPath());
			 for(int i=1;i<=reader.getNumberOfPages();i++) {
			 Rectangle rect = reader.getPageSize(i);
			 System.out.println("Width=="+Math.round(rect.getWidth() * pixelToInch * 100.0) / 100.0 +" Height=="+Math.round(rect.getHeight()*pixelToInch * 100.0) / 100.0); 
			 if(rect.getWidth() < rect.getHeight())
				 pageSizeForCalculation = pixelToInch * rect.getWidth();
			 else
				 pageSizeForCalculation = pixelToInch * rect.getHeight();
			 
			 pageWidth = Math.round(pageSizeForCalculation * 100.0) / 100.0; 
			 System.out.println("pageWidth=="+pageWidth);
			 //A4 Size
			 if(pageWidth <= a3Size) {
				 A4++;
				 System.out.println("Page No A4=="+i);
			 }
			 //A3 Size
			 else if(pageWidth > a3Size && pageWidth <= a2Size) {
				 A3++;
				 System.out.println("Page No A3=="+i);
			 }
			 //A2 Size
			 else if(pageWidth > a2Size && pageWidth <= a1Size) {
				 A2++;
				 System.out.println("Page No A2=="+i);
			 }
			//A1 Size
			 else if(pageWidth > a1Size && pageWidth <= a0Size) {
				 System.out.println("Page No A1=="+i);
				 A1++;
			 }
			//A0 Size
			 else if(pageWidth >= a0Size) {
				 System.out.println("Page No A0=="+i);
				 A0++;
			 }
			 }
			 System.out.println("A0=="+A0+" A1=="+A1+" A2=="+A2+" A3=="+A3+" A4=="+A4);
			 System.out.println(reader.getNumberOfPages());
			 documentObject.setFileName(file.getName());
			 documentObject.setA0Size(A0);
			 documentObject.setA1Size(A1);
			 documentObject.setA2Size(A2);
			 documentObject.setA3Size(A3);
			 documentObject.setA4Size(A4);
			 documentObject.setPageCnt(reader.getNumberOfPages());
			 documentObject.setFilePath(file.getPath());
			 arrayListDocument.add(documentObject);
			 System.out.println("Completed File Name:"+file.getName());
			 reader.close();
			}

}

