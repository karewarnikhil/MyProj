package com.common.ClearImage;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import net.sourceforge.tess4j.ITesseract;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;
import net.sourceforge.tess4j.ITesseract.RenderedFormat;

public class PdfOcr extends JFrame implements ActionListener{
	
	
	 
	private static final long serialVersionUID = 1L;
	JFrame jf,jf1;
	JTextField t1,t2,t3,t4,t5,tr,tq;
	JLabel l1,l2,l3,l4,l5,l6;
	JButton b0,b1,b2;
	Font f;
	JProgressBar jProgressBar;
	JCheckBox checkbox1,checkbox2;
	JPanel jPanel;
  
	

	DefaultTableModel model = new DefaultTableModel();
    JTable tabGrid = new JTable(model);
    JScrollPane scrlPane = new JScrollPane(tabGrid);
    
    public  PdfOcr()
   	{
   		jf=new JFrame();
   		f = new Font("Times New Roman",Font.BOLD,20);
   		jf.setLayout(null);

   	    l6=new JLabel("PDF OCR");
   	    l6.setFont(new Font("Times New Roman",Font.BOLD,25));
   	    l6.setBounds(320,50,300,40);l6.setForeground(Color.blue);
   	    jf.add(l6);

   		l1= new JLabel("Folder Path :");
   		//l1.setFont(f);
   		l1.setBounds(150,120,130,25);
   	    jf.add(l1);

   		t1=new JTextField(20);
   		t1.setBounds(320,120,300,25);t1.setToolTipText("Enter Folder Path");
   		jf.add(t1);

   		l2= new JLabel("Select Language :");
		l2.setBounds(150,200,130,25);
	    jf.add(l2);
	    
		checkbox1 = new JCheckBox("English");    
        checkbox1.setBounds(320,200,300,25);    
        jf.add(checkbox1);
        
        checkbox2 = new JCheckBox("Marathi");    
        checkbox2.setBounds(320,230,300,25);
        jf.add(checkbox2);
        
        
   	    b0 = new JButton("Save",new ImageIcon("images//save.png"));
        b0.setBounds(150,300,110,35);
        b0.setToolTipText("click to save auto crop");
   		jf.add(b0);
   		b0.addActionListener(this);

   		b1 = new JButton("Clear",new ImageIcon("images//clear.png"));
   		b1.setBounds(300,300,110,35);
   		b1.setToolTipText("click to clear all textfilds");
   	    jf.add(b1); 
   	    b1.addActionListener(this);
   	    
   	    b2 = new JButton("Close",new ImageIcon("images//clear.png"));
   		b2.setBounds(450,300,110,35);
   		b2.setToolTipText("click to Close Window");
   	    jf.add(b2); 
   	    b2.addActionListener(this);
   	    
   	    jProgressBar = new JProgressBar(); 
   	    jProgressBar.setMinimum(10);
   	    jProgressBar.setStringPainted(true); 
   	    jProgressBar.setForeground(Color.BLUE);
   	    jProgressBar.setBounds(150,100,300,40);
   	    
   		/*
   		 * jf1 = new JFrame(); jf1.setLayout(null); jf1.setTitle("Progress Bar");
   		 * jf1.setSize(500,400); jf1.add(jProgressBar);
   		 * jf1.getContentPane().setBackground(Color.WHITE); jf1.add(l6);
   		 * jf1.setVisible(true);
   		 */
   	    
   	    
   	    jf.setTitle("PDF OCR");
   	    jf.setSize(900,500);
   		jf.setLocation(20,20);
   		jf.setResizable(false);
   	    jf.getContentPane().setBackground(Color.WHITE);
   		 //jf.setContentPane(new JLabel(new ImageIcon("E:\\HomeImages\\01.jpg")));
   	    jf.setVisible(true);
        
   	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		if(ae.getSource()==b0)
		 {
		 	    String fileIn = t1.getText();

		    	if((((t1.getText()).equals(""))))
		        {
		    		JOptionPane.showMessageDialog(this,"* Detail are Missing !","Warning!!!",JOptionPane.WARNING_MESSAGE);
		        }
				else
				{
				  try
				  	 {
					  File directory = new File(fileIn); //get all the files from a directory
					  File[] fList = directory.listFiles();
					  
					  System.out.println("Number of files in folders:"+fList.length);
					  try { 
					  Tesseract tesseract = new Tesseract(); 
					  tesseract.setDatapath("E:\\workspaceNikhil\\ClearImage\\src\\tessdata"); 
					  tesseract.setLanguage("mar");
					  
					  List<ITesseract.RenderedFormat> renderFormat = new ArrayList<>();
			          renderFormat.add(RenderedFormat.PDF);
					  
					   for (File file : fList)
					   {   
						   String fileName = file.getName().replaceFirst("[.][^.]+$", "");;
						   tesseract.doOCR(file); 
						   System.out.println(directory.getPath()+"/"+"OCR");  
						   tesseract.createDocuments(file.getPath(), directory.getPath()+"/"+fileName+"OCR" , renderFormat);   
					   }
					   } catch (TesseractException e) { 
				            e.printStackTrace(); 
				       } 
					   System.out.println("Total process completed successfully:");
					  
					 
					 int reply=JOptionPane.showConfirmDialog(null,"Pdf Ocr Operation Done Successfully.Do you want continue more?","Done Pdf Ocr",JOptionPane.YES_NO_OPTION);
		             if (reply == JOptionPane.YES_OPTION)
		   			{
		   		       jf.setVisible(false);
		   		       new PdfOcr();
		   		    }
		   		  else if (reply == JOptionPane.NO_OPTION)
		   			{
		   			  jf.setVisible(false);
			        }
		          }
	  catch(Exception e)
	  {
	    System.out.println(e);
	    JOptionPane.showMessageDialog(null,"Error:"+e);
	  }
	 }
	}
	  else if(ae.getSource()==b1)
	     {//clear
	          t1.setText("");
	      }
	    else if(ae.getSource()==b2)
	    {
	    	jf.setVisible(false);
		}
	 }
		

}
