package com.common.ClearImage;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Image;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfGState;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;

import ClearImageJNI.ICiImage;
import ClearImageJNI.ICiServer;

public class WaterMark extends JFrame implements ActionListener
{
	/**
	 * 
	 */
	protected static ICiServer Ci = null;
	protected static ICiImage ICiImage = null;
	protected static boolean useFullIo = true;
	public static final String SRCIMAGE = "E:/java Data/FolderMove/approved.jpg";
	public static final String RESULT = "E:/java Data/Tax Sangavi/New folder/watermarked.pdf";
	 
	private static final long serialVersionUID = 1L;
	JFrame jf,jf1;
	JTextField t1,t2,t3,t4,t5,tr,tq;
	JLabel l1,l2,l3,l4,l5,l6;
	JButton b0,b1,b2;
	Font f;
	JProgressBar jProgressBar;
	JPanel jPanel;
  
	

	DefaultTableModel model = new DefaultTableModel();
    JTable tabGrid = new JTable(model);
    JScrollPane scrlPane = new JScrollPane(tabGrid);

    public  WaterMark()
	{
		jf = new JFrame();
		f = new Font("Times New Roman",Font.BOLD,20);
		jf.setLayout(null);

	    l6 = new JLabel("WATER MARK");
	    l6.setFont(new Font("Times New Roman",Font.BOLD,25));
	    l6.setBounds(320,50,300,40);l6.setForeground(Color.blue);
	    jf.add(l6);

		l1 = new JLabel("File Path :");
		//l1.setFont(f);
		l1.setBounds(150,120,130,25);
	    jf.add(l1);

		t1 = new JTextField(20);
		t1.setBounds(320,120,300,25);t1.setToolTipText("Enter File Path");
		jf.add(t1);

		l2 = new JLabel("Font Size :");
		//l2.setFont(f);
        l2.setBounds(150,160,170,25);
		jf.add(l2);

		t2 = new JTextField(20);
		t2.setBounds(320,160,100,25);t2.setToolTipText("Enter Font Size For Text Font");
		jf.add(t2);

		l3 = new JLabel("Opacity Size :");
		//l3.setFont(f);
        l3.setBounds(150,200,170,25);
		jf.add(l3);

		t3 = new JTextField(20);
		t3.setBounds(320,200,100,25);t3.setToolTipText("Enter Opacity Size For Image");
		jf.add(t3);

		/*
		 * l4 = new JLabel("Top Size Crop :"); //l4.setFont(f);
		 * l4.setBounds(150,240,170,25); jf.add(l4);
		 * 
		 * t4 = new JTextField(20);
		 * t4.setBounds(320,240,100,25);t4.setToolTipText("Enter Top Size For Crop");
		 * jf.add(t4);
		 * 
		 * l5 = new JLabel("Bottom Size Crop :"); //l5.setFont(f);
		 * l5.setBounds(150,280,170,25); jf.add(l5);
		 * 
		 * t5 = new JTextField(20);
		 * t5.setBounds(320,280,100,25);t5.setToolTipText("Enter Bottom Size For Crop");
		 * jf.add(t5);
		 */

	    b0 = new JButton("Save",new ImageIcon("images//save.png"));
        b0.setBounds(150,330,110,35);b0.setToolTipText("click to save water mark");
		jf.add(b0);b0.addActionListener(this);

		b1 = new JButton("Clear",new ImageIcon("images//clear.png"));
		b1.setBounds(300,330,110,35);b1.setToolTipText("click to clear all textfilds");
	    jf.add(b1); b1.addActionListener(this);
	    
	    b2 = new JButton("Close",new ImageIcon("images//clear.png"));
		b2.setBounds(450,330,110,35);b2.setToolTipText("click to Close Window");
	    jf.add(b2); b2.addActionListener(this);
	    
	    jProgressBar = new JProgressBar(); 
	    jProgressBar.setMinimum(10);
	    jProgressBar.setStringPainted(true); 
	    jProgressBar.setForeground(Color.BLUE);
	    jProgressBar.setBounds(150,100,300,40);
	    
		/*
		 * jf1 = new JFrame(); jf1.setLayout(null); jf1.setTitle("Progress Bar");
		 * jf1.setSize(500,400); jf1.add(jProgressBar);
		 * jf1.getContentPane().setBackground(Color.WHITE); jf1.add(l6);
		 * jf1.setVisible(true);
		 */
	    
	    
	    jf.setTitle("WATER MARK");
	    jf.setSize(900,500);
		jf.setLocation(20,20);
		jf.setResizable(false);
	    jf.getContentPane().setBackground(Color.WHITE);
		 //jf.setContentPane(new JLabel(new ImageIcon("E:\\HomeImages\\01.jpg")));
	    jf.setVisible(true);
     
	}

public void actionPerformed(ActionEvent ae)
	{
	if(ae.getSource()==b0)
	 {
	 	    String fileIn = t1.getText();
	       	String fontSize = t2.getText();
	       	String opacitySize = t3.getText();
	       	//String topCrop = t4.getText();
	       	//String bottomCrop = t5.getText();

	    	if((((t1.getText()).equals("")) || (t2.getText()).equals(""))||((t3.getText()).equals("")))
	        {
		    JOptionPane.showMessageDialog(this,"* Detail are Missing !","Warning!!!",JOptionPane.WARNING_MESSAGE);
	        }
			else
			{
			  try
			  	 {
				  PdfReader reader = null;
				  try {
					    System.out.println(fileIn);
						reader = new PdfReader(fileIn);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
			        PdfStamper stamper = null;
					try {
						stamper = new PdfStamper(reader, new FileOutputStream(RESULT));
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (DocumentException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					
					  // text watermark
				 // Font fontOne = new Font(Font.FontFamily.HELVETICA, 20, Font.BOLD,BaseColor.RED);
					com.itextpdf.text.Font fontOne = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, Integer.parseInt(fontSize), Font.BOLD,BaseColor.RED);
					Phrase phrase = new Phrase("APPROVED DOCUMENT", fontOne);
			        // image watermark
			        Image img = null;
					try {
						img = Image.getInstance(SRCIMAGE);
					} catch (BadElementException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (MalformedURLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					 // properties
			        PdfContentByte over;
			        Rectangle pagesize;
			        float x, y;

			        // loop over every page
			        int n = reader.getNumberOfPages();
			        
			        for (int i = 1; i <= n; i++) {
			  		  
			  		  // get page size and position 
			  		  pagesize = reader.getPageSizeWithRotation(i); 
			  		  x = (pagesize.getLeft() + pagesize.getRight()) / 2; 
			  		  y = (pagesize.getTop() + pagesize.getBottom()) / 2;
			  		  over = stamper.getOverContent(i);
			  		  over.saveState();
			  		  
			  		  // set transparency 
			  		  PdfGState state = new PdfGState();
			  		  state.setFillOpacity(Float.parseFloat(opacitySize)); 
			  		  over.setGState(state);
			  		  
			  		  // add watermark text and image center of page
			  		  if (i % 2 == 1) {
			  			  //ColumnText.showTextAligned(over, Element.ALIGN_CENTER, phrase, x, y, 0); 
			  			  ColumnText.showTextAligned(over, Element.ALIGN_CENTER, phrase, x, y, 0);
			  		  } 
			  		  else {
			  			  try { 
			  				  	//over.addImage(img, w, 0, 0, h, x - (w / 2), y - (h / 2)); 
			  				  	over.addImage(img, 80, 0, 0, 100, 450,52); 
			  				  } catch (DocumentException ex) {
			  				  // TODO Auto-generated catch block
			  					  ex.printStackTrace(); 
			  				  } 
			  		  }
			  		  	over.restoreState(); 
			  		  }
			        
			        try {
						stamper.close();
					} catch (DocumentException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			        reader.close();
				  
				  
			     
				 int reply=JOptionPane.showConfirmDialog(null,"Water Mark Operation Done Successfully.Do you want continue more?","Done Water Mark",JOptionPane.YES_NO_OPTION);
	             if (reply == JOptionPane.YES_OPTION)
	   			{
	   		       jf.setVisible(false);
	   		       new WaterMark();
	   		    }
	   		  else if (reply == JOptionPane.NO_OPTION)
	   			{
	   			  jf.setVisible(false);
		        }
	          }
  catch(Exception e)
  {
    System.out.println(e);
    JOptionPane.showMessageDialog(null,"Error:"+e);
  }
 }
}
  else if(ae.getSource()==b1)
     {//clear
          t1.setText("");
          t2.setText("");
          t3.setText("");
          t4.setText("");
          t5.setText("");
      }
    else if(ae.getSource()==b2)
    {
    	jf.setVisible(false);
	}
 }
	/*
	 * public static void main(String args[]) { new AutoCrop(); }
	 */

}

