package com.common.ClearImage;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class MainMenu extends JFrame implements ActionListener
{   /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    JFrame jf;
	JMenuBar mbar;
	JMenu m1,m2,m3,m4;
	JMenuItem m1_1,m1_2,m1_3,m1_4,m1_5,m1_6,m1_7,m1_8,m1_9,m1_10,m2_1,m2_2,m2_3,m2_4,m2_5,m3_1,m3_2,m4_1,m5_1;
	JLabel l1,LogoColl;
	GridBagLayout gbl;
	

	public MainMenu()
	{
        jf=new JFrame();
     	gbl=new GridBagLayout();
		jf.setLayout(gbl);

		l1=new JLabel("WELCOME TO IMAGE QC MANAGEMENT SYSTEM");
		l1.setFont(new Font("Times New Roman",Font.BOLD,20));
		jf.add(l1);

		mbar = new JMenuBar();
		jf.setJMenuBar(mbar);

		m1=new JMenu("REPAIR");
		mbar.add(m1);
		m1_1 = new JMenuItem("Auto Crop",new ImageIcon("images//addnew.png"));
		m1.add(m1_1);
		m1_2 = new JMenuItem("Auto Deskew",new ImageIcon("images//search.png"));
		m1.add(m1_2);
		m1_3 = new JMenuItem("Auto Rotate",new ImageIcon("images//update.png"));
		m1.add(m1_3);
		m1_4 = new JMenuItem("Remove Halftone",new ImageIcon("images//delete.png"));
		m1.add(m1_4);
	    m1_5 = new JMenuItem("Remove Punch Holes",new ImageIcon("images//all.png"));
		m1.add(m1_5);
		m1_6 = new JMenuItem("Clean Borders",new ImageIcon("images//all.png"));
			m1.add(m1_6);
		m1_7 = new JMenuItem("Smooth Characters",new ImageIcon("images//all.png"));
			m1.add(m1_7);
		m1_8 = new JMenuItem("Remove Backgrounds",new ImageIcon("images//all.png"));
			m1.add(m1_8);
		m1_9 = new JMenuItem("Remove Lines",new ImageIcon("images//all.png"));
			m1.add(m1_9);
		m1_10 = new JMenuItem("Clean Noise",new ImageIcon("images//all.png"));
			m1.add(m1_10);

	
		m2=new JMenu("MISCELLANEOUS");
		mbar.add(m2);
		m2_1 = new JMenuItem("MIX OPERATION",new ImageIcon("images//exit.png"));
		m2.add(m2_1);
		m2_2 = new JMenuItem("PAGE COUNT",new ImageIcon("images//exit.png"));
		m2.add(m2_2);
		
		m3=new JMenu("TOOL");
		mbar.add(m3);
		m3_1 = new JMenuItem("Skew Image",new ImageIcon("images//exit.png"));
		m3.add(m3_1);
		
		m4=new JMenu("EXIT");
		mbar.add(m4);
		m4_1 = new JMenuItem("Exit",new ImageIcon("images//exit.png"));
		m4.add(m4_1);

        m1_1.addActionListener(this);
		m1_2.addActionListener(this);
		m1_3.addActionListener(this);
		m1_4.addActionListener(this);
    	m1_5.addActionListener(this);
    	m1_6.addActionListener(this);
    	m1_7.addActionListener(this);
    	m1_8.addActionListener(this);
    	m1_9.addActionListener(this);
    	m1_10.addActionListener(this);

		m2_1.addActionListener(this);
		m2_2.addActionListener(this);
		
		m3_1.addActionListener(this);
		m4_1.addActionListener(this);
		
		jf.setTitle("Main Menu");
		jf.setLocation(20,20);
	    jf.setSize(900,500);
	    jf.setResizable(false);
	    //jf.getContentPane().setBackground(Color.WHITE);
	    jf.setContentPane(new JLabel(new ImageIcon("src//Untitled.jpg")));
		jf.setVisible(true);

	}

	public void actionPerformed(ActionEvent ae)
	{

	    if(ae.getSource()==m1_1)
		{
		  new AutoCrop();
		}
		else if(ae.getSource()==m1_2) 
		{ 
			new AutoDeskew(); 
		} 
		else if(ae.getSource()==m1_3) 
		{ 
			new AutoRotate(); 
		} 
		else if(ae.getSource()==m1_4)
		 {
			new RemoveHalfTone(); 
		 } 
		else if(ae.getSource()==m1_5)
		{ 
			new RemovePuncHoles();
		}
		else if(ae.getSource()==m1_6) 
		{ 
			new CleanBorders(); 
		} 
		else if(ae.getSource()==m1_7)
		{ 
			new SmoothCharacters();
		} 
		else if(ae.getSource()==m1_8)
		{ 
			new RemoveBackground(); 
		} 
		else if(ae.getSource()==m1_9)
		{ 
			new RemoveLines(); 
		} 
		else if(ae.getSource()==m1_10)
		{ 
			new CleanNoise();
		} 
		 
		else if(ae.getSource()==m2_1)
		{
		  new CombineOperation();
		}
	    
		else if(ae.getSource()==m2_2)
		{
		  new PageCount();
		}
	    
		else if(ae.getSource()==m3_1)
		{
		 
		}
	    
		else if(ae.getSource()==m4_1)
		{
		  System.exit(0);
		}


  }

}
