package com.common.ClearImage;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class ReportTable extends JFrame implements ActionListener{

	private static final long serialVersionUID = 1L;
	
	JFrame jf;
	JTable  jtable;
	JTextField t1,t2,t3,t4,t5,tr,tq;
	JLabel l1,l2,l3,l4,l5,l6;
	JButton b0,b1,b2,export;
	Font f;
	JScrollPane jScrollPane;
	
	public ArrayList<DocumentObject> arrayListDocument;
	File directory;
	
	public ReportTable(ArrayList<DocumentObject> arrayListDocument,File directory) {
		this.arrayListDocument = arrayListDocument;
		this.directory = directory;
		
		jf=new JFrame();
		//f = new Font("Times New Roman",Font.BOLD,20);
		//jf.setLayout(null);

		/*
		 * l6=new JLabel("Digitization Report"); l6.setFont(new
		 * Font("Times New Roman",Font.BOLD,25));
		 * l6.setBounds(320,50,300,40);l6.setForeground(Color.blue); jf.add(l6);
		 */
	    
	    jtable = new JTable(); 
		DefaultTableModel defaultTableModel = (DefaultTableModel) jtable.getModel();
		defaultTableModel.addColumn("Sr.No");
		defaultTableModel.addColumn("File Name");
		defaultTableModel.addColumn("Page Count");
		defaultTableModel.addColumn("A4 Size");
		defaultTableModel.addColumn("A3 Size");
		defaultTableModel.addColumn("A2 Size");
		defaultTableModel.addColumn("A1 Size");
		defaultTableModel.addColumn("A0 Size");
		defaultTableModel.addColumn("File Path");
		
		  Object rowData[] = new Object[9]; 
		  for(int i = 0; i < arrayListDocument.size(); i++) { 
			  rowData[0] =  i+1;
			  rowData[1] =  arrayListDocument.get(i).getFileName();
			  rowData[2] =  arrayListDocument.get(i).getPageCnt();
			  rowData[3] =  arrayListDocument.get(i).getA4Size();
			  rowData[4] =  arrayListDocument.get(i).getA3Size();
			  rowData[5] =  arrayListDocument.get(i).getA2Size();
			  rowData[6] =  arrayListDocument.get(i).getA1Size();
			  rowData[7] =  arrayListDocument.get(i).getA0Size();
			  rowData[8] = directory.getPath();
			  defaultTableModel.addRow(rowData);
		  }
		  
		  JScrollPane sp = new JScrollPane(jtable); 
		//  sp.setBounds(10,10,10,10); 
		  export = new JButton("Export");
		  export.addActionListener(this);
	    // jf1.add(sp); 
		  jf.setSize(600,500);    
		  jf.setVisible(true);  
		  jf.getContentPane().add("Center", sp);
		  jf.getContentPane().add("South", export);
		 // jf.pack();
		  jf.setVisible(true);
		  jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}
	
	
	@Override
	public void actionPerformed(ActionEvent ae) {
		
		if(ae.getSource()==export)
		 {
			 try {
					exportTable(jtable, new File(directory.getPath()+"\\digitizationReport.xls"));
					 int reply=JOptionPane.showConfirmDialog(null,"Export Report Operation Done Successfully.Do you want colse report?","Done Report",JOptionPane.YES_NO_OPTION);
		             if (reply == JOptionPane.YES_OPTION)
		   			{
		            	 jf.setVisible(false);
		   		    }
		   		  else if (reply == JOptionPane.NO_OPTION)
		   			{
		   			    jf.setVisible(false);
		   		        new ReportTable(arrayListDocument, directory);
			        }
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		 }
	}
	
	public void exportTable(JTable table, File file) throws IOException {
	    TableModel model = table.getModel();
	    FileWriter out = new FileWriter(file);
	    for(int i=0; i < model.getColumnCount(); i++) {
	    	out.write(model.getColumnName(i) + "\t");
	    }
	    out.write("\n");

	    for(int i=0; i< model.getRowCount(); i++) {
		for(int j=0; j < model.getColumnCount(); j++) {
		    out.write(model.getValueAt(i,j).toString()+"\t");
		    }
		    out.write("\n");
		}
	    out.close();
	System.out.println("write out to: " + file);
	}

}
