package com.common.Controllers;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.common.Dao.BranchDao;
import com.common.Dao.CompartmentDao;
import com.common.Dao.RackDao;
import com.common.Dao.ShelfDao;
import com.common.Objects.CompartmentObject;
import com.common.Objects.ShelfObject;
import com.common.Objects.UsersObject;



@Controller
public class CompartmentController {
	
	@Autowired
	CompartmentDao compartmentDao;
	
	@Autowired
	BranchDao branchDao;
	
	@Autowired
	RackDao rackDao;
	
	@Autowired
	ShelfDao shelfDao;
	
	@RequestMapping(value = "/manageCompartment", method = RequestMethod.GET)
	public ModelAndView manageCompartment(Model model,HttpServletRequest request) {
		  UsersObject usersObject = (UsersObject) request.getSession().getAttribute("users");
		  if (usersObject != null) { 
				 List<CompartmentObject> compartmentList = compartmentDao.getAllCompartments();
				 HashMap<Integer,String> hashmapOfRack = rackDao.getHashMapOfRack();
				 HashMap<Integer,String> hashmapOfShelf = shelfDao.getHashMapOfShelf();
				 model.addAttribute("hashmapOfRack", hashmapOfRack);
				 model.addAttribute("hashmapOfShelf", hashmapOfShelf);
				 return new ModelAndView("manageCompartment","compartmentList",compartmentList);  
		  }
		  else {
			   return new ModelAndView("loginIn");  
		  }
	}
	
	@RequestMapping(value = "/registerCompartment", method = RequestMethod.GET)
	   public String registerCompartment(Model model,HttpServletRequest request){  
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
		       model.addAttribute("compart",  new CompartmentObject());
		       return "registerCompartment"; 
		   }else {
			   return "loginIn"; 
		   }
	   } 
	
	@RequestMapping(value = "/saveCompartment", method = RequestMethod.POST)
	public String saveList(@ModelAttribute("compart") CompartmentObject compartmentObject, Model model, HttpServletRequest request) {
		UsersObject usersObject = (UsersObject) request.getSession().getAttribute("users");
		if (usersObject != null) {
			 CompartmentObject compartmentObjectOne = compartmentDao.getShelfByBRSId(compartmentObject.getBranchId(),compartmentObject.getRackId(),compartmentObject.getShelfId(),compartmentObject.getCompNo());
				if(compartmentObjectOne != null && compartmentObject.getCompNo().equals(compartmentObjectOne.getCompNo())) {
					model.addAttribute("error", "Compartment Number already exists.");
					model.addAttribute("compart", new CompartmentObject());
					return "registerCompartment";
				}else {
					compartmentDao.saveCompartment(compartmentObject);
					HashMap<Integer,String> hashmapOfRack = rackDao.getHashMapOfRack();
					HashMap<Integer,String> hashmapOfShelf = shelfDao.getHashMapOfShelf();
					model.addAttribute("hashmapOfRack", hashmapOfRack);
					model.addAttribute("hashmapOfShelf", hashmapOfShelf);
					model.addAttribute("message", "Compartment Number added successfully.");
					model.addAttribute("compartmentList", compartmentDao.getAllCompartments());
					return "manageCompartment";
				}
		}else {
			return "loginIn";
		}
		
	}
	
	@RequestMapping(value="/editCompartment", method = RequestMethod.GET)  
	   public ModelAndView editCompartment(@RequestParam("compartId") Integer compartId,HttpServletRequest request){  
		   HttpSession session = request.getSession();
		   request.setAttribute("compartId", compartId);
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
			   CompartmentObject compartmentObject = findByCompartId(compartId);
		       return new ModelAndView("editCompartment","compart",compartmentObject);  
		   }else {
			   return new ModelAndView("loginIn"); 
		   }
	   }  
	
	@RequestMapping(value = "/updateCompartment", method = RequestMethod.POST)
	   public String updateCompartment(@ModelAttribute("compart") CompartmentObject compartmentObject, BindingResult result,Model model,HttpServletRequest request){
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
			   CompartmentObject compartmentObjectOne = compartmentDao.getShelfByBRSId(compartmentObject.getBranchId(),compartmentObject.getRackId(),compartmentObject.getShelfId(),compartmentObject.getCompNo());				
			   if(compartmentObjectOne != null && compartmentObjectOne.getCompartId() != compartmentObject.getCompartId() && compartmentObject.getCompNo().equals(compartmentObject.getCompNo())) {
					model.addAttribute("error", "Compartment Number already exists.");
					model.addAttribute("compart",compartmentObject);
					return "editCompartment";
				}else {
					compartmentDao.saveCompartment(compartmentObject);
					model.addAttribute("message", "Compartment Updated Successfully.");
					model.addAttribute("compart",compartmentObject);
					return "editCompartment";
				}
		   }else {
			   return "loginIn"; 
		   }
	   }  
	
	 private CompartmentObject findByCompartId(Integer compartId) {
		   CompartmentObject compartmentObject =  compartmentDao.getCompartmentById(compartId); 
		   return compartmentObject;
	   }
	 
	 @RequestMapping(value = "/getCompartDropDown", method = RequestMethod.GET, produces = "application/json")
		public @ResponseBody List<CompartmentObject> getCompartDropDown(@RequestParam("shelfId") long shelfId) {
		    List<CompartmentObject> compartList = compartmentDao.getCompartDropDown(shelfId);
			return compartList;
		}
	
}
