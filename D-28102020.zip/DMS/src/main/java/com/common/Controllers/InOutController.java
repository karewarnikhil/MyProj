package com.common.Controllers;

import java.sql.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.common.Dao.BranchDao;
import com.common.Dao.DocumentDao;
import com.common.Dao.InOutDao;
import com.common.Objects.DocumentObject;
import com.common.Objects.FileInOutTransObject;
import com.common.Objects.ReportSearchObject;
import com.common.Objects.UsersObject;

@Controller
public class InOutController {
	
	@Autowired
	InOutDao inOutDao;
	
	@Autowired
	BranchDao branchDao;
	
	@Autowired
	DocumentDao documentDao;

	@RequestMapping(value = "/inwardOutward", method = RequestMethod.GET)
    public String reportForm(Model model,HttpServletRequest request) {
	   HttpSession session = request.getSession();
	   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
	   if(usersSessionObject != null) {
		   model.addAttribute("reportSearch",  new ReportSearchObject());
	       return "inOutFiles"; 
	   }else {
		   return "loginIn"; 
	   }
   }
	
	
   @RequestMapping(value = "/searchFile", method = RequestMethod.POST)
   public ModelAndView searchFile(@ModelAttribute("reportSearch")ReportSearchObject reportSearchObject,HttpServletRequest request,Model model) {
	   HttpSession session = request.getSession();
	   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
	   if(usersSessionObject != null) {
		   List<DocumentObject> documentlist = inOutDao.getFilesWithFileNm(reportSearchObject);
		   if(documentlist.size() == 0)
		   model.addAttribute("error", "No record found in search.");
		   model.addAttribute("reportSearch", reportSearchObject);
		   return new ModelAndView("inOutFiles","documentlist", documentlist); 
	   }else {
		   return new ModelAndView("loginIn"); 
	   }
   }
   
   @RequestMapping(value = "/fileInOutTrans", method = RequestMethod.GET)
   public String fileInOutTrans(Model model,@RequestParam("fileId") long fileId,@RequestParam("seqNo") long seqNo,HttpServletRequest request){  
	   HttpSession session = request.getSession();
	   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
	   if(usersSessionObject != null) {
		   DocumentObject documentObject = documentDao.getFileByFileIdAndSeqNo(fileId, seqNo);
		   FileInOutTransObject fileInOutTemp = inOutDao.getFilesWithFileId(fileId);
		  //List<BranchObject> branchList = branchDao.getBranchList();
		   model.addAttribute("documentObject", documentObject);
		   //model.addAttribute("branchList", branchList);
		   //System.out.println("Transaction Type===="+fileInOutTemp.getTxnType());
		   if(fileInOutTemp != null)
			   model.addAttribute("fileInOutTemp", fileInOutTemp);
		   else
			   model.addAttribute("fileInOutTemp", new FileInOutTransObject());
		   model.addAttribute("fileInOut", new FileInOutTransObject());
	       return "fileInOutTrans"; 
	   }else {
		   return "loginIn"; 
	   }
   } 
   
   @RequestMapping(value = "/saveFileInOutTrans", method = RequestMethod.POST)
   public String saveFileInOutTrans(@ModelAttribute("fileInOutTrans") FileInOutTransObject fileInOutTransObject, Model model,HttpServletRequest request){
	   HttpSession session = request.getSession();
	   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
	   if(usersSessionObject != null) {
		  // String rackFileNo = (String) request.getAttribute("rackFile");
		   System.out.println(fileInOutTransObject.getRackFileNo());
		   if(fileInOutTransObject.getTxnType().equals("IN")) {
		   FileInOutTransObject fileInOutTemp = inOutDao.getTransactionWithRackFileNo(fileInOutTransObject.getRackFileNo());
		   if(fileInOutTemp.getRackFileNo() != null && (fileInOutTransObject.getRackFileNo().equals(fileInOutTemp.getRackFileNo()) && fileInOutTemp.getTxnType().equals("IN"))) {
			   DocumentObject documentObject = documentDao.getFileByFileIdAndSeqNo(fileInOutTransObject.getFileId(), fileInOutTransObject.getSeqNo());
			   model.addAttribute("documentObject", documentObject);
			   FileInOutTransObject fileInOutTempOne = inOutDao.getFilesWithFileId(fileInOutTransObject.getFileId());
			   if(fileInOutTemp != null) {
				   model.addAttribute("fileInOutTemp", fileInOutTempOne);
			   }
			   else{
				   model.addAttribute("fileInOutTemp", new FileInOutTransObject());
			   }
			   model.addAttribute("fileInOut", new FileInOutTransObject());
			   model.addAttribute("error", "Rack file no already exists.");
			   return "fileInOutTrans"; 
		   }else {
			   if(fileInOutTransObject.getReturnDtStr() != null)  {
				   fileInOutTransObject.setReturnDt(Date.valueOf(fileInOutTransObject.getReturnDtStr()));
			   }
			   fileInOutTransObject.setUserId(usersSessionObject.getUserId());
			   inOutDao.saveTransaction(fileInOutTransObject);
			   return "redirect:/transactionDetails";
		   }
		   }else {
			   if(fileInOutTransObject.getReturnDtStr() != null)  {
				   fileInOutTransObject.setReturnDt(Date.valueOf(fileInOutTransObject.getReturnDtStr()));
			   }
			   fileInOutTransObject.setUserId(usersSessionObject.getUserId());
			   inOutDao.saveTransaction(fileInOutTransObject);
			   return "redirect:/transactionDetails";
		   }
	   }else {
		   return "loginIn"; 
	   }
	
   }  
   
   @RequestMapping(value="/transactionDetails", method = RequestMethod.GET)  
   public ModelAndView transactionDetails(Model model,HttpServletRequest request) {  
	   HttpSession session = request.getSession();
	   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
	   if(usersSessionObject != null) {
	   List<FileInOutTransObject> inOutList = inOutDao.getAllTransactionDetails();
       return new ModelAndView("transactionDetails","inOutList",inOutList);  
   }  else {
	   return new ModelAndView("loginIn");  
   }
   }
}
