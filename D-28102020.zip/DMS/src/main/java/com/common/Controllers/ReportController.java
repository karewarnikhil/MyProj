package com.common.Controllers;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.common.Dao.DepartmentDao;
import com.common.Dao.DocumentDao;
import com.common.Dao.ReportDao;
import com.common.Dao.SubDepartmentDao;
import com.common.Dao.TagDao;
import com.common.Objects.DepartmentReport;
import com.common.Objects.DocumentObject;
import com.common.Objects.ReportSearchObject;
import com.common.Objects.SubDepartmentObject;
import com.common.Objects.TagReportObject;
import com.common.Objects.UsersObject;
import com.common.Utilities.ExcelDeptReportView;
import com.common.Utilities.GeneralUtility;
import com.common.Utilities.PdfDeptReportView;

@Controller
public class ReportController {
	
	@Autowired
	DepartmentDao departmentDao;
	
	@Autowired
	SubDepartmentDao subDepartmentDao;
	
	@Autowired
    DocumentDao documentDao;
	
	@Autowired
    ReportDao reportDao;
	
	@Autowired
    TagDao tagDao;
	
	@Autowired
	ServletContext context;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	   public String login() {
	       return "loginIn";
	}
	
	/*
	 * @RequestMapping(value = "/departmetWiseReport", method = RequestMethod.GET)
	 * public String departmetWiseReport(Model model,HttpServletRequest request){
	 * 
	 * List<DepartmentObject> departmentList = departmentDao.getAllDepartments();
	 * model.addAttribute("departmentList", departmentList); return
	 * "departmentWiseReport";
	 * 
	 * }
	 */
	  
	  @RequestMapping(value = "/departmetWiseReport", method = RequestMethod.GET)
	    public String reportForm(Model model,HttpServletRequest request) {
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
			   request.getSession().removeAttribute("documentlist");
			   request.getSession().removeAttribute("reportSearchObject");
		       model.addAttribute("reportSearch",  new ReportSearchObject());
		       return "digitizationReport"; 
		   }else {
			   return "loginIn"; 
		   }
	   }
	  
	  
	  @RequestMapping(value = "/searchReportView", method = RequestMethod.GET)
	    public String searchReportView(Model model,HttpServletRequest request) {
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
			   model.addAttribute("reportSearch",  new ReportSearchObject());
		       return "digitizationReport"; 
		   }else {
			   return "loginIn"; 
		   }
	   }
	  
	  @RequestMapping(value = "/tagReport", method = RequestMethod.GET)
	    public String tagReportForm(Model model,HttpServletRequest request) {
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
		       model.addAttribute("reportSearch",  new ReportSearchObject());
		       return "tagReport"; 
		   }else {
			   return "loginIn"; 
		   }
	   }
	  
	  @RequestMapping(value = "/summaryReport", method = RequestMethod.GET)
	    public String summaryReport(Model model,HttpServletRequest request) {
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
			   request.getSession().removeAttribute("departmentReportList");
		       model.addAttribute("reportSearch",  new ReportSearchObject());
		       return "summaryReport"; 
		   }else {
			   return "loginIn"; 
		   }
	   }
	  
	  @RequestMapping(value = "/subDepartmetWiseReport", method = RequestMethod.GET)
	    public String subDepartmetWiseReport(Model model,HttpServletRequest request) {
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
			   request.getSession().removeAttribute("departmentReportList");
		       model.addAttribute("reportSearch",  new ReportSearchObject());
		       return "subDepartmentReport"; 
		   }else {
			   return "loginIn"; 
		   }
	   }
	  
	  @RequestMapping(value = "/searchReport", method = RequestMethod.POST)
	    public ModelAndView searchReport(@ModelAttribute("reportSearch")ReportSearchObject reportSearchObject,HttpServletRequest request,Model model) {
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
			      SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
				  
				  System.out.println(simpleDateFormat.format(reportSearchObject.getCreationFromTs()));
				 // System.out.println(simpleDateFormat.format(reportSearchObject.getCreationToTs()));
				  
				  //reportSearchObject.getCreationToTs().setHours(23);
				  //reportSearchObject.getCreationFromTs().setMonth(59);
				  //reportSearchObject.getCreationFromTs().setSeconds(59);
				  
				//  System.out.println(simpleDateFormat.format(reportSearchObject.getCreationToTs()));
				 
				  reportSearchObject.setCreationFromDt(simpleDateFormat.format(reportSearchObject.getCreationFromTs()));
				  if(reportSearchObject.getCreationToTs() != null) {
					  Calendar calendar = GeneralUtility.getEndOfDay(reportSearchObject.getCreationToTs());
					  reportSearchObject.setCreationToTs(calendar.getTime());
					  reportSearchObject.setCreationToDt(simpleDateFormat.format(reportSearchObject.getCreationToTs()));
				  }
				  
			   System.out.println(reportSearchObject.getCreationFromTs());
			   request.getSession().removeAttribute("reportSearchObject");
			   List<DocumentObject> documentlist = reportDao.departmentWiseDigitizationReports(reportSearchObject);
			   //System.out.println(documentlist.size());
			   if(documentlist.size() == 0)
				   model.addAttribute("error", "No record found in search.");
			   model.addAttribute("reportSearch", reportSearchObject);
			   request.getSession().setAttribute("documentlist", documentlist);
			   request.getSession().setAttribute("reportSearchObject", reportSearchObject);
			   return new ModelAndView("digitizationReport","documentlist", documentlist); 
		   }else {
			   return new ModelAndView("loginIn"); 
		   }
	   }
	  @RequestMapping(value = "/searchSummaryReport", method = RequestMethod.POST)
	    public ModelAndView searchSummaryReport(@ModelAttribute("reportSearch")ReportSearchObject reportSearchObject,HttpServletRequest request,Model model) {
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
			
			  SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
			  
			  System.out.println(simpleDateFormat.format(reportSearchObject.getCreationFromTs()));
			  //System.out.println(simpleDateFormat.format(reportSearchObject.getCreationToTs()));
			  
			 
			  reportSearchObject.setCreationFromDt(simpleDateFormat.format(reportSearchObject.getCreationFromTs()));
			  if(reportSearchObject.getCreationToTs() != null) {
				  Calendar calendar = GeneralUtility.getEndOfDay(reportSearchObject.getCreationToTs());
				  reportSearchObject.setCreationToTs(calendar.getTime());
				  reportSearchObject.setCreationToDt(simpleDateFormat.format(reportSearchObject.getCreationToTs()));
			  }
			   System.out.println(reportSearchObject.getCreationFromTs());
			   List<DepartmentReport> departmentReportList = reportDao.getDepartmentWiseSummaryReport(reportSearchObject);
			   if(departmentReportList.size() == 0)
				   model.addAttribute("error", "No record found in search.");
			   model.addAttribute("reportSearch", reportSearchObject);
			   request.getSession().setAttribute("reportSearchObject", reportSearchObject);
			   request.getSession().setAttribute("departmentReportList", departmentReportList);
			   return new ModelAndView("summaryReport","departmentReportList", departmentReportList); 
		   }else {
			   return new ModelAndView("loginIn"); 
		   }
	   }
	  
	  @RequestMapping(value = "/searchSubSummaryReport", method = RequestMethod.POST)
	    public ModelAndView searchSubSummaryReport(@ModelAttribute("reportSearch")ReportSearchObject reportSearchObject,HttpServletRequest request,Model model) {
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
			
			  SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
			  
			  System.out.println(simpleDateFormat.format(reportSearchObject.getCreationFromTs()));
			  //System.out.println(simpleDateFormat.format(reportSearchObject.getCreationToTs()));
			  
			 
			  reportSearchObject.setCreationFromDt(simpleDateFormat.format(reportSearchObject.getCreationFromTs()));
			  if(reportSearchObject.getCreationToTs() != null) {
				  Calendar calendar = GeneralUtility.getEndOfDay(reportSearchObject.getCreationToTs());
				  reportSearchObject.setCreationToTs(calendar.getTime());
				  reportSearchObject.setCreationToDt(simpleDateFormat.format(reportSearchObject.getCreationToTs()));
			  }
			   System.out.println(reportSearchObject.getCreationFromTs());
			   SubDepartmentObject subDepartmentObject = subDepartmentDao.getSubDepartmentById(reportSearchObject.getSubDeptId());
			   List<DepartmentReport> departmentReportList = reportDao.getSubDepartmentWiseSummaryReport(reportSearchObject,subDepartmentObject.getSubDeptNm());
			   List<SubDepartmentObject> subDepartmentList = subDepartmentDao.getClassByDeptAndROP(reportSearchObject.getDeptId());
			   if(departmentReportList.size() == 0)
				   model.addAttribute("error", "No record found in search.");
			   model.addAttribute("reportSearch", reportSearchObject);
			   model.addAttribute("subDepartmentList", subDepartmentList);
			   model.addAttribute("subDeptId", reportSearchObject.getSubDeptId());
			   request.getSession().setAttribute("reportSearchObject", reportSearchObject);
			   request.getSession().setAttribute("departmentReportList", departmentReportList);
			   return new ModelAndView("subDepartmentReport","departmentReportList", departmentReportList); 
		   }else {
			   return new ModelAndView("loginIn"); 
		   }
	   }

	  
	  @RequestMapping(value = "/searchTagReport", method = RequestMethod.POST)
	    public ModelAndView searchTagReport(@ModelAttribute("reportSearch")ReportSearchObject reportSearchObject,HttpServletRequest request,Model model) {
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
			   HashMap<Long,String> hashMapOfTagObj = tagDao.getHashmapofTagObject(reportSearchObject.getTagGrpId());
			   List<TagReportObject> tagReportList = tagDao.getTagReport(reportSearchObject,hashMapOfTagObj);
			   if(tagReportList.size() == 0)
				   model.addAttribute("error", "No record found in search.");
			   model.addAttribute("hashMapOfTagObj", hashMapOfTagObj);
			   return new ModelAndView("tagReport","tagReportList", tagReportList); 
		   }else {
			   return new ModelAndView("loginIn"); 
		   }
	   }
	  
	  
	  @RequestMapping(value="/exportReport", method = RequestMethod.GET)  
	   public ModelAndView exportReport(Model model,HttpServletRequest request,@RequestParam("export") String export) {  
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		    if(usersSessionObject != null) {
			 //  List<DocumentObject> documentlist = reportDao.departmentWiseDigitizationReports(reportSearchObject);
			     List<DocumentObject> documentlist = (List<DocumentObject>) session.getAttribute("documentlist");
			     ReportSearchObject reportSearchObject =  (ReportSearchObject) session.getAttribute("reportSearchObject");
			ModelAndView modelAndView;     
		    if(export.equals("pdf")) {
		    	modelAndView = new ModelAndView(new PdfDeptReportView());
		    	modelAndView.addObject("documentlist",documentlist);
		    	modelAndView.addObject("imagePath", context.getRealPath("/")+"\\resources\\images\\Official_Logo_of_PCMC.jpeg");
		    	modelAndView.addObject("reportSearchObject",reportSearchObject);
		    	return modelAndView; 
		    }
		    	 
		   else {
			    modelAndView = new ModelAndView (new ExcelDeptReportView());
		    	modelAndView.addObject("documentlist",documentlist);
		    	modelAndView.addObject("imagePath", context.getRealPath("/")+"\\resources\\images\\Official_Logo_of_PCMC.jpeg");
		    	modelAndView.addObject("reportSearchObject",reportSearchObject);
		    	return modelAndView; 
		   }
			  // return new ModelAndView(new PdfDeptReportView(),"documentlist",documentlist);  
	   }  else {
		   return new ModelAndView("loginIn");  
	   }
	   }
	  
	  @RequestMapping(value="/exportSummaryReport", method = RequestMethod.GET)  
	   public ModelAndView exportSummaryReport(Model model,HttpServletRequest request,@RequestParam("export") String export) {  
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   ReportSearchObject reportSearchObject =  (ReportSearchObject) session.getAttribute("reportSearchObject");
		   if(usersSessionObject != null) {
			 //  List<DocumentObject> documentlist = reportDao.departmentWiseDigitizationReports(reportSearchObject);
			     List<DepartmentReport> departmentReportList = (List<DepartmentReport>) session.getAttribute("departmentReportList");
			     ModelAndView modelAndView;     
		    if(export.equals("pdf")) {
		    	modelAndView = new ModelAndView(new PdfDeptReportView());
	    	    modelAndView.addObject("departmentReportList",departmentReportList);
	    	    modelAndView.addObject("imagePath", context.getRealPath("/")+"\\resources\\images\\Official_Logo_of_PCMC.jpeg");
	    	    modelAndView.addObject("reportSearchObject",reportSearchObject);
	    	    return modelAndView;  
		    }
		   else {
			   modelAndView = new ModelAndView (new ExcelDeptReportView());
	    	   modelAndView.addObject("departmentReportList",departmentReportList);
	    	   modelAndView.addObject("imagePath", context.getRealPath("/")+"\\resources\\images\\Official_Logo_of_PCMC.jpeg");
	    	   modelAndView.addObject("reportSearchObject",reportSearchObject);
	    	   return modelAndView; 
			  // return new ModelAndView(new PdfDeptReportView(),"documentlist",documentlist);  
		   }
	   }  else {
		   return new ModelAndView("loginIn");  
	   }
	   }
	  
	  @RequestMapping(value="/exportSubSummaryReport", method = RequestMethod.GET)  
	   public ModelAndView exportSubSummaryReport(Model model,HttpServletRequest request,@RequestParam("export") String export) {  
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   ReportSearchObject reportSearchObject =  (ReportSearchObject) session.getAttribute("reportSearchObject");
		   
		   if(usersSessionObject != null) {
			 //  List<DocumentObject> documentlist = reportDao.departmentWiseDigitizationReports(reportSearchObject);
			     List<DepartmentReport> departmentReportList = (List<DepartmentReport>) session.getAttribute("departmentReportList");
			     ModelAndView modelAndView;     
		    if(export.equals("pdf")) {
		    	modelAndView = new ModelAndView(new PdfDeptReportView());
	    	    modelAndView.addObject("departmentReportList",departmentReportList);
	    	    modelAndView.addObject("imagePath", context.getRealPath("/")+"\\resources\\images\\Official_Logo_of_PCMC.jpeg");
	    	    modelAndView.addObject("reportSearchObject",reportSearchObject);
	    	   // modelAndView.addObject("subDeptNm",subDepartmentObject.getSubDeptNm());
	    	    return modelAndView;  
		    }
		   else {
			   modelAndView = new ModelAndView (new ExcelDeptReportView());
	    	   modelAndView.addObject("departmentReportList",departmentReportList);
	    	   modelAndView.addObject("imagePath", context.getRealPath("/")+"\\resources\\images\\Official_Logo_of_PCMC.jpeg");
	    	   modelAndView.addObject("reportSearchObject",reportSearchObject);
	    	  // modelAndView.addObject("subDeptNm",subDepartmentObject.getSubDeptNm());
	    	   return modelAndView; 
			  // return new ModelAndView(new PdfDeptReportView(),"documentlist",documentlist);  
		   }
	   }  else {
		   return new ModelAndView("loginIn");  
	   }
	   }
	  
	  
	/*
	 * @RequestMapping(value="/departmentReport", method = RequestMethod.GET) public
	 * ModelAndView departmentReport(Model model,HttpServletRequest request) {
	 * HttpSession session = request.getSession(); UsersObject usersSessionObject =
	 * (UsersObject) session.getAttribute("users"); if(usersSessionObject != null) {
	 * List<DepartmentObject> departmentlist = departmentDao.getAllDepartments();
	 * model.addAttribute("departmentlist", departmentlist); return new
	 * ModelAndView(new ReportView(),"departmentlist",departmentlist); } else {
	 * return new ModelAndView("loginIn"); } }
	 */


	/*
	 * @Override protected ModelAndView handleRequestInternal(HttpServletRequest
	 * request, HttpServletResponse response)throws Exception { String output =
	 * ServletRequestUtils.getStringParameter(request, "output");
	 * 
	 * List<DepartmentObject> departmentObjectList =
	 * departmentDao.getAllDepartments();
	 * 
	 * if(output ==null || "".equals(output)){ //return normal view return new
	 * ModelAndView("DepartmentSummary","departmentObjectList",departmentObjectList)
	 * ;
	 * 
	 * }else if("PDF".equals(output.toUpperCase())){ //return excel view return new
	 * ModelAndView("PdfDepartmentSummary","departmentObjectList",
	 * departmentObjectList);
	 * 
	 * }else{ //return normal view return new
	 * ModelAndView("DepartmentSummary","departmentObjectList",departmentObjectList)
	 * ;
	 * 
	 * } }
	 */
	
	
	/*
	 * @InitBinder public void initBinder(WebDataBinder binder) { SimpleDateFormat
	 * dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	 * dateFormat.setLenient(false); binder.registerCustomEditor(Date.class, new
	 * CustomDateEditor(dateFormat,false)); }
	 */
	 
}