package com.common.Controllers;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.common.Dao.BranchDao;
import com.common.Dao.RackDao;
import com.common.Dao.ShelfDao;
import com.common.Objects.ShelfObject;
import com.common.Objects.UsersObject;

@Controller
public class ShelfController {
	
	@Autowired
	ShelfDao shelfDao;
	
	@Autowired
	BranchDao branchDao;
	
	@Autowired
	RackDao rackDao;
	
	@RequestMapping(value = "/manageShelf", method = RequestMethod.GET)
    public ModelAndView manageDepartment(Model model,HttpServletRequest request) {  
	   HttpSession session = request.getSession();
	   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
	   if(usersSessionObject != null) {
		   List<ShelfObject> shelfList = shelfDao.getAllShelfs();
		   HashMap<Integer,String> hashmapOfRack = rackDao.getHashMapOfRack();
		   model.addAttribute("hashmapOfRack", hashmapOfRack);
		   return new ModelAndView("manageShelf","shelfList",shelfList);  
	   }  else {
		   return new ModelAndView("loginIn");  
	   }
    } 
	
	@RequestMapping(value = "/registerShelf", method = RequestMethod.GET)
	   public String showShelfForm(Model model,HttpServletRequest request){  
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
			  // List<BranchObject> branchList = branchDao.getBranchList();
			    //List<RackObject> rackList = rackDao.getAllRacks();
			   //model.addAttribute("branchList", branchList);
			   //model.addAttribute("rackList", rackList);
		       model.addAttribute("shelf",  new ShelfObject());
		       return "registerShelf"; 
		   }else {
			   return "loginIn"; 
		   }
	   } 
	
	@RequestMapping(value = "/saveShelf", method = RequestMethod.POST)
	public String saveList(@ModelAttribute("shelf") ShelfObject shelfObject, Model model, HttpServletRequest request) {
		UsersObject usersObject = (UsersObject) request.getSession().getAttribute("users");
		if (usersObject != null) {
			    ShelfObject shelfObjectOne = shelfDao.getShelfByBRId(shelfObject.getBranchId(),shelfObject.getRackId(),shelfObject.getShelfNo());
				if(shelfObjectOne != null && shelfObject.getShelfNo().equals(shelfObjectOne.getShelfNo())) {
					model.addAttribute("error", "Shelf Number already exists.");
					model.addAttribute("shelf", new ShelfObject());
					return "registerShelf";
				}else {
					shelfDao.saveShelfObject(shelfObject);
					model.addAttribute("message", "Shelf number added successfully.");
					model.addAttribute("shelf", new ShelfObject());
					model.addAttribute("shelfList",shelfDao.getAllShelfs());
					HashMap<Integer,String> hashmapOfRack = rackDao.getHashMapOfRack();
					model.addAttribute("hashmapOfRack", hashmapOfRack);
					return "manageShelf";
				}
		}else {
			return "loginIn";
		}
		
	}
	
	@RequestMapping(value="/editShelf", method = RequestMethod.GET)  
	   public ModelAndView editShelf(@RequestParam("shelfId") Integer shelfId,HttpServletRequest request){  
		   HttpSession session = request.getSession();
		   request.setAttribute("shelfId", shelfId);
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
			   ShelfObject shelfObject = findByShelfId(shelfId);
		       return new ModelAndView("editShelf","shelf",shelfObject);  
		   }else {
			   return new ModelAndView("loginIn"); 
		   }
	   }  
	
	@RequestMapping(value = "/updateShelf", method = RequestMethod.POST)
	   public String updateShelf(@ModelAttribute("Shelf") ShelfObject shelfObject, BindingResult result,Model model,HttpServletRequest request){
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		      if(usersSessionObject != null) {
		    	ShelfObject shelfObjectOne = shelfDao.getShelfByBRId(shelfObject.getBranchId(),shelfObject.getRackId(),shelfObject.getShelfNo());
				if(shelfObjectOne != null && shelfObjectOne.getShelfId() != shelfObject.getShelfId() && shelfObject.getShelfNo().equals(shelfObjectOne.getShelfNo())) {
					model.addAttribute("error", "Shelf Number already exists.");
					model.addAttribute("shelf", shelfObject);
					return "editShelf";
				}else {
					shelfDao.saveShelfObject(shelfObject);
					model.addAttribute("message", "Shelf Updated Successfully.");
					model.addAttribute("shelf",shelfObject);
					return "editShelf";
				}
			  
		   }else {
			   return "loginIn"; 
		   }
	   }  
	
	@RequestMapping(value = "/getShelfDropDown", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<ShelfObject> getShelfDropDown(@RequestParam("rackId") long rackId) {
	    List<ShelfObject> shelfList = shelfDao.getShelfDropDown(rackId);
		return shelfList;
	}
	
	 private ShelfObject findByShelfId(Integer shelfId) {
		   ShelfObject shelfObject =  shelfDao.getShelfById(shelfId); 
		   return shelfObject;
	 }
}
