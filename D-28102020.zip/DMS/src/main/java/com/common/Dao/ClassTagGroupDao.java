package com.common.Dao;

import com.common.Objects.ClassTagGroup;

public interface ClassTagGroupDao {
	
	public void saveClassTagGroup(ClassTagGroup classTagGroup);

	
	/*public List<SubDepartmentObject> getClassData(long tagGrpId);*/

}
