package com.common.Dao;

import java.util.List;
import java.util.Map;

import com.common.Objects.DepartmentObject;

public interface DepartmentDao {
	
	 public	void saveDepartmentObject(DepartmentObject departmentObject);

	 public List<DepartmentObject> getAllDepartments();

	 public DepartmentObject getDepartmentById(Integer departmentId);
	 

	 //public void deleteDepartmentObject(DepartmentObject departmentObject);
	 
	 public Map<Long,String> getHashmapofDepartmentObject();
}
