package com.common.Dao;

import java.util.HashMap;
import java.util.List;

import com.common.Objects.RackObject;

public interface RackDao {

	public List<RackObject> getAllRacks();
	
	public void saveRackObject(RackObject rackObject);

	public RackObject getRackById(Integer rackId);

	public RackObject getRackByBranchId(Integer branchId,String rackNo);

	public HashMap<Integer, String> getHashMapOfRack();

	public List<RackObject> getRackDropDown(long branchId);
}
