package com.common.Dao;

import java.util.List;

import com.common.Objects.DepartmentReport;
import com.common.Objects.DocumentObject;
import com.common.Objects.ReportSearchObject;

public interface ReportDao {
	
	 public List<DepartmentReport> getDepartmentWiseSummaryReport(ReportSearchObject reportSearchObject);
	 
	 public List<DepartmentReport> getSubDepartmentWiseSummaryReport(ReportSearchObject reportSearchObject, String string);
	 
	 public List<DocumentObject> departmentWiseDigitizationReports(ReportSearchObject reportSearchObject);
}
