package com.common.Dao;

import java.util.HashMap;
import java.util.List;

import com.common.Objects.ShelfObject;

public interface ShelfDao {

	public List<ShelfObject> getAllShelfs();
	
	public void saveShelfObject(ShelfObject shelfObject);

	public ShelfObject getShelfById(Integer shelfId);

	public ShelfObject getShelfByBRId(int branchId, int rackId, String shelfNo);

	public List<ShelfObject> getShelfDropDown(long rackId);

	public HashMap<Integer, String> getHashMapOfShelf();

}
