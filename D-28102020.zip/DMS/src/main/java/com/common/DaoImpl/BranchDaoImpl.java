package com.common.DaoImpl;

import java.util.HashMap;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.BranchDao;
import com.common.Objects.BranchObject;

@Repository
@Transactional
public class BranchDaoImpl implements BranchDao{
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public List<BranchObject> getAllBranch() {
		return sessionFactory.getCurrentSession().createQuery(" FROM BranchObject order by branchId desc").list();
	}

	@Override
	public void saveBranchObject(BranchObject branchObject) {
		sessionFactory.getCurrentSession().saveOrUpdate(branchObject);
	}

	@Override
	public BranchObject getBranchById(Integer branchId) {
		BranchObject branchObject = (BranchObject) sessionFactory.getCurrentSession().get(BranchObject.class,branchId);
		return branchObject;
	}

	@Override
	public List<BranchObject> getBranchList() {
		return sessionFactory.getCurrentSession().createQuery(" FROM BranchObject where status='A' order by branchId desc").list();
	}

	@Override
	public HashMap<Integer, String> getHashmapofBranchObject() {
		HashMap<Integer, String> hashMapofBranchObject = new HashMap<>();
		
		List<BranchObject> getAllBranch = sessionFactory.getCurrentSession().createQuery(" SELECT new BranchObject (bo.branchId ,bo.branchNm )FROM BranchObject bo where bo.status='A'").list();
		for(BranchObject branchObject:getAllBranch) {
			hashMapofBranchObject.put(branchObject.getBranchId(),branchObject.getBranchNm());
		}
		
		hashMapofBranchObject.values().stream().forEach(System.out::println);
		return hashMapofBranchObject;
	}

}
