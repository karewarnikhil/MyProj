package com.common.DaoImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.CompartmentDao;
import com.common.Objects.CompartmentObject;

@Repository
@Transactional
public class CompartmentDaoImpl implements CompartmentDao{
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public List<CompartmentObject> getAllCompartments() {
		return sessionFactory.getCurrentSession().createQuery("FROM CompartmentObject order by compartId asc").list();
	}

	@Override
	public void saveCompartment(CompartmentObject compartmentObject) {
		sessionFactory.getCurrentSession().saveOrUpdate(compartmentObject);
	}

	@Override
	public CompartmentObject getCompartmentById(Integer compartId) {
		CompartmentObject compartmentObject = (CompartmentObject) sessionFactory.getCurrentSession().get(CompartmentObject.class,compartId);
		return compartmentObject;
	}

	@Override
	public CompartmentObject getShelfByBRSId(Integer branchId, Integer rackId, Integer shelfId, String compNo) {
		CompartmentObject compartmentObject = (CompartmentObject) sessionFactory.getCurrentSession().createQuery("FROM CompartmentObject where branchId="+branchId+" AND compNo='"+compNo+"' AND rackId="+rackId+" AND shelfId="+shelfId).uniqueResult();
		return compartmentObject;
	}

	@Override
	public List<CompartmentObject> getCompartDropDown(long shelfId) {
		return sessionFactory.getCurrentSession().createQuery("FROM CompartmentObject where shelfId ="+shelfId+"order by compNo asc").list();
	}

}
