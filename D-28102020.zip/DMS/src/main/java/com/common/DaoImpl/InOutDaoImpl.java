package com.common.DaoImpl;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;
import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.CompositeKey.DocumentCompositeKey;
import com.common.Dao.InOutDao;
import com.common.Objects.DocumentObject;
import com.common.Objects.FileInOutTransObject;
import com.common.Objects.ReportSearchObject;
import com.common.Utilities.DmsConstant;

@Repository
@Transactional
public class InOutDaoImpl implements InOutDao{
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public List<DocumentObject> getFilesWithFileNm(ReportSearchObject reportSearchObject) {
		//USE Native Query because of ILIke Function of postgres
		Query qry =  sessionFactory.getCurrentSession().createNativeQuery(" SELECT d.fileid,d.seqno,d.folderid,d.creationdt,d.rootid,d.filenm,d.pagecnt,fo.deptid FROM filemst d,foldermst fo where d.folderid = fo.folderid And d.filenm ILIKE '%"+reportSearchObject.getFileName()+"%' order by d.filenm asc");
		List<DocumentObject> listFileNm = new ArrayList<DocumentObject>();
		List<Object[]> row = qry.getResultList();
		row.stream().forEach((record) -> {
			DocumentObject documentObject = new DocumentObject();
			DocumentCompositeKey documentCompositeKey = new DocumentCompositeKey();
			documentCompositeKey.setFileId(((BigInteger) record[0]).longValue());
			documentCompositeKey.setSeqNo(((Integer) record[1]).intValue());
			documentObject.setDocumentCompositeKey(documentCompositeKey);
			documentObject.setFolderId(((BigInteger) record[2]).longValue());
			documentObject.setCreationDt((((Timestamp) record[3])));
			documentObject.setRootId(((BigInteger) record[4]).longValue());
			documentObject.setFileName((String)(record[5]));
			documentObject.setPageCnt(((Integer) record[6]).intValue());
			/*
			documentObject.setA0Size(((Integer) record[7]).intValue());
			documentObject.setA1Size(((Integer) record[8]).intValue());
			documentObject.setA2Size(((Integer) record[9]).intValue());
			documentObject.setA3Size(((Integer) record[10]).intValue());
			documentObject.setA4Size(((Integer) record[11]).intValue());
			*/
		//	int deptId = ;
			documentObject.setDepartmentNm(DmsConstant.HASHMAP_OF_DEPARTMENT.get(((Long.valueOf((int) record[7])))));
			listFileNm.add(documentObject);
		});
		return listFileNm;
	}

	@Override
	public FileInOutTransObject getFilesWithFileId(long fileId) {
		Query qry =  sessionFactory.getCurrentSession().createNativeQuery("SELECT f.transId,f.userId,f.fileId,f.branchId,f.rackId,f.shelfId,f.compartId,f.rackFileNo,f.txnType FROM fileInOutTrans f where f.fileId="+fileId+" Order by f.transId DESC limit 1");
		List<Object[]> row = qry.getResultList();
		FileInOutTransObject fileInOutTransObject = new FileInOutTransObject();
		row.stream().forEach((record) -> {
			fileInOutTransObject.setTransId(((BigInteger) record[0]).longValue());
			fileInOutTransObject.setUserId(((BigInteger) record[1]).intValue());
			fileInOutTransObject.setFileId(((BigInteger) record[2]).longValue());
			fileInOutTransObject.setBranchId(((Integer) record[3]).intValue());
			fileInOutTransObject.setRackId(((Integer) record[4]).intValue());
			fileInOutTransObject.setShelfId(((Integer) record[5]).intValue());
			fileInOutTransObject.setCompartId(((Integer) record[6]).intValue());
			fileInOutTransObject.setRackFileNo((String) (record[7]));
			fileInOutTransObject.setTxnType(((String) record[8]));
		});
		
		return fileInOutTransObject;
	}

	@Override
	public void saveTransaction(FileInOutTransObject fileInOutTransObject) {
		sessionFactory.getCurrentSession().saveOrUpdate(fileInOutTransObject);
	}

	@Override
	public List<FileInOutTransObject> getAllTransactionDetails() {
		return sessionFactory.getCurrentSession().createQuery(" FROM FileInOutTransObject order by transId desc").list();
	}

	@Override
	public FileInOutTransObject getTransactionWithRackFileNo(String rackFileNo) {
		Query qry =  sessionFactory.getCurrentSession().createNativeQuery("SELECT f.transId,f.userId,f.fileId,f.branchId,f.rackId,f.shelfId,f.compartId,f.rackFileNo,f.txnType FROM fileInOutTrans f where f.rackFileNo='"+rackFileNo+"' Order by f.transId DESC limit 1");
		List<Object[]> row = qry.getResultList();
		FileInOutTransObject fileInOutTransObject = new FileInOutTransObject();
		row.stream().forEach((record) -> {
			fileInOutTransObject.setTransId(((BigInteger) record[0]).longValue());
			fileInOutTransObject.setUserId(((BigInteger) record[1]).intValue());
			fileInOutTransObject.setFileId(((BigInteger) record[2]).longValue());
			fileInOutTransObject.setBranchId(((Integer) record[3]).intValue());
			fileInOutTransObject.setRackId(((Integer) record[4]).intValue());
			fileInOutTransObject.setShelfId(((Integer) record[5]).intValue());
			fileInOutTransObject.setCompartId(((Integer) record[6]).intValue());
			fileInOutTransObject.setRackFileNo((String) (record[7]));
			fileInOutTransObject.setTxnType(((String) record[8]));
		});
		return fileInOutTransObject;
	}
	
	

}
