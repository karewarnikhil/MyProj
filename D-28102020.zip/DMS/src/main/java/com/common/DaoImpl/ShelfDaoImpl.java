package com.common.DaoImpl;

import java.util.HashMap;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.ShelfDao;
import com.common.Objects.RackObject;
import com.common.Objects.ShelfObject;

@Repository
@Transactional
public class ShelfDaoImpl implements ShelfDao{
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public List<ShelfObject> getAllShelfs() {
		return sessionFactory.getCurrentSession().createQuery("FROM ShelfObject order by shelfId asc").list();
	}

	@Override
	public void saveShelfObject(ShelfObject shelfObject) {
		sessionFactory.getCurrentSession().saveOrUpdate(shelfObject);
	}

	@Override
	public ShelfObject getShelfById(Integer shelfId) {
		ShelfObject shelfObject = (ShelfObject) sessionFactory.getCurrentSession().get(ShelfObject.class,shelfId);
		return shelfObject;
	}

	@Override
	public ShelfObject getShelfByBRId(int branchId, int rackId, String shelfNo) {
		ShelfObject shelfObject = (ShelfObject) sessionFactory.getCurrentSession().createQuery("FROM ShelfObject where branchId="+branchId+" AND shelfNo='"+shelfNo+"' AND rackId="+rackId).uniqueResult();
		return shelfObject;
	}

	@Override
	public List<ShelfObject> getShelfDropDown(long rackId) {
		return sessionFactory.getCurrentSession().createQuery("FROM ShelfObject where rackId ="+rackId+"order by shelfNo asc").list();
	}

	@Override
	public HashMap<Integer, String> getHashMapOfShelf() {
		HashMap<Integer, String> hashMapofShelfObject = new HashMap<>();
		
		List<ShelfObject> getAllShelf = sessionFactory.getCurrentSession().createQuery(" SELECT new ShelfObject (so.shelfId ,so.shelfNo )FROM ShelfObject so where so.status='A'").list();
		for(ShelfObject shelfObject:getAllShelf) {
			hashMapofShelfObject.put(shelfObject.getShelfId(),shelfObject.getShelfNo());
		}
		
		hashMapofShelfObject.values().stream().forEach(System.out::println);
		return hashMapofShelfObject;
	}

	

}
