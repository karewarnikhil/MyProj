package com.common.Objects;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.CreationTimestamp;

@Entity @Table(name="FileInOutTrans")
public class FileInOutTransObject {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "transId", updatable = false, nullable = false)
	private Long transId;
	
	@JoinColumn(name="userId", referencedColumnName="userId")
	private Integer userId;
	
	@Column(name = "fileId")
	private Long fileId;
	
	@JoinColumn(name="branchId", referencedColumnName="branchId")
	private Integer branchId;
	
	@JoinColumn(name="rackId", referencedColumnName="rackId")
	private Integer rackId;
	
	@JoinColumn(name="shelfId", referencedColumnName="shelfId")
	private Integer shelfId;
	
	@JoinColumn(name="compartId", referencedColumnName="compartId")
	private Integer compartId;
	
	@Column(name = "rackfileno")
	private String rackFileNo;
	
	@Column(name = "txnType")
	private String txnType;
	
	@CreationTimestamp
	@Column(name = "txnDt")
	private Timestamp txnDt;
	
	@Column(name = "authorityNm")
	private String authorityNm;
	
	@Column(name = "remark")
	private String remark;
	
	@Column(name = "returnDt")
	private Date returnDt;
	
	@Column(name = "rtime")
	private Time returnTime;
	
	@Transient
	private String returnDtStr;
	
	@Column(name="rmobile")
	private BigDecimal mobileNo;
	
	@Transient
	private Integer seqNo;

	public Long getTransId() {
		return transId;
	}

	public void setTransId(Long transId) {
		this.transId = transId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Long getFileId() {
		return fileId;
	}

	public void setFileId(Long fileId) {
		this.fileId = fileId;
	}

	public Integer getBranchId() {
		return branchId;
	}

	public void setBranchId(Integer branchId) {
		this.branchId = branchId;
	}

	public Integer getRackId() {
		return rackId;
	}

	public void setRackId(Integer rackId) {
		this.rackId = rackId;
	}

	public Integer getShelfId() {
		return shelfId;
	}

	public void setShelfId(Integer shelfId) {
		this.shelfId = shelfId;
	}

	public Integer getCompartId() {
		return compartId;
	}

	public void setCompartId(Integer compartId) {
		this.compartId = compartId;
	}

	public String getRackFileNo() {
		return rackFileNo;
	}

	public void setRackFileNo(String rackFileNo) {
		this.rackFileNo = rackFileNo;
	}

	public String getTxnType() {
		return txnType;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	public Timestamp getTxnDt() {
		return txnDt;
	}

	public void setTxnDt(Timestamp txnDt) {
		this.txnDt = txnDt;
	}

	public String getAuthorityNm() {
		return authorityNm;
	}

	public void setAuthorityNm(String authorityNm) {
		this.authorityNm = authorityNm;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}


	public Date getReturnDt() {
		return returnDt;
	}

	public void setReturnDt(Date returnDt) {
		this.returnDt = returnDt;
	}

	public Time getReturnTime() {
		return returnTime;
	}

	public void setReturnTime(Time returnTime) {
		this.returnTime = returnTime;
	}

	public BigDecimal getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(BigDecimal mobileNo) {
		this.mobileNo = mobileNo;
	}
	
	

	public String getReturnDtStr() {
		return returnDtStr;
	}

	public void setReturnDtStr(String returnDtStr) {
		this.returnDtStr = returnDtStr;
	}
	
	public Integer getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(Integer seqNo) {
		this.seqNo = seqNo;
	}

	public FileInOutTransObject() {
		super();
	}

	public FileInOutTransObject(Long transId, Integer userId, Long fileId, Integer branchId, Integer rackId,
			Integer shelfId, Integer compartId, String rackFileNo, String txnType, Timestamp txnDt, String authorityNm,
			String remark, Date returnDt, Time returnTime, String returnDtStr, BigDecimal mobileNo, Integer seqNo) {
		super();
		this.transId = transId;
		this.userId = userId;
		this.fileId = fileId;
		this.branchId = branchId;
		this.rackId = rackId;
		this.shelfId = shelfId;
		this.compartId = compartId;
		this.rackFileNo = rackFileNo;
		this.txnType = txnType;
		this.txnDt = txnDt;
		this.authorityNm = authorityNm;
		this.remark = remark;
		this.returnDt = returnDt;
		this.returnTime = returnTime;
		this.returnDtStr = returnDtStr;
		this.mobileNo = mobileNo;
		this.seqNo = seqNo;
	}

	
	
}

	