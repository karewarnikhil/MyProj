package com.common.Utilities;

import java.util.HashMap;

public class DmsConstant {
	
	public static  HashMap<Long,String> HASHMAP_OF_DEPARTMENT;
	public static  HashMap<Long,String> HASHMAP_OF_DESIGNATION;
	public static  HashMap<Long,String> HASHMAP_OF_GROUP;
	public static  HashMap<Long,String> HASHMAP_OF_TAG_TYPE;
	public static  HashMap<Long,String> HASHMAP_OF_TAG_GROUP;
	public static  HashMap<Long,String> HASHMAP_OF_USER;
	public static  HashMap<Long,String> HASHMAP_OF_FOLDERS;
	public static  HashMap<Integer,String> HASHMAP_OF_BRANCH;

}
