package com.common.Controllers;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.common.Dao.ListDao;
import com.common.Dao.ListDataDao;
import com.common.Objects.ListDataObj;
import com.common.Objects.UsersObject;

@Controller
public class ListDataController {

	@Autowired
	private ListDataDao listDataDao;

	@Autowired
	private ListDao listDao;

	@RequestMapping(value = "/createListData", method = RequestMethod.GET)
	public String getListDataForm(Model model) {
		model.addAttribute("listDataObj", new ListDataObj());
		model.addAttribute("allList", listDao.getAllList());
		model.addAttribute("allListData", listDataDao.getAllListData());
		return "manageListData";
	}

	@RequestMapping(value = "/saveListData", method = RequestMethod.POST)
	public String saveListData(Model model, HttpServletRequest request,
			@ModelAttribute("list") ListDataObj listDataObj) {
		UsersObject usersSess = (UsersObject) request.getSession().getAttribute("users");
		if (usersSess != null) {
			if (listDataObj.getListObj().getListId() == -1) {
				model.addAttribute("message", "Please Select List type.");
				model.addAttribute("listDataObj", new ListDataObj());
				model.addAttribute("allList", listDao.getAllList());
				model.addAttribute("allListData", listDataDao.getAllListData());
				return "manageListData";
			} else {
				if (listDataDao.getListDataByListValue(listDataObj.getListValue()) == null) {
					int listno = listDataDao.getMaxId(listDataObj.getListObj().getListId());
					listDataObj.setListNo(listno);
					listDataObj.setListValue(listDataObj.getListValue());
					listDataObj.setCreationDate(new Timestamp(new Date().getTime()));
					listDataObj.setCreatedBy(usersSess.getUserId());
					listDataObj.setStatus("A");
					listDataDao.save(listDataObj);
				} else {
					System.out.println("List Value is already present.");
					model.addAttribute("message", "List Value is already present.");
				}
				model.addAttribute("listDataObj", new ListDataObj());
				model.addAttribute("allList", listDao.getAllList());
				model.addAttribute("allListData", listDataDao.getAllListData());
				return "manageListData";
			}
		} else {
			return "redirect:/login";
		}

	}

	@RequestMapping(value = "/editListData", method = RequestMethod.GET)
	public String getListDataObjectEdit(@RequestParam("listId") int listId, Model model) {
		model.addAttribute("allList", listDao.getAllList());
		model.addAttribute("listDataObject", listDataDao.getListDataById(listId));
		model.addAttribute("allListData", listDataDao.getListDataByListId(listId));
		return "updateListData";
	}

	@RequestMapping(value = "/updateListData", method = RequestMethod.POST)
	public String updateListData(@ModelAttribute("listDataObject") ListDataObj listDataObj,
			@RequestParam("listId") int listId, Model model, HttpServletRequest request) throws Exception {
		UsersObject usersSess = (UsersObject) request.getSession().getAttribute("users");
		String listValue = request.getParameter("listValueTemp");
		System.out.println("List Value: " + listValue);
		if (usersSess != null) {
			System.out.println(" " + listId);
			String str = listDataObj.getListValue();
			System.out.println("" + str);
			if (listDataDao.getListDataByListValue(str) == null || str.equalsIgnoreCase(listValue)) {
				listDataObj.setListValue(str);
				listDataObj.setListObj(listDao.getListObjById(listId));
				listDataObj.setCreatedBy(listDataObj.getCreatedBy());
				listDataObj.setCreationDate(listDataObj.getCreationDate());
				listDataObj.setListNo(listDataObj.getListNo());
				listDataObj.setStatus(listDataObj.getStatus());
				listDataDao.update(listDataObj);
			} else {
				System.out.println("List Value is already present.");
				model.addAttribute("message", "List Value is already present.");
			}
		}
		model.addAttribute("listDataObj", new ListDataObj());
		model.addAttribute("allList", listDao.getAllList());
		model.addAttribute("allListData", listDataDao.getAllListData());
		return "manageListData";
	}

	@RequestMapping(value = "/getListData", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<ListDataObj> getListData(@RequestParam("id") long id, Model model,
			HttpServletRequest request) {
		List<ListDataObj> listDataObject = listDataDao.getListDataByListId(id);
		return listDataObject;
	}
}
