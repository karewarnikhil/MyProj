package com.common.Dao;

import java.util.List;

import com.common.Objects.DocumentObject;

public interface DocumentDao {

	List<DocumentObject> getAllDocuments();

	DocumentObject findByFileId(long fileId);

	void save(DocumentObject documentObject);

	List<DocumentObject> findAllByFolderId(long folderId);

	void deleteById(int id);

	public List<DocumentObject> getFileMstByQuery(String sql);

	public DocumentObject getFileByFileIdAndSeqNo(int fileId, int seqNo);

	public List<DocumentObject> getFileVersions(int fileId);
}
