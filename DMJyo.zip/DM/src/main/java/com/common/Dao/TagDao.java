package com.common.Dao;

import java.util.List;

import com.common.Objects.DepartmentObject;
import com.common.Objects.TagObject;

public interface TagDao {
	 
	 public	void saveTagObject(TagObject departmentObject);

	 public List<DepartmentObject> getAllDepartments();

	 public DepartmentObject getDepartmentById(Integer departmentId);
	 
	 public void deleteDepartmentObject(DepartmentObject departmentObject);
}
