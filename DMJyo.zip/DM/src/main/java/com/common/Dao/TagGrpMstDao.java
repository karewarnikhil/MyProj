package com.common.Dao;

import java.util.List;

import com.common.Objects.TagGroupObject;
import com.common.Objects.TagObject;

public interface TagGrpMstDao {
	
	public List<TagGroupObject> getAllTagGroup();
	
	public void saveTagGrp(TagGroupObject tagGroup);
	
	public List<TagObject> getTagByClassId(long classId);

	public TagGroupObject getTagByTagId(long tagGrpId);
}
