package com.common.DaoImpl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;
import javax.transaction.Transactional;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.DocumentDao;
import com.common.Objects.DocumentObject;
import com.common.Objects.FileFolderObject;
import com.common.Objects.FolderObject;

@Repository
@Transactional
public class DocumentDaoImpl implements DocumentDao {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	//EntityManager em=(Session) sessionFactory.getCurrentSession().getEntityManagerFactory().createEntityManager();
	

	public long getIdForCurrentVal() {
		Session session = sessionFactory.getCurrentSession();
		StoredProcedureQuery storedProcedureQuery = session.createStoredProcedureQuery("increment_CurrentVal");
		storedProcedureQuery.registerStoredProcedureParameter("p_seqName", String.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("currentVal", Integer.class, ParameterMode.OUT);
		storedProcedureQuery.setParameter("p_seqName", "file_Id");

		storedProcedureQuery.execute();
		int fileId = (Integer) storedProcedureQuery.getOutputParameterValue("currentVal");
		System.out.println("folderId=======" + fileId);
		return fileId;
	};

	public List<DocumentObject> getAllDocuments() {
		return sessionFactory.getCurrentSession().createQuery("FROM DocumentObject").list();
	}

	public void save(DocumentObject documentObject) {
		// Id used for fileId
		long currentVal = getIdForCurrentVal();
		documentObject.setFileId(currentVal);
		sessionFactory.getCurrentSession().saveOrUpdate(documentObject);
	}

	public List<DocumentObject> findAllByUserId(int userId) {
		return sessionFactory.getCurrentSession().createQuery(" FROM DocumentObject where userId=" + userId).list();
	}

	public void deleteById(int id) {
		// TODO Auto-generated method stub

	}

	public DocumentObject findByFileId(long fileId) {
		DocumentObject documentObject = (DocumentObject) sessionFactory.getCurrentSession().get(DocumentObject.class,
				fileId);
		return documentObject;
	}

	public List<DocumentObject> findAllByFolderId(long folderId) {
		return sessionFactory.getCurrentSession().createQuery(" FROM DocumentObject where folderId=" + folderId).list();
	}

	public List<DocumentObject> getFileMstByQuery(String sql) {
		List<DocumentObject> documentObject = (List<DocumentObject>) sessionFactory.getCurrentSession().createQuery(sql).list();      
		return documentObject;
	}

	public DocumentObject getFileByFileIdAndSeqNo(int fileId, int seqNo){
		DocumentObject documentObject = (DocumentObject) sessionFactory.getCurrentSession()
		.createQuery("From DocumentObject where fileId="+fileId+" and seqNo="+seqNo).uniqueResult();
		return documentObject;
	}
	public List<DocumentObject> getFileVersions(int fileId){
		List<DocumentObject> seqNodocumentObject= (List<DocumentObject>) sessionFactory.getCurrentSession().createQuery("from DocumentObject where fileId="+fileId+" order by seqNo desc").list();
		return seqNodocumentObject;
	}
}
