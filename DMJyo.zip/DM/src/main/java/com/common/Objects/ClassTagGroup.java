package com.common.Objects;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "classtaggrp")
public class ClassTagGroup implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@OneToOne(targetEntity = ClassObject.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "classId", nullable = false)
	private ClassObject classObject;

	@Id
	@OneToOne(targetEntity = TagGroupObject.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "tagGrpId", nullable = false)
	private TagGroupObject tagGroup;

	@Column(name = "createdby")
	private int createdBy;

	@Column(name = "createddatetime")
	private Timestamp createdDate;

	@Transient
	private String tagGrpNm;

	@Transient
	private int tagGrpId;
	
	public ClassTagGroup() {

	}
	public ClassTagGroup(ClassObject classObject, TagGroupObject tagGroup, int createdBy, Timestamp createdDate,
			String tagGrpNm,int tagGrpId) {
		super();
		this.classObject = classObject;
		this.tagGroup = tagGroup;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.tagGrpNm = tagGrpNm;
		this.tagGrpId=tagGrpId;
	}

	public ClassObject getClassObject() {
		return classObject;
	}

	public void setClassObject(ClassObject classObject) {
		this.classObject = classObject;
	}

	public TagGroupObject getTagGroup() {
		return tagGroup;
	}

	public void setTagGroup(TagGroupObject tagGroup) {
		this.tagGroup = tagGroup;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getTagGrpNm() {
		return tagGrpNm;
	}

	public void setTagGrpNm(String tagGrpNm) {
		this.tagGrpNm = tagGrpNm;
	}

	public int getTagGrpId() {
		return tagGrpId;
	}

	public void setTagGrpId(int tagGrpId) {
		this.tagGrpId = tagGrpId;
	}

}
