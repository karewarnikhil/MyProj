package com.common.Objects;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity 
@Table(name="TagGrpMst")
public class TagGroupObject implements Serializable{

	private static final long serialVersionUID = 1L;
	
    @Id
    @Column(name = "tagGrpId", updatable = false, nullable = false)
	private long tagGrpId;
	
	@Column(name="taggrpnm")
	private String tagGrpNm;
	
	@Column(name="createdby")
	private int createdBy;
	
	@Column(name="createddatetime")
	private  Timestamp createdDate ;
	
	@Column(name="status")
	private String status;

	public TagGroupObject() {
		super();
	}

	public TagGroupObject(long tagGrpId, String tagGrpNm, int createdBy, Timestamp createdDate, String status) {
		super();
		this.tagGrpId = tagGrpId;
		this.tagGrpNm = tagGrpNm;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.status = status;
	}

	public long getTagGrpId() {
		return tagGrpId;
	}

	public void setTagGrpId(long tagGrpId) {
		this.tagGrpId = tagGrpId;
	}

	public String getTagGrpNm() {
		return tagGrpNm;
	}

	public void setTagGrpNm(String tagGrpNm) {
		this.tagGrpNm = tagGrpNm;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
}
