package com.common.DaoImpl;

import java.util.List;

import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.ListDao;
import com.common.Objects.ListObject;

@Repository
@Transactional
public class ListDaoImpl implements ListDao {

	@Autowired
	private SessionFactory sessionFactory;

	public int getIdForCurrentVal() {
		Session session = sessionFactory.getCurrentSession();
		StoredProcedureQuery storedProcedureQuery = session.createStoredProcedureQuery("increment_CurrentVal");
		storedProcedureQuery.registerStoredProcedureParameter("p_seqName", String.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("currentVal", Integer.class, ParameterMode.OUT);
		storedProcedureQuery.setParameter("p_seqName", "listId");

		storedProcedureQuery.execute();
		int listId = (Integer) storedProcedureQuery.getOutputParameterValue("currentVal");
		System.out.println("listId=======" + listId);
		return listId;
	};

	public void save(ListObject listObject) {
		int currentVal = getIdForCurrentVal();
		listObject.setListId(currentVal);
		sessionFactory.getCurrentSession().save(listObject);
	}

	public List<ListObject> getAllList() {
		return sessionFactory.getCurrentSession().createQuery("FROM ListObject where listId >0 order by listId asc").list();
	}

	public ListObject getListObjById(int listId) {
		return (ListObject) sessionFactory.getCurrentSession().createQuery("FROM ListObject where listId=" + listId)
				.uniqueResult();
	}

	public void update(ListObject listObj) {
		sessionFactory.getCurrentSession().update(listObj);
	}

	public ListObject getByListName(String listName) {
		return (ListObject) sessionFactory.getCurrentSession()
				.createQuery("From ListObject where listName='" + listName + "'").uniqueResult();
	}
}
