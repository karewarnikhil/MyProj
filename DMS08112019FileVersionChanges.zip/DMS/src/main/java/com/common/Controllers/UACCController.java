package com.common.Controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.common.CompositeKey.UACCCompositeKey;
import com.common.Dao.MenuDao;
import com.common.Dao.UACCDao;
import com.common.Objects.MenuObject;
import com.common.Objects.UACCObject;
import com.common.Objects.UsersObject;

@Controller
public class UACCController {

	   @Autowired
	   private UACCDao uaccDao ;
	   
	   @Autowired
	   private MenuDao menuDao;
	   
	   @RequestMapping(value = "/registerUaccObject", method = RequestMethod.GET)
	   public String showUACCForm(Model model,HttpServletRequest request){  
		 UsersObject usersSess = (UsersObject) request.getSession().getAttribute("users");
		 if (usersSess != null) {
		 UACCObject uaccObject = new UACCObject();
	     model.addAttribute("uaccObject", uaccObject);
	     return "menuAccess"; 
		 }else {
			 return "loginIn";
		 }
	   } 
	   
	   @RequestMapping(value="/changeUACC", method = RequestMethod.POST)  
	   public String changeUACCForm(@RequestParam("userId") Integer userId,Model model,HttpServletRequest request){ 
		   HttpSession session = request.getSession();
		   List<MenuObject> menulist = menuDao.getMenuList();
		   //Change get it from hash map and defined in constant files
	       List<UACCObject> uaccObjectList = uaccDao.getUACCListByUserId(userId); 
	       model.addAttribute("selectedUserId", userId);
	       model.addAttribute("menulist", menulist);
	       UACCObject uaccObject = new UACCObject();
	       model.addAttribute("uaccObject", uaccObject);
	       session.setAttribute("uaccObjectList", uaccObjectList);
	       return "menuAccess";
	   }  
	   
	   @RequestMapping(value = "/saveUACC", method = RequestMethod.POST)
	   public String saveData(@ModelAttribute("uaccObject") UACCObject uaccObject,@RequestParam("userId") Integer userId,HttpServletRequest request,RedirectAttributes redirectAttributes){
		   HttpSession session = request.getSession();
		   uaccDao.deleteUACCObjectByUserId(userId);
		   saveUaccObjectByList(uaccObject, userId);
		   session.removeAttribute("uaccObjectList");
		   //request.setAttribute("message", "Menu added Successfully.");
		   redirectAttributes.addFlashAttribute("message", "Menu added Successfully.");
	       return "redirect:menuAccess"; 
	   }

	private void saveUaccObjectByList(UACCObject uaccObject, Integer userId) {
		List<Integer> listOfMenuObject = uaccObject.getMenuIdList();
		   for(int menuId:listOfMenuObject) {
			   UACCObject uACCObjectTwo = new UACCObject();
			   UACCCompositeKey uACCCompositeKey = new UACCCompositeKey();
			   uACCCompositeKey.setMid(menuId);
			   uACCCompositeKey.setUserId(userId);
			   //uACCObjectTwo.getuACCCompositeKey().setMid(menuId);
			 //  uACCObjectTwo.getuACCCompositeKey().setUserId(userId);
			   uACCObjectTwo.setuACCCompositeKey(uACCCompositeKey);
			   uACCObjectTwo.setAddFlag("A");
			   uACCObjectTwo.setDeleteFlag("A");
			   uACCObjectTwo.setPassFlag("A");
			   uACCObjectTwo.setUpdateFlag("A");
			   uACCObjectTwo.setViewFlag("A");
		       uaccDao.saveUACCObject(uACCObjectTwo);
		   }
	}  
	   
	   /*@RequestMapping(value="/deleteFormUACCObject", method = RequestMethod.POST)  
	   public String manageDesignation(@RequestParam("userId") Integer userId,Model model,HttpServletRequest request){ 
		   HttpSession session = request.getSession();
		   List<MenuObject> menulist = menuDao.getMenuList();
	       List<UACCObject> uaccObjectList = uaccDao.getUACCListByUserId(userId); 
	       model.addAttribute("selectedUserId", userId);
	       model.addAttribute("menulist", menulist);
	       UACCObject uaccObject = new UACCObject();
	       model.addAttribute("uaccObject", uaccObject);
	       session.setAttribute("uaccObjectList", uaccObjectList);
	       return "menuAccessDelete";
	   }  */
	   
	   //check and change logic if required  
	   @RequestMapping(value="/deleteUACC", method = RequestMethod.POST)  
	   public String deleteUACC(@ModelAttribute("uaccObject") UACCObject uaccObject,@RequestParam("userId") Integer userId,HttpServletRequest request){ 
		   HttpSession session = request.getSession();
		   uaccDao.deleteUACCObjectByUserId(userId);
		   saveUaccObjectByList(uaccObject, userId);
		   session.removeAttribute("uaccObjectList");
	      // return "redirect:/deleteFormUACC";//will redirect to viewemp request mapping  
		   return "defaultPage"; 
	   }  
	   
	  /* private UACCObject findUaccById(Integer menuId,Integer userId) {
		   UACCObject uaccObject =  uaccDao.getUACCById(menuId,userId); 
		   return uaccObject;
	   }*/
}
