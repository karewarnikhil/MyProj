package com.common.Dao;

import java.util.List;
import java.util.Map;

import com.common.Objects.DesignationObject;

public interface DesignationDao {
	 
	 public	void saveDesignationObject(DesignationObject designationObject);

	 public List<DesignationObject> getAllDesignation();

	 public DesignationObject getDesignationById(Integer designationId);
	 
	 //public void deleteDesignationObject(DesignationObject designationObject);
	 
	 public Map<Long,String> getHashmapofDesignationObject();

}
