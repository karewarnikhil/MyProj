package com.common.Dao;

import com.common.Objects.HisFolderObject;

public interface HisFolderDao {
  public void saveHistory(HisFolderObject hisFolder);
}
