package com.common.DaoImpl;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.persistence.Query;
import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.CompositeKey.TagCompositeKey;
import com.common.Dao.TagDao;
import com.common.Objects.ReportSearchObject;
import com.common.Objects.TagGroupObject;
import com.common.Objects.TagObject;
import com.common.Objects.TagReportObject;

@Repository
@Transactional
public class TagDaoImpl implements TagDao{
	
	@Autowired
	private SessionFactory sessionFactory;

	public void saveTagObject(TagObject tagObject) {
		sessionFactory.getCurrentSession().save(tagObject);
	}

	public List<TagObject> getAllTagObject() {
		List<TagObject> tagList= sessionFactory.getCurrentSession().createQuery(" FROM TagObject order by tagCompositeKey desc").list();
		/*for(TagObject tagObject:tagList) {
			System.out.println(tagObject.getTagId()+""+tagObject.getTagNm());
		}*/
		return tagList;
	}
    
	/*//need to change for both composite primary key
	public TagObject getTagById(Integer tagId) {
		TagObject tagObject = (TagObject) sessionFactory.getCurrentSession().get(TagObject.class,tagId);
		return tagObject;
	}*/
	
	public TagObject getTagById(TagCompositeKey tagCompositeKey) {
		TagObject tagObject = (TagObject) sessionFactory.getCurrentSession().get(TagObject.class,tagCompositeKey);
		return tagObject;
	}
	
	//put it into utility class afterwards
	public int getMaxValueId(long tagGrpId) {
		// remove hard-code and define in constant files
		Query qry=sessionFactory.getCurrentSession().createQuery("select COALESCE(MAX(tagCompositeKey.tagId), 0) from TagObject where tagCompositeKey.tagGrpId="+tagGrpId);
		int count= (Integer)  ((org.hibernate.query.Query) qry).uniqueResult();
		// define purpose and change logic
		return count + 1;
	}

	public List<TagGroupObject> getAllTagsForFileDisplay(long rootId) {
		return  sessionFactory.getCurrentSession().createQuery(" FROM TagGroupObject tg where tg.tagGrpId IN( Select DISTINCT ct.classTgGrpCompositeKey.tagGrpId FROM  ClassTagGroup ct where ct.classTgGrpCompositeKey.classId ="+rootId+")").list();
	}

	public List<TagObject> getTagData(long tagGrpId) {
		List<TagObject> tagList  = sessionFactory.getCurrentSession().createQuery(" FROM TagObject where tagGrpId="+tagGrpId+" order by dispSeqNo ").list();
		return tagList;
	}

	
	public void updateTagObject(TagObject tagObject) {
		sessionFactory.getCurrentSession().update(tagObject);
	}

	@Override
	public HashMap<Long, String> getHashmapofTagObject(long tagGrpId) {
		HashMap<Long, String> hashMapofTagObj = new HashMap<>();
		List<TagObject> getAllTagObject = sessionFactory.getCurrentSession().createQuery(" FROM TagObject where  tagGrpId=:tagGrpId").setParameter("tagGrpId", tagGrpId).list();
		for(TagObject tagObject:getAllTagObject) {
			hashMapofTagObj.put((long)tagObject.getTagCompositeKey().getTagId(), tagObject.getTagNm());
		}
		hashMapofTagObj.values().stream().forEach(System.out::println);
		return hashMapofTagObj;
	}

	@Override
	public List<TagReportObject> getTagReport(ReportSearchObject reportSearchObject,HashMap<Long,String> hashMapOfTagObj) {
		int hashMapSize = hashMapOfTagObj.size();
		String dataSet = "fileId bigint";
		//String scalar = ".addScalar('fileId', new LongType())";
		String sql = "Select ft.fileId,tagId,tagdata from filemst fm,filetagsdata ft where fm.fileId = ft.fileId and ft.taggrpId ="+reportSearchObject.getTagGrpId()+" AND ft.creationDt between ''"+reportSearchObject.getCreationFromDt()+"'' AND ''"+ reportSearchObject.getCreationToDt()+"'' order by 1,2";
		 
		for(int i=1;i<=hashMapSize;i++) {
			dataSet = dataSet + ", data"+i+" character varying(200)";
		}
		
		Query qry=sessionFactory.getCurrentSession().createNativeQuery("SELECT * FROM crosstab ('"+ sql + "') AS final_result("+dataSet+")");
		
		List<TagReportObject> listagReport =  new ArrayList<TagReportObject>();
		List<Object[]> row = qry.getResultList();
		
		row.stream().forEach((record) -> {
			
			TagReportObject tagReportObject = new TagReportObject();
			List<String> listOfTagData = new ArrayList<String>();
			tagReportObject.setFileId(((BigInteger) record[0]).longValue());
			
			for(int i=1;i<record.length;i++) {
				listOfTagData.add((String) record[i]);
			}
			tagReportObject.setListOfTagData(listOfTagData);
			listagReport.add(tagReportObject);
		});
		
		return listagReport;
		
	}

	@Override
	public List<TagReportObject> getTagSearch(HashMap<Long, String> hashMapOfTagObj, String queryBuilder) {
		int hashMapSize = hashMapOfTagObj.size();
		String dataSet = "fileId bigint";
		
		for(int i=1;i<=hashMapSize;i++) {
			dataSet = dataSet + ", data"+i+" character varying(200)";
		}
		
		Query qry=sessionFactory.getCurrentSession().createNativeQuery("SELECT * FROM crosstab ('"+ queryBuilder + "') AS final_result("+dataSet+")");
		List<Object[]> row = qry.getResultList();
		List<TagReportObject> listagReport =  new ArrayList<TagReportObject>();
		row.stream().forEach((record) -> {
			
			TagReportObject tagReportObject = new TagReportObject();
			List<String> listOfTagData = new ArrayList<String>();
			tagReportObject.setFileId(((BigInteger) record[0]).longValue());
			
			for(int i=1;i<record.length;i++) {
				listOfTagData.add((String) record[i]);
			}
			tagReportObject.setListOfTagData(listOfTagData);
			listagReport.add(tagReportObject);
		});
		
		return listagReport;
	}

	
}
