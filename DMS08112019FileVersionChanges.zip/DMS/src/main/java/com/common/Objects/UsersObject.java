package com.common.Objects;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.web.multipart.MultipartFile;
@Entity @Table(name="usermst")
public class UsersObject implements Serializable{



	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "userId", updatable = false, nullable = false)
	private  Integer userId ;
	
	@Column(name="emailId")
	private  String emailId ;
	
	@Column(name="username")
	private  String userName ;
	
	
	@Column(name="address")
	private  String address ;
	
	@Column(name="mobno")
	private BigDecimal mobileNo ;
	
	@Column(name="userlevel")
	private  int userlevel ;
	
	@Column(name="hintid")
	private  int hintId ;
    
    @JoinColumn(nullable = false, name = "deptid")
    private long deptId;
    
    @JoinColumn(nullable = false, name = "desgid")
	private long desgId;
	
    
	@JoinColumn(nullable = false, name = "groupId")
	private long groupId;
	
	@Column(name="createdby")
	private  String createdBy ;
	
	@Column(name="upw1")
	private  String userPassword ;
	
	@Column(name="upw2")
	private  String userPasswordOne ;
	
	@Column(name="upw3")
	private  String userPasswordTwo ;
	
	@Column(name="hintans")
	private  String hintAnswer ;
	
	
	@Column(name="status")
	private  String status = "A";
	
	@Column(name="creationDt")
	private Timestamp creationDt;
	
	@Column(name="profileImage")
	private byte[] profileImage;
	
	@Transient
	private long messageCount; 
	
	@Transient
	private List<String> groupList;
	
    @Transient
    private AccessObject accessObject;
    
    @Transient
    private MultipartFile multipartFile;

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public BigDecimal getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(BigDecimal mobileNo) {
		this.mobileNo = mobileNo;
	}

	public int getUserlevel() {
		return userlevel;
	}

	public void setUserlevel(int userlevel) {
		this.userlevel = userlevel;
	}

	public int getHintId() {
		return hintId;
	}

	public void setHintId(int hintId) {
		this.hintId = hintId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public long getDeptId() {
		return deptId;
	}

	public void setDeptId(long deptId) {
		this.deptId = deptId;
	}

	public long getDesgId() {
		return desgId;
	}

	public void setDesgId(long desgId) {
		this.desgId = desgId;
	}

	public long getGroupId() {
		return groupId;
	}

	public void setGroupId(long groupId) {
		this.groupId = groupId;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getUserPasswordOne() {
		return userPasswordOne;
	}

	public void setUserPasswordOne(String userPasswordOne) {
		this.userPasswordOne = userPasswordOne;
	}

	public String getUserPasswordTwo() {
		return userPasswordTwo;
	}

	public void setUserPasswordTwo(String userPasswordTwo) {
		this.userPasswordTwo = userPasswordTwo;
	}

	public String getHintAnswer() {
		return hintAnswer;
	}

	public void setHintAnswer(String hintAnswer) {
		this.hintAnswer = hintAnswer;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getCreationDt() {
		return creationDt;
	}

	public void setCreationDt(Timestamp creationDt) {
		this.creationDt = creationDt;
	}


	public List<String> getGroupList() {
		return groupList;
	}

	public void setGroupList(List<String> groupList) {
		this.groupList = groupList;
	}

	public AccessObject getAccessObject() {
		return accessObject;
	}

	public void setAccessObject(AccessObject accessObject) {
		this.accessObject = accessObject;
	}
	
	public long getMessageCount() {
		return messageCount;
	}

	public void setMessageCount(long messageCount) {
		this.messageCount = messageCount;
	}
	
	public byte[] getProfileImage() {
		return profileImage;
	}

	public void setProfileImage(byte[] profileImage) {
		this.profileImage = profileImage;
	}
	
	public MultipartFile getMultipartFile() {
		return multipartFile;
	}

	public void setMultipartFile(MultipartFile multipartFile) {
		this.multipartFile = multipartFile;
	}

	public UsersObject() {
		super();
	}

	public UsersObject(Integer userId, String emailId, String userName, String address, BigDecimal mobileNo,
			int userlevel, int hintId, long deptId, long desgId, long groupId, String createdBy, String userPassword,
			String userPasswordOne, String userPasswordTwo, String hintAnswer, String status, Timestamp creationDt,
			byte[] profileImage, long messageCount, List<String> groupList, AccessObject accessObject,
			MultipartFile multipartFile) {
		super();
		this.userId = userId;
		this.emailId = emailId;
		this.userName = userName;
		this.address = address;
		this.mobileNo = mobileNo;
		this.userlevel = userlevel;
		this.hintId = hintId;
		this.deptId = deptId;
		this.desgId = desgId;
		this.groupId = groupId;
		this.createdBy = createdBy;
		this.userPassword = userPassword;
		this.userPasswordOne = userPasswordOne;
		this.userPasswordTwo = userPasswordTwo;
		this.hintAnswer = hintAnswer;
		this.status = status;
		this.creationDt = creationDt;
		this.profileImage = profileImage;
		this.messageCount = messageCount;
		this.groupList = groupList;
		this.accessObject = accessObject;
		this.multipartFile = multipartFile;
	}

	public UsersObject(Integer userId, String userName) {
		super();
		this.userId = userId;
		this.userName = userName;
	}

	
	

	

	
	
	
	
	
	
}	

	