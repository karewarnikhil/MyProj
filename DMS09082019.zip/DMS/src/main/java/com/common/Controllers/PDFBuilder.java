package com.common.Controllers;

public class PDFBuilder extends ReportView {

	/*
	 * @Override protected void buildPdfDocument(Map<String, Object> model, Document
	 * document, PdfWriter writer, HttpServletRequest request, HttpServletResponse
	 * response) throws Exception {
	 * 
	 * List<DepartmentObject> departmentList = (List<DepartmentObject>)
	 * model.get("departmentList");
	 * 
	 * document.add(new Paragraph("Department List"));
	 * 
	 * PdfPTable table = new PdfPTable(3); table.setWidthPercentage(100.0f);
	 * table.setWidths(new float[] {3.0f, 2.0f, 2.0f, 2.0f, 1.0f});
	 * table.setSpacingBefore(10);
	 * 
	 * // define font for table header row Font font =
	 * FontFactory.getFont(FontFactory.HELVETICA); font.setColor(BaseColor.WHITE);
	 * 
	 * // define table header cell PdfPCell cell = new PdfPCell();
	 * cell.setBackgroundColor(BaseColor.BLUE); cell.setPadding(5);
	 * 
	 * // write table header
	 * 
	 * cell.setPhrase(new Phrase("ID", font)); table.addCell(cell);
	 * 
	 * 
	 * cell.setPhrase(new Phrase("Name", font)); table.addCell(cell);
	 * 
	 * cell.setPhrase(new Phrase("Short Name", font)); table.addCell(cell);
	 * 
	 * cell.setPhrase(new Phrase("Status", font)); table.addCell(cell);
	 * 
	 * // write table row data for (DepartmentObject departmentObject :
	 * departmentList) { table.addCell(departmentObject.getDeptNm());
	 * table.addCell(departmentObject.getShrtNm());
	 * table.addCell(departmentObject.getStatus()); }
	 * 
	 * document.add(table);
	 * 
	 * }
	 */

}
