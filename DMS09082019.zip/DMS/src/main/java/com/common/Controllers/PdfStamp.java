package com.common.Controllers;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfGState;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;

public class PdfStamp {
	
	public static final String SRC = "E:/PdftoImage/1000000237.pdf";
	public static final String RESULT = "E:/PdftoImage/watermarked.pdf";
	public static final String SRCIMAGE = "E:/PdftoImage/approved.jpg";
  
	public static void main(String[] args) {
		
		// read existing pdf
		PdfReader reader = null;
		try {
			reader = new PdfReader(SRC);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        PdfStamper stamper = null;
		try {
			stamper = new PdfStamper(reader, new FileOutputStream(RESULT));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (DocumentException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

        // text watermark
        Font font = new Font(Font.FontFamily.HELVETICA, 40, Font.BOLD,  BaseColor.RED);
        Phrase p = new Phrase("APPROVED DOCUMENT", font);

        // image watermark
        Image img = null;
		try {
			img = Image.getInstance(SRCIMAGE);
		} catch (BadElementException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (MalformedURLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        float w = img.getScaledWidth();
        float h = img.getScaledHeight();

        // properties
        PdfContentByte over;
        Rectangle pagesize;
        float x, y;

        // loop over every page
        int n = reader.getNumberOfPages();
		
		  for (int i = 1; i <= n; i++) {
		  
		  // get page size and position 
		  pagesize = reader.getPageSizeWithRotation(i); 
		  x  = (pagesize.getLeft() + pagesize.getRight()) / 2; 
		  y = (pagesize.getTop() + pagesize.getBottom()) / 2;
		  over = stamper.getOverContent(i);
		  over.saveState();
		  
		  // set transparency 
		  PdfGState state = new PdfGState();
		  state.setFillOpacity(0.2f); 
		  over.setGState(state);
		  
		  // add watermark text and image 
		  if (i % 2 == 1) {
			  ColumnText.showTextAligned(over, Element.ALIGN_CENTER, p, x, y, 0); 
		  } 
		  else {
		  try { 
			  	over.addImage(img, w, 0, 0, h, x - (w / 2), y - (h / 2)); 
			  }   catch  (DocumentException ex) {
			  // TODO Auto-generated catch block
				  ex.printStackTrace(); 
			  } 
		  }
		  	over.restoreState(); 
		  }
		 
        
		/*
		 * for (int i = 1; i <= n; i++) { pagesize = reader.getPageSizeWithRotation(i);
		 * // left of the page x = pagesize.getLeft(); // middle of the height y =
		 * (pagesize.getTop() + pagesize.getBottom()) / 2; // getting the canvas
		 * covering the existing content over = stamper.getOverContent(i); // adding
		 * some lines to the left ColumnText.showTextAligned(over, Element.ALIGN_CENTER,
		 * new Phrase("This is some extra text added to the left of the page"), x + 18,
		 * y, 90); ColumnText.showTextAligned(over, Element.ALIGN_CENTER, new
		 * Phrase("This is some more text added to the left of the page"), x + 34, y,
		 * 90); }
		 */
        
        
        try {
			stamper.close();
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        reader.close();
    }
	
	
	private static URL getResource(String name){
	    return PdfStamp.class.getResource(name);
	}

}
