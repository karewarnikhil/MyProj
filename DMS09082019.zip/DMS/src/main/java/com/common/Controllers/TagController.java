package com.common.Controllers;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.common.CompositeKey.TagCompositeKey;
import com.common.Dao.ListDao;
import com.common.Dao.TagDao;
import com.common.Objects.TagGroupObject;
import com.common.Objects.TagObject;
import com.common.Objects.UsersObject;

@Controller
public class TagController {
	
	 @Autowired
	 private TagDao tagDao ;
	 
	 
	 @Autowired
	 private ListDao listDao;
	 
	   @RequestMapping(value = "/registerTag", method = RequestMethod.GET)
	   public String showTagForm(Model model,HttpServletRequest request){  
		   UsersObject usersSessionObject = (UsersObject) request.getSession().getAttribute("users");
		   if(usersSessionObject != null) {
	       model.addAttribute("tagObject", new TagObject());
	       //change get it from hash map and defined in constant files for following three
	      // model.addAttribute("tagGroupList",tagGrpDao.getAllTagForGroupDropDown());
	       model.addAttribute("listObjectlist",listDao.getAllListForDropdown());
	       //model.addAttribute("tagTypeList",tagGrpDao.getAllTagTypeObjectForDropDown());
	       return "registerTag"; 
		   }else {
			   return "loginIn";
		   }
	   } 
	
	 @RequestMapping(value = "/saveTag", method = RequestMethod.POST)
	   public String saveTag(@ModelAttribute("tagObject") TagObject tagObject, BindingResult result, HttpServletRequest request,Model model){
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
	       int maxValue =  tagDao.getMaxValueId(tagObject.getTagCompositeKey().getTagGrpId());
	       tagObject.getTagCompositeKey().setTagId(maxValue);
	       tagObject.setCreatedBy(usersSessionObject.getUserId());
	       model.addAttribute("message", "Tag Saved Successfully.");
	       model.addAttribute("tagGrpId", tagObject.getTagCompositeKey().getTagGrpId());
	       tagDao.saveTagObject(tagObject);
	       
	       model.addAttribute("tagObject", new TagObject());
	       model.addAttribute("listObjectlist",listDao.getAllListForDropdown());
	       return "registerTag"; 
	   }  
	 
	
	   @RequestMapping(value = "/updateTag", method = RequestMethod.POST)
	   public String updateTagData(@ModelAttribute("tagObject") TagObject tagObject, BindingResult result,HttpServletRequest request){
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   tagObject.setCreatedBy(usersSessionObject.getUserId());
		   tagDao.updateTagObject(tagObject);
	       return "redirect:/manageTag"; 
	   }  
	   
	   @RequestMapping(value="/manageTag", method = RequestMethod.GET)  
	   public ModelAndView manageTag(HttpServletRequest request){
		   UsersObject usersSessionObject = (UsersObject) request.getSession().getAttribute("users");
		   if(usersSessionObject != null) {
		   List<TagObject> taglist = tagDao.getAllTagObject();
	       return new ModelAndView("manageTag","taglist",taglist);  
		   }else {
			   return new ModelAndView("loginIn");   
		   }
	   } 
	   
	   @RequestMapping(value="/editTag", method = RequestMethod.GET)  
	   public String editTag(@RequestParam("tagId") Integer tagId,@RequestParam("tagGrpId") Long tagGrpId, Model model,HttpServletRequest request){  
		   UsersObject usersSessionObject = (UsersObject) request.getSession().getAttribute("users");
		   if(usersSessionObject != null) {
		   TagCompositeKey tagCompositeKey = new TagCompositeKey();
		   tagCompositeKey.setTagGrpId(tagGrpId);
		   tagCompositeKey.setTagId(tagId);
		   TagObject tagObject = findByTagId(tagCompositeKey);
		   model.addAttribute("tagObject", tagObject);
		   return "editTag";
		   }else {
			   return "loginIn";
		   }
	   }  
	   
	   
	   @RequestMapping(value = "/getTagList", method = RequestMethod.GET, produces = "application/json")
		public @ResponseBody List<TagObject> getTagList(@RequestParam("tagGrpId") long tagGrpId) {
		   List<TagObject> listOfTagObj = tagDao.getTagData(tagGrpId);
		   return listOfTagObj;
	   }
	   
	   
	   @RequestMapping(value = "/createTags", method = RequestMethod.GET)
	   public String createTags(HttpSession session)  {
 		  UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
 		  if(usersSessionObject != null) {
 			  return "defaultPageForTags";
 		  }
 		  else
 			  return "loginIn";	  
 	   }
	  
	   private TagObject findByTagId(TagCompositeKey tagCompositeKey) {
		   TagObject tagObject =  tagDao.getTagById(tagCompositeKey); 
		   return tagObject;
	   }

}
