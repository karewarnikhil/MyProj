package com.common.Dao;

public interface LoginDao {
	/*public	void findUser(UsersObject users);*/
}
