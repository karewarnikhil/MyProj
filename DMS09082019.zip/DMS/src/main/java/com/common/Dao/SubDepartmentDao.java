package com.common.Dao;

import java.util.List;
import java.util.Map;

import com.common.Objects.SubDepartmentObject;

public interface SubDepartmentDao {

	 public	void saveSubDepartmentObject(SubDepartmentObject subDepartmentObject);

	 public List<SubDepartmentObject> getAllSubDepartments();

	 public SubDepartmentObject getSubDepartmentById(Integer subDepartmentId);
	 
	 public Map<Long,String> getHashmapofSubDepartmentObject();

	void updateSubDepartmentObject(SubDepartmentObject subDepartmentObject);

	public List<SubDepartmentObject> getSubDeptForDropDownByDeptId(long deptId);

	public List<SubDepartmentObject> getClassByDeptAndROP(long deptId);
}
