package com.common.DaoImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.ClassTagGroupDao;
import com.common.Objects.ClassTagGroup;
import com.common.Objects.SubDepartmentObject;

@Repository
@Transactional
//remove  this unwanted class
public class ClassTagGroupDaoImpl implements ClassTagGroupDao {

	@Autowired
	private SessionFactory sessionFactory;
    
	//add in tagGrpoupDaoImpl remove extra class
	public void saveClassTagGroup(ClassTagGroup classTagGroup) {
		sessionFactory.getCurrentSession().save(classTagGroup);
	}

	@Override
	public List<SubDepartmentObject> getClassData(long tagGrpId) {
		
		return sessionFactory.getCurrentSession().createQuery(" FROM SubDepartmentObject where subDeptId in ( Select classTgGrpCompositeKey.classId from ClassTagGroup where classTgGrpCompositeKey.tagGrpId=:tagGrpId) order by subDeptNm ").setParameter("tagGrpId",tagGrpId).list();
	}
	

}
