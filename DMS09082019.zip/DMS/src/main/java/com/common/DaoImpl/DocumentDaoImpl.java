package com.common.DaoImpl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.hibernate.type.TimestampType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.CompositeKey.DocumentCompositeKey;
import com.common.Dao.DocumentDao;
import com.common.Objects.DocumentObject;
import com.common.Objects.FileMasterObject;
import com.common.Utilities.GeneralUtility;

@Repository
@Transactional
public class DocumentDaoImpl implements DocumentDao{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	//make one common update for all following used

	public List<DocumentObject> getAllDocuments() {
		//return sessionFactory.getCurrentSession().createSQLQuery(" SELECT d.fileId,d.seqNo,d.folderId,d.rootId,d.fileName,d.fileExtn,d.atriBt,d.createdBy FROM DocumentObject d ").addEntity(DocumentObject.class).list();
		//SELECT new org.thoughts.on.java.model.AuthorValue(a.id, a.firstName, a.lastName) FROM Author a
		return sessionFactory.getCurrentSession().createQuery(" SELECT new DocumentObject(d.documentCompositeKey,d.folderId,d.rootId,d.fileName,d.fileExtn,d.atriBt,d.createdBy,d.tagStatus) FROM DocumentObject d order by d.documentCompositeKey.fileId desc").list();
	}

	//Converted to save
	//change method name
	public void save(DocumentObject documentObject) {
		 //Id used for fileId
		//System.out.println("documentObject=="+documentObject.getFileName());
		Session session = sessionFactory.getCurrentSession();
		//remove hard code comes from hashmap values from constant files
		String seqName = "file_Id";
		if(documentObject.getDocumentCompositeKey().getFileId() == 0) {
			long currentVal = GeneralUtility.getIdForCurrentVal(session, seqName);
			documentObject.getDocumentCompositeKey().setFileId(currentVal);
		}
		session.save(documentObject);
	}
	
	/*
	 * //Converted to save
	 * 
	 * @Override public int saveBatch(List<DocumentObject> documentListFoSave,int
	 * fileSavedCount) { //Id used for fileId
	 * //System.out.println("documentObject=="+documentObject.getFileName());
	 * Session session = sessionFactory.openSession(); Transaction tx =
	 * session.beginTransaction();
	 * 
	 * 
	 * //remove hard code comes from hashmap values from constant files String
	 * seqName = "file_Id"; for(DocumentObject documentObject :documentListFoSave) {
	 * if(documentObject.getDocumentCompositeKey().getFileId() == 0) { long
	 * currentVal = GeneralUtility.getIdForCurrentVal(session, seqName);
	 * documentObject.getDocumentCompositeKey().setFileId(currentVal); }
	 * session.save(documentObject);
	 * 
	 * if (documentListFoSave.size() % 10 == 0) { session.flush(); session.clear();
	 * } fileSavedCount ++; System.out.println(fileSavedCount); } tx.commit();
	 * session.close(); return fileSavedCount; }
	 */

	public List<DocumentObject> findAllByUserId(int userId) {
		return sessionFactory.getCurrentSession().createQuery(" FROM DocumentObject where userId="+userId).list();
	}


	public DocumentObject findByFileId(DocumentCompositeKey documentCompositeKey) {
		DocumentObject documentObject = (DocumentObject) sessionFactory.getCurrentSession().get(DocumentObject.class,documentCompositeKey);
		return documentObject;
	}


	public List<DocumentObject> findAllByFolderId(long folderId) {
		//return sessionFactory.getCurrentSession().createQuery(" SELECT new DocumentObject(d.fileId,d.seqNo,d.folderId,d.rootId,d.fileName,d.fileExtn,d.atriBt,d.createdBy,d.tagStatus) FROM DocumentObject d where d.folderId="+folderId +" AND d.seqNo = 1 order by d.creationDt").list();
		//try to remove hard-code comes from constant file
		return sessionFactory.getCurrentSession().createQuery(" SELECT new DocumentObject(d.documentCompositeKey,d.folderId,d.rootId,d.fileName,d.fileExtn,d.atriBt,d.createdBy,d.tagStatus) FROM DocumentObject d where d.folderId="+folderId +" AND d.documentCompositeKey.seqNo = 1 order by d.creationDt").list();
	}

	//need to change following code use other query than following
   public List<FileMasterObject> getFileMstByQuery(String sql) {
		List<FileMasterObject> listFileMasterObject = new ArrayList<FileMasterObject>();
    	Query qry = sessionFactory.getCurrentSession().createNativeQuery(sql).addScalar("fileid", new LongType())
			.addScalar("seqNo", new LongType()).addScalar("filenm", new StringType())
			.addScalar("creationDt", new TimestampType()).addScalar("fldrnm", new StringType())
			.addScalar("createdby", new StringType()).addScalar("rootid", new LongType())
			.addScalar("folderid", new LongType()).addScalar("atribt", new StringType());
	List<Object[]> rows = qry.getResultList();
		for (Object row[] : rows) {
			FileMasterObject fileMasterObject = new FileMasterObject();
			fileMasterObject.setFileId((long) row[0]);
			fileMasterObject.setSeqNo((long) row[1]);
			fileMasterObject.setFileName(row[2].toString());
			fileMasterObject.setCreationDt(row[3].toString());
			fileMasterObject.setFolderNm(row[4].toString());
			fileMasterObject.setCreatedBy(row[5].toString());
			fileMasterObject.setRootId((long) row[6]);
			fileMasterObject.setFolderId((long) row[7]);
			fileMasterObject.setAtriBt(row[8].toString());
			listFileMasterObject.add(fileMasterObject);
		}
		return listFileMasterObject;
	}

	//change method to one composite key parameter remove following. 
	public DocumentObject getFileByFileIdAndSeqNo(long fileId, long seqNo) {
		DocumentObject documentObject = (DocumentObject) sessionFactory.getCurrentSession().createQuery("From DocumentObject where fileId=" + fileId + " and seqNo=" + seqNo).uniqueResult();
		return documentObject;
	}

	//try to make it one for all getFrom fileIds
	public List<DocumentObject> getFileVersions(long fileId) {
		List<DocumentObject> seqNodocumentObject = (List<DocumentObject>) sessionFactory.getCurrentSession().createQuery("SELECT d FROM DocumentObject d where d.documentCompositeKey.fileId=" + fileId + " order by d.documentCompositeKey.seqNo desc").list();
		return seqNodocumentObject;
	}

	@Override
	public void updateDocument(DocumentObject documentObject) {
		sessionFactory.getCurrentSession().update(documentObject);
	}

	public List<DocumentObject> findAllByFolderIdAndUntagged(long folderId) {
		//int paramValue = (Integer.parseInt(getparamValue())) ;
		//timestamp '2001-09-28 01:00' + interval '23 hours'
		//remove hard code comes from constant file
		Query query =   sessionFactory.getCurrentSession().createNativeQuery("SELECT CURRENT_TIMESTAMP - INTERVAL '2 hour'"); 
		Timestamp ts = (Timestamp) query.uniqueResult();
		/*DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
		LocalDateTime localDateTime = LocalDateTime.parse(ts.toString(), dateTimeFormatter);
		localDateTime = localDateTime.minusHours(2);
		String ts1 = localDateTime.format(dateTimeFormatter);*/
		//System.out.println(ts);
		//return null;
	    //return sessionFactory.getCurrentSession().createQuery("SELECT new DocumentObject(d.fileId, d.seqNo, d.folderId, d.rootId, d.fileName, d.fileExtn, d.atriBt, d.createdBy, d.tagStatus) FROM DocumentObject d where d.folderId="+folderId+" AND d.tagStatus ='N' AND d.seqNo = 1 AND (d.tagEntryDt <='" +ts+"' OR d.tagEntryDt = null) order by d.fileId").list();
		//try to remove hard-code 1 value of sequence no
		return sessionFactory.getCurrentSession().createQuery("SELECT new DocumentObject(d.documentCompositeKey, d.folderId, d.rootId, d.fileName, d.fileExtn, d.atriBt, d.createdBy, d.tagStatus) FROM DocumentObject d where d.folderId="+folderId+" AND d.tagStatus ='N' AND d.documentCompositeKey.seqNo = 1 AND (d.tagEntryDt <='" +ts+"' OR d.tagEntryDt = null) order by d.documentCompositeKey.fileId").list();
	}

	public DocumentObject findByFileNameAndFolderId(String originalFilename,long folderId) {
		DocumentObject documentObject = (DocumentObject) sessionFactory.getCurrentSession().createQuery("FROM DocumentObject where folderId = "+folderId+" AND fileName='"+originalFilename+"' And seqNo = 1").uniqueResult();
		return documentObject;
	}

	@Override
	public List<DocumentObject> getAllDocumentsForMultiTagging(DocumentObject documentObject) {
		//int paramValue = (Integer.parseInt(getparamValue())) ;
		Session session = sessionFactory.getCurrentSession();
		//get it from constant files instead here
		String pk = "FLT";
		String sk = "LIMT";
		int paramValue = (Integer.parseInt(GeneralUtility.getparamValue(session, pk, sk)));
		// remove hard-code and get from constant file andtry to eliminate following query or reduce it
		Query query =   sessionFactory.getCurrentSession().createSQLQuery("SELECT CURRENT_TIMESTAMP - INTERVAL '2 hour'"); 
		Timestamp ts = (Timestamp) query.uniqueResult();
		//List<DocumentObject> listOfMultipleFiles = sessionFactory.getCurrentSession().createQuery("SELECT new DocumentObject(d.fileId, d.seqNo, d.folderId, d.rootId, d.fileName, d.fileExtn, d.atriBt, d.createdBy, d.tagStatus) FROM DocumentObject d where  d.fileId >= "+ documentObject.getDocumentCompositeKey().getFileId() +" AND d.folderId="+documentObject.getFolderId()+" AND d.tagStatus ='N' AND (d.tagEntryDt <='" +ts+"' OR d.tagEntryDt = null) order by d.fileId").setMaxResults(paramValue).list();
		List<DocumentObject> listOfMultipleFiles = sessionFactory.getCurrentSession().createQuery("SELECT new DocumentObject(d.documentCompositeKey, d.folderId, d.rootId, d.fileName, d.fileExtn, d.atriBt, d.createdBy, d.tagStatus) FROM DocumentObject d where  d.documentCompositeKey.fileId >= "+ documentObject.getDocumentCompositeKey().getFileId() +" AND d.folderId="+documentObject.getFolderId()+" AND d.tagStatus ='N' AND (d.tagEntryDt <='" +ts+"' OR d.tagEntryDt = null) order by d.documentCompositeKey.fileId").setMaxResults(paramValue).list();
		for(DocumentObject documentObjectMul:listOfMultipleFiles) {
			documentObjectMul.setTagEntryDt(new Timestamp(new Date().getTime()));
			//documentDao.save(documentObjectMul);
			//change following hard-coded query to hibernate update query
			int queryUpdate =   session.createQuery("Update DocumentObject set tagEntryDt='"+documentObjectMul.getTagEntryDt()+"' where fileId="+documentObjectMul.getDocumentCompositeKey().getFileId()+"AND seqNo="+documentObject.getDocumentCompositeKey().getSeqNo()).executeUpdate(); 
			//System.out.println(documentObjectMul.getFileName());
		}
		return listOfMultipleFiles;
	}
	
	//make one common method for following both and put it into utility class
	public long getMaxSequenceValue(long fileId) {
		//try to eliminate hard code zero or define what it is
		Query qry = sessionFactory.getCurrentSession().createQuery("SELECT COALESCE(MAX(documentCompositeKey.seqNo), 0) from DocumentObject where documentCompositeKey.fileId="+fileId);
		Long count = (Long) ((org.hibernate.query.Query) qry).uniqueResult();
		return count + 1;
	}
	
	public long checkGreaterSeqNo(long fileId) {
		long number = (long) sessionFactory.getCurrentSession().createQuery("SELECT Max(documentCompositeKey.seqNo) from DocumentObject where documentCompositeKey.fileId="+fileId).uniqueResult();
		return number;
	}

	

	/*@Override
	public DocumentObject findByFileName(String originalFilename) {
		DocumentObject documentObject = (DocumentObject) sessionFactory.getCurrentSession().createQuery("FROM DocumentObject where fileName='"+originalFilename+"'").uniqueResult();
		return documentObject;
	}*/
	
	

}
