package com.common.DaoImpl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.FileTgDataDao;
import com.common.Objects.FileTagsDataObject;
import com.common.Objects.TagDataObject;
import com.common.Objects.TagGroupObject;

@Repository
@Transactional
public class FileTgDataDaoImpl implements FileTgDataDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	
	public void saveFileTagData(List<TagDataObject> listOfTagData) {
		Session session = sessionFactory.getCurrentSession();
		for(TagDataObject tagDataObject:listOfTagData) {
			session.saveOrUpdate(tagDataObject);
		}
	}

	
	public List<TagDataObject> getAllTagDataByFileId(long fileId,long tagGrpId) {
		return sessionFactory.getCurrentSession().createQuery(" FROM TagDataObject where fileId="+fileId+" AND tagObject.tagCompositeKey.tagGrpId="+tagGrpId).list();
	}

	
	public List<TagGroupObject> getAllTagGrpByFileId(long fileId) {
		return sessionFactory.getCurrentSession().createQuery(" FROM TagGroupObject tg where tg.tagGrpId IN( SELECT DISTINCT td.tagObject.tagCompositeKey.tagGrpId from TagDataObject td where td.fileId= "+fileId+")").list();
	}

	
	public TagDataObject getTagDataById(long fTagId) {
		TagDataObject tagDataObject = (TagDataObject) sessionFactory.getCurrentSession().get(TagDataObject.class,fTagId);
		return tagDataObject;
		
	}

	public void saveFileTagData(TagDataObject tagDataObject) {
		sessionFactory.getCurrentSession().saveOrUpdate(tagDataObject);
	}
	
	//need to change FileTagsDataObject to TagDataObject
	public List<FileTagsDataObject> getTagData(long fileId,long tagGrpId) {
		List<FileTagsDataObject> list = new ArrayList<FileTagsDataObject>();
		// try to remove following hard-code values change scalar query to other query find hibernate 5 solution for same.
		String sql = "select t.tagnm, f.tagdata,tm.taggrpnm from tagmst t, filetagsdata f,taggrpmst tm where t.tagGrpId=f.tagGrpId and t.tagid=f.tagid and tm.tagGrpId=t.tagGrpId and fileid="
				+ fileId + " AND t.tagGrpId="+tagGrpId +" order by dispseqno";
		Query query = sessionFactory.getCurrentSession().createSQLQuery(sql).addScalar("tagnm", new StringType())
				.addScalar("tagdata", new StringType()).addScalar("taggrpnm", new StringType());
		List<Object[]> rows = ((org.hibernate.query.Query) query).list();
		for (Object row[] : rows) {
			FileTagsDataObject fileTagsDataObject = new FileTagsDataObject();
			fileTagsDataObject.setTagNm(row[0].toString());
			fileTagsDataObject.setTagData(row[1].toString());
			fileTagsDataObject.setTagGrpName(row[2].toString());
			list.add(fileTagsDataObject);
		}
		return list;
	}
	
	
	public List<TagGroupObject> getTagGrpName(long fileId) {
		List<TagGroupObject> list = new ArrayList<TagGroupObject>();
		// try to change following scalar query to other define hibernate 5 query
		String sql = "select distinct tg.tagGrpNm,ft.taggrpid from taggrpmst tg, filetagsdata ft where tg.taggrpid=ft.taggrpid and ft.fileid="
				+ fileId;
		Query qry = sessionFactory.getCurrentSession().createSQLQuery(sql).addScalar("tagGrpNm", new StringType())
				.addScalar("taggrpid", new IntegerType());
		List<Object[]> rows = ((org.hibernate.query.Query) qry).list();
		for (Object row[] : rows) {
			TagGroupObject tagGroupObject = new TagGroupObject();
			tagGroupObject.setTagGrpId((int) row[1]);
			tagGroupObject.setTagGrpNm(row[0].toString());
			tagGroupObject.setFileId(fileId);
			list.add(tagGroupObject);
		}
		return list;
	}


}
