package com.common.Objects;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

@Entity @Table(name="subdeptmst")
public class SubDepartmentObject implements Serializable{
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "subDeptId", updatable = false, nullable = false)
	private  Integer subDeptId;
	
	@Column(name="subDeptNm",unique=true)
	private  String subDeptNm ;
	
	@JoinColumn(nullable = false, name = "deptid") 
	private long deptId;
	
	@Column(name="shrtNm")
	private  String shrtNm;
	
	@CreationTimestamp
	@Column(name="creationDt")
	private Timestamp creationDt;
	
	@Column(name="status")
	private String status;

	public Integer getSubDeptId() {
		return subDeptId;
	}

	public void setSubDeptId(Integer subDeptId) {
		this.subDeptId = subDeptId;
	}

	public String getSubDeptNm() {
		return subDeptNm;
	}

	public void setSubDeptNm(String subDeptNm) {
		this.subDeptNm = subDeptNm;
	}

	public long getDeptId() {
		return deptId;
	}

	public void setDeptId(long deptId) {
		this.deptId = deptId;
	}

	public String getShrtNm() {
		return shrtNm;
	}

	public void setShrtNm(String shrtNm) {
		this.shrtNm = shrtNm;
	}

	public Timestamp getCreationDt() {
		return creationDt;
	}

	public void setCreationDt(Timestamp creationDt) {
		this.creationDt = creationDt;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public SubDepartmentObject(Integer subDeptId, String subDeptNm, long deptId, String shrtNm, Timestamp creationDt,
			String status) {
		super();
		this.subDeptId = subDeptId;
		this.subDeptNm = subDeptNm;
		this.deptId = deptId;
		this.shrtNm = shrtNm;
		this.creationDt = creationDt;
		this.status = status;
	}

	public SubDepartmentObject() {
		super();
	}
	
	
	
}
