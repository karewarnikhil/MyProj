package com.common.Utilities;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.web.servlet.view.AbstractView;
import org.springframework.web.servlet.view.document.AbstractXlsView;

import com.common.Objects.DepartmentObject;
import com.common.Objects.DepartmentReport;
import com.common.Objects.DocumentObject;
import com.common.Objects.ReportSearchObject;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRXlsAbstractExporterParameter;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimpleXlsxReportConfiguration;

public class ExcelDeptReportView  extends AbstractView {

	
	  private JasperReport departmentReport;
	  
	  @Override protected boolean generatesDownloadContent() { 
		  return true; 
      }
	  
	  @Override protected void renderMergedOutputModel(Map<String, Object> model,
	  HttpServletRequest request, HttpServletResponse response) throws Exception {
	   ReportSearchObject reportSearchObject = (ReportSearchObject) model.get("reportSearchObject");
	   List<DocumentObject> documentlist =  (List<DocumentObject>) model.get("documentlist");
	   List<DepartmentReport> departmentReportList =  (List<DepartmentReport>) model.get("departmentReportList"); //data source
	   
	   JRBeanCollectionDataSource ds = null;
   	   String reportName = null;
	   	if(documentlist != null) {
	   		reportName = "/digitizationReport.jrxml";
	   		ds = new JRBeanCollectionDataSource(documentlist);
	   	}
   		
	   	else if(departmentReportList != null) {
	   		reportName = "/summaryReport.jrxml";
	   		ds = new JRBeanCollectionDataSource(departmentReportList);
	   	}
	  
	  
	  
	  //compile jrxml template and get report 
	  JasperReport report = getReport(reportName);
	  
	  //Map to hold Jasper report Parameters 
	  Map<String, Object> parameters = new HashMap<String, Object>();
	  parameters.put("dataSource", ds);
	  if(reportSearchObject.getDeptId() > 0)
    	  parameters.put("deptId", DmsConstant.HASHMAP_OF_DEPARTMENT.get(reportSearchObject.getDeptId()));
      else
    	  parameters.put("deptId", "All Departments");
      parameters.put("dateFrom", reportSearchObject.getCreationFromDt());
      parameters.put("dateTo", reportSearchObject.getCreationToDt());
      parameters.put("imagePath", model.get("imagePath"));
      
	  JasperPrint jasperPrint = JasperFillManager.fillReport(report, parameters,new
	  JREmptyDataSource());
		
	  SimpleXlsxReportConfiguration reportConfig = new  SimpleXlsxReportConfiguration();
	  reportConfig.setSheetNames(new String[] { "Digitization Report" });
	  reportConfig.setCollapseRowSpan(false);
	  reportConfig.setRemoveEmptySpaceBetweenRows(false);
	  reportConfig.setRemoveEmptySpaceBetweenColumns(false);
	  reportConfig.setOnePagePerSheet(false); 
	  reportConfig.setDetectCellType(false);
	  reportConfig.setWhitePageBackground(false);
		 
	  JRXlsxExporter exporter = new JRXlsxExporter(); 
	  
	  exporter.setConfiguration(reportConfig); 
	  exporter.setExporterInput(new  SimpleExporterInput(jasperPrint)); 
	 
	  ByteArrayOutputStream excelReportStream =   new ByteArrayOutputStream();
	  exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(excelReportStream));
	  exporter.exportReport();
	  
	  
	  response.setContentType("application/vnd.ms-excel");
	  response.setHeader("Content-Length", String.valueOf(excelReportStream.size()));
	  response.setHeader("Content-Disposition","inline; filename=\"digitizationReport.xls\"");
	  
	  
	  OutputStream responseOutputStream = response.getOutputStream();
	  responseOutputStream.write(excelReportStream.toByteArray());
	  responseOutputStream.close(); 
	  excelReportStream.close();
	  logger.info("Completed Successfully:"); }
	  
	/*
	 * private JRDataSource getDataSource(List<DepartmentObject> departmentlist) {
	 * JRBeanCollectionDataSource ds = new
	 * JRBeanCollectionDataSource(departmentlist); return ds; }
	 */
	  
	  public JasperReport getReport(String reportName) throws JRException { 
		  InputStream stream = getClass().getResourceAsStream(reportName); 
		  departmentReport = JasperCompileManager.compileReport(stream); 
		  return departmentReport; 
	  }
	 
}
