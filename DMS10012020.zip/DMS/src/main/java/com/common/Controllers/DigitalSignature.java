package com.common.Controllers;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.PrivateKey;
import java.security.Security;
import java.security.cert.Certificate;

import org.bouncycastle.jce.provider.BouncyCastleProvider;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfAnnotation;
import com.itextpdf.text.pdf.PdfAppearance;
import com.itextpdf.text.pdf.PdfFormField;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfSignatureAppearance;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.security.BouncyCastleDigest;
import com.itextpdf.text.pdf.security.DigestAlgorithms;
import com.itextpdf.text.pdf.security.ExternalDigest;
import com.itextpdf.text.pdf.security.ExternalSignature;
import com.itextpdf.text.pdf.security.MakeSignature;
import com.itextpdf.text.pdf.security.MakeSignature.CryptoStandard;
import com.itextpdf.text.pdf.security.PrivateKeySignature;

public class DigitalSignature 
{
	
	public static final String KEYSTORE = "E:/DFD.pfx";
	public static final char[] PASSWORD = "123456".toCharArray();
	public static final String SRC = "E:/HATGADI.pdf";
	public static final String DEST = "E:/hello_HATGADI.pdf";
	public static final String SIGNAME = "Signature1";
	
	
			
			
	public static void main (String [] args) throws FileNotFoundException, IOException, GeneralSecurityException, DocumentException 
	{
		
		BouncyCastleProvider provider = new BouncyCastleProvider();
		Security.addProvider(provider);
		/*
		 * KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType()); ks.load(new
		 * FileInputStream(KEYSTORE), PASSWORD);
		 */
		
		KeyStore keyStore = null;
		try {
			/*
			 * keyStore = KeyStore.getInstance("PKCS11",provider); keyStore.load(null,
			 * pin.toCharArray());
			 */
			 keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
			 keyStore.load(new FileInputStream(KEYSTORE), PASSWORD);
		} catch (KeyStoreException e) {
			e.printStackTrace();
			
		}
		
		 java.util.Enumeration<String> aliases = keyStore.aliases();
		 String alias = null;
		 PrivateKey pk = (PrivateKey) keyStore.getKey(alias, PASSWORD);
	     Certificate[] chain = keyStore.getCertificateChain(alias);
		 while (aliases.hasMoreElements()) {
		       alias = aliases.nextElement();
				 System.out.println("alias=========="+alias);
				 //System.out.println("pk======="+pk);
		}
		 
       // X509Certificate cert = (X509Certificate)keyStore.getCertificate(alias);
      
        DigitalSignature digitalSignature = new DigitalSignature();
        digitalSignature.sign(SRC, String.format(DEST, 1), chain, pk, DigestAlgorithms.SHA256, provider.getName(), CryptoStandard.CMS, "Test 1", "Ghent");
       // digitalSignature.sign(SRC, String.format(DEST, 2), chain, pk, DigestAlgorithms.SHA512, provider.getName(), CryptoStandard.CMS, "Test 2", "Ghent");
        //digitalSignature.sign(SRC, String.format(DEST, 3), chain, pk, DigestAlgorithms.SHA256, provider.getName(), CryptoStandard.CADES, "Test 3", "Ghent");
        //digitalSignature.sign(SRC, String.format(DEST, 4), chain, pk, DigestAlgorithms.RIPEMD160, provider.getName(), CryptoStandard.CADES, "Test 4", "Ghent");
	}
		
	/* Simple hello word sign
	 public void sign(String src, String dest,
			Certificate[] chain,
			PrivateKey pk, String digestAlgorithm, String provider,
			CryptoStandard subfilter,
			String reason, String location)
					throws GeneralSecurityException, IOException, DocumentException {
        // Creating the reader and the stamper
        PdfReader reader = new PdfReader(src);
        FileOutputStream os = new FileOutputStream(dest);
        PdfStamper stamper = PdfStamper.createSignature(reader, os, '\0');
        // Creating the appearance
        PdfSignatureAppearance appearance = stamper.getSignatureAppearance();
        appearance.setReason(reason);
        appearance.setLocation(location);
        appearance.setVisibleSignature(new Rectangle(36, 748, 144, 780), 1, "sig");
      
        // Creating the signature
        ExternalDigest digest = new BouncyCastleDigest();
        ExternalSignature signature = new PrivateKeySignature(pk, digestAlgorithm, provider);
    
        MakeSignature.signDetached(appearance, digest, signature, chain, null, null, null, 0, subfilter);
	}
	
	//HelloSignTemp
	public void sign(String src, String tmp, String dest,
			Certificate[] chain, PrivateKey pk,
			String digestAlgorithm,  String provider,
			CryptoStandard subfilter,
			String reason, String location)
					throws GeneralSecurityException, IOException, DocumentException {
        // Creating the reader and the stamper
        PdfReader reader = new PdfReader(src);
        FileOutputStream os = new FileOutputStream(dest);
        PdfStamper stamper = PdfStamper.createSignature(reader, os, '\0', new File(tmp));
        // Creating the appearance
        PdfSignatureAppearance appearance = stamper.getSignatureAppearance();
        appearance.setReason(reason);
        appearance.setLocation(location);
        appearance.setVisibleSignature(new Rectangle(36, 748, 144, 780), 1, "sig");
        // Creating the signature
        ExternalSignature pks = new PrivateKeySignature(pk, digestAlgorithm, provider);
        ExternalDigest digest = new BouncyCastleDigest();
        MakeSignature.signDetached(appearance, digest, pks, chain, null, null, null, 0, subfilter);
	}
	*/
	
	/*
	 * 
	 *custom appearance
	 public void addField(String src, String dest) throws IOException, DocumentException {
	    	PdfReader reader = new PdfReader(src);
	    	PdfStamper stamper = new PdfStamper(reader, new FileOutputStream(dest));
	        // create a signature form field
	        PdfFormField field = PdfFormField.createSignature(stamper.getWriter());
	        field.setFieldName(SIGNAME);
	        // set the widget properties
	        field.setWidget(new Rectangle(72, 732, 144, 780), PdfAnnotation.HIGHLIGHT_OUTLINE);
	        field.setFlags(PdfAnnotation.FLAGS_PRINT);
	        // add the annotation
	        stamper.addAnnotation(field, 1);
	        // close the stamper
	    	stamper.close();
 	    }
	
	public void sign(String src, String name, String dest,
			Certificate[] chain, PrivateKey pk,
			String digestAlgorithm, String provider,
			CryptoStandard subfilter,
			String reason, String location)
					throws GeneralSecurityException, IOException, DocumentException {
        // Creating the reader and the stamper
        PdfReader reader = new PdfReader(src);
        FileOutputStream os = new FileOutputStream(dest);
        PdfStamper stamper = PdfStamper.createSignature(reader, os, '\0');
        // Creating the appearance
        PdfSignatureAppearance appearance = stamper.getSignatureAppearance();
        appearance.setReason(reason);
        appearance.setLocation(location);
        appearance.setVisibleSignature(name);
        // Creating the appearance for layer 0
        PdfTemplate n0 = appearance.getLayer(0);
        float x = n0.getBoundingBox().getLeft();
        float y = n0.getBoundingBox().getBottom();
        float width = n0.getBoundingBox().getWidth();
        float height = n0.getBoundingBox().getHeight();
        n0.setColorFill(BaseColor.LIGHT_GRAY);
        n0.rectangle(x, y, width, height);
        n0.fill();
        // Creating the appearance for layer 2
        PdfTemplate n2 = appearance.getLayer(2);
        ColumnText ct = new ColumnText(n2);
        ct.setSimpleColumn(n2.getBoundingBox());
        Paragraph p = new Paragraph("This document was signed by Bruno Specimen.");
        ct.addElement(p);
        ct.go();
        // Creating the signature
        ExternalSignature pks = new PrivateKeySignature(pk, digestAlgorithm, provider);
        ExternalDigest digest = new BouncyCastleDigest();
        MakeSignature.signDetached(appearance, digest, pks, chain, null, null, null, 0, subfilter);
	}*/
	
	
	public void sign1(String src, String name, String dest,
			Certificate[] chain, PrivateKey pk,
			String digestAlgorithm, String provider, CryptoStandard subfilter,
			String reason, String location)
					throws GeneralSecurityException, IOException, DocumentException {
        // Creating the reader and the stamper
        PdfReader reader = new PdfReader(src);
        FileOutputStream os = new FileOutputStream(dest);
        PdfStamper stamper = PdfStamper.createSignature(reader, os, '\0');
        // Creating the appearance
        PdfSignatureAppearance appearance = stamper.getSignatureAppearance();
        appearance.setReason(reason);
        appearance.setLocation(location);
        appearance.setVisibleSignature(name);
        // Custom text and custom font
        appearance.setLayer2Text("This document was signed by Bruno Specimen");
        appearance.setLayer2Font(new Font(FontFamily.TIMES_ROMAN));
        // Creating the signature
        PrivateKeySignature pks = new PrivateKeySignature(pk, digestAlgorithm, provider);
        ExternalDigest digest = new BouncyCastleDigest();
        MakeSignature.signDetached(appearance, digest, pks, chain, null, null, null, 0, subfilter);
	}
	
	
	public void sign2(String src, String name, String dest,
			Certificate[] chain, PrivateKey pk,
			String digestAlgorithm, String provider, CryptoStandard subfilter,
			String reason, String location)
					throws GeneralSecurityException, IOException, DocumentException {
        // Creating the reader and the stamper
        PdfReader reader = new PdfReader(src);
        FileOutputStream os = new FileOutputStream(dest);
        PdfStamper stamper = PdfStamper.createSignature(reader, os, '\0');
        // Creating the appearance
        PdfSignatureAppearance appearance = stamper.getSignatureAppearance();
        appearance.setReason(reason);
        appearance.setLocation(location);
        appearance.setVisibleSignature(name);
        // Custom text, custom font, and right-to-left writing
        appearance.setLayer2Text("\u0644\u0648\u0631\u0627\u0646\u0633 \u0627\u0644\u0639\u0631\u0628");
        appearance.setRunDirection(PdfWriter.RUN_DIRECTION_RTL);
       // appearance.setLayer2Font(new Font(BaseFont.createFont("C:/windows/fonts/arialuni.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED), 12));
        // Creating the signature
        PrivateKeySignature pks = new PrivateKeySignature(pk, digestAlgorithm, provider);
        ExternalDigest digest = new BouncyCastleDigest();
        MakeSignature.signDetached(appearance, digest, pks, chain, null, null, null, 0, subfilter);
	}
	
	public void sign(String src, String dest,
			Certificate[] chain, PrivateKey pk, String digestAlgorithm, String provider,
			CryptoStandard subfilter, String reason, String location)
			throws GeneralSecurityException, IOException, DocumentException {
		    
		    float width = 160;
		    float height = 40;
		    
			// Creating the reader and the stamper
			PdfReader reader = new PdfReader(src);
			
			FileOutputStream os = new FileOutputStream(dest);
			PdfStamper stamper = PdfStamper.createSignature(reader, os, '\0');
			
			// Creating the appearance
			
			PdfSignatureAppearance appearance = stamper.getSignatureAppearance();
		//	appearance.setCrypto(key, chain, null, PdfSignatureAppearance.WINCER_SIGNED);
			appearance.setReason(reason);
			appearance.setLocation(location);
		    //appearance.setVisibleSignature(new Rectangle(36, 748, 144, 780), pageNo, "Signature2");
			
			// Bottom right
			Rectangle cropBox =  reader.getCropBox(reader.getNumberOfPages());
			Rectangle rectangle = new Rectangle(cropBox.getRight(width), cropBox.getBottom(),cropBox.getRight(), cropBox.getBottom(height));
			                              
			appearance.setVisibleSignature(rectangle, reader.getNumberOfPages(), "Signature1");
			// Creating the signature
			ExternalDigest digest = new BouncyCastleDigest();
			ExternalSignature signature = new PrivateKeySignature(pk, digestAlgorithm, provider);
			
			MakeSignature.signDetached(appearance, digest, signature, chain,
			null, null, null, 0, subfilter);
	}
	
	public void createPdf(String filename) throws IOException, DocumentException {
    	// step 1: Create a Document
        Document document = new Document();
        // step 2: Create a PdfWriter
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(filename));
        // step 3: Open the Document
        document.open();
        // step 4: Add content
        document.add(new Paragraph("Hello World!"));
        // create a signature form field
        PdfFormField field = PdfFormField.createSignature(writer);
        field.setFieldName(SIGNAME);
        // set the widget properties
        field.setPage();
        field.setWidget(new Rectangle(72, 732, 144, 780), PdfAnnotation.HIGHLIGHT_OUTLINE);
        field.setFlags(PdfAnnotation.FLAGS_PRINT);
        // add it as an annotation
        writer.addAnnotation(field);
        // maybe you want to define an appearance
        PdfAppearance tp = PdfAppearance.createAppearance(writer, 72, 48);
        tp.setColorStroke(BaseColor.BLUE);
        tp.setColorFill(BaseColor.LIGHT_GRAY);
        tp.rectangle(0.5f, 0.5f, 71.5f, 47.5f);
        tp.fillStroke();
        tp.setColorFill(BaseColor.BLUE);
        ColumnText.showTextAligned(tp, Element.ALIGN_CENTER, new Phrase("SIGN HERE"), 36, 24, 25);
        field.setAppearance(PdfAnnotation.APPEARANCE_NORMAL, tp);
        // step 5: Close the Document
        document.close();
    }
	
	
	
	
	
	
	
	
	//dot new digital signature
	
	
	/*
	 * pdfStamp = new PdfStamper(pdfReader, outStream, (char)0, true);
	 * 
	 * var rect = new iTextSharp.text.Rectangle((float)x, (float)y, (float)x +
	 * width, (float)y + height);
	 * 
	 * // Generating the annotation's appearance using a TextField TextField
	 * textField = new TextField(pdfStamp.Writer, rect, null); textField.Text =
	 * contents; textField.FontSize = 8; textField.TextColor = BaseColor.DARK_GRAY;
	 * textField.BackgroundColor = new BaseColor(Color.LightGoldenrodYellow);
	 * textField.BorderColor = new BaseColor(Color.BurlyWood); textField.Options =
	 * TextField.MULTILINE; textField.SetExtraMargin(2f, 2f); textField.Alignment =
	 * Element.ALIGN_TOP | Element.ALIGN_LEFT; PdfAppearance appearance =
	 * textField.GetAppearance();
	 * 
	 * // Create the annotation PdfAnnotation annotation =
	 * PdfAnnotation.CreateFreeText(pdfStamp.Writer, rect, null, new
	 * PdfContentByte(null)); annotation.SetAppearance(PdfName.N, appearance);
	 * annotation.Flags = PdfAnnotation.FLAGS_READONLY | PdfAnnotation.FLAGS_LOCKED
	 * | PdfAnnotation.FLAGS_PRINT; annotation.Put(PdfName.NM, new
	 * PdfString(Guid.NewGuid().ToString()));
	 * 
	 * // Add annotation to PDF pdfStamp.AddAnnotation(annotation, pageNum);
	 * pdfStamp.Close();
	 */
	
	
	/*
	 * //Creates a new PDF document PdfDocument document = new PdfDocument(); //Adds
	 * a new page PdfPageBase page = document.Pages.Add(); PdfGraphics graphics =
	 * page.Graphics; //Creates a certificate instance from PFX file with the
	 * private key PdfCertificate pdfCert = new PdfCertificate(@"PDF.pfx",
	 * "syncfusion"); //Creates a digital signature PdfSignature signature = new
	 * PdfSignature(document, page, pdfCert, "Signature"); //Sets an image for
	 * signature field PdfBitmap signatureImage = new PdfBitmap(@"signature.png");
	 * //Sets signature information signature.Bounds = new RectangleF(0,0,200,100);
	 * signature.ContactInfo = "johndoe@owned.us"; signature.LocationInfo =
	 * "Honolulu, Hawaii"; signature.Reason = "I am author of this document.";
	 * //Create appearance for the digital signature
	 * signature.Appearance.Normal.Graphics.DrawImage(signatureImage,
	 * signature.Bounds); //Save the document document.Save("DigitalSignature.pdf");
	 * //Close the document document.Close(true); //This will open the PDF file so,
	 * the result will be seen in default PDF viewer
	 * Process.Start("DigitalSignature.pdf");
	 */
	
	
	/*
	 * public void Sign1(String src, String name, String dest,
	 * ICollection<X509Certificate> chain, ICipherParameters pk, String
	 * digestAlgorithm, CryptoStandard subfilter, String reason, String location) {
	 * // Creating the reader and the stamper PdfReader reader = new PdfReader(src);
	 * FileStream os = new FileStream(dest, FileMode.Create); PdfStamper stamper =
	 * PdfStamper.CreateSignature(reader, os, '\0'); // Creating the appearance
	 * PdfSignatureAppearance appearance = stamper.SignatureAppearance;
	 * appearance.Reason = reason; appearance.Location = location;
	 * appearance.SetVisibleSignature(name); // Custom text and custom font
	 * appearance.Layer2Text = "This document was signed by ABC";
	 * appearance.Layer2Font = new
	 * iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN); //
	 * Creating the signature IExternalSignature pks = new PrivateKeySignature(pk,
	 * digestAlgorithm); MakeSignature.SignDetached(appearance, pks, chain, null,
	 * null, null, 0, subfilter); }
	 */
	
	/*
	 * String KEYSTORE = "C:/Users/user/Desktop/temp.pfx"; char[] PASSWORD =
	 * "blabla".ToCharArray(); String SRC = "C:/Users/user/abc.pdf"; String DEST =
	 * "C:/Users/user/Desktop/aaa.pdf"; Pkcs12Store store = new Pkcs12Store(new
	 * FileStream(KEYSTORE, FileMode.Open), PASSWORD); String alias = "";
	 * ICollection<X509Certificate> chain = new List<X509Certificate>(); //
	 * searching for private key
	 * 
	 * foreach (string al in store.Aliases) if (store.IsKeyEntry(al) &&
	 * store.GetKey(al).Key.IsPrivate) { alias = al; break; }
	 * 
	 * AsymmetricKeyEntry pk = store.GetKey(alias); foreach (X509CertificateEntry c
	 * in store.GetCertificateChain(alias)) chain.Add(c.Certificate);
	 * 
	 * RsaPrivateCrtKeyParameters parameters = pk.Key as RsaPrivateCrtKeyParameters;
	 * Sign1(SRC, "Signature1", String.Format(DEST, 1), chain, parameters,
	 * DigestAlgorithms.SHA256, CryptoStandard.CMS, "Customize apprearance",
	 * "Blabla");
	 */
	
	

	/*
	 * IExternalSignature externalSignature = new X509Certificate2Signature(cert,
	 * DigestAlgorithms.SHA256);
	 * 
	 * PdfReader pathToBasePdf = new PdfReader("c:\\memo_0.pdf"); PdfReader
	 * pdfReader = new PdfReader(pathToBasePdf); FileStream signedPdf = new
	 * FileStream("c:\\memo_00.pdf", FileMode.Create);
	 * 
	 * 
	 * PdfStamper pdfStamper = PdfStamper.CreateSignature(pdfReader, signedPdf,
	 * '\0', null, true); //add annotation start //free text comment var pcb = new
	 * iTextSharp.text.pdf.PdfContentByte(pdfStamper.Writer);
	 * pcb.SetColorFill(iTextSharp.text.BaseColor.MAGENTA);
	 * pcb.SetColorStroke(iTextSharp.text.BaseColor.BLUE);
	 * 
	 * 
	 * PdfAnnotation comment = PdfAnnotation.CreateFreeText(pdfStamper.Writer, new
	 * Rectangle(0, 560, 260, 580), "The case is reviewed and approved.", pcb);
	 * comment.Rotate = pathToBasePdf.GetPageRotation(1); comment.PlaceInPage = 1;
	 * comment.Flags = iTextSharp.text.pdf.PdfAnnotation.FLAGS_PRINT; comment.Flags
	 * = iTextSharp.text.pdf.PdfAnnotation.FLAGS_READONLY; comment.Title = "hello";
	 * PdfDate pdfdate = new PdfDate(); comment.Put(PdfName.CREATIONDATE, pdfdate);
	 * comment.Put(PdfName.M, pdfdate); comment.GetHashCode();
	 * pdfStamper.AddAnnotation(comment, 1);
	 * 
	 * 
	 * //add annotation end
	 * 
	 * PdfSignatureAppearance signatureAppearance = pdfStamper.SignatureAppearance;
	 * //digital signature signatureAppearance.SetVisibleSignature(new
	 * Rectangle(300, 250, 450, 401), pdfReader.NumberOfPages, null);
	 * signatureAppearance.SignatureRenderingMode =
	 * PdfSignatureAppearance.RenderingMode.GRAPHIC_AND_DESCRIPTION;
	 * 
	 * 
	 * 
	 * signatureAppearance.SignatureGraphic = Image.GetInstance("C:\\TEST.jpg");
	 * signatureAppearance.SignatureGraphic.Alignment = Image.ALIGN_RIGHT;
	 * signatureAppearance.CertificationLevel = 0; Rectangle rect = new
	 * iTextSharp.text.Rectangle(300, 250, 450, 401); rect.BackgroundColor = new
	 * BaseColor(255, 0, 0); rect.BorderColor = BaseColor.BLUE; rect.GrayFill = 1;
	 * rect.BorderWidth = 1;
	 * 
	 * signatureAppearance.SetVisibleSignature(rect, 1, null);
	 * 
	 * signatureAppearance.SignDate = System.DateTime.Now;
	 * 
	 * 
	 * signatureAppearance.Reason = null; signatureAppearance.Location = null;
	 * signatureAppearance.Contact = null; signatureAppearance.Acro6Layers = true;
	 * 
	 * //------------ PdfTemplate n0 = signatureAppearance.GetLayer(0); float x =
	 * n0.BoundingBox.Left; float y = n0.BoundingBox.Bottom; float width =
	 * n0.BoundingBox.Width; float height = n0.BoundingBox.Height;
	 * n0.SetColorFill(BaseColor.YELLOW); n0.Rectangle(x, y, width, height);
	 * n0.Fill();
	 * 
	 * //-----------
	 * 
	 * 
	 * 
	 * List<Org.BouncyCastle.X509.X509Certificate> certa = new
	 * List<Org.BouncyCastle.X509.X509Certificate>(chain); ICollection<byte[]>
	 * crlBytes = null; int i = 0;
	 * 
	 * int estimatedSize = 8192; if (crlBytes != null) { foreach (byte[] element in
	 * crlBytes) { estimatedSize += element.Length + 10; } }
	 * signatureAppearance.Certificate = certa[0]; PdfSignature dic = new
	 * PdfSignature(PdfName.ADOBE_PPKLITE, PdfName.ADBE_PKCS7_DETACHED); dic.Reason
	 * = signatureAppearance.Reason; dic.Location = signatureAppearance.Location;
	 * dic.Contact = signatureAppearance.Contact; dic.Date = new
	 * PdfDate(signatureAppearance.SignDate); // time-stamp will over-rule this
	 * signatureAppearance.CryptoDictionary = dic;
	 * 
	 * Dictionary<PdfName, int> exc = new Dictionary<PdfName, int>();
	 * exc[PdfName.CONTENTS] = estimatedSize * 2 + 2;
	 * signatureAppearance.PreClose(exc);
	 * 
	 * String hashAlgorithm = externalSignature.GetHashAlgorithm(); PdfPKCS7 sgn =
	 * new PdfPKCS7(null, chain, hashAlgorithm, false);
	 * 
	 * 
	 * 
	 * IDigest messageDigest = DigestUtilities.GetDigest(hashAlgorithm); Stream data
	 * = signatureAppearance.GetRangeStream(); byte[] hash =
	 * DigestAlgorithms.Digest(data, hashAlgorithm); DateTime cal = DateTime.Now;
	 * byte[] ocsp = null;
	 * 
	 * byte[] sh = sgn.getAuthenticatedAttributeBytes(hash, cal, null, crlBytes,
	 * CryptoStandard.CMS);
	 * 
	 * 
	 * 
	 * RSACryptoServiceProvider rsacsp = (RSACryptoServiceProvider)cert.PrivateKey;
	 * CspParameters cspParam = new CspParameters(); cspParam.KeyContainerName =
	 * rsacsp.CspKeyContainerInfo.KeyContainerName; cspParam.KeyNumber =
	 * rsacsp.CspKeyContainerInfo.KeyNumber == KeyNumber.Exchange ? 1 : 2;
	 * RSACryptoServiceProvider aescsp = new RSACryptoServiceProvider(cspParam);
	 * byte[] extSignature = aescsp.SignData(sh, "SHA256");
	 * 
	 * 
	 * sgn.SetExternalDigest(extSignature, null,
	 * externalSignature.GetEncryptionAlgorithm());
	 * 
	 * byte[] encodedSig = sgn.GetEncodedPKCS7(hash, cal, null, null, crlBytes,
	 * CryptoStandard.CMS);
	 * 
	 * if (estimatedSize < encodedSig.Length) throw new
	 * IOException("Not enough space");
	 * 
	 * byte[] paddedSig = new byte[estimatedSize]; System.Array.Copy(encodedSig, 0,
	 * paddedSig, 0, encodedSig.Length);
	 * 
	 * PdfDictionary dic2 = new PdfDictionary(); dic2.Put(PdfName.CONTENTS, new
	 * PdfString(paddedSig).SetHexWriting(true)); signatureAppearance.Close(dic2);
	 */
	
	
	
	//Now we just need to do something with those bytes.
    //Here I'm writing them to disk but if you were in ASP.Net you might Response.BinaryWrite() them.
    //You could also write the bytes to a database in a varbinary() column (but please don't) or you
    //could pass them to another function for further PDF processing.
	/*
	 * var testFile =
	 * Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
	 * "test.pdf"); System.IO.File.WriteAllBytes(testFile, bytes);
	 * //=================== GeneratorKey(); //===================
	 * 
	 * Stream fs = File.OpenRead(@"F:/PROJECTS/WebSite6/HTML/TestCert.pfx");
	 * 
	 * string sourceDocument = testFile; string destinationPath =
	 * testFile.Replace(".pdf", "_signed.pdf"); Stream privateKeyStream = fs; string
	 * keyPassword = "123"; string reason = "I am an Author"; string location =
	 * "Mumbai";
	 * 
	 * _Default.signPdfFile(sourceDocument, destinationPath, privateKeyStream,
	 * keyPassword, reason, location);
	 * 
	 * fs.Close(); }
	 * 
	 * private void GeneratorKey() { // Keypair Generator RsaKeyPairGenerator
	 * kpGenerator = new RsaKeyPairGenerator(); kpGenerator.Init(new
	 * KeyGenerationParameters(new SecureRandom(), 2048));
	 * 
	 * // Create a keypair AsymmetricCipherKeyPair kp =
	 * kpGenerator.GenerateKeyPair();
	 * 
	 * // Certificate Generator X509V3CertificateGenerator cGenerator = new
	 * X509V3CertificateGenerator();
	 * cGenerator.SetSerialNumber(BigInteger.ProbablePrime(120, new Random()));
	 * cGenerator.SetSubjectDN(new X509Name("CN=" + "domain.com"));
	 * cGenerator.SetIssuerDN(new X509Name("CN=" + "Amit"));
	 * cGenerator.SetNotBefore(DateTime.Now);
	 * cGenerator.SetNotAfter(DateTime.Now.Add(new TimeSpan(365, 0, 0, 0))); //
	 * Expire in 1 year
	 * cGenerator.SetSignatureAlgorithm(HashType.SHA256withRSA.ToString()); // See
	 * the Appendix Below for info on the hash types supported by Bouncy Castle C#
	 * cGenerator.SetPublicKey(kp.Public); // Only the public key should be used
	 * here! X509Certificate cert = cGenerator.Generate(kp.Private); // Create a
	 * self-signed cert
	 * 
	 * byte[] encoded = cert.GetEncoded(); using (FileStream outStream = new
	 * FileStream("F:/PROJECTS/WebSite6/HTML/TestCert.der", FileMode.Create,
	 * FileAccess.ReadWrite)) { outStream.Write(encoded, 0, encoded.Length); }
	 * 
	 * // Create the PKCS12 store Pkcs12Store store = new
	 * Pkcs12StoreBuilder().Build();
	 * 
	 * // Add a Certificate entry X509CertificateEntry certEntry = new
	 * X509CertificateEntry(cert);
	 * store.SetCertificateEntry(cert.SubjectDN.ToString(), certEntry); // use DN as
	 * the Alias.
	 * 
	 * // Add a key entry AsymmetricKeyEntry keyEntry = new
	 * AsymmetricKeyEntry(kp.Private); store.SetKeyEntry(cert.SubjectDN.ToString() +
	 * "_key", keyEntry, new X509CertificateEntry[] { certEntry }); // Note that we
	 * only have 1 cert in the 'chain'
	 * 
	 * // Save to the file system using (var filestream = new
	 * FileStream(@"F:/PROJECTS/WebSite6/HTML/TestCert.pfx", FileMode.Create,
	 * FileAccess.ReadWrite)) { store.Save(filestream, "123".ToCharArray(), new
	 * SecureRandom()); } }
	 * 
	 * public static void signPdfFile(string sourceDocument, string destinationPath,
	 * Stream privateKeyStream, string keyPassword, string reason, string location)
	 * { Pkcs12Store pk12 = new Pkcs12Store(privateKeyStream,
	 * keyPassword.ToCharArray()); privateKeyStream.Dispose();
	 * 
	 * //then Iterate throught certificate entries to find the private key entry
	 * string alias = null; foreach (string tAlias in pk12.Aliases) { if
	 * (pk12.IsKeyEntry(tAlias)) { alias = tAlias; break; } }
	 * 
	 * var pk = pk12.GetKey(alias).Key; // reader and stamper PdfReader reader = new
	 * PdfReader(sourceDocument); using (FileStream fout = new
	 * FileStream(destinationPath, FileMode.Create, FileAccess.ReadWrite)) { using
	 * (PdfStamper stamper = PdfStamper.CreateSignature(reader, fout, '\0')) { //
	 * appearance PdfSignatureAppearance appearance = stamper.SignatureAppearance;
	 * //appearance.Image = new iTextSharp.text.pdf.PdfImage(); appearance.Reason =
	 * reason; appearance.Location = location; appearance.SetVisibleSignature(new
	 * iTextSharp.text.Rectangle(20, 10, 170, 60), 1, "Icsi-Vendor"); // digital
	 * signature IExternalSignature es = new PrivateKeySignature(pk, "SHA-256");
	 * MakeSignature.SignDetached(appearance, es, new X509Certificate[] {
	 * pk12.GetCertificate(alias).Certificate }, null, null, null, 0,
	 * CryptoStandard.CMS); stamper.Close(); } } }
	 */

}