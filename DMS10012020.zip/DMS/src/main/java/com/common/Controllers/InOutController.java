package com.common.Controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.common.Dao.InOutDao;
import com.common.Objects.CompartmentObject;
import com.common.Objects.RackObject;
import com.common.Objects.ShelfObject;
import com.common.Objects.UsersObject;

@Controller
public class InOutController {
	
	@Autowired
	InOutDao inOutDao;

	@RequestMapping(value = "/manageRack", method = RequestMethod.GET)
	public String getRackForm(Model model,HttpServletRequest request) {
		UsersObject usersObject = (UsersObject) request.getSession().getAttribute("users");
		if (usersObject != null) {
			if (usersObject.getAccessObject().isAdd() == true) {
				model.addAttribute("rackObject", new RackObject());
				model.addAttribute("rackList",inOutDao.getAllRacks());
				return "manageRack";
			}else {
				model.addAttribute("error", "You Don't have authorize to do this functionality.");
				return "defaultPage";
			}
		}
		else {
			return "loginIn";
		}
	}
	
	
	@RequestMapping(value = "/saveRack", method = RequestMethod.POST)
	public String saveList(@ModelAttribute("rackObject") RackObject rackObject, Model model, HttpServletRequest request) {
		UsersObject usersObject = (UsersObject) request.getSession().getAttribute("users");
		if (usersObject != null) {
			inOutDao.saveRackObject(rackObject);
			model.addAttribute("message", "Rack number added successfully.");
			model.addAttribute("rackObject", new RackObject());
			model.addAttribute("rackList",inOutDao.getAllRacks());
			return "manageRack";
		}else {
			return "loginIn";
		}
		
	}
	
	
	@RequestMapping(value = "/manageShelf", method = RequestMethod.GET)
	public String getShelfForm(Model model,HttpServletRequest request) {
		UsersObject usersObject = (UsersObject) request.getSession().getAttribute("users");
		if (usersObject != null) {
			if (usersObject.getAccessObject().isAdd() == true) {
				model.addAttribute("shelfObject", new ShelfObject());
				model.addAttribute("rackList",inOutDao.getAllRacks());
				model.addAttribute("shelfList",inOutDao.getAllShelf());
				return "manageShelf";
			}else {
				model.addAttribute("error", "You Don't have authorize to do this functionality.");
				return "defaultPage";
			}
		}
		else {
			return "loginIn";
		}
	}
	
	@RequestMapping(value = "/saveShelf", method = RequestMethod.POST)
	public String saveShelf(@ModelAttribute("shelfObject") ShelfObject shelfObject, Model model, HttpServletRequest request) {
		UsersObject usersObject = (UsersObject) request.getSession().getAttribute("users");
		if (usersObject != null) {
			inOutDao.saveShelfObject(shelfObject);
			model.addAttribute("message", "Shelf added successfully.");
			model.addAttribute("shelfObject", new ShelfObject());
			model.addAttribute("rackList",inOutDao.getAllRacks());
			model.addAttribute("shelfList",inOutDao.getAllShelf());
			return "manageShelf";
		}else {
			return "loginIn";
		}
	}
	
	@RequestMapping(value = "/manageCompartment", method = RequestMethod.GET)
	public String getCompartmentForm(Model model,HttpServletRequest request) {
		UsersObject usersObject = (UsersObject) request.getSession().getAttribute("users");
		if (usersObject != null) {
			if (usersObject.getAccessObject().isAdd() == true) {
				model.addAttribute("compartObject", new CompartmentObject());
				model.addAttribute("rackList",inOutDao.getAllRacks());
				model.addAttribute("shelfList",inOutDao.getAllShelf());
				return "manageCompartment";
			}else {
				model.addAttribute("error", "You Don't have authorize to do this functionality.");
				return "defaultPage";
			}
		}
		else {
			return "loginIn";
		}
	}
	
	 @RequestMapping(value = "/getShelfDropDown", method = RequestMethod.GET, produces = "application/json")
		public @ResponseBody List<ShelfObject> getShelfDropDown(@RequestParam("rackId") int rackId) {
		    List<ShelfObject> shelfList = inOutDao.getShelfByRackAndROP(rackId);
			return shelfList;
		}
}
