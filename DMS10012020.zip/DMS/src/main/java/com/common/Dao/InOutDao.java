package com.common.Dao;

import java.util.List;

import com.common.Objects.RackObject;
import com.common.Objects.ShelfObject;

public interface InOutDao {
  
	public void saveRackObject(RackObject rackObject);
	
	public void saveShelfObject(ShelfObject shelfObject);

	public List<RackObject> getAllRacks();
	
	public List<ShelfObject> getAllShelf();

	public List<ShelfObject> getShelfByRackAndROP(int rackId);
     
}
