package com.common.DaoImpl;

import java.util.HashMap;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.GroupDao;
import com.common.Objects.GroupObject;

@Repository
@Transactional
public class GroupDaoImpl implements GroupDao{
	@Autowired
	private SessionFactory sessionFactory;
	
	
	/*public List<GroupObject> getAllGroupObject() {
		return sessionFactory.getCurrentSession().createQuery(" FROM GroupObject ").list();
	}*/


	public GroupObject getGroupByString(String main) {
		 return (GroupObject)sessionFactory.getCurrentSession().createQuery("FROM GroupObject where groupNm='"+main+"'").uniqueResult();
	}


	public GroupObject getGroupById(int grpId) {
		 return (GroupObject)sessionFactory.getCurrentSession().createQuery("FROM GroupObject where groupId="+grpId).uniqueResult();
	}


	@Override
	public HashMap<Long, String> getHashmapofGroupObject() {
		HashMap<Long, String> hashMapofGroup = new HashMap<>();
		List<GroupObject> getAllGroupObject = sessionFactory.getCurrentSession().createQuery(" FROM GroupObject ").list();
		for(GroupObject groupObject:getAllGroupObject) {
			hashMapofGroup.put((long)groupObject.getGroupId(), groupObject.getGroupNm());
		}
		hashMapofGroup.values().stream().forEach(System.out::println);
		return hashMapofGroup;
	}

}
