package com.common.DaoImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.InOutDao;
import com.common.Objects.RackObject;
import com.common.Objects.ShelfObject;

@Repository
@Transactional
public class InOutDaoImpl implements InOutDao{
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void saveRackObject(RackObject rackObject) {
		sessionFactory.getCurrentSession().saveOrUpdate(rackObject);
	}

	@Override
	public List<RackObject> getAllRacks() {
		return sessionFactory.getCurrentSession().createQuery("FROM RackObject order by rackId asc").list();
	}

	@Override
	public void saveShelfObject(ShelfObject shelfObject) {
		sessionFactory.getCurrentSession().saveOrUpdate(shelfObject);
		
	}

	@Override
	public List<ShelfObject> getAllShelf() {
		return sessionFactory.getCurrentSession().createQuery("FROM ShelfObject order by shelfId asc").list();
	}

	@Override
	public List<ShelfObject> getShelfByRackAndROP(int rackId) {
		List<ShelfObject> getShelfList = sessionFactory.getCurrentSession().createQuery(" SELECT new ShelfObject (sh.shelfId ,sh.shelfNo )FROM ShelfObject sh where sh.rackId= :rackId order by sh.shelfNo").setParameter("rackId",rackId).list();
		return getShelfList;	 
	}

}
