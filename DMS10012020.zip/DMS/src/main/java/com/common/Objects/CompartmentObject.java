package com.common.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

@Entity @Table(name="compartMst")
public class CompartmentObject {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "compId", updatable = false, nullable = false)
	private int compId;

	@Column(name = "compNo")
	private String compNo;
	
	@JoinColumn(name="rackId", referencedColumnName="rackId")
	private int rackId;
	
	@JoinColumn(name="shelfId", referencedColumnName="shelfId")
	private int shelfId;

	public int getCompId() {
		return compId;
	}

	public void setCompId(int compId) {
		this.compId = compId;
	}

	public String getCompNo() {
		return compNo;
	}

	public void setCompNo(String compNo) {
		this.compNo = compNo;
	}

	public int getRackId() {
		return rackId;
	}

	public void setRackId(int rackId) {
		this.rackId = rackId;
	}

	public int getShelfId() {
		return shelfId;
	}

	public void setShelfId(int shelfId) {
		this.shelfId = shelfId;
	}

	public CompartmentObject(int compId, String compNo, int rackId, int shelfId) {
		super();
		this.compId = compId;
		this.compNo = compNo;
		this.rackId = rackId;
		this.shelfId = shelfId;
	}

	public CompartmentObject() {
		super();
	}
	
	
}
