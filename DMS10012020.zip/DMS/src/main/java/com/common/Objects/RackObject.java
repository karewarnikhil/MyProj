package com.common.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity @Table(name="rackmst")
public class RackObject {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "rackId", updatable = false, nullable = false)
	private int rackId;

	@Column(name = "rackNo")
	private String rackNo;

	public int getRackId() {
		return rackId;
	}

	public void setRackId(int rackId) {
		this.rackId = rackId;
	}

	public String getRackNo() {
		return rackNo;
	}

	public void setRackNo(String rackNo) {
		this.rackNo = rackNo;
	}

	public RackObject(int rackId, String rackNo) {
		super();
		this.rackId = rackId;
		this.rackNo = rackNo;
	}

	public RackObject() {
		super();
	}

}
