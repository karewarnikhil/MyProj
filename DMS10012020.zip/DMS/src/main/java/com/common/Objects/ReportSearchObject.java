package com.common.Objects;

import java.io.Serializable;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class ReportSearchObject implements Serializable{

	
	
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	

	private  Long deptId;
	
	private  Integer subDeptId;
	
	private  Long tagGrpId;
	
	
	private String creationFromDt;
	
	
	private String creationToDt;
	
	 @DateTimeFormat(pattern="yyyy-MM-dd")
	 private Date creationFromTs;

	
	 @DateTimeFormat(pattern="yyyy-MM-dd")
	 private Date creationToTs;
	
	public Long getDeptId() {
		return deptId;
	}

	public void setDeptId(Long deptId) {
		this.deptId = deptId;
	}

	public String getCreationFromDt() {
		return creationFromDt;
	}

	public void setCreationFromDt(String creationFromDt) {
		this.creationFromDt = creationFromDt;
	}

	public String getCreationToDt() {
		return creationToDt;
	}

	public void setCreationToDt(String creationToDt) {
		this.creationToDt = creationToDt;
	}
	
	public Date getCreationFromTs() {
		return creationFromTs;
	}

	public void setCreationFromTs(Date creationFromTs) {
		this.creationFromTs = creationFromTs;
	}

	public Date getCreationToTs() {
		return creationToTs;
	}

	public void setCreationToTs(Date creationToTs) {
		this.creationToTs = creationToTs;
	}

	public Long getTagGrpId() {
		return tagGrpId;
	}

	public void setTagGrpId(Long tagGrpId) {
		this.tagGrpId = tagGrpId;
	}
	
	public Integer getSubDeptId() {
		return subDeptId;
	}

	public void setSubDeptId(Integer subDeptId) {
		this.subDeptId = subDeptId;
	}

	public ReportSearchObject() {
		super();
	}

	public ReportSearchObject(Long deptId, Integer subDeptId, Long tagGrpId, String creationFromDt, String creationToDt,
			Date creationFromTs, Date creationToTs) {
		super();
		this.deptId = deptId;
		this.subDeptId = subDeptId;
		this.tagGrpId = tagGrpId;
		this.creationFromDt = creationFromDt;
		this.creationToDt = creationToDt;
		this.creationFromTs = creationFromTs;
		this.creationToTs = creationToTs;
	}


}
