package com.common.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

@Entity @Table(name="shelfmst")
public class ShelfObject {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "shelfId", updatable = false, nullable = false)
	private int shelfId;

	@Column(name = "shelfNo")
	private String shelfNo;
	
	@JoinColumn(name="rackId", referencedColumnName="rackId")
	private int rackId;

	public int getShelfId() {
		return shelfId;
	}

	public void setShelfId(int shelfId) {
		this.shelfId = shelfId;
	}

	public String getShelfNo() {
		return shelfNo;
	}

	public void setShelfNo(String shelfNo) {
		this.shelfNo = shelfNo;
	}

	public int getRackId() {
		return rackId;
	}

	public void setRackId(int rackId) {
		this.rackId = rackId;
	}

	public ShelfObject() {
		super();
	}

	public ShelfObject(int shelfId, String shelfNo, int rackId) {
		super();
		this.shelfId = shelfId;
		this.shelfNo = shelfNo;
		this.rackId = rackId;
	}

	public ShelfObject(int shelfId, String shelfNo) {
		super();
		this.shelfId = shelfId;
		this.shelfNo = shelfNo;
	}
	
}
