package com.common.Dao;

import java.util.List;

import com.common.Objects.DocumentObject;

public interface DocumentDao {
	
	List<DocumentObject> getAllDocuments();
    
    DocumentObject findByFileId(long fileId);
     
    void save(DocumentObject documentObject);
     
    List<DocumentObject> findAllByFolderId(long folderId);
     
    void deleteById(int id);
}
