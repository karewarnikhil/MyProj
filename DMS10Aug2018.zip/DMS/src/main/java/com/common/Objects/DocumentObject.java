package com.common.Objects;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

  @Entity @Table(name="FileMst")
public class DocumentObject implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	    @Column(name="fileId",updatable = false, nullable = false)
	    private long fileId; 
	     
	    @Column(name="fileName")
	    private String fileName;
	     
	    @Column(name="discription")
	    private String description;
	     
	    @Column(name="type")
	    private String fileType;
	    
	    @Column(name="creationDt")
		private Timestamp creationDt;
	     
	   
	    @Column(name="content")
	    private byte[] fileContent;
	 
	    @Column(name="createdby")
		private int createdBy;
	    
	   
	    @Column(name = "folderid")
	    private long folderId;

		public DocumentObject() {
			super();
		}

		public long getFolderId() {
			return folderId;
		}

		public void setFolderId(long folderId) {
			this.folderId = folderId;
		}

		public DocumentObject(long fileId, String fileName, String description, String fileType, Timestamp creationDt,
				byte[] fileContent, int createdBy, long folderId) {
			super();
			this.fileId = fileId;
			this.fileName = fileName;
			this.description = description;
			this.fileType = fileType;
			this.creationDt = creationDt;
			this.fileContent = fileContent;
			this.createdBy = createdBy;
			this.folderId = folderId;
		}

		public long getFileId() {
			return fileId;
		}
		public void setFileId(long fileId) {
			this.fileId = fileId;
		}
		public String getFileName() {
			return fileName;
		}

		public void setFileName(String fileName) {
			this.fileName = fileName;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		public String getFileType() {
			return fileType;
		}

		public void setFileType(String fileType) {
			this.fileType = fileType;
		}

		public Timestamp getCreationDt() {
			return creationDt;
		}

		public void setCreationDt(Timestamp creationDt) {
			this.creationDt = creationDt;
		}

		public byte[] getFileContent() {
			return fileContent;
		}

		public void setFileContent(byte[] fileContent) {
			this.fileContent = fileContent;
		}

		public int getCreatedBy() {
			return createdBy;
		}

		public void setCreatedBy(int createdBy) {
			this.createdBy = createdBy;
		}

		

		

}
