package com.common.Objects;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

public class FileBucket {
	
	private List<MultipartFile> listOfMultipartFile;
	private String description;
	
    private long folderId;


	public List<MultipartFile> getListOfMultipartFile() {
		return listOfMultipartFile;
	}

	public void setListOfMultipartFile(List<MultipartFile> listOfMultipartFile) {
		this.listOfMultipartFile = listOfMultipartFile;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public long getFolderId() {
		return folderId;
	}

	public void setFolderId(long folderId) {
		this.folderId = folderId;
	}

	
	
}
