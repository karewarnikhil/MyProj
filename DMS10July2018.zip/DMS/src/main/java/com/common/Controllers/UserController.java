package com.common.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.common.Dao.ConfigDao;
import com.common.Dao.DepartmentDao;
import com.common.Dao.DesignationDao;
import com.common.Dao.GroupDao;
import com.common.Dao.HintQuesDao;
import com.common.Dao.UsersDao;
import com.common.Objects.ConfigObject;
import com.common.Objects.DepartmentObject;
import com.common.Objects.DesignationObject;
import com.common.Objects.GroupObject;
import com.common.Objects.HintQuestObject;
import com.common.Objects.UsersObject;



@Controller
public class UserController {
	
	@Autowired
	private UsersDao usersDao ;
	
	@Autowired
	private DepartmentDao departmentDao;  
	
	@Autowired
	private DesignationDao designationDao;
	
	@Autowired
    private GroupDao groupDao;
	
    @Autowired
	private ConfigDao configDao;

    @Autowired
	private HintQuesDao hintQuesDao;
    
    
    
	
	
	@RequestMapping(value = "/addUser", method = RequestMethod.GET)
	   public String showform(Model model){  
	       UsersObject usersObject = new UsersObject();
	       List<DepartmentObject> departmentList = departmentDao.getAllDepartments();
	       List<DesignationObject> designationList = designationDao.getAllDesignation();
	       List<GroupObject> groupList = groupDao.getAllGroupObject();
	       List<ConfigObject> configList = configDao.getAllConfigObject();
	       List<HintQuestObject> hintQuestList = hintQuesDao.getAllHintQuestObject();
	       model.addAttribute("users", usersObject);
	       model.addAttribute("departmentList",departmentList);
	       model.addAttribute("designationList",designationList);
	       model.addAttribute("groupList",groupList);
	       model.addAttribute("configList",configList);
	       model.addAttribute("hintQuestList",hintQuestList);
	       return "registration"; 
	 } 
	
	 @RequestMapping(value = "/saveUser", method = RequestMethod.POST)
	   public String saveData(@ModelAttribute("users") UsersObject users){  
		   usersDao.saveUsersObject(users);
	       return "redirect:/manageUsers"; 
	 }  
	
	 @RequestMapping(value="/manageUsers", method = RequestMethod.GET)  
	   public String manageUser(Model model){  
	       List<UsersObject> userslist = usersDao.getAllUsers(); 
	       model.addAttribute("usersList", userslist);
	       return "manageUsers";
	 }  
	 
	 @RequestMapping(value="/editUser", method = RequestMethod.GET)  
	   public String editUser(@RequestParam("userId") Integer userId,Model model){  
	       UsersObject usersObject = findByUserId(userId);
	       model.addAttribute("users", usersObject);
	       return "editUser";//will redirect to viewemp request mapping  
	   }  
	   
	   @RequestMapping(value="/deleteUser", method = RequestMethod.GET)  
	   public String deleteUser(@RequestParam("userId") Integer userId,Model model){  
		   UsersObject usersObject = findByUserId(userId);
		   usersDao.deleteUserObject(usersObject);
	       return "redirect:/manageUsers";//will redirect to viewemp request mapping  
	   }  
	   
	   private UsersObject findByUserId(Integer userId) {
		   UsersObject usersObject =  usersDao.getUsersById(userId); 
		   return usersObject;
	   }
	 
	 
}
