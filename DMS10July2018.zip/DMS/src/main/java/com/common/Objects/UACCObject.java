package com.common.Objects;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity @Table(name="uacc")
public class UACCObject implements Serializable{
	
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="userid")
	private int userId;
	
	@Id
	@Column(name="mid")
	private int mid;
	
	@Column(name="aadd")
	private String addFlag;
	
	@Column(name="aupdate")
	private String updateFlag;
	
	@Column(name="adel")
	private String deleteFlag;
	
	@Column(name="aview")
	private String viewFlag;
   
	@Column(name="apass")
	private String passFlag;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getMid() {
		return mid;
	}

	public void setMid(int mid) {
		this.mid = mid;
	}

	public String getAddFlag() {
		return addFlag;
	}

	public void setAddFlag(String addFlag) {
		this.addFlag = addFlag;
	}

	public String getUpdateFlag() {
		return updateFlag;
	}

	public void setUpdateFlag(String updateFlag) {
		this.updateFlag = updateFlag;
	}

	public String getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	public String getViewFlag() {
		return viewFlag;
	}

	public void setViewFlag(String viewFlag) {
		this.viewFlag = viewFlag;
	}

	public String getPassFlag() {
		return passFlag;
	}

	public void setPassFlag(String passFlag) {
		this.passFlag = passFlag;
	}
	
	
}
