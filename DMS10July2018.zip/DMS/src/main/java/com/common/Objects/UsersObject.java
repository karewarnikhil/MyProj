package com.common.Objects;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("session")
@Entity @Table(name="usermst")
public class UsersObject implements Serializable{
	
	
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "userId", updatable = false, nullable = false)
	private  int userId ;
	
	@Column(name="emailId")
	private  String emailId ;
	
	@Column(name="username")
	private  String userName ;
	
	
	@Column(name="address")
	private  String address ;
	
	@Column(name="mobno")
	private  String mobileNo ;
	
	@Column(name="deptid")
	private  int departmentId ;
	
	@Column(name="desgid")
	private  int designationId ;
	
	@Column(name="groupId")
	private  int groupId ;
	
	@Column(name="userlevel")
	private  int userlevel ;
	
	@Column(name="hintid")
	private  int hintId ;
	
	@Column(name="createdby")
	private  String createdBy ;
	
	@Column(name="upw1")
	private  String userPassword ;
	
	@Column(name="hintans")
	private  String hintAnswer ;
	
	@Column(name="status")
	private  String status ;
	
    public UsersObject(int userId, String userName, String emailId, String mobileNo, String address, int departmentId, int designationId, String createdBy, String status, String userPassword, int userlevel, int hintId, String hintAnswer,int groupId) {
    	super();
    	this.userId = userId;
    	this.emailId = emailId;
    	this.userName = userName;
    	this.address = address;
    	this.mobileNo = mobileNo;
    	this.departmentId = departmentId;
    	this.designationId = designationId;
    	this.userlevel = userlevel;
    	this.hintId = hintId;
    	this.createdBy = createdBy;
    	this.userPassword = userPassword;
    	this.hintAnswer = hintAnswer;
    	this.status = status;
    	this.groupId = groupId;
    	
    }
    
    public UsersObject(){
    	
    }

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public int getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}

	public int getDesignationId() {
		return designationId;
	}

	public void setDesignationId(int designationId) {
		this.designationId = designationId;
	}

	public int getUserlevel() {
		return userlevel;
	}

	public void setUserlevel(int userlevel) {
		this.userlevel = userlevel;
	}

	public int getHintId() {
		return hintId;
	}

	public void setHintId(int hintId) {
		this.hintId = hintId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getHintAnswer() {
		return hintAnswer;
	}

	public void setHintAnswer(String hintAnswer) {
		this.hintAnswer = hintAnswer;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	public int getGroupId() {
		return groupId;
	}

	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}

}
