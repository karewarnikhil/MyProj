package com.common.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.common.Dao.FolderDao;

@Component
public class StartInit {
	
	@Autowired
	FolderDao folderDao;
	
	/*@PostConstruct
	public void init() {
		List<FolderObject> folderList  = folderDao.getAllFolders();
		for (FolderObject folderObject : folderList) {
			System.out.println(folderObject.getFolderNm());
		}
		
	}
*/
}
