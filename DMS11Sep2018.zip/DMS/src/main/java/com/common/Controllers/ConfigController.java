package com.common.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.common.Dao.ConfigDao;
import com.common.Objects.ConfigObject;
import com.common.Objects.DepartmentObject;

@Controller
public class ConfigController {
	
	@Autowired
	ConfigDao configDao;
	
	@RequestMapping(value = "/manageLevel", method = RequestMethod.GET)
	public String getLevels(Model model) throws Exception {
		model.addAttribute("levelList", configDao.getAllConfigs());
		return "manageLevel";
	}

	@RequestMapping(value = "/addLevel", method = RequestMethod.GET)
	public String getLevelForm(Model model) throws Exception {
		model.addAttribute("config", new ConfigObject());
		return "registerLevel";
	}

	@RequestMapping(value = "/saveLevel", method = RequestMethod.POST)
	public String saveLevel(@ModelAttribute("config") ConfigObject config,Model model) throws Exception {
			configDao.saveConfigObject(config);
			return "redirect:/manageLevel"; 
	}
	
	@RequestMapping(value = "/editLevel", method = RequestMethod.GET)
	   public ModelAndView editLevel(@RequestParam("pk") String pk){  
		   ConfigObject configObject = findByPkValue(pk);
	       return new ModelAndView("editLevel","config",configObject);  
	}  

	@RequestMapping(value = "/updateLevel", method = RequestMethod.POST)
	public String updateLevel(@ModelAttribute("config") ConfigObject configObject,Model model) throws Exception {
		configDao.updateLevel(configObject);
		model.addAttribute("successmsg", "Level updated successfully....");
		model.addAttribute("levelList", configDao.getAllConfigs());
		return "redirect:/manageLevel"; 
	}
	
	private ConfigObject findByPkValue(String pk) {
		   ConfigObject configObject =  configDao.getConfigById(pk); 
		   return configObject;
	}

	/*@RequestMapping(value = "/deleteLevel", method = RequestMethod.GET)
	public String deleteLevel(@RequestParam("pk") String pk, @RequestParam("sk") String sk, Model model)
			throws Exception {
		configDao.deleteLevel(pk, sk);
		model.addAttribute("successmsg", "Level deleted successfully....");
		model.addAttribute("levelList", configDao.getLevel());
		model.addAttribute("pageName", "Manage Level");
		return "manageLevel";
	}
	*/
}
