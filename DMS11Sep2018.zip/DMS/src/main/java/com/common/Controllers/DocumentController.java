package com.common.Controllers;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.common.Dao.DocumentDao;
import com.common.Dao.FolderDao;
import com.common.Dao.TagDao;
import com.common.Objects.DocumentObject;
import com.common.Objects.FileBucket;
import com.common.Objects.FolderObject;
import com.common.Objects.TagGroupObject;
import com.common.Objects.UsersObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
public class DocumentController {
	
	//Save the uploaded file to this folder
    //private static String UPLOADED_FOLDER = "E://workspaceNikhil//DMS//src//main//webapp//upload//";
	private static String UPLOADED_FOLDER = "";
  
    
    @Autowired
    DocumentDao documentDao;
	
	@Autowired
	FolderDao folderDao;
	
	@Autowired
	TagDao tagDao;
	
	@Autowired
	ServletContext context;
	
	@RequestMapping(value = "/uploadFile", method = RequestMethod.GET)
	   public String showFileForm(Model model){  
		   //DocumentObject documentObject = new DocumentObject();
		   //List<FolderObject> listOffolder = folderDao.getAllFoldersByRootId(0);
		   FileBucket fileBucket = new FileBucket();
		   model.addAttribute("fileBucket", fileBucket);
		  // model.addAttribute("listOffolder", listOffolder);
	       return "fileUpload"; 
    } 
	
	@RequestMapping(value = "/displayFile", method = RequestMethod.GET)
	   public String displayFile(@RequestParam("fileId") long fileId,Model model,HttpServletRequest request,HttpServletResponse response) throws IOException{ 
		 HttpSession session = request.getSession();
		 session.removeAttribute("tagObjectlist");
		 session.removeAttribute("tagGroupList");
		 DocumentObject documentObject = documentDao.findByFileId(fileId);
		 long rootId = 0;
		 if(documentObject.getRootId() == 0)
			 rootId = documentObject.getFolderId();
		 else
			 rootId = documentObject.getRootId();
		 List<TagGroupObject> tagGroupList = tagDao.getAllTagsForFileDisplay(rootId);
		/*if(documentObject.getFileExtn().contains("application/pdf")) {
		        byte[] documentInBytes = documentObject.getFileContent();        
		        response.setHeader("Content-Disposition", "inline; filename=\"report.pdf\"");
		        response.setDateHeader("Expires", -1);
		        response.setContentType("application/pdf");
		        response.setContentLength(documentInBytes.length);
		        response.getOutputStream().write(documentInBytes);
	    } */
		
	  /* if(documentObject.getFileExtn().contains("image/"))  {*/
		 byte[] encodeBase64 = Base64.getEncoder().encode(documentObject.getFileContent());
		 String base64Encoded = new String(encodeBase64, "UTF-8");
		 //model.addAttribute("fileForDisplay", base64Encoded );
		 //model.addAttribute("imageExtension", documentObject.getFileExtn());
		 //model.addAttribute("tagGroupList",tagGroupList);
		 model.addAttribute("fileId",documentObject.getFileId());
		 session.setAttribute("tagGroupList", tagGroupList);
		 session.setAttribute("imageExtension", documentObject.getFileExtn());
		 session.setAttribute("fileForDisplay", base64Encoded);
		 session.setAttribute("documentObject", documentObject);
		
      /* }*/	 
	     return "fileDisplay"; 
 } 
	
	
	@RequestMapping(value = "/displayViewer", method = RequestMethod.GET)
	   public String displayViewer(@RequestParam("fileId") long fileId,Model model,HttpServletRequest request,HttpServletResponse response) throws IOException{ 
		 HttpSession session = request.getSession();
		 DocumentObject documentObject = documentDao.findByFileId(fileId);
		 long rootId = 0;
		 if(documentObject.getRootId() == 0)
			 rootId = documentObject.getFolderId();
		 else
			 rootId = documentObject.getRootId();
		 //List<TagGroupObject> tagGroupList = tagDao.getAllTagsForFileDisplay(rootId);
		/*if(documentObject.getFileExtn().contains("application/pdf")) {
		        byte[] documentInBytes = documentObject.getFileContent();        
		        response.setHeader("Content-Disposition", "inline; filename=\"report.pdf\"");
		        response.setDateHeader("Expires", -1);
		        response.setContentType("application/pdf");
		        response.setContentLength(documentInBytes.length);
		        response.getOutputStream().write(documentInBytes);
	    } */
		
	  /* if(documentObject.getFileExtn().contains("image/"))  {*/
		 byte[] encodeBase64 = Base64.getEncoder().encode(documentObject.getFileContent());
		 String base64Encoded = new String(encodeBase64, "UTF-8");
		 model.addAttribute("fileForDisplay", base64Encoded );
		 model.addAttribute("imageExtension", documentObject.getFileExtn());
		 model.addAttribute("imageExtension", documentObject.getFileExtn());
		 //model.addAttribute("tagGroupList",tagGroupList);
		 model.addAttribute("fileId",documentObject.getFileId());
		// session.setAttribute("tagGroupList", tagGroupList);
		 //session.setAttribute("imageExtension", documentObject.getFileExtn());
		 //session.setAttribute("fileForDisplay", base64Encoded);
		 model.addAttribute("documentObject", documentObject);
		
   /* }*/	
		
		    String name=documentObject.getFileName();
		    String filePath = context.getRealPath("/")+"resources\\upload\\"+name;
		        try {           
		            byte[] bytes = documentObject.getFileContent();
		            File file = new File(filePath);
		            BufferedOutputStream stream =
		                    new BufferedOutputStream(new FileOutputStream(file));
		            stream.write(bytes);
		            stream.close();
		            stream.flush();

		            System.out.println("You have uploaded file");
		            System.out.println(filePath);
		            
		            file.deleteOnExit();
		        } catch (Exception e) {
		          System.out.println("Failed to upload");
		        }
		
		    
	    
		 
		 
   /*  System.out.println("pathFR===="+pathFR);
	     //System.out.println("filePath===="+filePath);
	     
	OutputStream os = new FileOutputStream(pathFR+"/"+documentObject.getFileName());
	     os.write(documentObject.getFileContent());
	     os.close();
		
	     File temp = new File(pathFR,"abc.pdf");*/
	
	
		
		
	     return "fileViewer"; 
} 
	
	@RequestMapping(value="/manageDocument", method = RequestMethod.GET)  
	   public String manageDocument(Model model){
		 List<DocumentObject> documentlist = documentDao.getAllDocuments();
		// List<DocumentObject> documentlist = new ArrayList<>();
		/*for(DocumentObject documentObject:documentlist) {
			 System.out.println(documentObject.getFileId());
		 }*/
	     model.addAttribute("documentlist", documentlist);
	     return "manageDocument";
	} 
	
	 @RequestMapping(value = "/saveDocument", method = RequestMethod.POST)
	   public String saveDocument(@ModelAttribute("document") FileBucket fileBucket, HttpServletRequest request,Model model) throws IOException{  
		    HttpSession session = request.getSession();
		    long folderId = Integer.parseInt(request.getParameter("folderId"));
		    UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		    Date date = new Date();  
	        Timestamp ts = new Timestamp(date.getTime());  
	        System.out.println(ts);           
	       
	        List<MultipartFile> listOfMultipartFile = fileBucket.getListOfMultipartFile();
	        int fileLength = listOfMultipartFile.size();
	        //only 50 files for upload 
	        if(fileLength <= 50) {
	        	FolderObject folderObject = folderDao.getFolderById(folderId);
	        	List<FolderObject> listOfFolderObject = (List<FolderObject>) folderDao.getChildFolderList(folderObject.getRootId());
	        	
	        	String filepath = null;
	        	String fileLocation = null;
	        	for(FolderObject folderObject2:listOfFolderObject) {
	        		if(folderId == folderObject2.getFolderId()) {
	        			filepath = filepath+"/"+folderObject2.getFolderNm();
		        		fileLocation = fileLocation+"~"+folderObject2.getFolderId();
		        		break;
	        		}
	        			
	        		filepath = filepath+"/"+folderObject2.getFolderNm();
	        		fileLocation = fileLocation+"~"+folderObject2.getFolderId();
	        	}
	        	
	        	List<DocumentObject> documentListForDuplicate = new ArrayList<DocumentObject>();
		        for(MultipartFile multipartFile:listOfMultipartFile) {
		        	//change to string value after
		        	DocumentObject documentObjectCheck = documentDao.findByFileNameAndFolderId(multipartFile.getOriginalFilename(),folderObject.getFolderId());
		        	
		        	if((documentObjectCheck != null) && (documentObjectCheck.getFileExtn().contains(multipartFile.getContentType()))) {
		        		documentListForDuplicate.add(documentObjectCheck);
		        	}
		        	else {
		        		DocumentObject documentObject = new DocumentObject();
			 	        documentObject.setCreationDt(ts);
			 	        documentObject.setFolderId(folderObject.getFolderId());
			 	        documentObject.setRootId(folderObject.getRootId());
				        documentObject.setFileName(multipartFile.getOriginalFilename());
				        String aa = multipartFile.getContentType();
				        System.out.println(aa);
				        documentObject.setFileExtn(multipartFile.getContentType());
						documentObject.setFileContent(multipartFile.getBytes());
				        documentObject.setCreatedBy(usersSessionObject.getUserId());
				        documentObject.setAtriBt("A");
				        documentObject.setFileLocation(fileLocation);
				        documentObject.setPageCnt(0);
				        documentObject.setFilePath(filepath);
				        documentObject.setSeqNo(1);
				        documentObject.setTagStatus("N");
				        
				       // ServletContext context = request.getSession().getServletContext();
				  		//UPLOADED_FOLDER = context.getRealPath("//")+"//src//main//webapp//upload//";
				  		//System.out.println();
				  	
				       // Path path = Paths.get(UPLOADED_FOLDER + multipartFile.getOriginalFilename());
				       // Files.write(path, documentObject.getFileContent());
				        //documentlist.add(documentObject);
				        documentDao.save(documentObject);
		        	}
		        	
			        //model.addAttribute("documentlist", documentlist);
		        }
		      
		        if(documentListForDuplicate.size() > 0) {
		    	   model.addAttribute("documentListForDuplicate", documentListForDuplicate);
		    	   model.addAttribute("fileBucket", fileBucket);
		    	   return "fileUpload"; 
		       }  
		       else {
		    	   return "redirect:/manageDocument"; 
		       }
		    	   
	        }    
	        else {
	  		model.addAttribute("fileBucket", fileBucket);
	        request.setAttribute("error", "You Can select Only 50 files to upload.");
	        return "fileUpload"; 
	        }
	   }  
	
		 @RequestMapping(value="/downloadDocument", method = RequestMethod.GET)  
		   public String downloadDocument(@RequestParam("fileId") long fileId,Model model,HttpServletResponse response){  
			    DocumentObject documentObject = documentDao.findByFileId(fileId);
			    response.setContentType(documentObject.getFileExtn());
		        response.setContentLength(documentObject.getFileContent().length);
		        response.setHeader("Content-Disposition","attachment; filename=\"" + documentObject.getFileName() +"\"");
	            try
	            {
	            	FileCopyUtils.copy(documentObject.getFileContent(), response.getOutputStream());
	                response.getOutputStream().flush();
	                response.getOutputStream().close();
	            }
	            catch (IOException ex) {
	                ex.printStackTrace();
	            }
		       return "manageDocument";//will redirect to viewemp request mapping  
		   }  
		 
		 /*@RequestMapping(value="/manageDocument", method = RequestMethod.GET)  
		   public String documentReader(Model model,HttpServletResponse response){  
		        File directory = new File(UPLOADED_FOLDER);
		        System.out.println(directory.getTotalSpace());
		        File[] fList = directory.listFiles();
		        for (File file : fList){
		            System.out.println(file.getName());
		        }
				return "manageDocument";
		   } */
		 
		 @RequestMapping(value = "/getFiles", method = RequestMethod.POST, produces = "application/json")
			public @ResponseBody String getFiles(@RequestParam("folderId") long folderId, Model model) throws JsonProcessingException {
			    List<DocumentObject> documentlist = documentDao.findAllByFolderId(folderId);
			    for(DocumentObject documentObject:documentlist) {
			    	if(documentObject.getFileExtn().contains("application/pdf")) {
			    		documentObject.setExtensionIcon("fa fa-file-pdf-o");
			    	}
			    	else if(documentObject.getFileExtn().contains("image/")){
			    		documentObject.setExtensionIcon("fa fa-file-image-o");
			    	}
			    	else if(documentObject.getFileExtn().contains("text/plain")){
			    		documentObject.setExtensionIcon("fa fa-file-text-o");
			    	}
			    	else if(documentObject.getFileExtn().contains("application/msword")){
			    		documentObject.setExtensionIcon("fa fa-file-word-o");
			    	}
			    	else if(documentObject.getFileExtn().contains("application/octet-stream")){
			    		documentObject.setExtensionIcon("fa fa-file-zip-o");
			    	}
			    	else if(documentObject.getFileExtn().contains("application/vnd.openxmlformats-officedocument.presentationml.presentation")){
			    		documentObject.setExtensionIcon("fa fa-file-powerpoint-o");
			    		
			    	}
			    	else if(documentObject.getFileExtn().contains("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")){
			    		documentObject.setExtensionIcon("fa fa-file-excel-o");
			    	}
			    	else
			    		documentObject.setExtensionIcon("fa fa-file-o");
			    	
			    	
			    }
			    ObjectMapper mapper = new ObjectMapper();
	            String data = mapper.writeValueAsString(documentlist);
	            return data;
		 }
		 
		 @RequestMapping(value = "/getUnTagFilesData", method = RequestMethod.POST, produces = "application/json")
			public @ResponseBody String getUnTagFilesData(@RequestParam("folderId") long folderId, Model model) throws JsonProcessingException {
			    List<DocumentObject> documentlist = documentDao.findAllByFolderIdAndUntagged(folderId);
			    for(DocumentObject documentObject:documentlist) {
			    	if(documentObject.getFileExtn().contains("application/pdf")) {
			    		documentObject.setExtensionIcon("fa fa-file-pdf-o");
			    	}
			    	else if(documentObject.getFileExtn().contains("image/")){
			    		documentObject.setExtensionIcon("fa fa-file-image-o");
			    	}
			    	else if(documentObject.getFileExtn().contains("text/plain")){
			    		documentObject.setExtensionIcon("fa fa-file-text-o");
			    	}
			    	else if(documentObject.getFileExtn().contains("application/msword")){
			    		documentObject.setExtensionIcon("fa fa-file-word-o");
			    	}
			    	else if(documentObject.getFileExtn().contains("application/octet-stream")){
			    		documentObject.setExtensionIcon("fa fa-file-zip-o");
			    	}
			    	else if(documentObject.getFileExtn().contains("application/vnd.openxmlformats-officedocument.presentationml.presentation")){
			    		documentObject.setExtensionIcon("fa fa-file-powerpoint-o");
			    		
			    	}
			    	else if(documentObject.getFileExtn().contains("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")){
			    		documentObject.setExtensionIcon("fa fa-file-excel-o");
			    	}
			    	else
			    		documentObject.setExtensionIcon("fa fa-file-o");
			    	
			    	
			    }
			    ObjectMapper mapper = new ObjectMapper();
	            String data = mapper.writeValueAsString(documentlist);
	            return data;
		 }
		 
		 /***********
		  * Creating a folder
		 File fileMetadata = new File();
		 fileMetadata.setName("Invoices");
		 fileMetadata.setMimeType("application/vnd.google-apps.folder");

		 File file = driveService.files().create(fileMetadata)
		     .setFields("id")
		     .execute();
		 System.out.println("Folder ID: " + file.getId());
		 
		 //Inserting a file in a folder
		 String folderId = "0BwwA4oUTeiV1TGRPeTVjaWRDY1E";
		File fileMetadata = new File();
		fileMetadata.setName("photo.jpg");
		fileMetadata.setParents(Collections.singletonList(folderId));
		java.io.File filePath = new java.io.File("files/photo.jpg");
		FileContent mediaContent = new FileContent("image/jpeg", filePath);
		File file = driveService.files().create(fileMetadata, mediaContent)
		    .setFields("id, parents")
		    .execute();
		System.out.println("File ID: " + file.getId());


	    String fileId = "1sTWaJ_j7PkjzaBWtNc3IzovK5hQf21FbOw9yLeeLPNQ";
		String folderId = "0BwwA4oUTeiV1TGRPeTVjaWRDY1E";
		// Retrieve the existing parents to remove
		File file = driveService.files().get(fileId)
		    .setFields("parents")
		    .execute();
		StringBuilder previousParents = new StringBuilder();
		for (String parent : file.getParents()) {
		  previousParents.append(parent);
		  previousParents.append(',');
		}
		// Move the file to the new folder
		file = driveService.files().update(fileId, null)
		    .setAddParents(folderId)
		    .setRemoveParents(previousParents.toString())
		    .setFields("id, parents")
		    .execute();
		    
		    
		    
		    
		        /**

     * List all the files and folders from a directory

     * @param directoryName to be listed

    

    public void listFilesAndFolders(String directoryName){

        File directory = new File(directoryName);

        //get all the files from a directory

        File[] fList = directory.listFiles();

        for (File file : fList){

            System.out.println(file.getName());

        }

    }

    /**

     * List all the files under a directory

     * @param directoryName to be listed

    

    public void listFiles(String directoryName){

        File directory = new File(directoryName);

        //get all the files from a directory

        File[] fList = directory.listFiles();

        for (File file : fList){

            if (file.isFile()){

                System.out.println(file.getName());

            }

        }

    }

    /**

     * List all the folder under a directory

     * @param directoryName to be listed

     

    public void listFolders(String directoryName){

        File directory = new File(directoryName);

        //get all the files from a directory

        File[] fList = directory.listFiles();

        for (File file : fList){

            if (file.isDirectory()){

                System.out.println(file.getName());

            }

        }

    }

    /**

     * List all files from a directory and its subdirectories

     * @param directoryName to be listed

     

    public void listFilesAndFilesSubDirectories(String directoryName){

        File directory = new File(directoryName);

        //get all the files from a directory

        File[] fList = directory.listFiles();

        for (File file : fList){

            if (file.isFile()){

                System.out.println(file.getAbsolutePath());

            } else if (file.isDirectory()){

                listFilesAndFilesSubDirectories(file.getAbsolutePath());

            }

        }

    }

    public static void main (String[] args){

        ListFilesUtil listFilesUtil = new ListFilesUtil();

        final String directoryLinuxMac ="/Users/loiane/test";

        //Windows directory example

        final String directoryWindows ="C://test";

        listFilesUtil.listFiles(directoryLinuxMac);

    }

}
	 
		 
        ******/
}


