package com.common.DaoImpl;

import java.util.List;

import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.ClassDao;
import com.common.Dao.FolderDao;
import com.common.Objects.ClassObject;
import com.common.Objects.FolderObject;

@Repository
@Transactional
public class ClassDaoImpl implements ClassDao{
	
	@Autowired
	private SessionFactory sessionFactory;
	 
	@Autowired 
	FolderDao folderDao;
	
//code for increment and return currentVal through sp
	public long getIdForCurrentVal() {
		Session session = sessionFactory.getCurrentSession();
		StoredProcedureQuery storedProcedureQuery = session.createStoredProcedureQuery("increment_CurrentVal");
		storedProcedureQuery.registerStoredProcedureParameter("p_seqName", String.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("currentVal", Integer.class, ParameterMode.OUT);
		storedProcedureQuery.setParameter("p_seqName", "FolderId");
		
		storedProcedureQuery.execute();
		int folderId = (Integer) storedProcedureQuery.getOutputParameterValue("currentVal");
		System.out.println("folderId======="+folderId);
		return folderId;
	};
    
	public void saveClassObject(ClassObject classObject,FolderObject folderObject) {
		 //Id used for folderId and classId
		long currentVal = getIdForCurrentVal();
		classObject.setClassId(currentVal);
		folderObject.setFolderId(currentVal);
		folderDao.saveFolderObject(folderObject);
		sessionFactory.getCurrentSession().save(classObject);
	}

	public List<ClassObject> getAllClass(int userlevel,long deptId) {
		if(userlevel > 0)
			return sessionFactory.getCurrentSession().createQuery(" FROM ClassObject where deptid="+deptId).list();
		else
			return sessionFactory.getCurrentSession().createQuery(" FROM ClassObject").list();
	}

	public ClassObject getClassById(long classId) {
		ClassObject classObject = (ClassObject) sessionFactory.getCurrentSession().get(ClassObject.class,classId);
		return classObject;
	}

	public void deleteClassObject(ClassObject classObject) {
		sessionFactory.getCurrentSession().delete(classObject);
	}

	public void updateClassObject(ClassObject classObject) {
		FolderObject folderObject = folderDao.getFolderById(classObject.getClassId());
		folderObject.setFolderId(classObject.getClassId());
		folderObject.setFolderNm(classObject.getClassNm());
		folderObject.setReadOnlyOthDept(classObject.getReadOnlyOthDept());
		folderObject.setReadOnlyPublic(classObject.getReadOnlyPublic());
		folderObject.setIsInnerFolders(classObject.getIsInnerFolders());
		folderObject.setAtriBt(classObject.getAtriBt());
		
		folderDao.updateFolderObject(folderObject);
		sessionFactory.getCurrentSession().update(classObject);
	}
	
	
	 public List<ClassObject> getClasses() {
			return sessionFactory.getCurrentSession().createQuery(" FROM ClassObject").list();
		}

}
