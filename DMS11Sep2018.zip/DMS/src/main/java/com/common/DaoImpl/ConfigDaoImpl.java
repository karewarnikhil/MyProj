package com.common.DaoImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.ConfigDao;
import com.common.Objects.ConfigObject;

@Repository
@Transactional
public class ConfigDaoImpl implements ConfigDao {


	@Autowired
	private SessionFactory sessionFactory;
	
	public List<ConfigObject> getAllConfigs() {
		return sessionFactory.getCurrentSession().createQuery(" FROM ConfigObject").list();
	}
	public void saveConfigObject(ConfigObject configObject) {
		sessionFactory.getCurrentSession().saveOrUpdate(configObject);		
	}
	public ConfigObject getConfigById(String pk) {
		ConfigObject configObject = (ConfigObject) sessionFactory.getCurrentSession().createQuery(" FROM ConfigObject where pk = '"+pk+"'").uniqueResult();
		return configObject;
	}
	public ConfigObject getById(String pk, String sk) {
		return null;
	}
	public void updateLevel(ConfigObject config) {
		// TODO Auto-generated method stub
		
	}
	public void deleteLevel(String pk, String sk) {
		// TODO Auto-generated method stub
		
	}

}
