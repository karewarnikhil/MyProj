package com.common.DaoImpl;

import java.util.List;

import javax.persistence.Query;
import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.TagDao;
import com.common.Objects.DepartmentObject;
import com.common.Objects.ListDataObj;
import com.common.Objects.MenuObject;
import com.common.Objects.TagGroupObject;
import com.common.Objects.TagObject;

@Repository
@Transactional
public class TagDaoImpl implements TagDao{
	
	@Autowired
	private SessionFactory sessionFactory;

	public void saveTagObject(TagObject tagObject) {
		sessionFactory.getCurrentSession().save(tagObject);
	}

	public List<TagObject> getAllTagObject() {
		return sessionFactory.getCurrentSession().createQuery(" FROM TagObject").list();
	}

	public TagObject getTagById(Integer tagId) {
		TagObject tagObject = (TagObject) sessionFactory.getCurrentSession().get(TagObject.class,tagId);
		return tagObject;
	}
	
	public int getMaxValueId(long tagGrpId) {
		Query qry=sessionFactory.getCurrentSession().createQuery("select COALESCE(MAX(tagId), 0) from TagObject where tagGrpId="+tagGrpId);
		int count= (Integer)  ((org.hibernate.query.Query) qry).uniqueResult();
		return count + 1;
	}

	public List<TagGroupObject> getAllTagsForFileDisplay(long rootId) {
		return  sessionFactory.getCurrentSession().createQuery(" FROM TagGroupObject tg where tg.tagGrpId IN( Select DISTINCT ct.tagGrpId FROM  ClassTagGroup ct where ct.classId="+rootId+")").list();
	}

	public List<TagObject> getTagData(long tagGrpId) {
		List<TagObject> tagList  = sessionFactory.getCurrentSession().createQuery(" FROM TagObject where tagGrpId="+tagGrpId+" order by dispSeqNo ").list();
		return tagList;
	}

	
	public void updateTagObject(TagObject tagObject) {
		sessionFactory.getCurrentSession().update(tagObject);
	}
}
