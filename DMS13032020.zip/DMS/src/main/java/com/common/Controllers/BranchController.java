package com.common.Controllers;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.common.Dao.BranchDao;
import com.common.Objects.BranchObject;
import com.common.Objects.UsersObject;
import com.common.Utilities.DmsConstant;

@Controller
public class BranchController {
	
	@Autowired
	BranchDao branchDao;
	  
    @RequestMapping(value = "/manageBranch", method = RequestMethod.GET)
    public ModelAndView manageBranch(Model model,HttpServletRequest request) {  
	   HttpSession session = request.getSession();
	   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
	   if(usersSessionObject != null) {
		   List<BranchObject> branchList = branchDao.getAllBranch(); 
		   return new ModelAndView("manageBranch","branchList",branchList);  
	   }  else {
		   return new ModelAndView("loginIn");  
	   }
    } 
    
    @RequestMapping(value = "/registerBranch", method = RequestMethod.GET)
	   public String showBranchForm(Model model,HttpServletRequest request){  
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
		       model.addAttribute("branch",  new BranchObject());
		       return "registerBranch"; 
		   }else {
			   return "loginIn"; 
		   }
	   } 
    
    
    @RequestMapping(value = "/saveBranch", method = RequestMethod.POST)
	   public String saveBranch(@ModelAttribute("branch") BranchObject branchObject, Model model,HttpServletRequest request){
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
			     branchDao.saveBranchObject(branchObject);
				 if(branchObject.getStatus().equals("A")){
					 HashMap<Integer, String> hashMapofBranch = DmsConstant.HASHMAP_OF_BRANCH;
				  	 hashMapofBranch.put(branchObject.getBranchId(),branchObject.getBranchNm()); 
				 }
			   branchObject = new BranchObject();
			   model.addAttribute("branch", branchObject);
			   model.addAttribute("message", "Branch Saved Successfully.");
		       return "registerBranch"; 
		   }else {
			   return "loginIn"; 
		   }
	   }  
    
     @RequestMapping(value="/editBranch", method = RequestMethod.GET)  
	   public ModelAndView editBranch(@RequestParam("branchId") Integer branchId,HttpServletRequest request){  
		   HttpSession session = request.getSession();
		   request.setAttribute("branchId", branchId);
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
			   BranchObject branchObject = findByBranchId(branchId);
		       return new ModelAndView("editBranch","branch",branchObject);  
		   }else {
			   return new ModelAndView("loginIn"); 
		   }
	   }  
    
    @RequestMapping(value = "/updateBranch", method = RequestMethod.POST)
	   public String updateBranch(@ModelAttribute("branch") BranchObject branchObject, BindingResult result,Model model,HttpServletRequest request){
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
			   branchDao.saveBranchObject(branchObject);
			   HashMap<Integer, String> hashMapofBranch = DmsConstant.HASHMAP_OF_BRANCH;
			   if(branchObject.getStatus().equals("A") &&  hashMapofBranch.containsKey(branchObject.getBranchId())){	 
				   hashMapofBranch.replace(branchObject.getBranchId(),branchObject.getBranchNm());
			   }
			   else if(branchObject.getStatus().equals("A") &&  !(hashMapofBranch.containsKey(branchObject.getBranchId()))){
				   hashMapofBranch.put(branchObject.getBranchId(),branchObject.getBranchNm()); 
			   } 
			   else if(branchObject.getStatus().equals("D")){
				   hashMapofBranch.remove(branchObject.getBranchId()); 
			   }
				 
			   model.addAttribute("message", "Branch Updated Successfully.");
			   model.addAttribute("branch",branchObject);
			   return "editBranch";
		   }else {
			   return "loginIn"; 
		   }
	   }  
    
    private BranchObject findByBranchId(Integer branchId) {
		   BranchObject branchObject =  branchDao.getBranchById(branchId); 
		   return branchObject;
	   }

}
