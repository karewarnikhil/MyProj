package com.common.Controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.common.Dao.ListDao;
import com.common.Dao.ListDataDao;
import com.common.Objects.ListDataObj;
import com.common.Objects.UsersObject;

@Controller
public class ListDataController {

	@Autowired
	private ListDataDao listDataDao;

	@Autowired
	private ListDao listDao;

	@RequestMapping(value = "/createListData", method = RequestMethod.GET)
	public String getListDataForm(Model model,HttpServletRequest request) {
		UsersObject usersObject = (UsersObject) request.getSession().getAttribute("users");
		if (usersObject != null) {
			if (usersObject.getAccessObject().isAdd() == true) {
				model.addAttribute("listDataObj", new ListDataObj());
				//change get it from hash map defined in constant file.
				model.addAttribute("allList", listDao.getAllListForDropdown());
				//model.addAttribute("allListData", listDataDao.getAllListData());
				return "manageListData";
			}else {
				model.addAttribute("error", "You Don't have authorize to do this functionality.");
				return "defaultPage";
			}
		}else {
			return "loginIn";
		}
	}

	@RequestMapping(value = "/saveListData", method = RequestMethod.POST)
	public String saveListData(Model model, HttpServletRequest request,@ModelAttribute("list") ListDataObj listDataObj) {
		UsersObject usersSess = (UsersObject) request.getSession().getAttribute("users");
		if (usersSess != null) {
			if (listDataDao.getListDataByListValue(listDataObj.getListValue()) == null) {
				int listNo = listDataDao.getMaxId(listDataObj.getListDataCompositeKey().getListId());
				listDataObj.getListDataCompositeKey().setListNo(listNo);
				
				listDataObj.setCreatedBy(usersSess.getUserId());
				listDataObj.setStatus("A");
				listDataDao.saveListDataObj(listDataObj);
				
				List<ListDataObj> dataObjectlist = listDataDao.getListDataByListId(listDataObj.getListDataCompositeKey().getListId());
				model.addAttribute("dataObjectlist", dataObjectlist);
				model.addAttribute("listId", listDataObj.getListDataCompositeKey().getListId());
				model.addAttribute("message", "List Data Saved Successfully.");
				//change get it from hash map defined in constant file.
				//model.addAttribute("allListData", listDataDao.getAllListData());
				
			}else {
				model.addAttribute("error", "List Value is already present.");
			}
			model.addAttribute("listDataObj", new ListDataObj());
			//change get it from hash map defined in constant file.
			model.addAttribute("allList", listDao.getAllListForDropdown());
			return "manageListData";
		} else {
			return "loginIn";
		}

	}

	@RequestMapping(value = "/editListData", method = RequestMethod.GET)
	public String getListDataObjectEdit(@RequestParam("listId") int listId,@RequestParam("listNo") int listNo, Model model,HttpServletRequest request) {
		//change get it from hash map defined in constant file for following three .
		UsersObject usersSess = (UsersObject) request.getSession().getAttribute("users");
		if (usersSess != null) {
		//model.addAttribute("allList", listDao.getAllList());
		model.addAttribute("listDataObject", listDataDao.getListDataByListId(listId,listNo));
		//model.addAttribute("allListData", listDataDao.getListDataByListId(listId));
		return "updateListData";
		}else {
			return "loginIn";
		}
	}

	
	  @RequestMapping(value = "/updateListData", method = RequestMethod.POST)
	  public String updateListData(@ModelAttribute("listDataObject") ListDataObj listDataObj, Model model, HttpServletRequest request)
	  { 
		  UsersObject usersSess = (UsersObject) request.getSession().getAttribute("users");
	   //System.out.println("List Value: " +listValue);
	   if (usersSess != null) { 
		   listDataDao.update(listDataObj); 
		   model.addAttribute("listDataObj", new ListDataObj()); 
		   model.addAttribute("allList", listDao.getAllList());
		   model.addAttribute("message", "List Data Updated Successfully.");
		   model.addAttribute("allListData", listDataDao.getAllListData()); 
		   return "manageListData";
	   }else {
			return "loginIn";
		}
	  }
	  
	 
	@RequestMapping(value = "/getListData", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<ListDataObj> getListData(@RequestParam("id") long id, Model model,
			HttpServletRequest request) {
		List<ListDataObj> listDataObject = listDataDao.getListDataByListId(id);
		return listDataObject;
	}
	
	@RequestMapping(value = "/getTagDataByListId", method = RequestMethod.POST)
	public String getListDataByListId(@RequestParam("listId") long listId, Model model,HttpServletRequest request) {
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
				List<ListDataObj> dataObjectlist = listDataDao.getListDataByListId(listId);
				model.addAttribute("allList", listDao.getAllListForDropdown());
				model.addAttribute("dataObjectlist", dataObjectlist);
				model.addAttribute("listDataObj", new ListDataObj());
				model.addAttribute("listId", listId);
				return "manageListData";
		   }else {
				return "loginIn";
			}
	}
}
