package com.common.Controllers;

import java.util.HashMap;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.common.Dao.BranchDao;
import com.common.Dao.DepartmentDao;
import com.common.Dao.DesignationDao;
import com.common.Dao.FolderDao;
import com.common.Dao.GroupDao;
import com.common.Dao.TagGrpDao;
import com.common.Dao.UsersDao;
import com.common.Utilities.DmsConstant;

@Component
public class StartInit {
	
	@Autowired
	private GroupDao groupDao;
	
	@Autowired
	private DepartmentDao departmentDao ;
    
	@Autowired
	private DesignationDao designationDao ;
	
	@Autowired
	private TagGrpDao tagGroupDao;
	
	@Autowired
	private UsersDao usersDao;
	
	@Autowired
	private FolderDao folderDao;
	
	@Autowired
	private BranchDao branchDao;
	
	@PostConstruct
	public void init() {
		
		
		DmsConstant.HASHMAP_OF_DEPARTMENT = (HashMap<Long, String>) departmentDao.getHashmapofDepartmentObject();
		  
		DmsConstant.HASHMAP_OF_DESIGNATION = (HashMap<Long, String>) designationDao.getHashmapofDesignationObject();
		 
		DmsConstant.HASHMAP_OF_GROUP = (HashMap<Long, String>) groupDao.getHashmapofGroupObject();
		
		DmsConstant.HASHMAP_OF_TAG_GROUP = (HashMap<Long, String>)  tagGroupDao.getHashmapofTagGrpObject();
		  
		DmsConstant.HASHMAP_OF_TAG_TYPE = (HashMap<Long, String>) tagGroupDao.getHashmapofTagTypeObject();
		
		DmsConstant.HASHMAP_OF_USER = (HashMap<Long, String>) usersDao.getHashmapofUser();
		
		DmsConstant.HASHMAP_OF_FOLDERS = (HashMap<Long, String>) folderDao.getHashmapofFolderObject();
		  
		DmsConstant.HASHMAP_OF_BRANCH = (HashMap<Integer, String>) branchDao.getHashmapofBranchObject();


		
	}

	
		
	

}
