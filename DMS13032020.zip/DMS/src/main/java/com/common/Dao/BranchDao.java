package com.common.Dao;

import java.util.HashMap;
import java.util.List;

import com.common.Objects.BranchObject;

public interface BranchDao {

	List<BranchObject> getAllBranch();

	void saveBranchObject(BranchObject branchObject);
	
	BranchObject getBranchById(Integer branchId);

	List<BranchObject> getBranchList();

	HashMap<Integer, String> getHashmapofBranchObject();

}
