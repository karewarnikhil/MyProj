package com.common.Dao;

import java.util.List;

import com.common.Objects.CompartmentObject;

public interface CompartmentDao {
	
	public List<CompartmentObject> getAllCompartments();

	public void saveCompartment(CompartmentObject compartmentObject);

	public CompartmentObject getCompartmentById(Integer compartId);

	public CompartmentObject getShelfByBRSId(Integer branchId, Integer rackId, Integer shelfId, String compNo);
}
