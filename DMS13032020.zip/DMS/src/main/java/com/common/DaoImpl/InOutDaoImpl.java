package com.common.DaoImpl;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;
import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.CompositeKey.DocumentCompositeKey;
import com.common.Dao.InOutDao;
import com.common.Objects.DocumentObject;
import com.common.Objects.ReportSearchObject;
import com.common.Utilities.DmsConstant;

@Repository
@Transactional
public class InOutDaoImpl implements InOutDao{
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public List<DocumentObject> getFilesWithFileNm(ReportSearchObject reportSearchObject) {
		Query qry =  sessionFactory.getCurrentSession().createNativeQuery(" SELECT d.fileid,d.seqno,d.folderid,d.creationdt,d.rootid,d.filenm,d.pagecnt,d.a0size,d.a1size,d.a2size,d.a3size,d.a4size,fo.deptid FROM filemst d,foldermst fo where d.folderid = fo.folderid And d.filenm ILIKE '%"+reportSearchObject.getFileName()+"%' order by d.filenm asc");
		List<DocumentObject> listFileNm = new ArrayList<DocumentObject>();
		List<Object[]> row = qry.getResultList();
		row.stream().forEach((record) -> {
			DocumentObject documentObject = new DocumentObject();
			DocumentCompositeKey documentCompositeKey = new DocumentCompositeKey();
			documentCompositeKey.setFileId(((BigInteger) record[0]).longValue());
			documentCompositeKey.setSeqNo(((Integer) record[1]).intValue());
			//documentObject.setDocumentCompositeKey((DocumentCompositeKey)record[0]);
			documentObject.setFolderId(((BigInteger) record[2]).longValue());
			documentObject.setCreationDt((((Timestamp) record[3])));
			documentObject.setRootId(((BigInteger) record[4]).longValue());
			documentObject.setFileName((String)(record[5]));
			documentObject.setPageCnt(((Integer) record[6]).intValue());
			documentObject.setA0Size(((Integer) record[7]).intValue());
			documentObject.setA1Size(((Integer) record[8]).intValue());
			documentObject.setA2Size(((Integer) record[9]).intValue());
			documentObject.setA3Size(((Integer) record[10]).intValue());
			documentObject.setA4Size(((Integer) record[11]).intValue());
			documentObject.setDepartmentNm(DmsConstant.HASHMAP_OF_DEPARTMENT.get(((record[12]))));
			listFileNm.add(documentObject);
		});
		return listFileNm;
	}
	
	

}
