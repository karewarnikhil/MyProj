package com.common.DaoImpl;

import java.util.HashMap;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.RackDao;
import com.common.Objects.BranchObject;
import com.common.Objects.RackObject;

@Repository
@Transactional
public class RackDaoImpl implements RackDao{
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public List<RackObject> getAllRacks() {
		return sessionFactory.getCurrentSession().createQuery("FROM RackObject order by rackId asc").list();
	}
	
	@Override
	public void saveRackObject(RackObject rackObject) {
		sessionFactory.getCurrentSession().saveOrUpdate(rackObject);
	}

	@Override
	public RackObject getRackById(Integer rackId) {
		RackObject rackObject = (RackObject) sessionFactory.getCurrentSession().get(RackObject.class,rackId);
		return rackObject;
	}

	@Override
	public RackObject getRackByBranchId(Integer branchId,String rackNo) {
		RackObject rackObject = (RackObject) sessionFactory.getCurrentSession().createQuery("FROM RackObject where branchId="+branchId+" AND rackNo='"+rackNo+"'").uniqueResult();
		return rackObject;
	}

	@Override
	public HashMap<Integer, String> getHashMapOfRack() {
		HashMap<Integer, String> hashMapofRackObject = new HashMap<>();
		
		List<RackObject> getAllRack = sessionFactory.getCurrentSession().createQuery(" SELECT new RackObject (ro.rackId ,ro.rackNo )FROM RackObject ro where ro.status='A'").list();
		for(RackObject rackObject:getAllRack) {
			hashMapofRackObject.put(rackObject.getRackId(),rackObject.getRackNo());
		}
		
		hashMapofRackObject.values().stream().forEach(System.out::println);
		return hashMapofRackObject;
	}

	@Override
	public List<RackObject> getRackDropDown(long branchId) {
		return sessionFactory.getCurrentSession().createQuery("FROM RackObject where branchId ="+branchId+"order by rackNo asc").list();
	}

}
