package com.common.Objects;

import java.util.List;
import java.util.Map;



public class CanvasChartData {
	
	public Map<Object,Object> map = null;
	//public List<List<Map<Object,Object>>> list = new ArrayList<List<Map<Object,Object>>>();
	//public List<Map<Object,Object>> dataPoints1 = new ArrayList<Map<Object,Object>>();
	public List<List<Map<Object,Object>>> list = null;
	public List<Map<Object,Object>> dataPoints1 = null;
	
	
		
		
		
	
 

}
