package com.common.Objects;

public class InfoObject {
	
	private long deptCount;
	
	private long fileCount;
	
	private long userCount;
	
	private long pageCount;
	
	private long a0Size;
	
	private long a1Size;
	
	private long a2Size;
	
	private long a3Size;
	
	private long a4Size;

	public long getDeptCount() {
		return deptCount;
	}

	public void setDeptCount(long deptCount) {
		this.deptCount = deptCount;
	}

	public long getFileCount() {
		return fileCount;
	}

	public void setFileCount(long fileCount) {
		this.fileCount = fileCount;
	}


	public long getUserCount() {
		return userCount;
	}

	public void setUserCount(long userCount) {
		this.userCount = userCount;
	}

	public long getPageCount() {
		return pageCount;
	}

	public void setPageCount(long pageCount) {
		this.pageCount = pageCount;
	}

	public long getA0Size() {
		return a0Size;
	}

	public void setA0Size(long a0Size) {
		this.a0Size = a0Size;
	}

	public long getA1Size() {
		return a1Size;
	}

	public void setA1Size(long a1Size) {
		this.a1Size = a1Size;
	}

	public long getA2Size() {
		return a2Size;
	}

	public void setA2Size(long a2Size) {
		this.a2Size = a2Size;
	}

	public long getA3Size() {
		return a3Size;
	}

	public void setA3Size(long a3Size) {
		this.a3Size = a3Size;
	}

	public long getA4Size() {
		return a4Size;
	}

	public void setA4Size(long a4Size) {
		this.a4Size = a4Size;
	}
	
	
	

}
