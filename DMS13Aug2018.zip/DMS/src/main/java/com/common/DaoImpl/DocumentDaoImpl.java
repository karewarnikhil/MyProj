package com.common.DaoImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.DocumentDao;
import com.common.Objects.DepartmentObject;
import com.common.Objects.DocumentObject;

@Repository
@Transactional
public class DocumentDaoImpl implements DocumentDao{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public List<DocumentObject> getAllDocuments() {
		return sessionFactory.getCurrentSession().createQuery(" FROM DocumentObject").list();
	}

	
	public void save(DocumentObject documentObject) {
		sessionFactory.getCurrentSession().saveOrUpdate(documentObject);
	}

	public List<DocumentObject> findAllByUserId(int userId) {
		return sessionFactory.getCurrentSession().createQuery(" FROM DocumentObject where userId="+userId).list();
	}

	public void deleteById(int id) {
		// TODO Auto-generated method stub
		
	}


	public DocumentObject findByFileId(long fileId) {
		DocumentObject documentObject = (DocumentObject) sessionFactory.getCurrentSession().get(DocumentObject.class,fileId);
		return documentObject;
	}


	public List<DocumentObject> findAllByFolderId(long folderId) {
		return sessionFactory.getCurrentSession().createQuery(" FROM DocumentObject where folderId="+folderId).list();
	}

}
