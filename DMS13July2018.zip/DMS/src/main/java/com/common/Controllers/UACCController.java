package com.common.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.common.Dao.MenuDao;
import com.common.Dao.UACCDao;
import com.common.Objects.MenuObject;
import com.common.Objects.UACCObject;
import com.common.Objects.UsersObject;

@Controller
@SessionAttributes("uaccObjectList")
public class UACCController {

	   @Autowired
	   private UACCDao uaccDao ;
	   
	   @Autowired
	   private MenuDao menuDao;
	   
	   @RequestMapping(value = "/registerUaccObject", method = RequestMethod.GET)
	   public String showUACCForm(Model model){  
		 UACCObject uaccObject = new UACCObject();
	     model.addAttribute("uaccObject", uaccObject);
	     return "menuAccess"; 
	   } 
	   
	   @RequestMapping(value="/changeUACC", method = RequestMethod.POST)  
	   public String manageDesignation(@RequestParam("userId") Integer userId,Model model){ 
		   List<MenuObject> menulist = menuDao.getMenuList();
	       List<UACCObject> uaccObjectList = uaccDao.getUACCListByUserId(userId); 
	       model.addAttribute("selectedUserId", userId);
	       model.addAttribute("menulist", menulist);
	       UACCObject uaccObject = new UACCObject();
	       model.addAttribute("uaccObject", uaccObject);
	       model.addAttribute("uaccObjectList", uaccObjectList);
	       return "menuAccess";
	   }  
	   
	   @RequestMapping(value = "/saveUACC", method = RequestMethod.POST)
	   public String saveData(@ModelAttribute("uaccObject") UACCObject uaccObject,@RequestParam("userId") Integer userId){  
		   List<Integer> menuIdList = uaccObject.getMenuIdList();
		   int menuId;
		   for(int i=0;i<menuIdList.size();i++) {
			   menuId = menuIdList.get(i);
			   UACCObject uACCObjectTwo = new UACCObject();
			   uACCObjectTwo.setMid(menuId);
			   uACCObjectTwo.setUserId(userId);
			   uACCObjectTwo.setAddFlag("A");
			   uACCObjectTwo.setDeleteFlag("A");
			   uACCObjectTwo.setPassFlag("A");
			   uACCObjectTwo.setUpdateFlag("A");
			   uACCObjectTwo.setViewFlag("A");
		       uaccDao.saveUACCObject(uACCObjectTwo);
		   }
	       return "home"; 
	   }  
	   
	   @RequestMapping(value="/deleteUACC", method = RequestMethod.POST)  
	   public String deleteUACC(@RequestParam("menuId") Integer menuId,@RequestParam("userId") Integer userId){  
		   UACCObject uaccObject = findUaccById(menuId,userId);
		   uaccDao.deleteUACCObject(uaccObject);
	       return "menuAccess";//will redirect to viewemp request mapping  
	   }  
	   
	   private UACCObject findUaccById(Integer menuId,Integer userId) {
		   UACCObject uaccObject =  uaccDao.getUACCById(menuId,userId); 
		   return uaccObject;
	   }
}
