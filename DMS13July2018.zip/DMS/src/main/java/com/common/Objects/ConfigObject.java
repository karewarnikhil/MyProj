package com.common.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity @Table(name="config")
public class ConfigObject {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "pk", updatable = false, nullable = false)
	private  int pk ;
	
	@Column(name="sk")
	private  String sk ;
	
	@Column(name="ds")
	private  String ds ;
	
	@Column(name="value")
	private  String value ;
	
	public ConfigObject() {
		
	}

	public ConfigObject(int pk, String sk, String ds, String value) {
		super();
		this.pk = pk;
		this.sk = sk;
		this.ds = ds;
		this.value = value;
	}

	public int getPk() {
		return pk;
	}

	public void setPk(int pk) {
		this.pk = pk;
	}

	public String getSk() {
		return sk;
	}

	public void setSk(String sk) {
		this.sk = sk;
	}

	public String getDs() {
		return ds;
	}

	public void setDs(String ds) {
		this.ds = ds;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	
}
