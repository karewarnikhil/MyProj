package com.common.Controllers;

import java.io.IOException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.common.Dao.DesignationDao;
import com.common.Objects.DesignationObject;
import com.common.Objects.UsersObject;




@Controller
public class DesignationController {
	
	/*public static final String UNSIGNED = "E:/SpringBooks/DigitalSignature/hello_empty.pdf";
	public static final String SIGNAME = "Signature1";
 
	public static final String UNSIGNED2 = "E:/SpringBooks/DigitalSignature/hello_empty2.pdf";
	
	
	public static final String DESTTwo = "E:/SpringBooks/DigitalSignature/OT_TS-7082_286082_158-1_v2.pdf";*/
	  
	   @Autowired
	   private DesignationDao designationDao ;
	   
	   @Autowired
	   ServletContext context;
	
	   @RequestMapping(value = "/registerDesignation", method = RequestMethod.GET)
	   public String showDesignationForm(Model model){  
		 DesignationObject designationObject = new DesignationObject();
	     model.addAttribute("designation", designationObject);
	     return "registerDesignation"; 
	   } 
	   
	   @RequestMapping(value = "/saveDesignation", method = RequestMethod.POST)
	   public String saveDesignationData(@ModelAttribute("designation") DesignationObject designationObject,Model model){  
	       Timestamp ts = new Timestamp(new Date().getTime());  
	       designationObject.setCreationDt(ts);
		   designationDao.saveDesignationObject(designationObject);
		  
		   designationObject = new DesignationObject();
		   model.addAttribute("designation", designationObject);
		   model.addAttribute("message", "Designation Saved Successfully.");
		   return "registerDesignation";
	      // return "redirect:/manageDesignation"; 
	   }  
	   
	   @RequestMapping(value = "/updateDesignation", method = RequestMethod.POST)
	   public String updateDesignationData(@ModelAttribute("designation") DesignationObject designationObject,Model model){  
		   designationDao.saveDesignationObject(designationObject);
		   model.addAttribute("message", "Designation Updated Successfully.");
		   model.addAttribute("designation",designationObject);
		   return "editDesignation";
	       //return "redirect:/manageDesignation"; 
	   }  
	   
	   @RequestMapping(value="/manageDesignation", method = RequestMethod.GET)  
	   public String manageDesignation(Model model,HttpServletRequest request) throws NoSuchAlgorithmException, CertificateException, IOException, KeyStoreException{
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
		  /* String SRC = "E:/SpringBooks/TSSJS2008-Donald-SpringForJavaServerFaces1.pdf";
		   String DEST = "E:/SpringBooks/DigitalSignature/TSSJS2008-Donald-SpringForJavaServerFaces1.pdf";
		   String configName = "/opt/bar/cfg/pkcs11.cfg";
		   Provider p = new sun.security.pkcs11.SunPKCS11();
		   System.out.println(p.getName());
		   Security.addProvider(p);
		 
		   String configName = "E:\\eTPKCS11.cfg.txt";
		   Provider provider = Security.getProvider("SunPKCS11");
		   provider = provider.configure(configName);
		   Security.addProvider(provider); 
		   
		   // Get provider KeyStore and login with PIN
		   String pin = "12345678";
		   
		   KeyStore keyStore = null;
			try {
				keyStore = KeyStore.getInstance("PKCS11",provider);
				keyStore.load(null, pin.toCharArray());
				 keyStore = KeyStore.getInstance("Windows-MY");
				 keyStore.load(null, null);
			} catch (KeyStoreException e) {
				e.printStackTrace();
				
			}
		
			
		   // Enumerate items (certificates and private keys) in the KeyStore
		   java.util.Enumeration<String> aliases = keyStore.aliases();
		  
		   String alias = null;
		  // String fileName = "2005_BookMatter_BeginningDatabasesWithPostgreS.pdf";
		   PrivateKey pk = null;
		   while (aliases.hasMoreElements()) {
		       alias = aliases.nextElement();
		   	   try {
				 pk = (PrivateKey) keyStore.getKey(alias,  pin.toCharArray());
				 System.out.println("alias=========="+alias);
				 //System.out.println("pk======="+pk);
			} catch (UnrecoverableKeyException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		       
		       Certificate[] chain = keyStore.getCertificateChain(alias);
		       System.out.println("Chain====="+chain);
		       
		       DigitalSignature digitalSignature = new DigitalSignature();
		       try {
				*//**
				 HelloWordSign
		    	   digitalSignature.sign(SRC, String.format(DEST, 1), chain, pk, DigestAlgorithms.SHA256, provider.getName(), CryptoStandard.CMS, "Test 1", "Ghent");
		    	  HelloWordSignTemp 
		    	   digitalSignature.sign(SRC, TEMP, DEST, chain, pk, DigestAlgorithms.SHA256, provider.getName(), CryptoStandard.CMS, "Temp test", "Ghent");	
		    	
		    	custom appearance
		    	   digitalSignature.addField(SRC, DEST);
		    	   digitalSignature.sign(DEST, "Signature1", DESTTwo, chain, pk,
		           		DigestAlgorithms.SHA256, provider.getName(), CryptoStandard.CMS,
		           		"Custom appearance example", "Ghent");
		        
		    	   sign1
		    	   digitalSignature.sign1(SRC, "Signature1", String.format(DEST, 1), chain, pk,
		           		DigestAlgorithms.SHA256, provider.getName(), CryptoStandard.CMS,
		           		"Custom appearance example", "Ghent");
		    	    **//*	 
		    	  // digitalSignature.createPdf("E:/SpringBooks/0764574833.pdf");
		    	   digitalSignature.sign(SRC, String.format(DEST, 1), chain, pk, 
		           DigestAlgorithms.SHA256, provider.getName(), CryptoStandard.CMS,"Digital Demo", "Pune");
		    	  } catch (GeneralSecurityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (DocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
		       
	
		  
			
		  /* // Enumerate items (certificates and private keys) in the KeyStore
		   java.util.Enumeration<String> aliases = keyStore.aliases();
		  
		   String alias = null;
		   String fileName = "2005_BookMatter_BeginningDatabasesWithPostgreS.pdf";
		   while (aliases.hasMoreElements()) {
		       alias = aliases.nextElement();
		       System.out.println("alias=========="+alias);
		       Certificate[] chain = keyStore.getCertificateChain(alias);
		       
		       System.out.println("Chain====="+chain);
		       //Print certificate
               X509Certificate cert = (X509Certificate)keyStore.getCertificate(alias);
               PublicKey pk = cert.getPublicKey(); 
               
               System.out.println("Public Key..........."+pk);
             
               Signature signature = Signature.getInstance(cert.getSigAlgName());
               FileOutputStream sigfos = new FileOutputStream(fileName);
               sigfos.write(cert.getSignature());
               sigfos.close();*/
               /*try {
            	  signature.initVerify(pk);
            	 
			} catch (InvalidKeyException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
             /*  System.out.println("Certificate: " + cert);
               System.out.println("Signature======================: "+ signature);
		  }*/
		   
		   
	       List<DesignationObject> designationlist = designationDao.getAllDesignation(); 
	       model.addAttribute("designationList", designationlist);
	       return "manageDesignation";
		   }else {
		   return "loginIn";
		   }
	   }  
	   
	   @RequestMapping(value="/editDesignation", method = RequestMethod.GET)  
	   public String editDesignation(@RequestParam("designationId") Integer designationId,Model model,HttpServletRequest request){  
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
		   DesignationObject designationObject = findByDesignationId(designationId);
	       model.addAttribute("designation", designationObject);
	       return "editDesignation";//will redirect to viewemp request mapping  
		   }else {
			   return "loginIn";
		   }
		   
	   }  
	   
	 /*  @RequestMapping(value="/deleteDesignation", method = RequestMethod.GET)  
	   public String deleteDesignation(@RequestParam("designationId") Integer designationId,Model model){  
		   DesignationObject designationObject = findByDesignationId(designationId);
		   designationDao.deleteDesignationObject(designationObject);
	       return "redirect:/manageDesignation";//will redirect to viewemp request mapping  
	   }  */
	   
	   private DesignationObject findByDesignationId(Integer designationId) {
		   DesignationObject designationObject =  designationDao.getDesignationById(designationId);
		   return designationObject;
	   }
}
