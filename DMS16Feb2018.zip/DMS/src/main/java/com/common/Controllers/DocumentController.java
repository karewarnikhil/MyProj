package com.common.Controllers;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.common.CompositeKey.DocumentCompositeKey;
import com.common.Dao.ClassDao;
import com.common.Dao.DocumentDao;
import com.common.Dao.FolderDao;
import com.common.Dao.TagDao;
import com.common.Objects.ClassObject;
import com.common.Objects.DocumentObject;
import com.common.Objects.FileBucket;
import com.common.Objects.FolderObject;
import com.common.Objects.TagGroupObject;
import com.common.Objects.UsersObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;



@Controller
public class DocumentController {
	
	//Save the uploaded file to this folder
    //private static String UPLOADED_FOLDER = "E://workspaceNikhil//DMS//src//main//webapp//upload//";
	//private static String UPLOADED_FOLDER = "";
  
    
    @Autowired
    DocumentDao documentDao;
	
	@Autowired
	FolderDao folderDao;
	
	@Autowired
	ClassDao classDao;
	
	@Autowired
	TagDao tagDao;
	
	@Autowired
	ServletContext context;
	
	@RequestMapping(value = "/uploadFile", method = RequestMethod.GET)
	   public String showFileForm(Model model,HttpServletRequest request){  
		  HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
		   //DocumentObject documentObject = new DocumentObject();
		   //List<FolderObject> listOffolder = folderDao.getAllFoldersByRootId(0);
		   FileBucket fileBucket = new FileBucket();
		   model.addAttribute("fileBucket", fileBucket);
		  // model.addAttribute("listOffolder", listOffolder);
	       return "fileUpload"; 
		   }else {
			   return "loginIn"; 
		   }
    } 
	
	@RequestMapping(value = "/uploadFolder", method = RequestMethod.GET)
	   public String showFolderForm(Model model,HttpServletRequest request){  
		HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
		   //DocumentObject documentObject = new DocumentObject();
		   //List<FolderObject> listOffolder = folderDao.getAllFoldersByRootId(0);
		   FileBucket fileBucket = new FileBucket();
		   model.addAttribute("fileBucket", fileBucket);
		  // model.addAttribute("listOffolder", listOffolder);
	       return "folderUpload"; 
		   }else {
			   return "loginIn";
		   }
	} 
	
	 @RequestMapping(value = "/saveFolder", method = RequestMethod.POST)
	   public String saveFolder(@ModelAttribute("document") FileBucket fileBucket, HttpServletRequest request,Model model){  
		   // HttpSession session = request.getSession();
		   // long folderId = Integer.parseInt(request.getParameter("folderId"));
		   // UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		  //  Date date = new Date();  
	     //   Timestamp ts = new Timestamp(date.getTime());  
	        
	        //String filePath = context.getRealPath("/")+fileBucket.getFolderPath();
	       /* File file = new File(fileBucket.getFolderPath());
	        String path = file.getAbsolutePath();*/
	        
	        File directory = new File(fileBucket.getFolderPath());
	       // String path = directory.getAbsolutePath();
	        //get all the files from a directory
	        File[] fList = directory.listFiles();
	        for (File file : fList){
	            if (file.isFile()){
	                System.out.println("File Name==="+file.getName());
	            }
	            
	            else if (file.isDirectory()){
	                System.out.println("Folder Name ==="+file.getName());
	            }
	        }    
	        /*for (File file : fList){
	            if (file.isFile()){
	                System.out.println("File Name"+file.getName());
	            }
	            
	            else if (file.isDirectory()){
	                System.out.println("Folder Name"+file.getName());
	            }
	        }*/
	    
	        //System.out.println("filePath==="+path);
	        
	        	/*FolderObject folderObject = folderDao.getFolderById(folderId);
	        	ClassObject classObject = null;
	        	if(folderObject.getRootId() == 0)
	        		classObject = classDao.getClassById(folderId);
	        	else 
	        		classObject = classDao.getClassById(folderObject.getRootId());*/
	      return "defaultPage";
	   }  
	 
	 
	 
	
	@RequestMapping(value = "/uploadFileVersion", method = RequestMethod.GET)
	   public String uploadFileVersion(Model model,@RequestParam("fileId") long fileId,HttpServletRequest request){  
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
		   FileBucket fileBucket = new FileBucket();
		   model.addAttribute("fileBucket", fileBucket);
		   long seqNoMax = documentDao.checkGreaterSeqNo(fileId);
		   DocumentCompositeKey documentCompositeKey = new DocumentCompositeKey(fileId, seqNoMax);
		   DocumentObject documentObject = documentDao.findByFileId(documentCompositeKey);
		   
		   //System.out.println(documentObject.getSeqNo());
		  // FolderObject folderObject = folderDao.getFolderById(folderId);
		   // check and try to eliminate following session values
		   if(documentObject.getAtriBt().equals("O") ) {
			   model.addAttribute("error", "You can not upload file version.");
			   return "defaultPage"; 
		   }
		   else {
			   session.setAttribute("documentObject", documentObject);
		       return "fileUploadVersion"; 
		   }
		   }else {
			   return "loginIn";
		   }
	} 
	
	   @RequestMapping(value = "/displayFile", method = RequestMethod.GET)
	   public String displayFile(@RequestParam("fileId") long fileId,@RequestParam("seqNo") long seqNo,Model model,HttpServletRequest request,HttpServletResponse response){ 
		 HttpSession session = request.getSession();
		 UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
		 session.removeAttribute("tagObjectlist");
		 session.removeAttribute("tagGroupList");
		 DocumentCompositeKey documentCompositeKey = new DocumentCompositeKey(fileId, seqNo);
		 DocumentObject documentObject = documentDao.findByFileId(documentCompositeKey);
		 long rootId = 0;
		 // need to remove hardCoding
		 if(documentObject.getRootId() == 0)
			 rootId = documentObject.getFolderId();
			// rootId = documentObject.getFolderObject().getFolderId();
		 else
			 rootId = documentObject.getRootId();
		 //remove following and comes from hash map defined in constant files
		 List<TagGroupObject> tagGroupList = tagDao.getAllTagsForFileDisplay(rootId);
		/*if(documentObject.getFileExtn().contains("application/pdf")) {
		        byte[] documentInBytes = documentObject.getFileContent();        
		        response.setHeader("Content-Disposition", "inline; filename=\"report.pdf\"");
		        response.setDateHeader("Expires", -1);
		        response.setContentType("application/pdf");
		        response.setContentLength(documentInBytes.length);
		        response.getOutputStream().write(documentInBytes);
	    } */
		
	  /* if(documentObject.getFileExtn().contains("image/"))  {*/
		//need to remove this base 64 encoding use file create.
		 
		 String name=documentObject.getFileName();
		 // get file separator get it from java class separator . 
		 String filePath = context.getRealPath("/")+"resources\\upload\\"+name;
		        try {           
			            File file = new File(filePath);
			            if(file.exists() == false) {
			            BufferedOutputStream stream =  new BufferedOutputStream(new FileOutputStream(file));
			            byte[] bytes = documentObject.getFileContent();
			            stream.write(bytes);
			            stream.close();
			            stream.flush();
			           // System.out.println("You have uploaded file");
			          //  System.out.println(filePath);
			            file.deleteOnExit();
		            }
		        } catch (Exception e) {
		          //System.out.println("Failed to upload");
		        	e.printStackTrace();
		        }
		        
		/*byte[] encodeBase64 = Base64.getEncoder().encode(documentObject.getFileContent());
		 //change it to error message of catch printStackTrace
		String base64Encoded = null;
		try {
			base64Encoded = new String(encodeBase64, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		 */
		        
		 
		 //model.addAttribute("fileForDisplay", base64Encoded );
		 //model.addAttribute("imageExtension", documentObject.getFileExtn());
		 //model.addAttribute("tagGroupList",tagGroupList);
		 model.addAttribute("fileId",documentObject.getDocumentCompositeKey().getFileId());
		 session.setAttribute("tagGroupList", tagGroupList);
		 session.setAttribute("imageExtension", documentObject.getFileExtn());
		 session.setAttribute("fileName", name);
		// session.setAttribute("fileForDisplay", base64Encoded);
		 session.setAttribute("documentObject", documentObject);
		
      /* }*/	 
	     return "fileDisplay"; 
		   }else {
			   return "loginIn";
		   }
 } 
	
	
	 @RequestMapping(value = "/multipleTagging", method = RequestMethod.GET)
	   public String multipleTagging(@RequestParam("fileId") long fileId,@RequestParam("seqNo") long seqNo,Model model,HttpServletRequest request,HttpServletResponse response) { 
	  
		 HttpSession session = request.getSession();
		 UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
		 session.removeAttribute("tagObjectlist");
		 //session.removeAttribute("imageExtension");
		 //session.removeAttribute("fileForDisplay");
		 session.removeAttribute("tagObjectlist");
		 session.removeAttribute("documentObject");
		 List<DocumentObject> documentlist = (List<DocumentObject>) session.getAttribute("documentlist");
		 int objectIndex = 0;
		 DocumentObject documentObjectInit = null;
		 if(documentlist == null) {
			 DocumentCompositeKey documentCompositeKey = new DocumentCompositeKey(fileId, seqNo);
			 //documentObjectInit = documentDao.findByFileId(fileId);
			 documentObjectInit = documentDao.findByFileId(documentCompositeKey);
			 documentlist  = documentDao.getAllDocumentsForMultiTagging(documentObjectInit);
			 objectIndex = objectIndex+1;
			 
			 long rootId = 0;
			 // need to remove following hardcoding
			 if(documentObjectInit.getRootId() == 0)
				 rootId = documentObjectInit.getFolderId();
			 else
				 rootId = documentObjectInit.getRootId();
			 List<TagGroupObject> tagGroupList = tagDao.getAllTagsForFileDisplay(rootId);
		//	 model.addAttribute();
			 session.setAttribute("tagGroupList", tagGroupList);
			 
		 }
		 else {
			 //index out of bound exception solve
			 objectIndex = (int)fileId;
			 DocumentObject documentObjectList = documentlist.get(objectIndex);
			 documentObjectInit = documentDao.findByFileId(documentObjectList.getDocumentCompositeKey());
			
			 if(objectIndex == documentlist.size()-1)
				 objectIndex = 0;
			 else
				 objectIndex = objectIndex+1;
		 }
		 
		 //remove base64Encoded and get from file upload function
		 
		/* byte[] encodeBase64 = Base64.getEncoder().encode(documentObjectInit.getFileContent());
		 String base64Encoded = null;*/
      // change it to errorMessage of catch printStackTrace
		/*try {
			base64Encoded = new String(encodeBase64, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}*/
		// model.addAttribute("fileForDisplay", base64Encoded );
		 //model.addAttribute("imageExtension", documentObjectInit.getFileExtn());
		 //model.addAttribute("nextFileId",objectIndex);
		 
		 String name=documentObjectInit.getFileName();
		 // get file separator get it from java class separator . 
		 String filePath = context.getRealPath("/")+"resources\\upload\\"+name;
		        try {           
			            File file = new File(filePath);
			            if(file.exists() == false) {
			            BufferedOutputStream stream =  new BufferedOutputStream(new FileOutputStream(file));
			            byte[] bytes = documentObjectInit.getFileContent();
			            stream.write(bytes);
			            stream.close();
			            stream.flush();
			           // System.out.println("You have uploaded file");
			          //  System.out.println(filePath);
			            file.deleteOnExit();
		            }
		        } catch (Exception e) {
		          //System.out.println("Failed to upload");
		        	e.printStackTrace();
		        }
		        
		// session.setAttribute("imageExtension", documentObjectInit.getFileExtn());
		 //session.setAttribute("fileForDisplay", base64Encoded);
		 session.setAttribute("fileName", name);
		 session.setAttribute("nextFileId",objectIndex);
		 session.setAttribute("seqNo",1);
		 //session.setAttribute(nextSeqNo, arg1);
		 session.setAttribute("documentlist", documentlist);
		 session.setAttribute("documentObject", documentObjectInit);
		 //model.addAttribute("documentObject", documentObjectInit);
		 //model.addAttribute("fileName", documentObject.getFileName());
	     return "multipleFileDisplay"; 
		 }else {
			 return "loginIn";
		 }
   } 
	 
	
	@RequestMapping(value = "/displayViewer", method = RequestMethod.GET)
	   public String displayViewer(@RequestParam("fileId") long fileId,@RequestParam("seqNo") long seqNo,Model model,HttpServletRequest request,HttpServletResponse response){ 
		 HttpSession session = request.getSession();
		 UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
		 DocumentCompositeKey documentCompositeKey = new DocumentCompositeKey(fileId, seqNo);
		 DocumentObject documentObject = documentDao.findByFileId(documentCompositeKey);
		 List<DocumentObject> seqNodocumentObject = documentDao.getFileVersions(fileId);

		 long rootId = 0;
		 if(documentObject.getRootId() == 0)
			// rootId = documentObject.getFolderObject().getFolderId();
			 rootId = documentObject.getFolderId();
		 else
			 rootId = documentObject.getRootId();
		 //List<TagGroupObject> tagGroupList = tagDao.getAllTagsForFileDisplay(rootId);
		/*if(documentObject.getFileExtn().contains("application/pdf")) {
		        byte[] documentInBytes = documentObject.getFileContent();        
		        response.setHeader("Content-Disposition", "inline; filename=\"report.pdf\"");
		        response.setDateHeader("Expires", -1);
		        response.setContentType("application/pdf");
		        response.setContentLength(documentInBytes.length);
		        response.getOutputStream().write(documentInBytes);
	    } */
		
	  /* if(documentObject.getFileExtn().contains("image/"))  {*/
		 
		  String fileName = documentObject.getFileName();
		  String filePath = context.getRealPath("/")+"resources\\upload\\"+fileName;
		        try {           
			            File file = new File(filePath);
			            if(file.exists() == false) {
				            BufferedOutputStream stream =  new BufferedOutputStream(new FileOutputStream(file));
				            byte[] bytes = documentObject.getFileContent();
				            stream.write(bytes);
				            stream.close();
				            stream.flush();
				           // System.out.println("You have uploaded file");
				          //  System.out.println(filePath);
				            file.deleteOnExit();
		            }
		        } catch (Exception e) {
		          //System.out.println("Failed to upload");
		        	e.printStackTrace();
		        }
		
		 //need to remove byte64 encoding      
		/* byte[] encodeBase64 = Base64.getEncoder().encode(documentObject.getFileContent());
		//change it to error message  of catch block afterwards.
		String base64Encoded = null;
		try {
			base64Encoded = new String(encodeBase64, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			
			e.printStackTrace();
		}*/
		System.out.println(filePath);
		// model.addAttribute("fileForDisplay", base64Encoded );
		// model.addAttribute("imageExtension", "text/html");
		// model.addAttribute("fileId",documentObject.getFileId());
		 model.addAttribute("documentObject", documentObject);
		 model.addAttribute("fileName", fileName);
		 model.addAttribute("seqNodocumentObject", seqNodocumentObject);
		 return "fileViewer"; 
		// model.addAttribute("imageExtension", documentObject.getFileExtn());
	    //model.addAttribute("tagGroupList",tagGroupList);
		// session.setAttribute("tagGroupList", tagGroupList);
		 //session.setAttribute("imageExtension", documentObject.getFileExtn());
		 //session.setAttribute("fileForDisplay", base64Encoded);
		// model.addAttribute("documentObject", documentObject);
		
		
   /* }*/	
		
		 
		 /* System.out.println("pathFR===="+pathFR);
	     //System.out.println("filePath===="+filePath);
	     
	     OutputStream os = new FileOutputStream(pathFR+"/"+documentObject.getFileName());
	     os.write(documentObject.getFileContent());
	     os.close();
		
	     File temp = new File(pathFR,"abc.pdf");*/
		}  else {
			return "loginIn";
		}
} 
	
	@RequestMapping(value = "/fileVersionViewer", method = RequestMethod.GET)
	public String fileVersionViewer(Model model, @RequestParam("fileId") String fileIdSeqNo, HttpServletRequest request,HttpServletResponse response) {
		UsersObject usersSessionObject = (UsersObject) request.getSession().getAttribute("users");
		if(usersSessionObject != null) {
		String[] fileIdSeqNo1 = fileIdSeqNo.split("~");
		int fileId = Integer.parseInt(fileIdSeqNo1[0]);
		int seqNo = Integer.parseInt(fileIdSeqNo1[1]);
		DocumentObject documentObject = documentDao.getFileByFileIdAndSeqNo(fileId, seqNo);
		List<DocumentObject> seqNodocumentObject = documentDao.getFileVersions(fileId);
        
		//remove hard coding and come from constant file.
		DateFormat df = new SimpleDateFormat("ddMMyyyyHHmmss");
		String reportDate = df.format(Calendar.getInstance().getTime());

		String fileName = usersSessionObject.getUserName() + "~" + reportDate + "~"
				+ documentObject.getFileName().trim().replaceAll(" ", "");
		// get file separator get it from java class separator . 
		String filePath = context.getRealPath("/") + "resources\\upload\\" + fileName;
        
		//convert afterwards to error message of printStackTrace of catch block
		File file = new File(filePath);
		try {
			OutputStream out = new FileOutputStream(filePath);
			out.write(documentObject.getFileContent());
			out.close();
		}catch (IOException e) {
			e.printStackTrace();
		}
		file.deleteOnExit();

		model.addAttribute("fileName", fileName);
		request.getSession().setAttribute("documentObject", documentObject);
		model.addAttribute("seqNodocumentObject", seqNodocumentObject);
		model.addAttribute("attribute", documentObject.getAtriBt());
		model.addAttribute("documentObjectData", documentObject);

		return "fileViewer";
		}else {
			return "loginIn";
		}
	}
	
	@RequestMapping(value="/manageDocument", method = RequestMethod.GET)  
	   public String manageDocument(Model model,HttpServletRequest request){
		 UsersObject usersSessionObject = (UsersObject) request.getSession().getAttribute("users");
		 if(usersSessionObject != null) {
		 List<DocumentObject> documentlist = documentDao.getAllDocuments();
		// List<DocumentObject> documentlist = new ArrayList<>();
		/*for(DocumentObject documentObject:documentlist) {
			 System.out.println(documentObject.getFileId());
		 }*/
	     model.addAttribute("documentlist", documentlist);
	     return "manageDocument";
		 }else {
			 return "loginIn";
		 }
	} 
	
	 @RequestMapping(value = "/saveDocument", method = RequestMethod.POST)
	   public String saveDocument(@ModelAttribute("document") FileBucket fileBucket, HttpServletRequest request,Model model){  
		    System.gc();
		    HttpSession session = request.getSession();
		    long folderId = Integer.parseInt(request.getParameter("folderId"));
		    UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		    Date date = new Date();  
	        Timestamp ts = new Timestamp(date.getTime());  
	    //  System.out.println(ts);           
	       
	        List<MultipartFile> listOfMultipartFile = fileBucket.getListOfMultipartFile();
	        //long fileLength = listOfMultipartFile.size();
	        //only 50 files for upload 
	        // change hard-code come from constant file
	        if(listOfMultipartFile.size() <= 50) {
	        	FolderObject folderObject = folderDao.getFolderById(folderId);
	        	ClassObject classObject = null;
	        	if(folderObject.getRootId() == 0)
	        		classObject = classDao.getClassById(folderId);
	        	else 
	        		classObject = classDao.getClassById(folderObject.getRootId());
	        	//need to remove afterwards
	        	String filepath = folderDao.getPath((int) folderId);
				String fileLocation = folderDao.getLocation((int) folderId);
	        	/*List<FolderObject> listOfFolderObject = (List<FolderObject>) folderDao.getChildFolderList(folderObject.getRootId());
	        	
	        	//need to remove following path given
	        	String filepath = null;
	        	String fileLocation = null;
	        	for(FolderObject folderObject2:listOfFolderObject) {
	        		if(folderId == folderObject2.getFolderId()) {
	        			filepath = filepath+"/"+folderObject2.getFolderNm();
		        		fileLocation = fileLocation+"~"+folderObject2.getFolderId();
		        		break;
	        		}
	        			
	        		filepath = filepath+"/"+folderObject2.getFolderNm();
	        		fileLocation = fileLocation+"~"+folderObject2.getFolderId();
	        	}*/
	        	
	        	List<DocumentObject> documentListForDuplicate = null; 
	        	int fileSavedCount = 0;
		        for(MultipartFile multipartFile:listOfMultipartFile) {
		        	//change to string value after
		        	DocumentObject documentObjectCheck = documentDao.findByFileNameAndFolderId(multipartFile.getOriginalFilename(),folderObject.getFolderId());
		        	
		        	if((documentObjectCheck != null) && (documentObjectCheck.getFileExtn().contains(multipartFile.getContentType()))) {
		        		if(documentListForDuplicate.size() < 0) {
		        			documentListForDuplicate = new ArrayList<DocumentObject>();
		        		}
		        		documentListForDuplicate.add(documentObjectCheck);
		        	}
		        	else {
		        		DocumentObject documentObject = new DocumentObject();
			 	        documentObject.setCreationDt(ts);
			 	        documentObject.setFolderId(folderObject.getFolderId());
			 	         //documentObject.setFolderObject(folderObject);
			 	        documentObject.setRootId(folderObject.getRootId());
				        documentObject.setFileName(multipartFile.getOriginalFilename());
				       // String aa = multipartFile.getContentType();
				       // System.out.println(aa);
				        documentObject.setFileExtn(multipartFile.getContentType());
				        //change it to error message of catch printStackTrace
						try {
							documentObject.setFileContent(multipartFile.getBytes());
						} catch (IOException e) {
							e.printStackTrace();
						}
				       // documentObject.setCreatedBy(usersSessionObject.getUserId());
						documentObject.setUsersObject(usersSessionObject);
				       
				        //changed to folder location and folderpath
				       // documentObject.setFileLocation(folderObject.getLocation());
				     //   documentObject.setFilePath(folderObject.getFolderPath());
				        documentObject.setFileLocation(fileLocation);
				        documentObject.setFilePath(filepath);
				        //need to remove following hardcoding
				        documentObject.setPageCnt(0);
				        DocumentCompositeKey documentCompositeKey = new DocumentCompositeKey();
				        documentCompositeKey.setSeqNo(1);
				        documentObject.setDocumentCompositeKey(documentCompositeKey);
				       //documentObject.setSeqNo(1);
				        documentObject.setAtriBt("A");
				        documentObject.setTagStatus("N");
				       
				        //set it for default versioning
				        documentObject.setVerType("BT");
				        documentObject.setVerId(0);
				        documentObject.setVerNo(1);
				        
				       //ServletContext context = request.getSession().getServletContext();
				  		//UPLOADED_FOLDER = context.getRealPath("//")+"//src//main//webapp//upload//";
				  		//System.out.println();
				  	
				       // Path path = Paths.get(UPLOADED_FOLDER + multipartFile.getOriginalFilename());
				       // Files.write(path, documentObject.getFileContent());
				        //documentlist.add(documentObject);
				        
				        documentDao.save(documentObject);
				        fileSavedCount++;
		        	}
		        	// 
			        //model.addAttribute("documentlist", documentlist);
		        }
		        
		        if(documentListForDuplicate == null) {
		        	 updateClassAndFolder(folderObject, classObject, fileSavedCount);
		               
		    	   model.addAttribute("documentListForDuplicate", documentListForDuplicate);
		    	   model.addAttribute("fileBucket", fileBucket);
		    	   return "fileUpload"; 
		       }  
		       else {
		    	   //check following code
		    	   updateClassAndFolder(folderObject, classObject, fileSavedCount);
		    	   return "redirect:/manageDocument"; 
		       }
		    	   
	        }    
	        else {
	  		model.addAttribute("fileBucket", fileBucket);
	  	   //need to remove following hardcoding get it from message resource bundles.
	        request.setAttribute("error", "You Can select Only 50 files to upload.");
	        return "fileUpload"; 
	        }
	   }

	private void updateClassAndFolder(FolderObject folderObject, ClassObject classObject, int fileSavedCount) {
		   classObject.setFileCnt(classObject.getFileCnt()+fileSavedCount);
		   fileSavedCount = fileSavedCount+folderObject.getFileCnt();
		   folderObject.setFileCnt(fileSavedCount);  
		   
		   //need to put in exception Handler
		   folderDao.updateFolderObject(folderObject);
		   classDao.updateClassObject(classObject);
	}  
	 
	 
	 @RequestMapping(value = "/saveDocumentVersion", method = RequestMethod.POST)
	   public String saveDocumentVersion(@ModelAttribute("document") FileBucket fileBucket, HttpServletRequest request,Model model){  
		    HttpSession session = request.getSession();
		    //FolderObject folderObject = (FolderObject) session.getAttribute("folderObject");
		    DocumentObject documentSessionObject = (DocumentObject) session.getAttribute("documentObject");
		  
		    long seqNo =  documentDao.getMaxSequenceValue(documentSessionObject.getDocumentCompositeKey().getFileId());
		    UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		    Date date = new Date();  
	        Timestamp ts = new Timestamp(date.getTime());  
	        
	        //List<MultipartFile> listOfMultipartFile = fileBucket.getListOfMultipartFile();
	        MultipartFile multipartFile = fileBucket.getMultipartFile();
	       
	        	//change to string value after
	        	//DocumentObject documentObjectCheck = documentDao.findByFileNameAndFolderId(multipartFile.getOriginalFilename(),folderObject.getFolderId());
	        	
	        	//if((documentObjectCheck != null) && (documentObjectCheck.getFileExtn().contains(multipartFile.getContentType()))) {
	        	
	        	    if(!(documentSessionObject.getFileName().equals(multipartFile.getOriginalFilename()))) {
	        			   model.addAttribute("fileBucket", fileBucket);
	        			   model.addAttribute("error", "File Name Does not match to selected file name.");
	        		       return "fileUploadVersion"; 
	        	    }
	        	    
	        		DocumentObject documentObject = new DocumentObject();
	        		DocumentCompositeKey documentCompositeKey = new DocumentCompositeKey(documentSessionObject.getDocumentCompositeKey().getFileId(), seqNo);
	        		//documentObject.setFileId(documentSessionObject.getDocumentCompositeKey().getFileId());
		 	        documentObject.setCreationDt(ts);
		 	        documentObject.setFolderId(documentSessionObject.getFolderId());
		 	         //documentObject.setFolderObject(folderObject);
		 	        documentObject.setRootId(documentSessionObject.getRootId());
			        documentObject.setFileName(multipartFile.getOriginalFilename());
			       // String aa = multipartFile.getContentType();
			       // System.out.println(aa);
			        documentObject.setFileExtn(multipartFile.getContentType());
			        //change it to error message of catch printStackTrace
					try {
						documentObject.setFileContent(multipartFile.getBytes());
					} catch (IOException e) {
						e.printStackTrace();
					}
			       // documentObject.setCreatedBy(usersSessionObject.getUserId());
					documentObject.setUsersObject(usersSessionObject);
			        documentObject.setFileLocation(documentSessionObject.getFileLocation());
			        documentObject.setFilePath(documentSessionObject.getFilePath());
			        //need to remove following hardcoding
			        documentObject.setPageCnt(0);
			        
			        
			      //  documentObject.setSeqNo(seqNo);
			        documentObject.setDocumentCompositeKey(documentCompositeKey);
			        documentObject.setAtriBt(documentSessionObject.getAtriBt());
			        documentObject.setTagStatus(documentSessionObject.getTagStatus());
			       
			       //get this values from constant files.
			        if(fileBucket.getVersion().equals("MN")) {
			        	 //set it for default versioning
				        documentObject.setVerType(fileBucket.getVersion());
				        documentObject.setVerNo(documentSessionObject.getVerNo());
				        documentObject.setVerId(documentSessionObject.getVerId()+1);
			        }
			        //get this values from constant files.
			        else if(fileBucket.getVersion().equals("MJ") ) {
			        	 //set it for default versioning
				        documentObject.setVerType(fileBucket.getVersion());
				        documentObject.setVerNo(documentSessionObject.getVerNo()+1);
			        	documentObject.setVerId(0);
			        }
			        else {
			        	 //set it for default versioning
			        	 //get this values from constant files.
				        documentObject.setVerType("BT");
				        documentObject.setVerNo(1);
			        	documentObject.setVerId(0);
			        }
			        documentDao.save(documentObject);
			        session.removeAttribute("documentObject");
	        	//}
	        	/*else {
	        		model.addAttribute("fileBucket", fileBucket);
	    	        request.setAttribute("error", "Selected file does not exists.");
	    	        return "fileUploadVersion"; 
	        	}*/

	        return "defaultPage"; 
	       
	   }  
	
		 @RequestMapping(value="/downloadDocument", method = RequestMethod.GET)  
		   public String downloadDocument(@RequestParam("fileId") long fileId,@RequestParam("seqNo") long seqNo,Model model,HttpServletResponse response,HttpServletRequest request){
			 HttpSession session = request.getSession();
			 UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
			 if(usersSessionObject != null) {
			    DocumentCompositeKey documentCompositeKey = new DocumentCompositeKey(fileId, seqNo);
			    DocumentObject documentObject = documentDao.findByFileId(documentCompositeKey);
			    response.setContentType(documentObject.getFileExtn());
		        response.setContentLength(documentObject.getFileContent().length);
				// get file separator get it from java class separator . 
		        response.setHeader("Content-Disposition","attachment; filename=\"" + documentObject.getFileName() +"\"");
	            try
	            {
	            	FileCopyUtils.copy(documentObject.getFileContent(), response.getOutputStream());
	                response.getOutputStream().flush();
	                response.getOutputStream().close();
	            }
	            catch (IOException ex) {
	                ex.printStackTrace();
	            }
		       return "manageDocument";//will redirect to viewemp request mapping  
			 }else {
				 return "loginIn";
			 }
		   }  
		 
		 /*@RequestMapping(value="/manageDocument", method = RequestMethod.GET)  
		   public String documentReader(Model model,HttpServletResponse response){  
		        File directory = new File(UPLOADED_FOLDER);
		        System.out.println(directory.getTotalSpace());
		        File[] fList = directory.listFiles();
		        for (File file : fList){
		            System.out.println(file.getName());
		        }
				return "manageDocument";
		   } */
		 
		 //get all hard code values for both following two functions from constant files.
		 @RequestMapping(value = "/getFiles", method = RequestMethod.POST, produces = "application/json")
			public @ResponseBody String getFiles(@RequestParam("folderId") long folderId, Model model){
			    List<DocumentObject> documentlist = documentDao.findAllByFolderId(folderId);
			    for(DocumentObject documentObject:documentlist) {
			    	if(documentObject.getFileExtn().contains("application/pdf")) {
			    		documentObject.setExtensionIcon("fa fa-file-pdf-o");
			    	}
			    	else if(documentObject.getFileExtn().contains("image/")){
			    		documentObject.setExtensionIcon("fa fa-file-image-o");
			    	}
			    	else if(documentObject.getFileExtn().contains("text/plain")){
			    		documentObject.setExtensionIcon("fa fa-file-text-o");
			    	}
			    	else if(documentObject.getFileExtn().contains("application/msword")){
			    		documentObject.setExtensionIcon("fa fa-file-word-o");
			    	}
			    	else if(documentObject.getFileExtn().contains("application/octet-stream")){
			    		documentObject.setExtensionIcon("fa fa-file-zip-o");
			    	}
			    	else if(documentObject.getFileExtn().contains("application/vnd.openxmlformats-officedocument.presentationml.presentation")){
			    		documentObject.setExtensionIcon("fa fa-file-powerpoint-o");
			    		
			    	}
			    	else if(documentObject.getFileExtn().contains("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")){
			    		documentObject.setExtensionIcon("fa fa-file-excel-o");
			    	}
			    	else
			    		documentObject.setExtensionIcon("fa fa-file-o");
			    	
			    	
			    }
			    ObjectMapper mapper = new ObjectMapper();
			    //convert it afterwards to error message for catch block printStackTrace
	            String data = null;
				try {
					data = mapper.writeValueAsString(documentlist);
				} catch (JsonProcessingException e) {
					e.printStackTrace();
				}
	            return data;
		 }
		 
		 //get all hard code values for both following two functions from constant files.
		 @RequestMapping(value = "/getUnTagFilesData", method = RequestMethod.POST, produces = "application/json")
			public @ResponseBody String getUnTagFilesData(@RequestParam("folderId") long folderId, Model model,HttpServletRequest request){
			 HttpSession session = request.getSession();
			 //for removing attribute
			 session.removeAttribute("documentlist");
			
			    List<DocumentObject> documentlist = documentDao.findAllByFolderIdAndUntagged(folderId);
			    for(DocumentObject documentObject:documentlist) {
			    	if(documentObject.getFileExtn().contains("application/pdf")) {
			    		documentObject.setExtensionIcon("fa fa-file-pdf-o");
			    	}
			    	else if(documentObject.getFileExtn().contains("image/")){
			    		documentObject.setExtensionIcon("fa fa-file-image-o");
			    	}
			    	else if(documentObject.getFileExtn().contains("text/plain")){
			    		documentObject.setExtensionIcon("fa fa-file-text-o");
			    	}
			    	else if(documentObject.getFileExtn().contains("application/msword")){
			    		documentObject.setExtensionIcon("fa fa-file-word-o");
			    	}
			    	else if(documentObject.getFileExtn().contains("application/octet-stream")){
			    		documentObject.setExtensionIcon("fa fa-file-zip-o");
			    	}
			    	else if(documentObject.getFileExtn().contains("application/vnd.openxmlformats-officedocument.presentationml.presentation")){
			    		documentObject.setExtensionIcon("fa fa-file-powerpoint-o");
			    		
			    	}
			    	else if(documentObject.getFileExtn().contains("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")){
			    		documentObject.setExtensionIcon("fa fa-file-excel-o");
			    	}
			    	else
			    		documentObject.setExtensionIcon("fa fa-file-o");
			    	
			    	
			    }
			    ObjectMapper mapper = new ObjectMapper();
			    //change it to error message of catch printStackTrace
	            String data = null;
				try {
					data = mapper.writeValueAsString(documentlist);
				} catch (JsonProcessingException e) {
					e.printStackTrace();
				}
	            return data;
		 }
		 
		
		 /**
			 * Upload single file using Spring Controller
			 */
			/*@RequestMapping(value = "/uploadFile", method = RequestMethod.POST)
			public @ResponseBody
			String uploadFileHandler(@RequestParam("name") String name,
					@RequestParam("file") MultipartFile file) {

				if (!file.isEmpty()) {
					try {
						byte[] bytes = file.getBytes();

						// Creating the directory to store file
						String rootPath = System.getProperty("catalina.home");
						File dir = new File(rootPath + File.separator + "tmpFiles");
						if (!dir.exists())
							dir.mkdirs();

						// Create the file on server
						File serverFile = new File(dir.getAbsolutePath()
								+ File.separator + name);
						BufferedOutputStream stream = new BufferedOutputStream(
								new FileOutputStream(serverFile));
						stream.write(bytes);
						stream.close();

						logger.info("Server File Location="
								+ serverFile.getAbsolutePath());

						return "You successfully uploaded file=" + name;
					} catch (Exception e) {
						return "You failed to upload " + name + " => " + e.getMessage();
					}
				} else {
					return "You failed to upload " + name
							+ " because the file was empty.";
				}
			}*/
		 
		 /***********
		  * Creating a folder
		 File fileMetadata = new File();
		 fileMetadata.setName("Invoices");
		 fileMetadata.setMimeType("application/vnd.google-apps.folder");

		 File file = driveService.files().create(fileMetadata)
		     .setFields("id")
		     .execute();
		 System.out.println("Folder ID: " + file.getId());
		 
		 //Inserting a file in a folder
		 String folderId = "0BwwA4oUTeiV1TGRPeTVjaWRDY1E";
		File fileMetadata = new File();
		fileMetadata.setName("photo.jpg");
		fileMetadata.setParents(Collections.singletonList(folderId));
		java.io.File filePath = new java.io.File("files/photo.jpg");
		FileContent mediaContent = new FileContent("image/jpeg", filePath);
		File file = driveService.files().create(fileMetadata, mediaContent).setFields("id, parents").execute();
		   
		System.out.println("File ID: " + file.getId());

	    String fileId = "1sTWaJ_j7PkjzaBWtNc3IzovK5hQf21FbOw9yLeeLPNQ";
		String folderId = "0BwwA4oUTeiV1TGRPeTVjaWRDY1E";
		// Retrieve the existing parents to remove
		File file = driveService.files().get(fileId)
		    .setFields("parents")
		    .execute();
		StringBuilder previousParents = new StringBuilder();
		for (String parent : file.getParents()) {
		  previousParents.append(parent);
		  previousParents.append(',');
		}
		// Move the file to the new folder
		file = driveService.files().update(fileId, null)
		    .setAddParents(folderId)
		    .setRemoveParents(previousParents.toString())
		    .setFields("id, parents")
		    .execute();
		    
		    
		    
		    
		        /**

     * List all the files and folders from a directory

     * @param directoryName to be listed

    

    public void listFilesAndFolders(String directoryName){

        File directory = new File(directoryName);

        //get all the files from a directory

        File[] fList = directory.listFiles();

        for (File file : fList){

            System.out.println(file.getName());

        }

    }

    /**

     * List all the files under a directory

     * @param directoryName to be listed

    

    public void listFiles(String directoryName){

        File directory = new File(directoryName);

        //get all the files from a directory

        File[] fList = directory.listFiles();

        for (File file : fList){

            if (file.isFile()){

                System.out.println(file.getName());

            }

        }

    }

    /**

     * List all the folder under a directory

     * @param directoryName to be listed

     

    public void listFolders(String directoryName){

        File directory = new File(directoryName);

        //get all the files from a directory

        File[] fList = directory.listFiles();

        for (File file : fList){

            if (file.isDirectory()){

                System.out.println(file.getName());

            }

        }

    }

    /**

     * List all files from a directory and its subdirectories

     * @param directoryName to be listed

     

    public void listFilesAndFilesSubDirectories(String directoryName){

        File directory = new File(directoryName);

        //get all the files from a directory

        File[] fList = directory.listFiles();

        for (File file : fList){

            if (file.isFile()){

                System.out.println(file.getAbsolutePath());

            } else if (file.isDirectory()){

                listFilesAndFilesSubDirectories(file.getAbsolutePath());

            }

        }

    }

    public static void main (String[] args){

        ListFilesUtil listFilesUtil = new ListFilesUtil();

        final String directoryLinuxMac ="/Users/loiane/test";

        //Windows directory example

        final String directoryWindows ="C://test";

        listFilesUtil.listFiles(directoryLinuxMac);

    }

}
	 
		 
        ******/
}


