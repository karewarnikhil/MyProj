package com.common.Dao;

import java.util.List;

import com.common.Objects.ClassObject;
import com.common.Objects.FolderObject;

public interface ClassDao {
	
	 public	void saveClassObject(ClassObject classObject,FolderObject folderObject);
	 
	 public	void updateClassObject(ClassObject classObject);

	 public List<ClassObject> getAllClass(int userLevel,long deptId);

	 public ClassObject getClassById(long classId);
	 
	/* public ClassObject getClassByName(String classNm);*/
	 
/*	 public void deleteClassObject(ClassObject classObject);*/
	 
	 public List<ClassObject> getClasses();

	 public List<ClassObject> getClassByDeptAndROP(int userDeptId);

	 public Object getClassesForDropDown();
	
	

}
