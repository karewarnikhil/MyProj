package com.common.DaoImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.DepartmentDao;
import com.common.Objects.DepartmentObject;

@Repository
@Transactional
public class DepartmentDaoImpl implements DepartmentDao{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public void saveDepartmentObject(DepartmentObject departmentObject) {
		sessionFactory.getCurrentSession().saveOrUpdate(departmentObject);
	}

	public List<DepartmentObject> getAllDepartments() {
		return sessionFactory.getCurrentSession().createQuery(" FROM DepartmentObject order by deptId desc").list();
	}
	
	public List<DepartmentObject> getAllDepartmentsForAddUser() {
		//remove hard-code comes from constant file
		return sessionFactory.getCurrentSession().createQuery(" FROM DepartmentObject where status='A' order by deptNm").list();
	}

	public DepartmentObject getDepartmentById(Integer departmentId) {
		DepartmentObject departmentObject = (DepartmentObject) sessionFactory.getCurrentSession().get(DepartmentObject.class,departmentId);
		return departmentObject;
	}

	/*public void deleteDepartmentObject(DepartmentObject departmentObject) {
		sessionFactory.getCurrentSession().delete(departmentObject);
	}*/

}
