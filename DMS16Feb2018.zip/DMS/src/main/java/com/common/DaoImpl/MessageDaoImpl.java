package com.common.DaoImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.MessageDao;
import com.common.Objects.MessageObject;

@Repository
@Transactional
public class MessageDaoImpl implements MessageDao{
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void saveMessageObject(MessageObject messageObject) {
		sessionFactory.getCurrentSession().saveOrUpdate(messageObject);
	}

	@Override
	public List<MessageObject> getMessages(String userId) {
		return sessionFactory.getCurrentSession().createQuery(" FROM MessageObject where messageTo like '%"+userId+"%'  order by creationDt desc").list();
	}

	@Override
	public MessageObject getMessageById(long messageId) {
		MessageObject messageObject = (MessageObject) sessionFactory.getCurrentSession().get(MessageObject.class,messageId);
		return messageObject;
	}

	@Override
	public long getUserMessageCount(String userId) {
		return (Long) sessionFactory.getCurrentSession().createQuery(" SELECT count(messageId) FROM MessageObject where messageTo like '%"+userId+"_N%'").uniqueResult();
	}
}
