package com.common.Objects;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.common.CompositeKey.ConfigCompositeKey;

@Entity @Table(name="config")
public class ConfigObject implements Serializable{
	
	private static final long serialVersionUID = 1L;
   // commented because make composite primary key
	/*@Id
	@Column(name="pk",unique=true)
	private  String pk ;
	
	@Id
	@Column(name="sk",unique=true)
	private  String sk ;*/
	
	@EmbeddedId
    private ConfigCompositeKey configCompositeKey;
	
	@Column(name="ds")
	private  String ds ;
	
	@Column(name="value")
	private  String value ;

	public ConfigCompositeKey getConfigCompositeKey() {
		return configCompositeKey;
	}

	public void setConfigCompositeKey(ConfigCompositeKey configCompositeKey) {
		this.configCompositeKey = configCompositeKey;
	}

	public String getDs() {
		return ds;
	}

	public void setDs(String ds) {
		this.ds = ds;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public ConfigObject(ConfigCompositeKey configCompositeKey, String ds, String value) {
		super();
		this.configCompositeKey = configCompositeKey;
		this.ds = ds;
		this.value = value;
	}

	public ConfigObject() {
		super();
	}
}
