package com.common.Objects;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity @Table(name="deptmst")
public class DepartmentObject implements Serializable{
	
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "deptId", updatable = false, nullable = false)
	private  int deptId;
	
	@Column(name="deptNm",unique=true)
	private  String deptNm ;
	
	@Column(name="shrtNm")
	private  String shrtNm;
	
	@Column(name="creationDt")
	private Timestamp creationDt;
	
	@Column(name="status")
	private String status;
	
	public int getDeptId() {
		return deptId;
	}
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}
	public String getDeptNm() {
		return deptNm;
	}
	public void setDeptNm(String deptNm) {
		this.deptNm = deptNm;
	}
	public String getShrtNm() {
		return shrtNm;
	}
	public void setShrtNm(String shrtNm) {
		this.shrtNm = shrtNm;
	}
	public Timestamp getCreationDt() {
		return creationDt;
	}
	public void setCreationDt(Timestamp creationDt) {
		this.creationDt = creationDt;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public DepartmentObject(int deptId, String deptNm, String shrtNm, Timestamp creationDt, String status) {
		super();
		this.deptId = deptId;
		this.deptNm = deptNm;
		this.shrtNm = shrtNm;
		this.creationDt = creationDt;
		this.status = status;
	}
	public DepartmentObject() {
		super();
		
	}
	
	

	
}
