package com.common.DaoImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.UACCDao;
import com.common.Objects.UACCObject;

@Repository
@Transactional
public class UACCDaoImpl implements UACCDao{
	
	@Autowired
	private SessionFactory sessionFactory;
	public List<UACCObject> getUACCListByUserId(int userId) {
		return (List<UACCObject>) sessionFactory.getCurrentSession().createQuery(" From UACCObject where userId = "+userId).list();
	}
	
	public void saveUACCObject(UACCObject uaccObject) {
		sessionFactory.getCurrentSession().saveOrUpdate(uaccObject);
	}

	public void deleteUACCObject(UACCObject uaccObject) {
		
		
	}

	public UACCObject getUACCById(Integer menuId, Integer userId) {
		
		return null;
	}

}
