package com.common.Controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.common.Dao.UsersDao;
import com.common.Objects.UsersObject;

@Controller
public class PasswordController {
	
	@Autowired
	private UsersDao usersDao ;
	
	@RequestMapping(value = "/changePassword", method = RequestMethod.GET)
	   public String changePasswordForm() { 
	       return "changePassword"; 
	} 
	
	@RequestMapping(value = "/saveChangePassword", method = RequestMethod.POST)
	   public String saveChangePassword(@RequestParam("oldPasswordFn") String oldPassword, @RequestParam("newPasswordFn") String newPassword,HttpServletRequest request) { 
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   String originalPassword = usersSessionObject.getUserPassword();
		   String originalPasswordOne = usersSessionObject.getUserPasswordOne();
		   String originalPasswordTwo = usersSessionObject.getUserPasswordTwo();
		   if( !(originalPassword.equals(oldPassword))) {
			   System.out.println("old password does not match.");
			   return "changePassword"; 
		   }
		   else if((originalPassword.equals(newPassword)) || (originalPasswordOne.equals(newPassword)) || (originalPasswordTwo.equals(newPassword) )){
			   System.out.println("password must be other than last three passwords. ");
			   return "changePassword";
		   }
		   else {
			    usersSessionObject.setUserPasswordTwo(originalPasswordOne);
			    usersSessionObject.setUserPasswordOne(originalPassword);
			    usersSessionObject.setUserPassword(newPassword);
			    usersDao.saveUsersObject(usersSessionObject);
			    System.out.println("password is changed. ");
			   return "home"; 
		   }
	       
	} 
}