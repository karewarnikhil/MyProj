package com.common.Controllers;

import java.sql.Timestamp;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.common.Dao.ConfigDao;
import com.common.Dao.DepartmentDao;
import com.common.Dao.DesignationDao;
import com.common.Dao.GroupDao;
import com.common.Dao.HintQuesDao;
import com.common.Dao.UsersDao;
import com.common.Objects.ConfigObject;
import com.common.Objects.DepartmentObject;
import com.common.Objects.DesignationObject;
import com.common.Objects.EmailObject;
import com.common.Objects.GroupObject;
import com.common.Objects.HintQuestObject;
import com.common.Objects.UsersObject;
@Controller
public class UserController {
	
	@Autowired
	private UsersDao usersDao ;
	
	@Autowired
	private DepartmentDao departmentDao;  
	
	@Autowired
	private DesignationDao designationDao;
	
	@Autowired
    private GroupDao groupDao;
	
    @Autowired
	private ConfigDao configDao;

    @Autowired
	private HintQuesDao hintQuesDao;
    
	
	@RequestMapping(value = "/addUser", method = RequestMethod.GET)
	   public String showform(Model model){  
	       UsersObject usersObject = new UsersObject();
	       List<DepartmentObject> departmentList = departmentDao.getAllDepartments();
	       List<DesignationObject> designationList = designationDao.getAllDesignation();
	       List<GroupObject> groupList = groupDao.getAllGroupObject();
	       List<ConfigObject> configList = configDao.getAllConfigObject();
	       List<HintQuestObject> hintQuestList = hintQuesDao.getAllHintQuestObject();
	       model.addAttribute("user", usersObject);
	       model.addAttribute("departmentList",departmentList);
	       model.addAttribute("designationList",designationList);
	       model.addAttribute("groupList",groupList);
	       model.addAttribute("configList",configList);
	       model.addAttribute("hintQuestList",hintQuestList);
	       return "registration"; 
	 } 
	
	 @RequestMapping(value = "/saveUser", method = RequestMethod.POST)
	   public String saveData(@ModelAttribute("usersObject") UsersObject usersObject, HttpServletRequest request){ 
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   Timestamp creationDt = new Timestamp(System.currentTimeMillis());
		   usersObject.setCreationDt(creationDt);
		   String userPassword = usersObject.getUserName().substring(0,4)+usersObject.getEmailId().substring(0, 2);
		   usersObject.setUserPassword(userPassword);
		   if(usersSessionObject != null)
			   usersObject.setCreatedBy(usersSessionObject.getUserName());
		   else
			   usersObject.setCreatedBy(usersObject.getUserName());
		   usersDao.saveUsersObject(usersObject);
		   
		   EmailObject emailObject = new EmailObject();
		   String link =  "<a href='http://localhost:8080/DMS/changePassword'>Click here for change Password.</a>";
		   String message = "Hello dear user"+usersObject.getUserlevel()+"you are registered with us successfully.</br>";
		   message+= "Your temporary password for login is "+ usersObject.getUserPassword()+"</br>";
		   message+= "And link for change password is </br>";
		   message+= link;
		   emailObject.setFrom("admin@test.com");
		   emailObject.setTo(usersObject.getUserName());
		   emailObject.setSubject("Change your password for login.");
		   emailObject.setMessage(message);
		   
		   System.out.println("message body  is."+emailObject.getMessage());
		   System.out.println("link is."+link);
		   
		   System.out.println("Email is sent to user.");
		   if(usersSessionObject != null)
	       return "redirect:/manageUsers"; 
		   else
		   return "loginIn"; 	   
	 }  
	
	 @RequestMapping(value="/manageUsers", method = RequestMethod.GET)  
	   public String manageUser(Model model){  
	       List<UsersObject> userslist = usersDao.getAllUsers(); 
	       model.addAttribute("usersList", userslist);
	       return "manageUsers";
	 }  
	 
	 @RequestMapping(value="/editUser", method = RequestMethod.GET)  
	   public String editUser(@RequestParam("userId") Integer userId,Model model){  
	       UsersObject usersObject = findByUserId(userId);
	       List<DepartmentObject> departmentList = departmentDao.getAllDepartments();
	       List<DesignationObject> designationList = designationDao.getAllDesignation();
	       List<ConfigObject> configList = configDao.getAllConfigObject();
	       
	       model.addAttribute("departmentList",departmentList);
	       model.addAttribute("designationList",designationList);
	       model.addAttribute("configList",configList);
	       model.addAttribute("user", usersObject);
	       return "editUser";//will redirect to viewemp request mapping  
	 }  
	   
	   @RequestMapping(value="/deleteUser", method = RequestMethod.GET)  
	   public String deleteUser(@RequestParam("userId") Integer userId,Model model){  
		   UsersObject usersObject = findByUserId(userId);
		   usersDao.deleteUserObject(usersObject);
	       return "redirect:/manageUsers";//will redirect to viewemp request mapping  
	   }  
	   
	   private UsersObject findByUserId(Integer userId) {
		   UsersObject usersObject =  usersDao.getUsersById(userId); 
		   return usersObject;
	   }
	 
	 
}
