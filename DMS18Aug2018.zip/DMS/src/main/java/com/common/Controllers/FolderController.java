package com.common.Controllers;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.common.Dao.DepartmentDao;
import com.common.Dao.FolderDao;
import com.common.Dao.HisFolderDao;
import com.common.Objects.FolderObject;
import com.common.Objects.HisFolder;
import com.common.Objects.UsersObject;

@Controller
public class FolderController {
	   
	   @Autowired
	   FolderDao folderDao;
	   
	   @Autowired
	   DepartmentDao departmentDao;
	   
	   @Autowired
	   HisFolderDao hisFolderDao;
	
	  /* @RequestMapping(value = "/", method = RequestMethod.GET)
	   public String showClassForm(Model model){  
		   FolderObject folderObject = new FolderObject();
	       model.addAttribute("folder", folderObject);
	       return "registerClass"; 
	   } */
	
	   @RequestMapping(value = "/saveFolder", method = RequestMethod.POST)
	   public String saveClassData(@ModelAttribute("folder") FolderObject folderObject, BindingResult result){
		   Date date = new Date();  
	       Timestamp ts = new Timestamp(date.getTime());  
	       folderObject.setCreationDt(ts);
	       folderDao.saveFolderObject(folderObject);
	       return "redirect:/manageFolder"; 
	   }  
	   
	   @RequestMapping(value="/manageFolder", method = RequestMethod.GET)  
	   public ModelAndView manageFolder(){  
		   List<FolderObject> folderlist = folderDao.getAllFolders(); 
	       return new ModelAndView("manageFolder","folderlist",folderlist);  
	   } 
	   
	   @RequestMapping(value ="/defaultPage", method = RequestMethod.GET)
		public ModelAndView getDefaultPage() {
		      //List<FolderObject> folderlist = folderDao.getParentFolderList();
		      //return new ModelAndView("defaultPage","folderlist",folderlist); 
			  return new ModelAndView("defaultPageDummy");  
		}
	   
	   @RequestMapping(value = "/loadChildFolders", method = RequestMethod.GET, produces = "application/json")
	   public @ResponseBody List<FolderObject> loadChildFolder(@RequestParam("id") long rootId, Model model) {
		     List<FolderObject> folderlist = folderDao.getParentFolderList();
		     return folderlist;
		}
	   
	   @RequestMapping(value = "/loadFoldersById", method = RequestMethod.GET, produces = "application/json")
	   public @ResponseBody List<FolderObject> loadFoldersById(@RequestParam("id") long rootId, Model model,HttpServletRequest request) {
		     HttpSession session = request.getSession();
		     UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		     List<FolderObject> folderlist = folderDao.getAllFoldersByRootId(rootId,usersSessionObject.getDepartmentObject().getDeptId());
		     return folderlist;
		}
	  
	   @RequestMapping(value="/editFolder", method = RequestMethod.GET)  
	   public ModelAndView editFolder(@RequestParam("folderId") Integer folderId){  
		   FolderObject folderObject = findByFolderId(folderId);
	       return new ModelAndView("editFolder","folder",folderObject);  
	   }  
	   
	   
	   @RequestMapping(value="/deleteFolder", method = RequestMethod.GET)  
	   public String deleteFolder(@RequestParam("FolderId") Integer folderId,Model model){  
		   FolderObject folderObject = findByFolderId(folderId);
		   folderDao.deleteFolderObject(folderObject);
	       return "redirect:/manageFolder";//will redirect to viewemp request mapping  
	   }  
	   
	   private FolderObject findByFolderId(Integer folderId) {
		   FolderObject folderObject =  folderDao.getFolderById(folderId); 
		   return folderObject;
	   }
	   
	   @RequestMapping(value = "/getFolderAttributes", method = RequestMethod.POST, produces = "application/json")
	   public @ResponseBody FolderObject getFolderAttributes(@RequestParam("folderId") long folderId, Model model) {
		     FolderObject folderObject =  folderDao.getFolderByIdForDefault(folderId); 
		     return folderObject;
		}
	   
	   
	   // jyoti code
	   
	   @RequestMapping(value = "/createFolder", method = RequestMethod.POST)
		public String getCreateFolderForm(Model model, @RequestParam("folderid") int folderId,
				@RequestParam("rootid") int rootid, HttpServletRequest request) {
			UsersObject usersSess = (UsersObject) request.getSession().getAttribute("users");
			model.addAttribute("folderId", folderId);
			model.addAttribute("rootid", rootid);
			model.addAttribute("rootFolder", folderDao.getFolderById(folderId));
			model.addAttribute("ClassFolder", folderDao.getClassFolder(rootid));
			model.addAttribute("userlevel", usersSess.getUserlevel());
			//Check User level 
			model.addAttribute("departmentList", departmentDao.getAllDepartments());
			model.addAttribute("Folder", new FolderObject());
			model.addAttribute("pageName", "Create Folder");
			return "createFolder";
		}

		@RequestMapping(value = "/saveFolders", method = RequestMethod.POST)
		public String saveFolders(Model model, @RequestParam("folderId") int folderId, @RequestParam("rootId") int rootid,
				@ModelAttribute("folder") FolderObject folders, HttpServletRequest request) {
			UsersObject usersSess = (UsersObject) request.getSession().getAttribute("users");
			if (usersSess != null) {
				if (rootid == 0) {
					folders.setParentId(folderId);
					folders.setRootId(folderId);
				} else {
					folders.setParentId(folderId);
					folders.setRootId(rootid);
				}
				folders.setFolderNm(folders.getFolderNm());
				folders.setIsInnerFolders(folders.getIsInnerFolders());
				folders.setFolderCnt(0);
				folders.setFileCnt(0);
				folders.setAtriBt("A");
				folders.setReadOnlyOthDept(folders.getReadOnlyOthDept());
				folders.setReadOnlyPublic(folders.getReadOnlyPublic());
				folders.setCreatedBy(usersSess.getUserId());
				folders.setCreationDt(new Timestamp(new Date().getTime()));
				folderDao.saveFolders(folders);
				return "defaultPageDummy";
			} else {

				return "redirect:login";
			}
		}

		@RequestMapping(value = "/updateFolder", method = RequestMethod.POST)
		public String getUpdateFolderForm(Model model, @RequestParam("folderid") int folderId,
				@RequestParam("rootid") int rootid, HttpServletRequest request) {
			HttpSession session = request.getSession();
			UsersObject usersSess = (UsersObject) session.getAttribute("users");
			if (usersSess != null) {
			model.addAttribute("folderId", folderId);
			model.addAttribute("rootid", rootid);
			model.addAttribute("Folder", folderDao.getFolderById(folderId));
			model.addAttribute("ClassFolder", folderDao.getClassFolder(rootid));
			model.addAttribute("pageName", "Update Folder");
			return "editFolder";
			}
			else {
				return "redirect:login";
			}
		}
		@RequestMapping(value = "/updateFolderName", method = RequestMethod.POST)
		public String updateFolders(Model model, @RequestParam("folderId") int folderId, @RequestParam("folderNm") String folderNm,
				@ModelAttribute("folder") FolderObject folders, HttpServletRequest request) {
			UsersObject usersSess = (UsersObject) request.getSession().getAttribute("users");
			if (usersSess != null) {
				FolderObject folder= folderDao.getFolderById(folderId);
				folder.setFolderNm(folderNm);
				folder.setAtriBt(folders.getAtriBt());
				folder.setReadOnlyPublic(folders.getReadOnlyPublic());
				folder.setReadOnlyOthDept(folders.getReadOnlyOthDept());
				
				folderDao.updateFolderName(folder);
				
				HisFolder hisFolder =new HisFolder();
				hisFolder.setFolderId(folderId);
				hisFolder.setFolderNm(folderNm);
				hisFolder.setIsInnerFolder(folders.getIsInnerFolders());
				hisFolder.setAtriBt(folders.getAtriBt());
				hisFolder.setReadOnlyOthDept(folders.getReadOnlyOthDept());
				hisFolder.setReadOnlyPublic(folders.getReadOnlyPublic());
			    hisFolder.setCreatedBy(usersSess.getUserId()); 
			    hisFolder.setCreationDateTime(new Timestamp(new Date().getTime()));
			    
			    hisFolderDao.saveHistory(hisFolder);
			    
				return "defaultPageDummy";
			} else {

				return "redirect:login";
			}
		}
}
