package com.common.Dao;

import com.common.Objects.UsersObject;

public interface LoginDao {
	public	void findUser(UsersObject users);
}
