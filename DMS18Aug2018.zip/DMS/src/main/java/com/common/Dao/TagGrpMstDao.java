package com.common.Dao;

import java.util.List;

import com.common.Objects.TagGroup;

public interface TagGrpMstDao {

	
	public List<TagGroup> getAllTagGroup();
	
	public void saveTagGrp(TagGroup tagGroup);
}
