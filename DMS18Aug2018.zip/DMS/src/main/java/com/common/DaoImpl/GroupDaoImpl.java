package com.common.DaoImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.GroupDao;
import com.common.Objects.GroupObject;

@Repository
@Transactional
public class GroupDaoImpl implements GroupDao{
	@Autowired
	private SessionFactory sessionFactory;
	
	
	public List<GroupObject> getAllGroupObject() {
		return sessionFactory.getCurrentSession().createQuery(" FROM GroupObject ").list();
	}

}
