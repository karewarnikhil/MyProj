package com.common.Objects;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity 
@Table(name="classtaggrp")
public class ClassTagGroup implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	private int classId;
	
	@Id
	private long taggrpid;
	
	@Column(name="createdby")
	private int createdBy;
	
	@Column(name="createddatetime")
	private  Timestamp createdDate ;

	@Transient
	private String tagGrpNm;
	
	public ClassTagGroup() {
		
	}
	public ClassTagGroup(int classId, long taggrpid, int createdBy, Timestamp createdDate,String tagGrpNm) {
		super();
		this.classId = classId;
		this.taggrpid = taggrpid;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.tagGrpNm=tagGrpNm;
	}

	public int getClassId() {
		return classId;
	}

	public void setClassId(int classId) {
		this.classId = classId;
	}

	public long getTaggrpid() {
		return taggrpid;
	}

	public void setTaggrpid(long taggrpid) {
		this.taggrpid = taggrpid;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getTagGrpNm() {
		return tagGrpNm;
	}
	public void setTagGrpNm(String tagGrpNm) {
		this.tagGrpNm = tagGrpNm;
	}

}
