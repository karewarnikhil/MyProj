package com.common.Controllers;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.common.CompositeKey.DocumentCompositeKey;
import com.common.Dao.ClassTagGroupDao;
import com.common.Dao.DocumentDao;
import com.common.Dao.FileTgDataDao;
import com.common.Dao.ListDataDao;
import com.common.Dao.TagDao;
import com.common.Objects.DocumentObject;
import com.common.Objects.ListDataObj;
import com.common.Objects.ListObject;
import com.common.Objects.SubDepartmentObject;
import com.common.Objects.TagDataObject;
import com.common.Objects.TagGroupObject;
import com.common.Objects.TagObject;
import com.common.Objects.UsersObject;

@Controller
public class FileTgDtController {
	
	@Autowired
	TagDao tagDao;
	
	@Autowired
	ListDataDao listDataDao;
	
	@Autowired
	FileTgDataDao fileTgDataDao;
	
	@Autowired
	DocumentDao documentDao;
	
	@Autowired
	ClassTagGroupDao classTagGroupDao;
	
	@RequestMapping(value="/getTagData", method = RequestMethod.POST)  
	   public String getTagData(@RequestParam("tagGrpId") long tagGrpId,Model model,HttpServletRequest request){ 
		   HttpSession session = request.getSession();
		   session.removeAttribute("tagObjectlist");
		   List<TagObject> tagObjectlist = tagDao.getTagData(tagGrpId);
		   //List<ClassObject> classObjectlist = classTagGroupDao.getClassData(tagGrpId);
		   //List<SubDepartmentObject> subDepartmentList = classTagGroupDao.getClassData(tagGrpId);
		   for(TagObject tagObject:tagObjectlist) {
				if(tagObject.getListObject().getListId() > 0) {
					 List<ListDataObj> listDataObject = (List<ListDataObj>) listDataDao.getListDataByListId(tagObject.getListObject().getListId());
					 tagObject.setListDataObjs(listDataObject);
				}
			}
	      // model.addAttribute("subDepartmentList", subDepartmentList);
	       model.addAttribute("selectedtagGrpId", tagGrpId);
	       //model.addAttribute("subDeptId", subDeptId);
	      
	       session.setAttribute("tagObjectlist", tagObjectlist);
	       //model.addAttribute();
	       //model.addAttribute("data", new TagDataObject());
	       return "fileDisplay";
	}  
	
	@RequestMapping(value="/getMultipleTagData", method = RequestMethod.POST)  
	   public String getMultipleTagData(@RequestParam("tagGrpId") long tagGrpId,Model model,HttpServletRequest request){ 
		   HttpSession session = request.getSession();
		   //List<SubDepartmentObject> subDepartmentList = classTagGroupDao.getClassData(tagGrpId);
		   session.removeAttribute("tagObjectlist");
		   List<TagObject> tagObjectlist = tagDao.getTagData(tagGrpId);
		   for(TagObject tagObject:tagObjectlist) {
				if(tagObject.getListObject().getListId() > 0) {
					 List<ListDataObj> listDataObject = (List<ListDataObj>) listDataDao.getListDataByListId(tagObject.getListObject().getListId());
					 tagObject.setListDataObjs(listDataObject);
				}
			}
		   //model.addAttribute("subDepartmentList", subDepartmentList);
		   model.addAttribute("selectedtagGrpId", tagGrpId);
	      // model.addAttribute("subDeptId", subDeptId);
	       //model.addAttribute("tagObjectlist", tagObjectlist);
	       session.setAttribute("tagObjectlist", tagObjectlist);
	       //model.addAttribute();
	       //model.addAttribute("data", new TagDataObject());
	       return "multipleFileDisplay";
	}  
	
	 @RequestMapping(value = "/saveTagData", method = RequestMethod.POST)
	   public String saveTagData(HttpServletRequest request,Model model){ 
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   DocumentObject documentObject = (DocumentObject) session.getAttribute("documentObject");
		   List<TagObject> tagObjectlist = (List<TagObject>) session.getAttribute("tagObjectlist");
		   long tagGrpId = Long.parseLong(request.getParameter("tagGrpId"));
		 //  long subDeptId = Long.parseLong(request.getParameter("subDeptId"));
	       Timestamp ts = new Timestamp(new Date().getTime());  
	       List<TagDataObject> listOfTagData = new ArrayList<TagDataObject>();
		   for(TagObject tagObject:tagObjectlist) {
			  int value =  tagObject.getTagCompositeKey().getTagId();
			  //needed because getting values from view pages.
			  String tag = value+" ";
			  String tagData = request.getParameter(tag);
			  System.out.println(tagData.isEmpty() + tagObject.getIsMandatory());
			  
			  //need to remove hardcoding
			  if((tagData.isEmpty()) && (tagObject.getIsMandatory().equals("Y"))) {
					  model.addAttribute("selectedtagGrpId", tagGrpId);
					  //request.setAttribute("error", "Mandatory Fields are required.");
					  model.addAttribute("error", "Mandatory Fields are required.");
					  return "fileDisplay";
			  }
			//need to remove hardcoding
			  else if(!(tagData.isEmpty()) || (tagData == "0")) {
				  TagDataObject tagDataObject = new TagDataObject();
				  ListObject listObject = tagObject.getListObject();
				  tagDataObject.setCreatedBy(usersSessionObject.getUserId());
				  tagDataObject.setCreationDt(ts);
				  tagDataObject.setFileId(documentObject.getDocumentCompositeKey().getFileId());
				  tagDataObject.setSeqNo(documentObject.getDocumentCompositeKey().getSeqNo());
				  //TagCompositeKey tagCompositeKey = new TagCompositeKey();
				  //tagCompositeKey.setTagGrpId(tagGrpId);
				  //tagDataObject.getTagObject().setTagCompositeKey(tagCompositeKey);
				  //tagDataObject.setTagId(tagObject.getTagId());
				  tagDataObject.setTagObject(tagObject);
				 
				  tagDataObject.setTagData(tagData);
				  
				  tagDataObject.setListId(listObject.getListId());
				  
				//  tagDataObject.setClassId(subDeptId);
				  if(listObject.getListId() == 0)
					  tagDataObject.setListNo(listObject.getListId());
				  else {
					  tagData = tagData.trim();
					  int valueOne = Integer.parseInt(tagData);
					  tagDataObject.setListNo(valueOne);
				  }
				  
				  listOfTagData.add(tagDataObject);
				  //for update tag Status of file
			  } 
			  }
		      fileTgDataDao.saveFileTagData(listOfTagData);
			  documentObject.setTagStatus("Y");
			  documentObject.setTagEntryDt(ts);
			  documentDao.updateDocument(documentObject);
			  model.addAttribute("message", "Tag Data Saved Successfully.");
		      session.removeAttribute("tagObjectlist");
		   return "redirect:/displayFile?fileId="+documentObject.getDocumentCompositeKey().getFileId()+"&seqNo="+documentObject.getDocumentCompositeKey().getSeqNo(); 
	   }  
	 
	   @RequestMapping(value = "/saveMultipleTagData", method = RequestMethod.POST)
	   public String saveMultipleTagData(@RequestParam("fileIndex") long fileIndex,HttpServletRequest request,Model model){ 
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   DocumentObject documentObject = (DocumentObject) session.getAttribute("documentObject");
		   List<TagObject> tagObjectlist = (List<TagObject>) session.getAttribute("tagObjectlist");
		   long tagGrpId = Long.parseLong(request.getParameter("tagGrpId"));
		  // long subDeptId = Long.parseLong(request.getParameter("subDeptId"));
	       Timestamp ts = new Timestamp(new Date().getTime());  
	       List<TagDataObject> listOfTagData = new ArrayList<TagDataObject>();
		   for(TagObject tagObject:tagObjectlist) {
			  int value =  tagObject.getTagCompositeKey().getTagId();
			  //need to check and remove following hard coding also on jsp page.
			  String tag = value+" ";
			  String tagData = request.getParameter(tag);
			//  System.out.println(tagData.isEmpty() + tagObject.getIsMandatory());
			//need to remove hardcoding
			  if((tagData.isEmpty()) && (tagObject.getIsMandatory().equals("Y"))) {
					  model.addAttribute("selectedtagGrpId", tagGrpId);
					  //request.setAttribute("error", "Mandatory Fields are required.");
					  model.addAttribute("error", "Mandatory Fields are required.");
					  return "fileDisplay";
			  }
			//need to remove hardcoding
		     //define in constant file use of tagData and remove hard code value
			  else if(!(tagData.isEmpty()) || (tagData == "0")) {
				  TagDataObject tagDataObject = new TagDataObject();
				  ListObject listObject = tagObject.getListObject();
				  tagDataObject.setCreatedBy(usersSessionObject.getUserId());
				  tagDataObject.setCreationDt(ts);
				  tagDataObject.setFileId(documentObject.getDocumentCompositeKey().getFileId());
				  tagDataObject.setSeqNo(documentObject.getDocumentCompositeKey().getSeqNo());
				 // tagDataObject.getTagObject().getTagCompositeKey().setTagGrpId(tagGrpId);
				  //tagDataObject.setTagId(tagObject.getTagId());
				  tagDataObject.setTagObject(tagObject);
				 // tagDataObject.setClassId(subDeptId);
				 
				  tagDataObject.setTagData(tagData);
				  
				  tagDataObject.setListId(listObject.getListId());
				//need to remove hardcoding
				  if(listObject.getListId() == 0)
					  tagDataObject.setListNo(listObject.getListId());
				  else {
					  tagData = tagData.trim();
					  int valueOne = Integer.parseInt(tagData);
					  tagDataObject.setListNo(valueOne);
				  }
				  
				  listOfTagData.add(tagDataObject);
			  } 
			  }
		      //for update tag Status of file
		      fileTgDataDao.saveFileTagData(listOfTagData);
			  documentObject.setTagStatus("Y");
			  documentObject.setTagEntryDt(ts);
			  documentDao.updateDocument(documentObject);
			  model.addAttribute("message", "Tag Data Saved Successfully.");
		      session.removeAttribute("tagObjectlist");
		   return "redirect:/multipleTagging?fileId="+fileIndex+"&seqNo=1"; 
	   }  
	 
	 @RequestMapping(value="/manageFileTgDt", method = RequestMethod.GET)  
	   public ModelAndView manageDepartment(@RequestParam("fileId") long fileId,@RequestParam("seqNo") long seqNo,Model model,HttpServletRequest request){  
		   //List<TagDataObject> tagDataList = fileTgDataDao.getAllTagDataByFileId(fileId); 
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) request.getSession().getAttribute("users");
		   if(usersSessionObject != null) {
		   session.removeAttribute("tagGroupList");
		   //change get it from hash map define in constant file 
		   List<TagGroupObject> tagGroupList = fileTgDataDao.getAllTagGrpByFileId(fileId); 
		   DocumentCompositeKey documentCompositeKey = new DocumentCompositeKey(fileId, seqNo);
		   //model.addAttribute("fileId", fileId);
		   model.addAttribute("documentCompositeKey", documentCompositeKey);
		   // check why both are required here eliminate one
		   session.setAttribute("tagGroupList", tagGroupList);
	       return new ModelAndView("manageFileTgData","tagGroupList",tagGroupList);  
		   }else {
			   return new ModelAndView("loginIn");  
		   }
	 }  
	 @RequestMapping(value="/manageFileTgDtForView", method = RequestMethod.GET)  
	   public ModelAndView manageFileTgDtForView(@RequestParam("fileId") long fileId,Model model,HttpServletRequest request){  
		   //List<TagDataObject> tagDataList = fileTgDataDao.getAllTagDataByFileId(fileId); 
		   UsersObject usersSessionObject = (UsersObject) request.getSession().getAttribute("users");
		   if(usersSessionObject != null) {
		   List<TagGroupObject> tagGroupList = fileTgDataDao.getAllTagGrpByFileId(fileId); 
		   model.addAttribute("fileId", fileId);
	       return new ModelAndView("manageFileTgDataForView","tagGroupList",tagGroupList);  
		   }else {
			   return new ModelAndView("loginIn");  
		   }
	 } 
	 
	 @RequestMapping(value="/getFileTgDataForView", method = RequestMethod.POST)  
	   public ModelAndView getFileTgDataForView(@RequestParam("fileId") long fileId,@RequestParam("tagGrpId") long tagGrpId,@RequestParam("seqNo") long seqNo,Model model){  
		   List<TagDataObject> tagDataList = fileTgDataDao.getAllTagDataByFileId(fileId,tagGrpId); 
		   model.addAttribute("selectedtagGrpId", tagGrpId);
		   model.addAttribute("fileId", fileId);
	       return new ModelAndView("manageFileTgDataForView","tagDataList",tagDataList);  
	 }  
	 
	 @RequestMapping(value="/getFileTgData", method = RequestMethod.POST)  
	   public ModelAndView getFileTgData(@RequestParam("fileId") long fileId,@RequestParam("tagGrpId") long tagGrpId,@RequestParam("seqNo") long seqNo,Model model){  
		   List<TagDataObject> tagDataList = fileTgDataDao.getAllTagDataByFileId(fileId,tagGrpId); 
		   model.addAttribute("selectedtagGrpId", tagGrpId);
		   //model.addAttribute("fileId", fileId);
		   DocumentCompositeKey documentCompositeKey = new DocumentCompositeKey(fileId, seqNo);
		   model.addAttribute("documentCompositeKey", documentCompositeKey);
	       return new ModelAndView("manageFileTgData","tagDataList",tagDataList);  
	 }  
	 
	 @RequestMapping(value="/editTagData", method = RequestMethod.GET)  
	   public String editTagData(@RequestParam("fTagId") long fileTagId,Model model,HttpServletRequest request){  
		 UsersObject usersSessionObject = (UsersObject) request.getSession().getAttribute("users");
		   if(usersSessionObject != null) {
		   TagDataObject tagDataObject = findByfTagId(fileTagId);
		   TagObject tagObject = tagDataObject.getTagObject();
		   //Change get it from hash map defined in constant files
		   List<ListDataObj> listDataObject = (List<ListDataObj>) listDataDao.getListDataByListId(tagObject.getListObject().getListId());
		   tagObject.setListDataObjs(listDataObject);
		   
		   model.addAttribute("tagDataObject",tagDataObject);
		   return "editTagData";
		   }else {
			   return "loginIn";
		   }
	   } 
	 
	 @RequestMapping(value = "/updateTagData", method = RequestMethod.POST)
	   public String updateTagData(@ModelAttribute("tagDataObject") TagDataObject tagDataObject, BindingResult result, HttpServletRequest request){
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   tagDataObject.setCreatedBy(usersSessionObject.getUserId());
		  // System.out.println(tagDataObject);
		   if(tagDataObject.getListNo() > 0) {
			 //need to remove hardcoding
			   tagDataObject.setTagData(tagDataObject.getSeqNo()+"");
		   }
		   
		   fileTgDataDao.saveFileTagData(tagDataObject);
	       return "redirect:/manageFileTgDt?fileId="+tagDataObject.getFileId()+"&seqNo="+tagDataObject.getSeqNo(); 
		  // return "redirect:/displayFile?fileId="+documentObject.getDocumentCompositeKey().getFileId()+"&seqNo="+documentObject.getDocumentCompositeKey().getSeqNo(); 

	   }  
	 
	 private TagDataObject findByfTagId(long fTagId) {
		   TagDataObject tagDataObject =  fileTgDataDao.getTagDataById(fTagId); 
		   return tagDataObject;
	 }
	 

 }
