package com.common.Controllers;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.common.Dao.DocumentDao;
import com.common.Dao.FileTgDataDao;
import com.common.Dao.HistoryFileDao;
import com.common.Dao.ListDataDao;
import com.common.Dao.SearchConditionDao;
import com.common.Dao.SubDepartmentDao;
import com.common.Dao.TagDao;
import com.common.Dao.TagGrpDao;
import com.common.Embeddable.FileIdSeqNo;
import com.common.Objects.DocumentObject;
import com.common.Objects.FileMasterObject;
import com.common.Objects.FileTagsDataObject;
import com.common.Objects.HistoryFileObject;
import com.common.Objects.ListDataObj;
import com.common.Objects.SearchConditionObject;
import com.common.Objects.SearchCriteria;
import com.common.Objects.SubDepartmentObject;
import com.common.Objects.TagGroupObject;
import com.common.Objects.TagObject;
import com.common.Objects.TagReportObject;
import com.common.Objects.UsersObject;

@Controller
public class SearchController implements Serializable {

	private static final long serialVersionUID = 1L;

	@Autowired
	ServletContext context;

	/*@Autowired
	private TagGrpMstDao tagGroupDao;
*/
	@Autowired
	TagGrpDao tagGrpDao;
	
	@Autowired
	FileTgDataDao fileTgDataDao;
	
	@Autowired
	private SubDepartmentDao subDepartmentDao;

	@Autowired
	private SearchConditionDao searchConditionDao;

	@Autowired
	private ListDataDao listDataDao;

	@Autowired
	private DocumentDao documentDao;

	/*@Autowired
	private TagDataObjectDao tagDataObjectDao;*/

	@Autowired
	private HistoryFileDao historyFileDao;
	
	@Autowired
	private TagDao tagDao;
	
	@RequestMapping(value = "/searchByValuesProperties", method = RequestMethod.GET)
	public String getSearchForm(Model model, HttpServletRequest request) {
		UsersObject usersSess = (UsersObject) request.getSession().getAttribute("users");
		List<SearchCriteria> listSearchCriteria = new ArrayList<SearchCriteria>();
		request.getSession().removeAttribute("listSearchCriteria");
		if (usersSess != null) {
			  //change get it from hash map define in constant file for following all
			//model.addAttribute("classList", classDao.getClassByDeptAndROP(usersSess.getDeptId()));
			//model.addAttribute("departmentList", departmentDao.getAllDepartments());
			request.getSession().setAttribute("listSearchCriteria", listSearchCriteria);
			request.getSession().removeAttribute("documentObjectlist");
			return "searchByValuesProperties";
		} else {
			return "redirect:/login";
		}
	}
	
	@RequestMapping(value = "/searchByTagGroup", method = RequestMethod.GET)
	public String searchByTagGroup(Model model, HttpServletRequest request) {
		UsersObject usersSess = (UsersObject) request.getSession().getAttribute("users");
		List<SearchCriteria> listSearchCriteria = new ArrayList<SearchCriteria>();
		request.getSession().removeAttribute("listSearchCriteria");
		request.getSession().removeAttribute("hashMapOfTagObj");
		request.getSession().removeAttribute("tagReportList");
		
		if (usersSess != null) {
			request.getSession().setAttribute("listSearchCriteria", listSearchCriteria);
			return "searchByTagGroup";
		} else {
			return "redirect:/login";
		}
	}
	
	
	  @RequestMapping(value = "/searchByValuesPropertiesBack", method = RequestMethod.GET) 
      public String searchByValuesPropertiesBack(Model model,HttpServletRequest request)
	   { 
	  	UsersObject usersSess = (UsersObject) request.getSession().getAttribute("users");
	  	//model.addAttribute("classList",classDao.getClassByDeptAndROP(usersSess.getDeptId()));
	  	model.addAttribute("subDeptList",subDepartmentDao.getClassByDeptAndROP(usersSess.getDeptId()));
	    return "searchByValuesProperties"; 
       }
	  
	  @RequestMapping(value = "/searchByTagBack", method = RequestMethod.GET) 
      public String searchByTagBack(Model model,HttpServletRequest request)
	   { 
	    return "searchByTagGroup"; 
       }
	  
	  @RequestMapping(value = "/getClassDropDown", method = RequestMethod.GET, produces = "application/json")
		public @ResponseBody List<SubDepartmentObject> getClassDropDown(@RequestParam("deptId") long deptId) {
			  //check and change get it from hash map define in constant file
		    //List<ClassObject> listClassObject = classDao.getClassByDeptAndROP(deptId);
		    List<SubDepartmentObject> subDeptList = subDepartmentDao.getClassByDeptAndROP(deptId);
			return subDeptList;
		}

	@RequestMapping(value = "/getTagNames", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<TagObject> getTagNames(@RequestParam("classId") long classId) {
		  //check and change get it from hash map define in constant file
		List<TagObject> listTagObject = tagGrpDao.getTagByClassId(classId);
		return listTagObject;
	}

	@RequestMapping(value = "/getSearchCondition", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<SearchConditionObject> getSearchCondition(@RequestParam("tagId") int tagId,@RequestParam("taggrpId") int taggrpId) {
		List<SearchConditionObject> searchConditionObject = searchConditionDao.getSerachByTagNm(tagId, taggrpId);
		return searchConditionObject;
	}

	//change name accordingly
	@RequestMapping(value = "/getListDataObje", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<ListDataObj> getListData(@RequestParam("listId") int listId) {
		List<ListDataObj> listDataObject = listDataDao.getListDataByListId(listId);
		return listDataObject;
	}

	//change the following logic change names respectively
	@RequestMapping(value = "/addCriteria", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<SearchCriteria> getSearchCondition(@RequestParam("selectedTag") String selectedTag,
			@RequestParam("srNo") int srNo, @RequestParam("backData") String backData,
			@RequestParam("values") String values, @RequestParam("queryCondition") String queryCondition,
			@RequestParam("tagId") int tagId, @RequestParam("tagGrpId") int tagGrpId,
			@RequestParam("query1") String query1, HttpServletRequest request, Model model) {
		boolean recordExist = false;
		List<SearchCriteria> list = (List<SearchCriteria>) request.getSession().getAttribute("listSearchCriteria");
		if (list.size() == 0) {
			SearchCriteria searchCriteria = new SearchCriteria();
			searchCriteria.setTagId(tagId);
			searchCriteria.setTagGrpId(tagGrpId);
			searchCriteria.setSrNo(srNo);
			searchCriteria.setTagName(selectedTag);
			searchCriteria.setValues(values);
			searchCriteria.setCondition(backData);
			searchCriteria.setCriteria(queryCondition);
			searchCriteria.setQuery1(query1);
			list.add(searchCriteria);
		} else {
			for (SearchCriteria searchCriteria1 : list) {
				if ((searchCriteria1.getTagId() == tagId) && (searchCriteria1.getTagGrpId() == tagGrpId)) {
					recordExist = true;
					model.addAttribute("alert", "Search condition is already included in search criteria");
					System.out.println("Search condition is already included in search criteria");
					break;
				}
			}
			if (recordExist == false) {
				SearchCriteria searchCriteria = new SearchCriteria();
				searchCriteria.setTagId(tagId);
				searchCriteria.setTagGrpId(tagGrpId);
				searchCriteria.setSrNo(srNo);
				searchCriteria.setTagName(selectedTag);
				searchCriteria.setValues(values);
				searchCriteria.setCondition(backData);
				searchCriteria.setCriteria(queryCondition);
				searchCriteria.setQuery1(query1);
				list.add(searchCriteria);
				recordExist = false;
			}
		}
		return list;
	}
	
	
	@RequestMapping(value = "/addTagSearchCriteria", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<SearchCriteria> addTagSearchCriteria(@RequestParam("selectedTag") String selectedTag,
		   @RequestParam("srNo") int srNo, @RequestParam("backData") String backData,
		   @RequestParam("values") String values, @RequestParam("queryCondition") String queryCondition,
		   @RequestParam("tagId") int tagId, @RequestParam("tagGrpId") int tagGrpId,
		   @RequestParam("query1") String query1, HttpServletRequest request, Model model) {
		boolean recordExist = false;
		List<SearchCriteria> list = (List<SearchCriteria>) request.getSession().getAttribute("listSearchCriteria");
		if (list.size() == 0) {
			SearchCriteria searchCriteria = new SearchCriteria();
			searchCriteria.setTagId(tagId);
			searchCriteria.setTagGrpId(tagGrpId);
			searchCriteria.setSrNo(srNo);
			searchCriteria.setTagName(selectedTag);
			searchCriteria.setValues(values);
			searchCriteria.setCondition(backData);
			searchCriteria.setCriteria(queryCondition);
			searchCriteria.setQuery1(query1);
			list.add(searchCriteria);
		} else {
			for (SearchCriteria searchCriteria1 : list) {
				if ((searchCriteria1.getTagId() == tagId) && (searchCriteria1.getTagGrpId() == tagGrpId)) {
					recordExist = true;
					model.addAttribute("alert", "Search condition is already included in search criteria");
					System.out.println("Search condition is already included in search criteria");
					break;
				}
			}
			if (recordExist == false) {
				SearchCriteria searchCriteria = new SearchCriteria();
				searchCriteria.setTagId(tagId);
				searchCriteria.setTagGrpId(tagGrpId);
				searchCriteria.setSrNo(srNo);
				searchCriteria.setTagName(selectedTag);
				searchCriteria.setValues(values);
				searchCriteria.setCondition(backData);
				searchCriteria.setCriteria(queryCondition);
				searchCriteria.setQuery1(query1);
				list.add(searchCriteria);
				recordExist = false;
			}
		}
		return list ;
	}

	//check and check logic accordingly
	@RequestMapping(value = "/removeSearchCriteria", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<SearchCriteria> removeSearchCriteria(@RequestParam("srNo") int srNo,HttpServletRequest request) {
		List<SearchCriteria> listSearchCriteria = (List<SearchCriteria>) request.getSession().getAttribute("listSearchCriteria");
		for (SearchCriteria sObj : listSearchCriteria) {
			if (sObj.getSrNo() == srNo) {
				listSearchCriteria.remove(sObj);
				break;
			}
		}
		return listSearchCriteria;
	}

	@RequestMapping(value = "/getSessionList", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<SearchCriteria> getSessionList(HttpServletRequest request) {
		List<SearchCriteria> listSearchCriteria = (List<SearchCriteria>) request.getSession().getAttribute("listSearchCriteria");
		return listSearchCriteria;
	}

	@RequestMapping(value = "/getFileMst", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<FileMasterObject> getFileMst(@RequestParam("queryBuilder") String queryBuilder,
			HttpServletRequest request) {
		//check and remove object FileMasterObject use default defined one
		//find logic in hibernate for defining various selective data in query
		List<FileMasterObject> documentObjectlist = documentDao.getFileMstByQuery(queryBuilder);
		request.getSession().setAttribute("documentObjectlist", documentObjectlist);
		return documentObjectlist;
	}
	
	@RequestMapping(value = "/getTagFileMst", method = RequestMethod.POST, produces = "application/json")
	public String getTagFileMst(@RequestParam("tagGrpId") long tagGrpId,
			HttpServletRequest request) {
		//check and remove object FileMasterObject use default defined one
		//find logic in hibernate for defining various selective data in query
		List<SearchCriteria> listSearchCriteria = (List<SearchCriteria>) request.getSession().getAttribute("listSearchCriteria");
		
		String datatableQuery = " Select distinct fileId from FileTagsData where ";
		String datatableQueryNew;
		
		for(SearchCriteria searchCriteria : listSearchCriteria){
			datatableQuery = datatableQuery+" "+searchCriteria.getQuery1();
	    }
		System.out.println(datatableQuery.substring((datatableQuery.length())-2,datatableQuery.length()));
		
		if( datatableQuery.substring((datatableQuery.length())-2,datatableQuery.length()).equals("Or")){
     	   datatableQueryNew = datatableQuery.substring(0,(datatableQuery.length()-2));
        }
       
        else if(datatableQuery.substring((datatableQuery.length())-2,datatableQuery.length()).equals("nd")){
     	 datatableQueryNew = datatableQuery.substring(0,(datatableQuery.length()-3));
        }
        else{
     	   datatableQueryNew = datatableQuery;
        }
		
		String queryBuilder="select fm.fileid, tagId,tagdata from filemst fm, filetagsdata  ft where fm.fileId=ft.fileId and fm.atriBt!=''D'' and fm.seqNo=(Select max(fm.seqNo) from filemst fm where fileid in ("+datatableQueryNew+")) and fm.fileid in ( "+datatableQueryNew+") order by 1,2";
		
		
		HashMap<Long,String> hashMapOfTagObj = tagDao.getHashmapofTagObject(tagGrpId);
		List<TagReportObject> tagReportList = tagDao.getTagSearch(hashMapOfTagObj,queryBuilder);
		request.getSession().setAttribute("hashMapOfTagObj", hashMapOfTagObj);
		request.getSession().setAttribute("tagReportList", tagReportList);
		return "searchByTagGroup";
		
		/*
		 * List<FileMasterObject> documentObjectlist =
		 * documentDao.getFileMstByQuery(queryBuilder);
		 * request.getSession().setAttribute("documentObjectlist", documentObjectlist);
		 * return documentObjectlist;
		 */
	}


	//need to change this code eliminate file write 
	@RequestMapping(value = "/searchViewer", method = RequestMethod.GET)
	public String searchViewer(Model model, @RequestParam("fileId") String fileIdSeqNo,@RequestParam("search") String search, HttpServletRequest request,
			HttpServletResponse response) {
		UsersObject usersSessionObject = (UsersObject) request.getSession().getAttribute("users");
		if(usersSessionObject != null) {
		//removing following hardCoding of seqNo and fileId and use composite key
		String[] fileIdSeqNo1 = fileIdSeqNo.split("~");
		int fileId = Integer.parseInt(fileIdSeqNo1[0]);
		int seqNo = Integer.parseInt(fileIdSeqNo1[1]);
		DocumentObject documentObject = documentDao.getFileByFileIdAndSeqNo(fileId, seqNo);
		List<DocumentObject> seqNodocumentObject = documentDao.getFileVersions(fileId);

			/*
			 * DateFormat df = new SimpleDateFormat("ddMMyyyyHHmmss"); String reportDate =
			 * df.format(Calendar.getInstance().getTime());
			 * 
			 * String fileName = usersSessionObject.getUserName() + "~" + reportDate + "~" +
			 * documentObject.getFileName().trim().replaceAll(" ", ""); //change use file
			 * separator class instead of hard coding String filePath =
			 * context.getRealPath("/") + "resources\\upload\\" + fileName;
			 */
        //String filePath = context.getRealPath("/")+"resources\\upload\\"+documentObject.getFileName()+documentObject.getDocumentCompositeKey().getFileId();
		String fileName = Long.toString(fileId)+Long.toString(seqNo)+documentObject.getFileName();
        String filePath = context.getRealPath("/")+"resources\\upload\\"+fileName;
		//convert afterwards to error message of printStackTrace of catch block
		File file = new File(filePath);
		try {
			OutputStream out = new FileOutputStream(filePath);
			out.write(documentObject.getFileContent());
			out.close();
		}catch (IOException e) {
			e.printStackTrace();
		}
		file.deleteOnExit();
        
		model.addAttribute("search", search);
		//model.addAttribute("fileName", fileName);
		model.addAttribute("fileName", fileName );
		request.getSession().setAttribute("documentObject", documentObject);
		model.addAttribute("seqNodocumentObject", seqNodocumentObject);
		model.addAttribute("attribute", documentObject.getAtriBt());
		model.addAttribute("documentObjectData", documentObject);

		return "searchViewer";
	}else {
		return "loginIn";
	}
	}

	//check and change following logic of next and previous files
	//eliminate hard coding in following code
	@RequestMapping(value = "/nextPreviousFile", method = RequestMethod.GET)
	public String nextPreviousFile(Model model, @RequestParam("fileId") String fileIdSeqNo, HttpServletRequest request,HttpServletResponse response)  {
		UsersObject usersSessionObject = (UsersObject) request.getSession().getAttribute("users");
		if(usersSessionObject != null) {
		List<FileMasterObject> folderObjectSessionList = (List<FileMasterObject>) request.getSession().getAttribute("documentObjectlist");
		String[] fileIdSeqNo1 = fileIdSeqNo.split("~");
		long fileId = Long.parseLong(fileIdSeqNo1[0]);
		long seqNo = Long.parseLong(fileIdSeqNo1[1]);
		String nextPrevoius = fileIdSeqNo1[2];
        
		//try to eliminate multiple place try catch for same method
		int objIndex;
		long nextfileId, nextseqNo;
		for (FileMasterObject Obj : folderObjectSessionList) {
			if (Obj.getFileId() == fileId && Obj.getSeqNo() == seqNo) {
				objIndex = folderObjectSessionList.indexOf(Obj);
				if (objIndex != 0 && nextPrevoius.equals("P")) {
					objIndex = objIndex - 1;
					FileMasterObject ObjNew =  folderObjectSessionList.get(objIndex);
					nextfileId = (long) ObjNew.getFileId();
					nextseqNo = (long) ObjNew.getSeqNo();
					try {
						getAllData(request, model, nextfileId, nextseqNo, fileId);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} else if (objIndex == 0 && nextPrevoius.equals("P")) {
					model.addAttribute("docObj1", "Hard");
					model.addAttribute("fileIdSeqNo", fileId + "~" + seqNo);
				} else if (objIndex != 0 && nextPrevoius.equals("N")) {
					objIndex = objIndex + 1;
					if (objIndex > (folderObjectSessionList.size() - 1)) {
						model.addAttribute("docObj1", "Hard");
						model.addAttribute("fileIdSeqNo", fileId + "~" + seqNo);
					} else {
						FileMasterObject ObjNew =  folderObjectSessionList.get(objIndex);
						nextfileId = (long) ObjNew.getFileId();
						nextseqNo = (long) ObjNew.getSeqNo();
						try {
							getAllData(request, model, nextfileId, nextseqNo, fileId);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				} else if (objIndex == 0 && nextPrevoius.equals("N")) {
					objIndex = objIndex + 1;
					if (objIndex > (folderObjectSessionList.size() - 1)) {
						model.addAttribute("docObj1", "Hard");
						model.addAttribute("fileIdSeqNo", fileId + "~" + seqNo);
					} else {
						FileMasterObject ObjNew =  folderObjectSessionList.get(objIndex);
						nextfileId = (long) ObjNew.getFileId();
						nextseqNo = (long) ObjNew.getSeqNo();
						try {
							getAllData(request, model, nextfileId, nextseqNo, fileId);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}
		}
		model.addAttribute("search", "searchValue");
		return "searchViewer";
		}else {
			return "loginIn";
		}
	}

	public void getAllData(HttpServletRequest request, Model model, long nextfileId, long nextseqNo, long fileId)throws IOException {
		//UsersObject usersSessionObject = (UsersObject) request.getSession().getAttribute("users");
		DocumentObject documentObject = documentDao.getFileByFileIdAndSeqNo(nextfileId, nextseqNo);
		List<DocumentObject> seqNodocumentObject = documentDao.getFileVersions(fileId);
		/*
		 * DateFormat df = new SimpleDateFormat("ddMMyyyyHHmmss"); Date today =
		 * Calendar.getInstance().getTime(); String reportDate = df.format(today);
		 * String fileName = usersSessionObject.getUserName() + "~" + reportDate + "~" +
		 * documentObject.getFileName().trim().replaceAll(" ", ""); //Change use file
		 * separator class remove hard code String filePath = context.getRealPath("/") +
		 * "resources\\upload\\" + fileName;
		 */
        //String filePath = context.getRealPath("/")+"resources\\upload\\"+documentObject.getDocumentCompositeKey().getFileId()+documentObject.getFileName();
		String fileName = Long.toString(nextfileId)+Long.toString(nextseqNo)+documentObject.getFileName();
        String filePath = context.getRealPath("/")+"resources\\upload\\"+fileName;
		File file = new File(filePath);
		OutputStream out = new FileOutputStream(filePath);
		out.write(documentObject.getFileContent());
		out.close();
		file.deleteOnExit();
		model.addAttribute("seqNodocumentObject", seqNodocumentObject);
		model.addAttribute("fileName", fileName);
		model.addAttribute("documentObjectData", documentObject);
	}

	@RequestMapping(value = "/downloadFile", method = RequestMethod.GET)
	public void downloadFile(@RequestParam("fileId") String fileIdSeqNo, HttpServletResponse response) {
		String[] fileIdSeqNo1 = fileIdSeqNo.split("~");
		int fileId = Integer.parseInt(fileIdSeqNo1[0]);
		int seqNo = Integer.parseInt(fileIdSeqNo1[1]);
		DocumentObject documentObject = documentDao.getFileByFileIdAndSeqNo(fileId, seqNo);
		if(documentObject.getAtriBt().equals("H")) {
			return;
		}else {
		response.setContentType(documentObject.getFileExtn());
		response.setContentLength(documentObject.getFileContent().length);
		//Change use file separator class remove hard code
		response.setHeader("Content-Disposition", "attachment; filename=\"" + documentObject.getFileName() + "\"");
			try {
				FileCopyUtils.copy(documentObject.getFileContent(), response.getOutputStream());
				response.getOutputStream().flush();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
			finally {
				try {
					response.getOutputStream().close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	@RequestMapping(value = "/getFileTagGrpName", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<TagGroupObject> getFileTagGrpName(@RequestParam("fileId") long fileId) {
		List<TagGroupObject> tagDataList = fileTgDataDao.getTagGrpName(fileId);
		return tagDataList;
	}
	
	@RequestMapping(value="/getFileTagsData", method=RequestMethod.GET, produces="application/json")
	public @ResponseBody List<FileTagsDataObject> getFileTagsData(@RequestParam("fileId") long fileId,@RequestParam("tagGrpId") long tagGrpId){
		List<FileTagsDataObject> fileTagsDataObjectList=fileTgDataDao.getTagData(fileId,tagGrpId);
		return fileTagsDataObjectList;
	}

	@RequestMapping(value = "/getCheckOutFile", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody DocumentObject getCheckOutFile(@RequestParam("fileId") String fileIdSeqNo) {
		String[] fileIdSeqNo1 = fileIdSeqNo.split("~");
		long fileId = Long.parseLong(fileIdSeqNo1[0]);
		long seqNo = Long.parseLong(fileIdSeqNo1[1]);
		long maxSeqno=documentDao.checkGreaterSeqNo(fileId);
		if( maxSeqno <= seqNo) {
			DocumentObject docObj = documentDao.getFileByFileIdAndSeqNo(fileId, seqNo);
			return docObj;
		}
		else {
			DocumentObject docObj=new DocumentObject();
			docObj.setAtriBt(null);
		    return docObj;
	   }
	}

	//check and change logic
	@RequestMapping(value = "/updatecheckOut", method = RequestMethod.POST)
	public String checkOutFile(HttpServletRequest request) {
		UsersObject usersSess = (UsersObject) request.getSession().getAttribute("users");
		long fileId = Long.parseLong(request.getParameter("fileId"));
		long seqNo = Long.parseLong(request.getParameter("seqNo"));
		if(usersSess!=null) {
			DocumentObject docObj = documentDao.getFileByFileIdAndSeqNo(fileId, seqNo);
			//remove hard code get it from constant files
			if(request.getParameter("atribt").equals("O")) {
				HistoryFileObject historyFileObject=new HistoryFileObject();
				
				FileIdSeqNo fileIdSeqNo = new FileIdSeqNo();
				fileIdSeqNo.setFileId(fileId);
				fileIdSeqNo.setSeqNo(seqNo);
				
				historyFileObject.setId(fileIdSeqNo);
				historyFileObject.setFileNm(docObj.getFileName());
				//remove hard code and get it from constant file or message source 
				historyFileObject.setAtribt(request.getParameter("atribt"));
				historyFileObject.setRemark(request.getParameter("remark"));
				historyFileObject.setCreatedBy(usersSess.getUserId());
			 	historyFileObject.setCreationDt(new Timestamp(new Date().getTime()));
			 	historyFileDao.saveHisFile(historyFileObject);
			 	docObj.setModifiedBy(usersSess.getUserId());
				docObj.setModificationDt(historyFileObject.getCreationDt());
			  }
		docObj.setAtriBt(request.getParameter("atribt"));
		
		documentDao.updateDocument(docObj);
		return "redirect:/searchViewer?fileId=" + fileId + "~" + seqNo;
		}else {
			return "loginIn";
		}
		//System.out.println("Update Successfully");
		
	}
}
