package com.common.Dao;

import java.util.HashMap;
import java.util.List;

import com.common.CompositeKey.TagCompositeKey;
import com.common.Objects.ReportSearchObject;
import com.common.Objects.TagGroupObject;
import com.common.Objects.TagObject;
import com.common.Objects.TagReportObject;

public interface TagDao {
	 
	 public	void saveTagObject(TagObject tagObject);

	 public List<TagObject> getAllTagObject();

	// public TagObject getTagById(Integer tagId);
	 
	 public TagObject getTagById(TagCompositeKey tagCompositeKey);
	 
	 public List<TagGroupObject> getAllTagsForFileDisplay(long rootId);
	 
	 public int getMaxValueId(long tagGrpValue);

	public List<TagObject> getTagData(long tagGrpId);

	public void updateTagObject(TagObject tagObject);
	
	public HashMap<Long, String> getHashmapofTagObject(long tagGrpId);
	
	public List<TagReportObject> getTagReport(ReportSearchObject reportSearchObject, HashMap<Long,String> hashMapOfTagObj);

	public List<TagReportObject> getTagSearch(HashMap<Long, String> hashMapOfTagObj, String queryBuilder);
	 
}
/*
 * int hashMapSize = hashMapOfTagObj.size(); String dataSet = "fileId bigint";
 * for(int i=1;i<hashMapSize;i++) {
 * dataSet.concat(","+hashMapOfTagObj.get(i)+" character varying(200)"); }
 * String sql =
 * "Select ft.fileId,tagId,tagdata from filemst fm,filetagsdata ft where fm.fileId = ft.fileId and ft.taggrpId ="
 * +reportSearchObject.getTagGrpId()+" AND ft.creationDt between ''"
 * +reportSearchObject.getCreationFromDt()+"'' AND ''"+
 * reportSearchObject.getCreationToDt()+"''";
 */