package com.common.DaoImpl;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.HistoryFileDao;
import com.common.Objects.HistoryFileObject;

@Repository
@Transactional
public class HistoryFileDaoImpl implements HistoryFileDao{

	@Autowired
	private SessionFactory sessionFactory;

	//try to eliminate and put it in utility or common
	@Override
	public void saveHisFile(HistoryFileObject historyFileObject) {
		sessionFactory.getCurrentSession().save(historyFileObject);
	}

}
