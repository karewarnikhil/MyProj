package com.common.DaoImpl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;
import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.ReportDao;
import com.common.Objects.DepartmentReport;
import com.common.Objects.DocumentObject;
import com.common.Objects.FolderObject;
import com.common.Objects.ReportSearchObject;
import com.common.Utilities.DmsConstant;

@Repository
@Transactional
public class ReportDaoImpl implements ReportDao{
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public List<DepartmentReport> getDepartmentWiseSummaryReport(ReportSearchObject reportSearchObject) {
		List<FolderObject> listOfFolder = null;
		if(reportSearchObject.getDeptId() > 0) {
		    listOfFolder  = sessionFactory.getCurrentSession().createQuery("FROM FolderObject where deptId ="+reportSearchObject.getDeptId() +" And folderId > 0 And rootId > 0 order by folderNm").list();
		}else {
			listOfFolder  = sessionFactory.getCurrentSession().createQuery("FROM FolderObject where  folderId > 0 And rootId > 0 order by deptId").list();
		}
		List<DepartmentReport> listSummaryReport = new ArrayList<DepartmentReport>();
		if(listOfFolder != null){
			Query qry = null;
			for(FolderObject folderObject:listOfFolder){
			  if(reportSearchObject.getCreationToDt() != null) {
				/** long fileCnt = (Long)sessionFactory.getCurrentSession().createQuery("SELECT COALESCE(count(fileId),0) FROM DocumentObject where folderId="+folderObject.getFolderId()+" And creationDt BETWEEN '"+reportSearchObject.getCreationFromTs()+"' And '"+reportSearchObject.getCreationToTs()+"'AND documentCompositeKey.seqNo = 1").uniqueResult();
				long pageCnt = (Long)sessionFactory.getCurrentSession().createQuery("SELECT COALESCE(sum(pageCnt),0) FROM DocumentObject where folderId="+folderObject.getFolderId()+" And creationDt BETWEEN '"+reportSearchObject.getCreationFromTs()+"' And '"+reportSearchObject.getCreationToTs()+"'AND documentCompositeKey.seqNo = 1").uniqueResult();
				long a0Size = (Long)sessionFactory.getCurrentSession().createQuery("SELECT COALESCE(sum(a0Size),0) FROM DocumentObject where folderId="+folderObject.getFolderId()+" And creationDt BETWEEN '"+reportSearchObject.getCreationFromTs()+"' And '"+reportSearchObject.getCreationToTs()+"'AND documentCompositeKey.seqNo = 1").uniqueResult();
				long a1Size = (Long)sessionFactory.getCurrentSession().createQuery("SELECT COALESCE(sum(a1Size),0) FROM DocumentObject where folderId="+folderObject.getFolderId()+" And creationDt BETWEEN '"+reportSearchObject.getCreationFromTs()+"' And '"+reportSearchObject.getCreationToTs()+"'AND documentCompositeKey.seqNo = 1").uniqueResult();
				long a2Size = (Long)sessionFactory.getCurrentSession().createQuery("SELECT COALESCE(sum(a2Size),0) FROM DocumentObject where folderId="+folderObject.getFolderId()+" And creationDt BETWEEN '"+reportSearchObject.getCreationFromTs()+"' And '"+reportSearchObject.getCreationToTs()+"'AND documentCompositeKey.seqNo = 1").uniqueResult();
				long a3Size = (Long)sessionFactory.getCurrentSession().createQuery("SELECT COALESCE(sum(a3Size),0) FROM DocumentObject where folderId="+folderObject.getFolderId()+" And creationDt BETWEEN '"+reportSearchObject.getCreationFromTs()+"' And '"+reportSearchObject.getCreationToTs()+"'AND documentCompositeKey.seqNo = 1").uniqueResult();
				long a4Size = (Long)sessionFactory.getCurrentSession().createQuery("SELECT COALESCE(sum(a4Size),0) FROM DocumentObject where folderId="+folderObject.getFolderId()+" And creationDt BETWEEN '"+reportSearchObject.getCreationFromTs()+"' And '"+reportSearchObject.getCreationToTs()+"'AND documentCompositeKey.seqNo = 1").uniqueResult();
				**/
				
				  qry = sessionFactory.getCurrentSession().createQuery("SELECT COALESCE(count(fileId),0) as fileCnt,COALESCE(sum(pageCnt),0) as pageCnt, COALESCE(sum(a0Size),0) as a0Size, COALESCE(sum(a1Size),0) as a1Size, COALESCE(sum(a2Size),0) as a2Size, COALESCE(sum(a3Size),0) as a3Size, COALESCE(sum(a4Size),0) as a4Size FROM DocumentObject where folderId="+folderObject.getFolderId()+" And creationDt BETWEEN '"+reportSearchObject.getCreationFromTs()+"' And '"+reportSearchObject.getCreationToTs()+"'AND documentCompositeKey.seqNo = 1");
				  fillDocumentObjectFromResultSet(listSummaryReport, qry, folderObject);
			  }else
			  {
				  qry =  sessionFactory.getCurrentSession().createQuery("SELECT COALESCE(count(fileId),0) as fileCnt,COALESCE(sum(pageCnt),0) as pageCnt,COALESCE(sum(a0Size),0) as a0Size,COALESCE(sum(a1Size),0) as a1Size,COALESCE(sum(a2Size),0) as a2Size,COALESCE(sum(a3Size),0) as a3Size,COALESCE(sum(a4Size),0) as a4Size FROM DocumentObject where folderId="+folderObject.getFolderId()+" And creationDt >= '"+reportSearchObject.getCreationFromTs()+"' AND documentCompositeKey.seqNo = 1");
				  fillDocumentObjectFromResultSet(listSummaryReport, qry, folderObject);
			  }
				
				
			} 
		}	
		return listSummaryReport;
	}

	private void fillDocumentObjectFromResultSet(List<DepartmentReport> listSummaryReport, Query qry,FolderObject folderObject) {
		  List<Object[]> row = qry.getResultList();
		  row.stream().forEach((record) -> {
				if(((Long) record[0]).longValue() > 0) {
					DepartmentReport departmentReport = new DepartmentReport();
					departmentReport.setFolderNm(folderObject.getFolderNm());
					departmentReport.setFileCnt(((Long) record[0]).longValue());
					departmentReport.setPageCnt(((Long) record[1]).longValue());
					departmentReport.setA0Size(((Long) record[2]).longValue());
					departmentReport.setA1Size(((Long) record[3]).longValue());
					departmentReport.setA2Size(((Long) record[4]).longValue());
					departmentReport.setA3Size(((Long) record[5]).longValue());
					departmentReport.setA4Size(((Long) record[6]).longValue());
					departmentReport.setDepartmentNm(DmsConstant.HASHMAP_OF_DEPARTMENT.get(folderObject.getDeptId()));
					listSummaryReport.add(departmentReport);
			}
		});
	}

	@Override
	public List<DocumentObject> departmentWiseDigitizationReports(ReportSearchObject reportSearchObject) {
		Query qry = null;
		if(reportSearchObject.getCreationToDt() != null) {
			if(reportSearchObject.getDeptId() > 0) {
				qry =  sessionFactory.getCurrentSession().createQuery(" SELECT d.folderId,d.creationDt,d.rootId,d.fileName,d.pageCnt,d.a0Size,d.a1Size,d.a2Size,d.a3Size,d.a4Size,fo.deptId FROM DocumentObject d,FolderObject fo where d.folderId = fo.folderId  And fo.deptId = "+reportSearchObject.getDeptId()+" AND d.creationDt BETWEEN '"+reportSearchObject.getCreationFromTs()+"' AND '"+ reportSearchObject.getCreationToTs()+"'AND d.documentCompositeKey.seqNo = 1 order by d.documentCompositeKey.fileId asc");
			}
			else {
				qry = sessionFactory.getCurrentSession().createQuery(" SELECT d.folderId,d.creationDt,d.rootId,d.fileName,d.pageCnt,d.a0Size,d.a1Size,d.a2Size,d.a3Size,d.a4Size,fo.deptId FROM DocumentObject d,FolderObject fo where d.folderId = fo.folderId AND d.creationDt BETWEEN '"+reportSearchObject.getCreationFromTs()+"' AND '"+ reportSearchObject.getCreationToTs()+"'AND d.documentCompositeKey.seqNo = 1 order by fo.deptId");
			}
		}else {
			if(reportSearchObject.getDeptId() > 0) {
				qry =  sessionFactory.getCurrentSession().createQuery(" SELECT d.folderId,d.creationDt,d.rootId,d.fileName,d.pageCnt,d.a0Size,d.a1Size,d.a2Size,d.a3Size,d.a4Size,fo.deptId FROM DocumentObject d,FolderObject fo where d.folderId = fo.folderId  And fo.deptId = "+reportSearchObject.getDeptId()+" AND d.creationDt >= '"+reportSearchObject.getCreationFromTs()+"'AND d.documentCompositeKey.seqNo = 1 order by d.documentCompositeKey.fileId asc");
			}
			else {
				qry = sessionFactory.getCurrentSession().createQuery(" SELECT d.folderId,d.creationDt,d.rootId,d.fileName,d.pageCnt,d.a0Size,d.a1Size,d.a2Size,d.a3Size,d.a4Size,fo.deptId FROM DocumentObject d,FolderObject fo where d.folderId = fo.folderId AND d.creationDt >= '"+reportSearchObject.getCreationFromTs()+"' AND d.documentCompositeKey.seqNo = 1 order by fo.deptId");
			}
		}
			List<DocumentObject> listSummaryReport = new ArrayList<DocumentObject>();
			List<Object[]> row = qry.getResultList();
			row.stream().forEach((record) -> {
				DocumentObject documentObject = new DocumentObject();
				documentObject.setFolderId(((Long) record[0]).longValue());
				documentObject.setCreationDt((((Timestamp) record[1])));
				documentObject.setRootId(((Long) record[2]).longValue());
				documentObject.setFileName((String)(record[3]));
				documentObject.setPageCnt(((Integer) record[4]).intValue());
				documentObject.setA0Size(((Integer) record[5]).intValue());
				documentObject.setA1Size(((Integer) record[6]).intValue());
				documentObject.setA2Size(((Integer) record[7]).intValue());
				documentObject.setA3Size(((Integer) record[8]).intValue());
				documentObject.setA4Size(((Integer) record[9]).intValue());
				documentObject.setDepartmentNm(DmsConstant.HASHMAP_OF_DEPARTMENT.get(((Long) (record[10])).longValue()));
				listSummaryReport.add(documentObject);
			});
	    return listSummaryReport;
	}
	
	
	/*
	 * SELECT COALESCE(sum(pageCnt),0),COALESCE(sum(a0size),0),
	 * COALESCE(sum(a1size),0),COALESCE(sum(a2size),0),COALESCE(sum(a3size),0),
	 * COALESCE(sum(a4size),0) FROM filemst where folderId = 16
	 */

}
