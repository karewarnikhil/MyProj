package com.common.Utilities;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.view.AbstractView;

import com.common.Objects.DepartmentReport;
import com.common.Objects.DocumentObject;
import com.common.Objects.ReportSearchObject;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;

public class PdfDeptReportView extends AbstractView{

	  private JasperReport departmentReport;
	 
	  @Autowired
	  ServletContext context;
	   
		 
	    @Override
	    protected boolean generatesDownloadContent() {
	        return true;
	    }
	    
	    @Override
	    protected void renderMergedOutputModel(Map<String, Object> model,
	            HttpServletRequest request, HttpServletResponse response) throws Exception {
	    	ReportSearchObject reportSearchObject = (ReportSearchObject) model.get("reportSearchObject");
	    	List<DocumentObject> documentlist =  (List<DocumentObject>) model.get("documentlist");
	    	List<DepartmentReport> departmentReportList =  (List<DepartmentReport>) model.get("departmentReportList");
	        //data source
	        //JRDataSource ds = getDataSource(departmentlist);
	    	JRBeanCollectionDataSource ds = null;
	    	String reportName = null;
	    	if(documentlist != null) {
	    		reportName = 	"/digitizationReport.jrxml";
	    		ds = new JRBeanCollectionDataSource(documentlist);
	    	}
	    		
	    	else if(departmentReportList != null) {
	    		reportName = 	"/summaryReport.jrxml";
	    		ds = new JRBeanCollectionDataSource(departmentReportList);
	    	}
	    		
	        //compile jrxml template and get report
	        JasperReport report = getReport(reportName);
	        //fill the report with data source objects
		
	        /* Map to hold Jasper report Parameters */
          Map<String, Object> parameters = new HashMap<String, Object>();
          parameters.put("dataSource", ds);
        //  System.out.println(DmsConstant.HASHMAP_OF_DEPARTMENT.get(reportSearchObject.getDeptId()));
          //System.out.println( reportSearchObject.getCreationFromDt());
          if(reportSearchObject.getDeptId() > 0)
        	  parameters.put("deptId", DmsConstant.HASHMAP_OF_DEPARTMENT.get(reportSearchObject.getDeptId()));
          else
        	  parameters.put("deptId", "All Departments");

          parameters.put("dateFrom", reportSearchObject.getCreationFromDt());
          parameters.put("dateTo", reportSearchObject.getCreationToDt());
          parameters.put("imagePath", model.get("imagePath"));
		 
	        JasperPrint jasperPrint = JasperFillManager.fillReport(report, parameters,new JREmptyDataSource());
		/*
		 * //export to html HtmlExporter exporter = new
		 * HtmlExporter(DefaultJasperReportsContext.getInstance());
		 * exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
		 * exporter.setExporterOutput(new
		 * SimpleHtmlExporterOutput(response.getWriter())); exporter.exportReport();
		 */
		
		
		/*
		 * byte[] bytes = JasperExportManager.exportReportToPdf(jasperPrint);
		 * response.setContentType("application/pdf");
		 * response.setContentLength(bytes.length); // get file separator get it from
		 * java class separator . response.setHeader(
		 * "Content-Disposition","attachment; filename=\"Digitization Report.pdf\"");
		 * 
		 * try { FileCopyUtils.copy(bytes, response.getOutputStream());
		 * response.getOutputStream().flush(); response.getOutputStream().close(); }
		 * catch (IOException ex) { ex.printStackTrace(); }
		 */
	        
	        JRPdfExporter pdfExporter = new JRPdfExporter();
            pdfExporter.setExporterInput(new SimpleExporterInput(jasperPrint));
            ByteArrayOutputStream pdfReportStream = new ByteArrayOutputStream();
            pdfExporter.setExporterOutput(new SimpleOutputStreamExporterOutput(pdfReportStream));
            pdfExporter.exportReport();

            response.setContentType("application/pdf");
            response.setHeader("Content-Length", String.valueOf(pdfReportStream.size()));
            response.addHeader("Content-Disposition", "inline; filename=digitizationReport.pdf;");

            OutputStream responseOutputStream = response.getOutputStream();
            responseOutputStream.write(pdfReportStream.toByteArray());
            responseOutputStream.close();
            pdfReportStream.close();
            logger.info("Completed Successfully: ");
	    }
	    
	/*
	 * private JRDataSource getDataSource(List<DepartmentObject> departmentlist) {
	 * JRBeanCollectionDataSource ds = new
	 * JRBeanCollectionDataSource(departmentlist); return ds; }
	 */
	    
	    public JasperReport getReport(String reportName) throws JRException {
	        InputStream stream = getClass().getResourceAsStream(reportName);
	        departmentReport = JasperCompileManager.compileReport(stream);
	        return departmentReport;
	    }
  
 
	
	
	

	/*
	 * @Override protected void buildPdfDocument(Map<String, Object> model, Document
	 * document, PdfWriter writer, HttpServletRequest request, HttpServletResponse
	 * response) throws Exception { response.setHeader(
	 * "Content-Disposition","attachment; filename=\"digitizationReport.pdf\"");
	 * List<DocumentObject> documentlist = (List<DocumentObject>)
	 * model.get("documentlist");
	 * document.addTitle("Dipartment Wise Digitization Report");
	 * 
	 * float [] pointColumnWidths = {5F,20F, 5F, 5F,5F, 5F,5F, 5F}; Table table =
	 * new Table(8); table.setWidth(100); table.setWidths(pointColumnWidths);
	 * table.addCell("Sr No"); table.addCell("File Name");
	 * table.addCell("Page Count"); table.addCell("A0 Size");
	 * table.addCell("A1 Size"); table.addCell("A2 Size"); table.addCell("A3 Size");
	 * table.addCell("A4 Size"); int i = 0; for(DocumentObject
	 * documentObject:documentlist) { table.addCell(String.valueOf(++i));
	 * table.addCell(documentObject.getFileName());
	 * table.addCell(String.valueOf(documentObject.getPageCnt()));
	 * table.addCell(String.valueOf(documentObject.getA0Size()));
	 * table.addCell(String.valueOf(documentObject.getA1Size()));
	 * table.addCell(String.valueOf(documentObject.getA2Size()));
	 * table.addCell(String.valueOf(documentObject.getA3Size()));
	 * table.addCell(String.valueOf(documentObject.getA4Size())); }
	 * document.add(table);
	 * 
	 * }
	 */

}
