package com.common.Controllers;

import java.io.IOException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.Provider;
import java.security.Security;
import java.security.cert.CertificateException;
import java.util.Enumeration;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class DscController {
	
	
	 @RequestMapping(value="/displayDigitalSign", method = RequestMethod.POST)
	   public String displayDigitalSign(Model model,@RequestParam("tokenPassword") String tokenPassword,@RequestParam("fileName") String fileName){
		 
		   String configName = "E:\\eTPKCS11.cfg.txt";
		   Provider provider = Security.getProvider("SunPKCS11");
		   provider = provider.configure(configName);
		   Security.addProvider(provider);   
		   Enumeration<String> signName = null;
		   
		   KeyStore keyStore = null;
		
				try {
					keyStore = KeyStore.getInstance("PKCS11",provider);
					keyStore.load(null, tokenPassword.toCharArray());
					signName = keyStore.aliases();
				} catch (KeyStoreException | NoSuchAlgorithmException | CertificateException | IOException e) {
					e.printStackTrace();
				}
		   
		   model.addAttribute("dscList",signName );
		   model.addAttribute("fileName", fileName);
	       return "displayDigitalSignature"; 
	   }
	 
	 
	   @RequestMapping(value="/manageDScETokon", method = RequestMethod.GET)  
	   public ModelAndView manageDScETokon(String tokenPassword) {  
		   
		  /* String pkcs11Config = "name=eToken\nlibrary=C:\\Windows\\System32\\eps2003csp11.dll";
		   java.io.ByteArrayInputStream pkcs11ConfigStream = new java.io.ByteArrayInputStream(pkcs11Config.getBytes());
		       sun.security.pkcs11.SunPKCS11 providerPKCS11 = new sun.security.pkcs11.SunPKCS11("pkcs11Config");
		       java.security.Security.addProvider(providerPKCS11);

		   // Get provider KeyStore and login with PIN
		   String pin = "12345678";
		  // java.security.KeyStore keyStore = java.security.KeyStore.getInstance("PKCS11", providerPKCS11);
		   KeyStore keyStore=KeyStore.getInstance("PKCS11",providerPKCS11);
		   keyStore.load(null, pin.toCharArray());

		   // Enumerate items (certificates and private keys) in the KeyStore
		   java.util.Enumeration<String> aliases = keyStore.aliases();
		   String alias = null;
		   while (aliases.hasMoreElements()) {
		       alias = aliases.nextElement();
		       System.out.println(alias);

		       }*/
		   
		   /* String lineSeparator = System.getProperty("path.separator");
		    String libraryPath = System.getProperty("java.library.path");
		    for (String dir : libraryPath.split(lineSeparator)) {
		        File f = new File(dir + "/" + "pkcs11wrapper.dll"); 
		        if (f.exists()) {
		            System.out.println("found in: " + f.getAbsolutePath());
		        }
		    }*/
		   
		  /* try  
			{
				// Get constructor to the Sun PKCS11 provider
				Class<?> pkcs11Class = Class.forName("sun.security.pkcs11.SunPKCS11");
				//Constructor<?> construct = pkcs11Class.getConstructor(new Class[] {String.class});
				Constructor<?> construct = pkcs11Class.getConstructor(new Class[] {String.class});

				// Construct the provider
				String configName = "pkcs11.cfg";
				Provider p = (Provider)construct.newInstance(new Object[] {configName});
				Security.addProvider(p);

				// Create key store
				KeyStore ks = KeyStore.getInstance("PKCS11");
				ks.load(null, "tokenpwd".toCharArray());

				// Get the alias of the first entry in the keystore
				Enumeration<?> aliases = ks.aliases();
				if (aliases.hasMoreElements() == false)
				{
					System.out.println ("No digital IDs found in token.");
					System.exit(-1);
				}
				String idAlias = (String)aliases.nextElement();

				// Load PDF document with jPDFSecure
				PDFSecure pdf = new PDFSecure ("input.pdf", null);
				
				// Add a signature field to the document
				SignatureField signField = pdf.addSignatureField(0, "SignHere", new Rectangle2D.Double(180, 72, 200, 60));
				
				// Create signature information from the keystore
				SigningInformation signingInfo = new SigningInformation(ks, idAlias, "");
				
				// Sign and save the document
				pdf.signDocument(signField, signingInfo);
				pdf.saveDocument("signed.pdf");
			}
			catch (Throwable t)
			{
				t.printStackTrace();
			}*/
		   
		   /*try {
			    
				// Generate a 1024-bit Digital Signature Algorithm (DSA) key pair
			    try {
			    	
			    	FileInputStream fis = new FileInputStream("test");
					ObjectInputStream ois = new ObjectInputStream(fis);
			    	
					KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
							
					char[] password = "some password".toCharArray();
					ks.load(null, password);

					// Store away the keystore.
					FileOutputStream fos = new FileOutputStream("newKeyStoreFileName");
					ks.store(fos, password);
					fos.close();
					System.out.println(ks.getCertificate("Nikhil"));
				} catch (KeyStoreException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			    
			   
				KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("DSA");
				keyPairGenerator.initialize(1024);
				KeyPair keyPair = keyPairGenerator.genKeyPair();
				PrivateKey privateKey = keyPair.getPrivate();
				PublicKey publicKey = keyPair.getPublic();
				    
				// We can sign Serializable objects only
				String unsignedObject = new String("A Test Object");
				Signature signature = Signature.getInstance(privateKey.getAlgorithm());
				SignedObject signedObject = new SignedObject(unsignedObject, privateKey, signature);
				
				// Verify the signed object
				Signature sig = Signature.getInstance(publicKey.getAlgorithm());
				System.out.println("sig==="+sig);
				boolean verified = signedObject.verify(publicKey, sig);

				System.out.println("Is signed Object verified ? " + verified);
				
				// Retrieve the object
				unsignedObject = (String) signedObject.getObject();
				
				System.out.println("Unsigned Object : " + unsignedObject);
				
			    } catch (SignatureException e) {
			    } catch (InvalidKeyException e) {
			    } catch (NoSuchAlgorithmException e) {
			    } catch (ClassNotFoundException e) {
			    } catch (IOException e) {
			    }*/
	/*	   
	 * 
		name=<Name of Etoken>
		slot=<slot number for etoken>
		library=<path of the pckcs11 library(dll) for that etoken>

      PrivateKey privateKey = null;
char password[] = "1234".toCharArray();
Provider userProvider = new sun.security.pkcs11.SunPKCS11("D:\\config.cfg");
ks = KeyStore.getInstance("PKCS11", userProvider);
ks.load(null, password);    
Enumeration e = ks.aliases();
String alias=null;
while (e.hasMoreElements()) 
{
  alias = (String) e.nextElement();
  privateKey = (PrivateKey) ks.getKey(alias, password);
}
*/

      /*   String configName = "/opt/bar/cfg/pkcs11.cfg";
         PKCS11 a= new PKCS11Signer(0, configName);
		   Provider p = new PKCS11Signer(configName);
		   Security.addProvider(p);
		   
		   String pkcs11Config = "name=eToken\nlibrary=C:\\Windows\\System32\\eps2003csp11.dll";
		   java.io.ByteArrayInputStream pkcs11ConfigStream = new java.io.ByteArrayInputStream(pkcs11Config.getBytes());
		   SunPKCS11 providerPKCS11 = new SunPKCS11("pkcs11Config");
		       java.security.Security.addProvider(providerPKCS11);

		   // Get provider KeyStore and login with PIN
		   String pin = "12345678";
		   java.security.KeyStore keyStore = java.security.KeyStore.getInstance("PKCS11", providerPKCS11);
		  // KeyStore keyStore=KeyStore.getInstance("PKCS11",providerPKCS11);
		   keyStore.load(null, pin.toCharArray());

		   // Enumerate items (certificates and private keys) in the KeyStore
		   java.util.Enumeration<String> aliases = keyStore.aliases();
		   String alias = null;
		   while (aliases.hasMoreElements()) {
		       alias = aliases.nextElement();
		       System.out.println(alias);

		  }*/
		       
		       
		       
/*		       String pkcs11ConfigFile = "D:\\NCSA\\java\\SmartCardSecurity\
\pkcs11.cfg";
Provider pkcs11Provider = new
sun.security.pkcs11.SunPKCS11(pkcs11ConfigFile);
Security.addProvider(pkcs11Provider);
          //PIN is used to protect the information strored in the
card
          char[] pin = ...;//password
          KeyStore smartCardKeyStore =
KeyStore.getInstance("PKCS11");
          smartCardKeyStore.load(null, pin);

          //Get the enumeration of the entris in the keystore
          Enumeration aliasesEnum = smartCardKeyStore.aliases();
          while (aliasesEnum.hasMoreElements()) {
              //Print certificate
              X509Certificate cert = (X509Certificate)
smartCardKeyStore.getCertificate(alias);
              System.out.println("Certificate: " + cert);
          }
		       */
		     
		   
		/*   try {
				String data = null;
				byte signature[] = null;
				FileInputStream fis = new FileInputStream("test");
				ObjectInputStream ois = new ObjectInputStream(fis);
				Object o = ois.readObject();
				try {
				    data = (String) o;
				} catch (ClassCastException cce) {
				    System.out.println("Unexpected data in file");
				    System.exit(-1);
				}
				o = ois.readObject();
				try {
				    signature = (byte []) o;
				} catch (ClassCastException cce) {
				    System.out.println("Unexpected data in file");
				    System.exit(-1);
				}
				System.out.println("Received message");
				System.out.println(data);

				KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
	                      
				ks.load(new FileInputStream(
							System.getProperty("user.home") +
							File.separator + ".keystore"), args[1]);

				Certificate c = ks.getCertificate(args[0]);
				PublicKey pk = c.getPublicKey();
				Signature s = Signature.getInstance("DSA");
				s.initVerify(pk);
				s.update(data.getBytes());
				if (s.verify(signature)) {
					System.out.println("Message is valid");
				}
				else System.out.println("Message was corrupted");
			} catch (Exception e) {
				System.out.println(e);
			}*/
	   
	       return new ModelAndView("manageDepartment");  
	   }  

}
