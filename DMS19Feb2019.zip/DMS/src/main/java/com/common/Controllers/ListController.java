package com.common.Controllers;

import java.sql.Timestamp;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.common.Dao.ListDao;
import com.common.Objects.ListObject;
import com.common.Objects.UsersObject;

@Controller
public class ListController {

	@Autowired
	private ListDao listDao;

	@RequestMapping(value = "/createList", method = RequestMethod.GET)
	public String getListForm(Model model,HttpServletRequest request) {
		UsersObject usersSess = (UsersObject) request.getSession().getAttribute("users");
		if (usersSess != null) {
		model.addAttribute("listObject", new ListObject());
		model.addAttribute("allList", listDao.getAllList());
		return "manageList";
		}else {
			return "loginIn";
		}
	}
 
	@RequestMapping(value = "/saveList", method = RequestMethod.POST)
	public String saveList(@ModelAttribute("list") ListObject listObj, Model model, HttpServletRequest request) {
		UsersObject usersObject = (UsersObject) request.getSession().getAttribute("users");
		if (usersObject != null) {
			//change following direct call check condition afterwards
			//make common saveorUpdate 
			if (listDao.getByListName(listObj.getListName()) == null) {
				listObj.setListName(listObj.getListName());
				listObj.setCreatedBy(usersObject.getUserId());
				listObj.setCreationDt(new Timestamp(new Date().getTime()));
			//	need to remove hardCoding
				listObj.setStatus("A");
				listDao.save(listObj);
			} else {
				model.addAttribute("message", "List Name Already Present");
			}
			model.addAttribute("listObject", new ListObject());
			//change get it from hash map defined in constant file.
			model.addAttribute("allList", listDao.getAllList());
			return "manageList";
		}
		return "redirect:/login";
	}

	/*
	 * @RequestMapping(value = "/editList", method = RequestMethod.GET, produces =
	 * "application/json") public @ResponseBody ListObj
	 * getListObjEdit(@RequestParam("listId") int listId) { ListObj listObj =
	 * listDao.getListObjById(listId); return listObj; }
	 */

	@RequestMapping(value = "/editList", method = RequestMethod.GET)
	public String getListObjEdit(@RequestParam("listId") int listId, Model model,HttpServletRequest request) {
		UsersObject usersObject = (UsersObject) request.getSession().getAttribute("users");
		if (usersObject != null) {
		model.addAttribute("listObject", listDao.getListObjById(listId));
		//change get it from hash map defined in constant file.
		model.addAttribute("allList", listDao.getAllList());
		return "updateList";
		}else {
			return "loginIn";
		}
	}

	@RequestMapping(value = "/updateList", method = RequestMethod.POST)
	public String updateList(@ModelAttribute("list") ListObject listObj, Model model, HttpServletRequest request) {
		UsersObject usersSess = (UsersObject) request.getSession().getAttribute("users");
		if (usersSess != null) {
			//remove following rewriting of object update directly modelAttribute
			listObj.setListName(listObj.getListName());
			listObj.setCreatedBy(listObj.getCreatedBy());
			listObj.setCreationDt(listObj.getCreationDt());
			listObj.setStatus(listObj.getStatus());
			listDao.update(listObj);
			//check and avoid new object creation used following instead
			//model.addAttribute("listObject", listObj);
			model.addAttribute("listObject", new ListObject());
			//change get it from hash map defined in constant file.
			model.addAttribute("allList", listDao.getAllList());
			return "manageList";
		}
		return "redirect:/login";
	}
}
