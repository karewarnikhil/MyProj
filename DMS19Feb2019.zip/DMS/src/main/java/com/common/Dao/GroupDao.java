package com.common.Dao;

import java.util.HashMap;

import com.common.Objects.GroupObject;

public interface GroupDao {
	/*public List<GroupObject> getAllGroupObject();*/
	
	public GroupObject getGroupById(int grpId);
	
	public GroupObject getGroupByString(String main);

	public HashMap<Long, String> getHashmapofGroupObject();
}
