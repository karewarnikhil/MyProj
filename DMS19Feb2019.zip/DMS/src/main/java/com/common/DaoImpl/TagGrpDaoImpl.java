package com.common.DaoImpl;

import java.util.HashMap;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.TagGrpDao;
import com.common.Objects.TagGroupObject;
import com.common.Objects.TagObject;
import com.common.Objects.TagTypeObject;
import com.common.Utilities.GeneralUtility;

@Repository
@Transactional
public class TagGrpDaoImpl implements TagGrpDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	/*public List<TagGroupObject> getAllTagGroup() {
		return sessionFactory.getCurrentSession().createQuery(" FROM TagGroupObject ").list();
	}*/
	
	public void saveTagGrp(TagGroupObject tagGroup) {
		Session session = sessionFactory.getCurrentSession();
		//remove hard-code define in constant file
		String seqName = "tagGrpId";
		long currentVal = GeneralUtility.getIdForCurrentVal(session, seqName);
		tagGroup.setTagGrpId(currentVal);
		//System.out.println("Tag Group Id: "+tagGroup.getTagGrpId());
		sessionFactory.getCurrentSession().save(tagGroup);
	}

	/*@Override
	public List<TagTypeObject> getAllTagTypeObject() {
		return sessionFactory.getCurrentSession().createQuery(" FROM TagTypeObject ").list();
	}*/
	
	
	@Override
	public List<TagObject> getTagByClassId(long classId) {
		String sql="FROM TagObject tO where tO.tagCompositeKey.tagGrpId IN(select distinct cG.tagGroup from ClassTagGroup cG where cG.classObject.classId="+classId+")order by tO.tagCompositeKey.tagGrpId,tO.tagCompositeKey.tagId";
		return sessionFactory.getCurrentSession().createQuery(sql).list();
	}
	
	@Override
	public TagGroupObject getTagByTagId(long tagGrpId) {
		return (TagGroupObject) sessionFactory.getCurrentSession().createQuery(" FROM TagGroupObject where taggrpid="+tagGrpId).uniqueResult();
	}

	//used trim here see other solution
	@Override
	public Object getAllTagForGroupDropDown() {
		//remove hard-code value and get it from constant file.
		return sessionFactory.getCurrentSession().createQuery(" FROM TagGroupObject where status='A' order by trim (tagGrpNm)").list();
	}
	
	@Override
	public List<TagTypeObject> getAllTagTypeObjectForDropDown() {
		//remove hard-code value and get it from constant file.
		return sessionFactory.getCurrentSession().createQuery(" FROM TagTypeObject where status='A' order by tagTypeDesc").list();
	}

	@Override
	public HashMap<Long, String> getHashmapofTagGrpObject() {
		HashMap<Long, String> hashMapofTagGrp = new HashMap<>();
		List<TagGroupObject> getAllTagGroupObject = sessionFactory.getCurrentSession().createQuery(" FROM TagGroupObject where status='A' order by trim (tagGrpNm)").list();
		for(TagGroupObject tagGroupObject:getAllTagGroupObject) {
			hashMapofTagGrp.put((long)tagGroupObject.getTagGrpId(), tagGroupObject.getTagGrpNm());
		}
		hashMapofTagGrp.values().stream().forEach(System.out::println);
		return hashMapofTagGrp;
	}

	@Override
	public HashMap<Long, String> getHashmapofTagTypeObject() {
		HashMap<Long, String> hashMapofTagType = new HashMap<>();
		List<TagTypeObject> getAllTagTypeObject = sessionFactory.getCurrentSession().createQuery(" FROM TagTypeObject where status='A' order by tagTypeDesc").list();
		for(TagTypeObject tagTypeObject:getAllTagTypeObject) {
			hashMapofTagType.put((long)tagTypeObject.getTagTypeId(), tagTypeObject.getTagTypeDesc());
		}
		hashMapofTagType.values().stream().forEach(System.out::println);
		return hashMapofTagType;
	}
	
	
	

}
