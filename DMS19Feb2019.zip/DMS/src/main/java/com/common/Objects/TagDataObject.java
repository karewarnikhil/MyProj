package com.common.Objects;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity @Table(name="FileTagsData")
public class TagDataObject implements Serializable{

	private static final long serialVersionUID = 1L;
	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name="FTagId",updatable = false, nullable = false)
	    private long fTagId; 
	   
	    @Column(name="FileId") 
	    private long fileId; 
	    
	    @Column(name="Seqno") 
	    private long seqNo; 
	   
	    /*@Column(name="TagGrpId") 
	    private long tagGrpId;*/
	   
	    /*@Column(name="TagId") 
	    private  int tagId ;*/
	    
	    @OneToOne(targetEntity = TagObject.class, fetch = FetchType.EAGER)
		    @JoinColumns({ @JoinColumn(nullable = false, name = "tagGrpId"),
		    			   @JoinColumn(nullable = false, name = "tagId")
		    }
	    )
	    private TagObject tagObject;
	   
	    @Column(name="TagData") 
	    private String tagData;
	    
	    @Column(name = "ListId")
	    private int listId;
	    
	    @Column(name = "ListNo")
	    private int listNo;
	    
	    @Column(name="CreatedBy")
		private long createdBy;
	    
	    @Column(name="CreationDt")
		private Timestamp creationDt;

		public TagDataObject() {
			super();
		}

		public TagDataObject(long fTagId, long fileId, long seqNo, TagObject tagObject, String tagData,
				int listId, int listNo, long createdBy, Timestamp creationDt) {
			super();
			this.fTagId = fTagId;
			this.fileId = fileId;
			this.seqNo = seqNo;
		//	this.tagGrpId = tagGrpId;
			this.tagObject = tagObject;
			this.tagData = tagData;
			this.listId = listId;
			this.listNo = listNo;
			this.createdBy = createdBy;
			this.creationDt = creationDt;
		}

		public long getfTagId() {
			return fTagId;
		}

		public void setfTagId(long fTagId) {
			this.fTagId = fTagId;
		}

		public long getFileId() {
			return fileId;
		}

		public void setFileId(long fileId) {
			this.fileId = fileId;
		}

		public long getSeqNo() {
			return seqNo;
		}

		public void setSeqNo(long seqNo) {
			this.seqNo = seqNo;
		}


		/*public int getTagId() {
			return tagId;
		}

		public void setTagId(int tagId) {
			this.tagId = tagId;
		}*/
		
		public String getTagData() {
			return tagData;
		}

		
		public TagObject getTagObject() {
			return tagObject;
		}

		public void setTagObject(TagObject tagObject) {
			this.tagObject = tagObject;
		}

		public void setTagData(String tagData) {
			this.tagData = tagData;
		}

		public int getListId() {
			return listId;
		}

		public void setListId(int listId) {
			this.listId = listId;
		}

		public int getListNo() {
			return listNo;
		}

		public void setListNo(int listNo) {
			this.listNo = listNo;
		}

		public long getCreatedBy() {
			return createdBy;
		}

		public void setCreatedBy(long createdBy) {
			this.createdBy = createdBy;
		}

		public Timestamp getCreationDt() {
			return creationDt;
		}

		public void setCreationDt(Timestamp creationDt) {
			this.creationDt = creationDt;
		}
		
}
