package com.common.Objects;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.common.CompositeKey.UACCCompositeKey;

@Entity @Table(name="uacc")
public class UACCObject implements Serializable{
	
	
	
	private static final long serialVersionUID = 1L;
    //commented because making composite primary key
	/*@Id
	@Column(name="userid")
	private int userId;
	
	@Id
	@Column(name="mid")
	private int mid;*/
	@EmbeddedId
	private UACCCompositeKey uACCCompositeKey;
	
	@Column(name="aadd")
	private String addFlag;
	
	@Column(name="aupdate")
	private String updateFlag;
	
	@Column(name="adel")
	private String deleteFlag;
	
	@Column(name="aview")
	private String viewFlag;
   
	@Column(name="apass")
	private String passFlag;
	
	@Transient
	private List<Integer> menuIdList;
	
	public UACCObject() {
		
	}

	public UACCObject(UACCCompositeKey uACCCompositeKey, String addFlag, String updateFlag, String deleteFlag,
			String viewFlag, String passFlag, List<Integer> menuIdList) {
		super();
		this.uACCCompositeKey = uACCCompositeKey;
		this.addFlag = addFlag;
		this.updateFlag = updateFlag;
		this.deleteFlag = deleteFlag;
		this.viewFlag = viewFlag;
		this.passFlag = passFlag;
		this.menuIdList = menuIdList;
	}

	public UACCCompositeKey getuACCCompositeKey() {
		return uACCCompositeKey;
	}

	public void setuACCCompositeKey(UACCCompositeKey uACCCompositeKey) {
		this.uACCCompositeKey = uACCCompositeKey;
	}

	public String getAddFlag() {
		return addFlag;
	}

	public void setAddFlag(String addFlag) {
		this.addFlag = addFlag;
	}

	public String getUpdateFlag() {
		return updateFlag;
	}

	public void setUpdateFlag(String updateFlag) {
		this.updateFlag = updateFlag;
	}

	public String getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	public String getViewFlag() {
		return viewFlag;
	}

	public void setViewFlag(String viewFlag) {
		this.viewFlag = viewFlag;
	}

	public String getPassFlag() {
		return passFlag;
	}

	public void setPassFlag(String passFlag) {
		this.passFlag = passFlag;
	}

	public List<Integer> getMenuIdList() {
		return menuIdList;
	}

	public void setMenuIdList(List<Integer> menuIdList) {
		this.menuIdList = menuIdList;
	}
	
}
