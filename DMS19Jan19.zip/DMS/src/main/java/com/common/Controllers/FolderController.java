package com.common.Controllers;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.common.Dao.DepartmentDao;
import com.common.Dao.FolderDao;
import com.common.Dao.HisFolderDao;
import com.common.Objects.FolderObject;
import com.common.Objects.HisFolder;
import com.common.Objects.UsersObject;

@Controller
public class FolderController {
	   
	   @Autowired
	   FolderDao folderDao;
	   
	   @Autowired
	   DepartmentDao departmentDao;
	   
	   @Autowired
	   HisFolderDao hisFolderDao;
	
	  /* @RequestMapping(value = "/", method = RequestMethod.GET)
	   public String showClassForm(Model model){  
		   FolderObject folderObject = new FolderObject();
	       model.addAttribute("folder", folderObject);
	       return "registerClass"; 
	   } */
	
	  /* @RequestMapping(value = "/saveFolder", method = RequestMethod.POST)
	   public String saveClassData(@ModelAttribute("folder") FolderObject folderObject, BindingResult result){
		   Date date = new Date();  
	       Timestamp ts = new Timestamp(date.getTime());  
	       folderObject.setCreationDt(ts);
	       folderDao.saveFolderObject(folderObject);
	       return "redirect:/manageFolder"; 
	   }  
	   
	   @RequestMapping(value="/manageFolder", method = RequestMethod.GET)  
	   public ModelAndView manageFolder(){  
		   List<FolderObject> folderlist = folderDao.getAllFolders(); 
	       return new ModelAndView("manageFolder","folderlist",folderlist);  
	   } 
	   */
	   
	   @RequestMapping(value ="/defaultPage", method = RequestMethod.GET)
		public ModelAndView getDefaultPage() {
		      //List<FolderObject> folderlist = folderDao.getParentFolderList();
		      //return new ModelAndView("defaultPage","folderlist",folderlist); 
			  return new ModelAndView("defaultPage");  
		}
	  //need to check afterwards
	   @RequestMapping(value = "/loadChildFolders", method = RequestMethod.GET, produces = "application/json")
	   public @ResponseBody List<FolderObject> loadChildFolder(@RequestParam("id") long rootId, Model model) {
		     List<FolderObject> folderlist = folderDao.getParentFolderList();
		     return folderlist;
		}
	   
	   @RequestMapping(value = "/loadFoldersById", method = RequestMethod.GET, produces = "application/json")
	   public @ResponseBody List<FolderObject> loadFoldersById(@RequestParam("id") long rootId, Model model,HttpServletRequest request) {
		     HttpSession session = request.getSession();
		     UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		     List<FolderObject> folderlist = null;
		     if(usersSessionObject.getUserlevel() > 0)
		    	 folderlist = folderDao.getAllFoldersByRootId(rootId,usersSessionObject.getDepartmentObject().getDeptId());
		     else
		    	 folderlist = folderDao.getParentFolderList();
		     return folderlist;
		}
	  
	   /* 
	   @RequestMapping(value="/editFolder", method = RequestMethod.GET)  
	   public ModelAndView editFolder(@RequestParam("folderId") Integer folderId){  
		   FolderObject folderObject = findByFolderId(folderId);
	       return new ModelAndView("editFolder","folder",folderObject);  
	   }  
	   
	   
	 @RequestMapping(value="/deleteFolder", method = RequestMethod.GET)  
	   public String deleteFolder(@RequestParam("FolderId") Integer folderId,Model model){  
		   FolderObject folderObject = findByFolderId(folderId);
		   folderDao.deleteFolderObject(folderObject);
	       return "redirect:/manageFolder";//will redirect to viewemp request mapping  
	   }  */
	   
	  /* private FolderObject findByFolderId(Integer folderId) {
		   FolderObject folderObject =  folderDao.getFolderById(folderId); 
		   return folderObject;
	   }*/
	   
	   @RequestMapping(value = "/getFolderAttributes", method = RequestMethod.POST, produces = "application/json")
	   public @ResponseBody FolderObject getFolderAttributes(@RequestParam("folderId") long folderId, Model model) {
		     FolderObject folderObject =  folderDao.getFolderByIdForDefault(folderId); 
		     return folderObject;
		}
	   @RequestMapping(value = "/getFolderPath", method = RequestMethod.GET, produces = "application/json")
	   public @ResponseBody FolderObject getFolderPath(@RequestParam("folderId") int folderId) {
		   FolderObject folderObject =  folderDao.getFolderById(folderId); 
		   return folderObject;
		}
	  /* @RequestMapping(value = "/createFolder", method = RequestMethod.GET)
		public String getCreateFolderForm(Model model, @RequestParam("folderid") int folderId,
				@RequestParam("rootid") int rootid, HttpServletRequest request) {
			UsersObject usersSess = (UsersObject) request.getSession().getAttribute("users");
			model.addAttribute("folderId", folderId);
			model.addAttribute("rootid", rootid);
			model.addAttribute("rootFolder", folderDao.getFolderById(folderId));
			model.addAttribute("ClassFolder", folderDao.getClassFolder(rootid));
			model.addAttribute("userlevel", usersSess.getUserlevel());
			//Check User level 
			if(usersSess.getUserlevel()==0) {
				model.addAttribute("departmentList", departmentDao.getAllDepartments());
				}
				else {
					model.addAttribute("department", departmentDao.getDepartmentById(usersSess.getDepartmentObject().getDeptId()));
				}
			model.addAttribute("Folder", new FolderObject());
			model.addAttribute("pageName", "Create Folder");
			return "createFolder";
		}
*/
	   //need to check follwing all code
	   @RequestMapping(value = "/createFolder", method = RequestMethod.GET)
	 		public String getCreateFolderForm(Model model, @RequestParam("folderIdRootId") String folderIdRootId,HttpServletRequest request) {
	 			UsersObject usersSess = (UsersObject) request.getSession().getAttribute("users");
	 			String[] folderRootId = folderIdRootId.split("~");
	 			int folderId = Integer.parseInt(folderRootId[0]);
	 			int rootId = Integer.parseInt(folderRootId[1]);
	 			model.addAttribute("folderId", folderId);
	 			model.addAttribute("rootid", rootId);
	 			model.addAttribute("rootFolder", folderDao.getFolderById(folderId));
	 			model.addAttribute("ClassFolder", folderDao.getClassFolder(rootId));
	 			model.addAttribute("userlevel", usersSess.getUserlevel());
	 			if(usersSess.getUserlevel()==0) {
	 				model.addAttribute("departmentList", departmentDao.getAllDepartmentsForAddUser());
	 			}
 				else {
 					//model.addAttribute("department", departmentDao.getDepartmentById(usersSess.getDepartmentObject().getDeptId()));
 					model.addAttribute("department", usersSess.getDepartmentObject());
 				}
	 			model.addAttribute("Folder", new FolderObject());
	 			model.addAttribute("pageName", "Create Folder");
	 			return "createFolder";
	 		}
	   
		@RequestMapping(value = "/saveFolders", method = RequestMethod.POST)
		public String saveFolders(Model model, @RequestParam("folderId") int folderId, @RequestParam("rootId") int rootId,
			@ModelAttribute("folder") FolderObject folders, HttpServletRequest request) {
			UsersObject usersSess = (UsersObject) request.getSession().getAttribute("users");
			if (usersSess != null) {
				if (rootId == 0) {
					folders.setParentId(folderId);
					folders.setRootId(folderId);
				} else {
					folders.setParentId(folderId);
					folders.setRootId(rootId);
				}
				//String path = folderDao.getPath(folderId);
				//String location = folderDao.getLocation(folderId);
				//System.out.println(locat+" :::  "+path);
				FolderObject folderClassObject= folderDao.getClassFolder(folderId);
				folders.setFolderPath(folderClassObject.getFolderPath()+"/"+folders.getFolderNm());
				folders.setLocation(folderClassObject.getLocation());
				folders.setRmk(folders.getRmk());
				folders.setFolderNm(folders.getFolderNm());
				folders.setIsInnerFolders(folders.getIsInnerFolders());
				//need to remove following hardcoding
				folders.setFolderCnt(0);
				folders.setFileCnt(0);
				folders.setAtriBt("A");
				folders.setReadOnlyOthDept(folders.getReadOnlyOthDept());
				folders.setReadOnlyPublic(folders.getReadOnlyPublic());
				//folders.usetCreatedBy(usersSess.getUserId());
				folders.setUsersObject(usersSess);
				folders.setCreationDt(new Timestamp(new Date().getTime()));
				folderDao.saveFolders(folders);
				
				folderClassObject.setFolderCnt(folderClassObject.getFolderCnt()+1);
				folderDao.updateFolderObject(folderClassObject);
				return "defaultPage";
			} else {
				return "redirect:login";
			}
		}

	/*	@RequestMapping(value = "/updateFolder", method = RequestMethod.POST)
		public String getUpdateFolderForm(Model model, @RequestParam("folderid") int folderId,
				@RequestParam("rootid") int rootid, HttpServletRequest request) {
			HttpSession session = request.getSession();
			UsersObject usersSess = (UsersObject) session.getAttribute("users");
			if (usersSess != null) {
			model.addAttribute("folderId", folderId);
			model.addAttribute("rootid", rootid);
			model.addAttribute("Folder", folderDao.getFolderById(folderId));
			model.addAttribute("ClassFolder", folderDao.getClassFolder(rootid));
			model.addAttribute("pageName", "Update Folder");
			return "editFolder";
			}
			else {
				return "redirect:login";
			}
		}*/
		
		@RequestMapping(value = "/updateFolder", method = RequestMethod.GET)
		public String getUpdateFolderForm(Model model, @RequestParam("folderIdRootId") String folderIdRootId,
				 HttpServletRequest request) {
			HttpSession session = request.getSession();
			UsersObject usersSess = (UsersObject) session.getAttribute("users");
			String[] folderRootId = folderIdRootId.split("~");
			int folderId = Integer.parseInt(folderRootId[0]);
			int rootId = Integer.parseInt(folderRootId[1]);
			if (usersSess != null) {
				model.addAttribute("folderId", folderId);
				model.addAttribute("rootid", rootId);
				model.addAttribute("folder", folderDao.getFolderById(folderId));
				model.addAttribute("classFolder", folderDao.getClassFolder(rootId));
				model.addAttribute("pageName", "Update Folder");
				return "editFolder";
			}
			else {
				return "redirect:login";
			}
		}
		
		//need to change filelocation and path 
		//try to eliminate call for folderObject for update
		@RequestMapping(value = "/updateFolderName", method = RequestMethod.POST)
		public String updateFolders(Model model, @ModelAttribute("folder") FolderObject folders,@RequestParam("folderPathNm") String folderPathNm, HttpServletRequest request) {
			UsersObject usersSess = (UsersObject) request.getSession().getAttribute("users");
			if (usersSess != null) {
				//try to remove this impl call
				/*FolderObject folder= folderDao.getFolderById(folderId);
				folder.setFolderNm(folderNm);
				folder.setAtriBt(folders.getAtriBt());
				folder.setReadOnlyPublic(folders.getReadOnlyPublic());
				folder.setReadOnlyOthDept(folders.getReadOnlyOthDept());
				folder.setIsInnerFolders(folders.getIsInnerFolders());*/
				if(!(folders.getFolderNm().equals(folderPathNm))) {
					String path = folderDao.getPath((int) folders.getFolderId());
					//System.out.println(path);
					//used file separator class
					path= path+"/"+folders.getFolderNm();
					folders.setFolderPath(path);
				}		
				//String locat=folderDao.getLocation(folderId);
			//	System.out.println(locat+" :::  "+path);
				//folder.setFolderPath(path);
				//folder.setLocation(locat);
				/*System.out.println(folders.getFolderPath());
				int folderNmLength = folderPathNm.length();
				String folderPath = folders.getFolderPath().substring(0, (folders.getFolderPath().length()-folderNmLength));
			
				
				folderPath = folderPath+folders.getFolderNm();
				System.out.println(folderPath);
				folders.setFolderPath(folderPath);*/
				//folders.setFolderPath(folders.getFolderPath().replaceAll(folderPathNm, folders.getFolderNm()));
				folderDao.updateFolderName(folders);
				
				HisFolder hisFolder = new HisFolder();
				hisFolder.setFolderId(folders.getFolderId());
				hisFolder.setFolderNm(folders.getFolderNm());
				hisFolder.setIsInnerFolder(folders.getIsInnerFolders());
				hisFolder.setAtriBt(folders.getAtriBt());
				hisFolder.setReadOnlyOthDept(folders.getReadOnlyOthDept());
				hisFolder.setReadOnlyPublic(folders.getReadOnlyPublic());
			    hisFolder.setCreatedBy(usersSess.getUserId()); 
			    hisFolder.setCreationDt(new Timestamp(new Date().getTime()));
			    
			    hisFolderDao.saveHistory(hisFolder);
			    
				return "defaultPage";
			} else {

				return "redirect:login";
			}
		}
}
