package com.common.Controllers;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.common.Dao.DepartmentDao;
import com.common.Dao.DocumentDao;
import com.common.Dao.MessageDao;
import com.common.Dao.UsersDao;
import com.common.Objects.DocumentObject;
import com.common.Objects.MessageObject;
import com.common.Objects.UsersObject;


@Controller
public class MessageController {
	
	@Autowired
	private UsersDao usersDao;
	
	@Autowired
	private MessageDao messageDao;
	
	@Autowired
	private DocumentDao documentDao;
	
	@Autowired
	private DepartmentDao departmentDao;
	
	@Autowired
	ServletContext context;
	
	@RequestMapping(value = "/sendMessage", method = RequestMethod.GET)
    public String sendMessage(Model model,@RequestParam("fileId") long fileId,@RequestParam("seqNo") long seqNo){  
	   DocumentObject documentObject = documentDao.getFileByFileIdAndSeqNo(fileId, seqNo);
	   MessageObject messageObject = new MessageObject();
	   messageObject.setFileId(fileId+"~"+seqNo);
	   List<UsersObject> usersList = usersDao.getAllUsersForMenu();
	  // model.addAttribute("departmentList", departmentDao.getAllDepartmentsForAddUser());
	   model.addAttribute("documentObject", documentObject);
	   model.addAttribute("usersList", usersList);
       model.addAttribute("messageObject", messageObject);
       return "sendMessage"; 
    } 
	
	@RequestMapping(value = "/sendMultipleFiles", method = RequestMethod.GET)
    public String sendMultipleFiles(Model model){  
	   MessageObject messageObject = new MessageObject();
	   List<UsersObject> usersList = usersDao.getAllUsersForMenu();
	   //model.addAttribute("departmentList", departmentDao.getAllDepartmentsForAddUser());
	 //  model.addAttribute("documentObject", documentObject);
	   model.addAttribute("usersList", usersList);
       model.addAttribute("messageObject", messageObject);
       return "sendMultiple"; 
    } 
	
	
	 @RequestMapping(value = "/saveMessage", method = RequestMethod.POST)
	   public String saveSendMessageData(@ModelAttribute("messageObject") MessageObject messageObject, Model model, HttpServletRequest request){
		   UsersObject usersSess = (UsersObject) request.getSession().getAttribute("users");
		   Date date = new Date();  
	       Timestamp ts = new Timestamp(date.getTime());  
	       String messageToStr = "~";
	       if(messageObject.getMessageToList() != null) {
		       for(long messageTo:messageObject.getMessageToList()) {
		    	   messageToStr += messageTo+"~";
		       }
	       }
	       messageObject.setCreationDt(ts);
	       messageObject.setMessageTo(messageToStr);
	       messageObject.setReadStatus("N");
	       messageObject.setMessageFrom(usersSess.getUserId());
	       messageDao.saveMessageObject(messageObject);
	   	   long messageCount = messageDao.getUserMessageCount(usersSess.getUserId().toString());
	   	   usersSess.setMessageCount(messageCount);
		   model.addAttribute("messageObject", messageObject);
		   model.addAttribute("message", "Message Send Successfully.");
	       return "defaultPage"; 
	   }  
	 
	 @RequestMapping(value = "/receivedMessage", method = RequestMethod.GET)
	    public String receivedMessage(Model model,HttpServletRequest request){  
		   UsersObject usersSess = (UsersObject) request.getSession().getAttribute("users");
		   long messageCount = messageDao.getUserMessageCount(usersSess.getUserId().toString());
	   	   usersSess.setMessageCount(messageCount);
		   List<MessageObject> messageList = messageDao.getMessages(usersSess.getUserId().toString());
		   model.addAttribute("messageList", messageList);
	       return "manageMessage"; 
	    } 
	 
	 @RequestMapping(value = "/replyToMessage", method = RequestMethod.POST)
	    public String replyToMessage(Model model,@ModelAttribute("messageObject") MessageObject messageObject,HttpServletRequest request){ 
		   MessageObject messageObject2 = new MessageObject();
		   //messageObject2.setFileNm(messageObject.getFileNm());
		   //messageObject2.setMessageFrom(messageObject.getMessageTo());
		   //messageObject2.setMessageTo(messageObject.getMessageFrom());
	       model.addAttribute("messageObject", messageObject2);
	       return "sendReply"; 
	    } 
	 
	 @RequestMapping(value="/displayMessage", method = RequestMethod.GET)  
	   public ModelAndView displayMessage(@RequestParam("messageId") long messageId,HttpServletRequest request){ 
		   UsersObject usersSess = (UsersObject) request.getSession().getAttribute("users");
		   usersSess.setMessageCount(usersSess.getMessageCount()-1);
		   MessageObject messageObject = findByMessageId(messageId);
		   if(messageObject.getReadStatus().equals("N")) {
			   messageObject.setReadStatus("Y");
			   messageDao.saveMessageObject(messageObject);
		   }
		   /*//DocumentObject documentObject = documentDao.findByFileName(messageObject.getFileNm());
		   //String filePath = context.getRealPath("/")+"resources\\upload\\"+messageObject.getFileNm();
	        try {           
		           // File file = new File(filePath);
		          //  if(file.exists() == false) {
		          //  BufferedOutputStream stream =  new BufferedOutputStream(new FileOutputStream(file));
		          //  byte[] bytes = documentObject.getFileContent();
		          //  stream.write(bytes);
		          //  stream.close();
		          //  stream.flush();
		           // System.out.println("You have uploaded file");
		          //  System.out.println(filePath);
		          //  file.deleteOnExit();
	           // }
	        } catch (Exception e) {
	          //System.out.println("Failed to upload");
	        	e.printStackTrace();
	        }*/
	        
	       return new ModelAndView("displayMessage","messageObject",messageObject);  
	   }  
	 
	 private MessageObject findByMessageId(long messageId) {
		   MessageObject messageObject =  messageDao.getMessageById(messageId); 
		   return messageObject;
	 }

}
