package com.common.Dao;

import java.util.List;

import com.common.Objects.DepartmentObject;

public interface DepartmentDao {
	 public	void saveDepartmentObject(DepartmentObject departmentObject);

	 public List<DepartmentObject> getAllDepartments();

	 public DepartmentObject getDepartmentById(Integer departmentId);
	 
	 //public UsersObject getUsersByUserName(String userName);

	 //public void deleteDepartmentObject(DepartmentObject departmentObject);
	 
	 public List<DepartmentObject> getAllDepartmentsForAddUser();
}
