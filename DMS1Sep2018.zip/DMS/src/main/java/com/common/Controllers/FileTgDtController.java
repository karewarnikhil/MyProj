package com.common.Controllers;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.common.Dao.FileTgDataDao;
import com.common.Dao.ListDataDao;
import com.common.Dao.TagDao;
import com.common.Objects.DepartmentObject;
import com.common.Objects.DocumentObject;
import com.common.Objects.ListDataObj;
import com.common.Objects.ListObject;
import com.common.Objects.TagDataObject;
import com.common.Objects.TagGroupObject;
import com.common.Objects.TagObject;
import com.common.Objects.TagTypeObject;
import com.common.Objects.UsersObject;

@Controller
public class FileTgDtController {
	
	@Autowired
	TagDao tagDao;
	
	@Autowired
	ListDataDao listDataDao;
	
	@Autowired
	FileTgDataDao fileTgDataDao;
	
	@RequestMapping(value="/getTagData", method = RequestMethod.POST)  
	   public String changeUACCForm(@RequestParam("tagGrpId") long tagGrpId,Model model,HttpServletRequest request){ 
		   HttpSession session = request.getSession();
		   List<TagObject> tagObjectlist = tagDao.getTagData(tagGrpId);
		   for(TagObject tagObject:tagObjectlist) {
				if(tagObject.getListObject().getListId() > 0) {
					 List<ListDataObj> listDataObject = (List<ListDataObj>) listDataDao.getListDataByListId(tagObject.getListObject().getListId());
					 tagObject.setListDataObjs(listDataObject);
				}
			}
	       model.addAttribute("selectedtagGrpId", tagGrpId);
	       session.setAttribute("tagObjectlist", tagObjectlist);
	       //model.addAttribute();
	       //model.addAttribute("data", new TagDataObject());
	       return "fileDisplay";
	}  
	
	 @RequestMapping(value = "/saveTagData", method = RequestMethod.POST)
	   public String saveTagData(HttpServletRequest request,Model model){ 
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   
		  
		 
		   DocumentObject documentObject = (DocumentObject) session.getAttribute("documentObject");
		   List<TagObject> tagObjectlist = (List<TagObject>) session.getAttribute("tagObjectlist");
		   long tagGrpId = Long.parseLong(request.getParameter("tagGrpId"));
		   Date date = new Date();  
	       Timestamp ts = new Timestamp(date.getTime());  
	       List<TagDataObject> listOfTagData = new ArrayList();
		   for(TagObject tagObject:tagObjectlist) {
			  int value =  tagObject.getTagId();
			  String tag = value+" ";
			  String tagData = request.getParameter(tag);
			  System.out.println(tagData.isEmpty() + tagObject.getIsMandatory());
			 
			  if((tagData.isEmpty()) && (tagObject.getIsMandatory().equals("Y"))) {
					  model.addAttribute("selectedtagGrpId", tagGrpId);
					  request.setAttribute("error", "Mandatory Fields are required.");
					  return "fileDisplay";
			  }
			  else if(!(tagData.isEmpty()) || (tagData == "0")) {
				  TagDataObject tagDataObject = new TagDataObject();
				  ListObject listObject = tagObject.getListObject();
				  tagDataObject.setCreatedBy(usersSessionObject.getUserId());
				  tagDataObject.setCreationDt(ts);
				  tagDataObject.setFileId(documentObject.getFileId());
				  tagDataObject.setSeqNo(documentObject.getSeqNo());
				  tagDataObject.setTagGrpId(tagGrpId);
				  //tagDataObject.setTagId(tagObject.getTagId());
				  tagDataObject.setTagObject(tagObject);
				 
				  tagDataObject.setTagData(tagData);
				  
				  tagDataObject.setListId(listObject.getListId());
				  if(listObject.getListId() == 0)
					  tagDataObject.setListNo(listObject.getListId());
				  else {
					  tagData = tagData.trim();
					  int valueOne = Integer.parseInt(tagData);
					  tagDataObject.setListNo(valueOne);
				  }
				  
				  listOfTagData.add(tagDataObject);
				  fileTgDataDao.saveFileTagData(listOfTagData);
						 
			  } 
				  
			  }
		   session.removeAttribute("tagObjectlist");
		   return "redirect:/dispalyFile?fileId="+documentObject.getFileId(); 
	   }  
	 
	 @RequestMapping(value="/manageFileTgDt", method = RequestMethod.GET)  
	   public ModelAndView manageDepartment(@RequestParam("fileId") long fileId,Model model){  
		   //List<TagDataObject> tagDataList = fileTgDataDao.getAllTagDataByFileId(fileId); 
		   List<TagGroupObject> tagGroupList = fileTgDataDao.getAllTagGrpByFileId(fileId); 
		   model.addAttribute("fileId", fileId);
	       return new ModelAndView("manageFileTgData","tagGroupList",tagGroupList);  
	 }  
	 
	 @RequestMapping(value="/getFileTgData", method = RequestMethod.POST)  
	   public ModelAndView getFileTgData(@RequestParam("fileId") long fileId,@RequestParam("tagGrpId") long tagGrpId){  
		   List<TagDataObject> tagDataList = fileTgDataDao.getAllTagDataByFileId(fileId,tagGrpId); 
	       return new ModelAndView("manageFileTgData","tagDataList",tagDataList);  
	 }  
	 
	 @RequestMapping(value="/editTagData", method = RequestMethod.GET)  
	   public String editTagData(@RequestParam("fTagId") long fTagId,Model model){  
		   TagDataObject tagDataObject = findByfTagId(fTagId);
		   TagObject tagObject = tagDataObject.getTagObject();
		   List<ListDataObj> listDataObject = (List<ListDataObj>) listDataDao.getListDataByListId(tagObject.getListObject().getListId());
		   tagObject.setListDataObjs(listDataObject);
		   model.addAttribute("tagDataObject",tagDataObject);
		   return "editTagData";
	   } 
	 
	 @RequestMapping(value = "/updateTagData", method = RequestMethod.POST)
	   public String updateTagData(@ModelAttribute("tagDataObject") TagDataObject tagDataObject, BindingResult result){
		
		   if(tagDataObject.getSeqNo() > 0) {
			   tagDataObject.setTagData(tagDataObject.getSeqNo()+"");
		   }
		   
		   fileTgDataDao.saveFileTagData(tagDataObject);
	       return "redirect:/manageFileTgDt?fileId="+tagDataObject.getFileId(); 
	   }  
	 
	 private TagDataObject findByfTagId(long fTagId) {
		   TagDataObject tagDataObject =  fileTgDataDao.getTagDataById(fTagId); 
		   return tagDataObject;
	   }
	 

 }
