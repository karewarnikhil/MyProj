package com.common.Dao;

import java.util.List;

import com.common.Objects.TagDataObject;
import com.common.Objects.TagGroupObject;

public interface FileTgDataDao {
	public	void saveFileTagData( List<TagDataObject> listOfTagData);

	public List<TagDataObject> getAllTagDataByFileId(long fileId,long grpTg);

	public List<TagGroupObject> getAllTagGrpByFileId(long fileId);

	public TagDataObject getTagDataById(long fTagId);

	public void saveFileTagData(TagDataObject tagDataObject);

}
