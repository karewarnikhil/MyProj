package com.common.Dao;

import java.util.List;

import com.common.Objects.ListObject;;

public interface ListDao {
  
	public void save(ListObject list);

	public List<ListObject> getAllList();

	public ListObject getListObjById(int listId);

	public void update(ListObject listObj);

	public ListObject getByListName(String listName);
}
