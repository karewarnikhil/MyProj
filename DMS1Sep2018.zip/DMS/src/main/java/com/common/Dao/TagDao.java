package com.common.Dao;

import java.util.List;

import com.common.Objects.TagGroupObject;
import com.common.Objects.TagObject;

public interface TagDao {
	 
	 public	void saveTagObject(TagObject tagObject);

	 public List<TagObject> getAllTagObject();

	 public TagObject getTagById(Integer tagId);
	 
	 public List<TagGroupObject> getAllTagsForFileDisplay(long rootId);
	 
	 public int getMaxValueId(long tagGrpValue);

	public List<TagObject> getTagData(long tagGrpId);
	 
}
