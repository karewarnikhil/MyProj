package com.common.Objects;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity @Table(name="FileMst")
public class DocumentObject implements Serializable{
	
	private static final long serialVersionUID = 1L;

	    @Id
	    @Column(name="fileid",updatable = false, nullable = false)
	    private long fileId; 
	   
	    @Column(name="Seqno") 
	    private long seqNo; 
	    
	    @Column(name = "folderid")
	    private long folderId;
	    
	    @Column(name = "rootid")
	    private long rootId;
	    
	    @Column(name="filenm")
	    private String fileName;
	    
	    @Column(name="filecontents")
	    private byte[] fileContent;
	     
	    @Column(name="FileExtn")
	    private String fileExtn;
	    
	    @Column(name="Atribt")
		private String atriBt;
	    
	    @Column(name="CreatedBy")
		private long createdBy;
	    
	    @Column(name="CreationDt")
		private Timestamp creationDt;
	     
	    @Column(name="modifiedby")
		private long modifiedBy;
	   
	    @Column(name="ModificationDt")
		private Timestamp modificationDt;
	   
	    @Column(name="PageCnt") 
	    private int pageCnt; 
	    
	    @Column(name="FilePath")
	    private String filePath;
	    
	    @Column(name="FileLocation ")
	    private String fileLocation;
	    
	    @Column(name="TagStatus ")
	    private String tagStatus;
	    
	    @Transient
	    private String extensionIcon;
	    
	    
		public String getExtensionIcon() {
			return extensionIcon;
		}

		public void setExtensionIcon(String extensionIcon) {
			this.extensionIcon = extensionIcon;
		}

		public DocumentObject() {
			super();
		}

		public DocumentObject(long fileId, long seqNo, long folderId, long rootId, String fileName, byte[] fileContent,
				String fileExtn, String atriBt, long createdBy, Timestamp creationDt, long modifiedBy,
				Timestamp modificationDt, int pageCnt, String filePath, String fileLocation, String tagStatus,
				String extensionIcon) {
			super();
			this.fileId = fileId;
			this.seqNo = seqNo;
			this.folderId = folderId;
			this.rootId = rootId;
			this.fileName = fileName;
			this.fileContent = fileContent;
			this.fileExtn = fileExtn;
			this.atriBt = atriBt;
			this.createdBy = createdBy;
			this.creationDt = creationDt;
			this.modifiedBy = modifiedBy;
			this.modificationDt = modificationDt;
			this.pageCnt = pageCnt;
			this.filePath = filePath;
			this.fileLocation = fileLocation;
			this.tagStatus = tagStatus;
			this.extensionIcon = extensionIcon;
		}

		public long getFileId() {
			return fileId;
		}


		public void setFileId(long fileId) {
			this.fileId = fileId;
		}


		public long getSeqNo() {
			return seqNo;
		}


		public void setSeqNo(long seqNo) {
			this.seqNo = seqNo;
		}


		public long getFolderId() {
			return folderId;
		}


		public void setFolderId(long folderId) {
			this.folderId = folderId;
		}


		public long getRootId() {
			return rootId;
		}


		public void setRootId(long rootId) {
			this.rootId = rootId;
		}


		public String getFileName() {
			return fileName;
		}


		public void setFileName(String fileName) {
			this.fileName = fileName;
		}


		public byte[] getFileContent() {
			return fileContent;
		}


		public void setFileContent(byte[] fileContent) {
			this.fileContent = fileContent;
		}


		public String getFileExtn() {
			return fileExtn;
		}


		public void setFileExtn(String fileExtn) {
			this.fileExtn = fileExtn;
		}


		public String getAtriBt() {
			return atriBt;
		}


		public void setAtriBt(String atriBt) {
			this.atriBt = atriBt;
		}


		public long getCreatedBy() {
			return createdBy;
		}


		public void setCreatedBy(long createdBy) {
			this.createdBy = createdBy;
		}


		public Timestamp getCreationDt() {
			return creationDt;
		}


		public void setCreationDt(Timestamp creationDt) {
			this.creationDt = creationDt;
		}


		public long getModifiedBy() {
			return modifiedBy;
		}


		public void setModifiedBy(long modifiedBy) {
			this.modifiedBy = modifiedBy;
		}


		public Timestamp getModificationDt() {
			return modificationDt;
		}


		public void setModificationDt(Timestamp modificationDt) {
			this.modificationDt = modificationDt;
		}


		public int getPageCnt() {
			return pageCnt;
		}


		public void setPageCnt(int pageCnt) {
			this.pageCnt = pageCnt;
		}


		public String getFilePath() {
			return filePath;
		}


		public void setFilePath(String filePath) {
			this.filePath = filePath;
		}


		public String getFileLocation() {
			return fileLocation;
		}


		public void setFileLocation(String fileLocation) {
			this.fileLocation = fileLocation;
		}


		public String getTagStatus() {
			return tagStatus;
		}


		public void setTagStatus(String tagStatus) {
			this.tagStatus = tagStatus;
		}

		
        
		
		

		

}
