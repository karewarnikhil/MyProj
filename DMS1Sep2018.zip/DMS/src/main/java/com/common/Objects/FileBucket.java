package com.common.Objects;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

public class FileBucket {
	
	private List<MultipartFile> listOfMultipartFile;

	public List<MultipartFile> getListOfMultipartFile() {
		return listOfMultipartFile;
	}

	public void setListOfMultipartFile(List<MultipartFile> listOfMultipartFile) {
		this.listOfMultipartFile = listOfMultipartFile;
	}

}
