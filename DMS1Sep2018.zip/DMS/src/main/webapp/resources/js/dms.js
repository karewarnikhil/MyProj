$(document).ready(function(){
		  $('.dropdown-submenu a.test').on("click", function(e){
		    $(this).next('ul').toggle();
		    e.stopPropagation();
		    e.preventDefault();
		  });
		});
		
		
 (function($){
		$('.dropdown-menu a.dropdown-toggle').on('click', function(e) {
		  if (!$(this).next().hasClass('show')) {
			$(this).parents('.dropdown-menu').first().find('.show').removeClass("show");
		  }
		  var $subMenu = $(this).next(".dropdown-menu");
		  $subMenu.toggleClass('show');

		  $(this).parents('li.nav-item.dropdown.show').on('hidden.bs.dropdown', function(e) {
			$('.dropdown-submenu .show').removeClass("show");
		  });

		  return false;
		});
	})(jQuery)

function validateForm(formObject){
	 var userId = document.getElementById("userId").value;
	 //alert(userId);
	 //alert(formObject);
	 if(userId>0){
		 var action = formObject.action; 
		 formObject.action = 'changeUACC?userId='+userId;
		 action = formObject.action ;
		 //alert(action);
		 formObject.submit();
	 }
	 else{
		 return false;
	 } 
	
 }
 
 function getTagData(formObject){
	 var tagGrpId = document.getElementById("tagGrpId").value;
	 //alert(userId);
	 //alert(formObject);
	 if(tagGrpId>0){
		 var action = formObject.action; 
		 formObject.action = 'getTagData?tagGrpId='+tagGrpId;
		 action = formObject.action ;
		 //alert(action);
		 formObject.submit();
	 }
	 else{
		 return false;
	 } 
	
 }
 
 function getTagDataForManage(formObject){
	 var tagGrpId = document.getElementById("tagGrpId").value;
	 var fileId = document.getElementById("fileId").value;
	 //alert(tagGrpId);
	 //alert(fileId);
	 if(tagGrpId>0){
		 var action = formObject.action; 
		 formObject.action = 'getFileTgData?tagGrpId='+tagGrpId+'&fileId='+fileId;
		 action = formObject.action ;
		 //alert(action);
		 formObject.submit();
	 }
	 else{
		 return false;
	 } 
	
 }
 
 
 function deleteRecord(formObject){
	 var userId = document.getElementById("userId").value;
	 //alert(userId);
	 //alert(formObject);
	 if(userId>0){
		 var action = formObject.action; 
		 formObject.action = 'deleteFormUACCObject?userId='+userId;
		 action = formObject.action ;
		 //alert(action);
		 formObject.submit();
	 }
	 else{
		 return false;
	 } 
	
 }
 
 
 function accessFunction(link,accessVariable){
	// alert(accessVariable);
	// alert(link);
	 if(accessVariable == false){
		 alert("You Dont have authorize to do this functionality.");
		 return false;
	 }
	 else{
		 window.location.href = link;
		 //alert("aaaaa");
	 } 
 }
 

// rnd for mouse events
function whichButton(event,linkEdit,linkShow) {
	// alert("You pressed button: " + event.button)
	 if(event.button == 0){
		 window.location.href = linkEdit;
	 }
	 if(event.button == 2){
		 window.open(''+linkShow,'mywin',
		 'left=100, top=400, screenX=200, screenY=150,width=400,height=300,toolbar=1,resizable=0');
	 }
 }
 
 function storageTypeChange(type) {
	 var storageType = type;
	 if(storageType == 'DTBS'){
		 document.getElementById('driveNm').disabled = true;
	 }
	 if(storageType == 'DISC'){
		 document.getElementById('driveNm').disabled = false;
	 }
	 
 }
 
 function validateTagData(evt,tagTypeId,tagId) {
	 
	
	 if(tagTypeId==1 || tagTypeId==2){
		 //alert(tagTypeId);
		 $("#"+tagId).keypress(function (e) {
			 //alert(tagTypeId);
			     if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
			 		$("."+tagId).html("Digits Only.").show().delay(2000).fadeOut("slow"); 
			        return false;
			    }
			   });
	        }
	 else if(tagTypeId==5){
		 $("#"+tagId).keypress(function (e){
				if((e.which >=65 && e.which <=90) || (e.which>=97 && e.which<=122)){
		  return true
		}
		else{
			 $("."+tagId).html("Alphabets Only.").show().delay(2000).fadeOut("slow");
               return false;
		}
	  });
	}
     /*var iKeyCode = (evt.which) ? evt.which : evt.keyCode
     if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
         return false;

     return true;*/
 }    
 
 
 	/*function loadSubFoldersForDropDown(folderId) {
	 $.ajax({
			contentType : "application/json; charset=utf-8",
			dataType : "json",
			url : "loadFoldersById",
			type : 'GET',
			data : {
				id : folderId
			},
			success : function(response) {
				alert("Folder in");
				 $(".submitEnd").prepend("<div class='form-group row'>"+
		                    "<label class='col-md-3 control-lable'>Select Folder:</label>"+
		                    "<div class='col-md-7'>"+
		                    "<f:select path='folderId' id='folderId' class='form-control'  onchange='loadSubFoldersForDropDown(0)'></f:select> </div></div> ");
		    if(response.length > 0){            
		    for (i = 0; i < response.length; i++) {
		    	var rootId=response[i].rootId
		    	if(folderId == rootId){
		    		 $(".folderId").append("<f:option value='0'>--Select--</f:option>"+
                 "<f:option  value="+response[i].folderId+" label="+response[i].folderNm+"/>");
		    	}
          }
			}
			else{
	    		alert("Not Containing folder.");
	    	}
		    },
			error : function(res, textStatus) {
				var msg = "Unable to load Subfolder";
				alert(msg);
			}
		});
}
*/
