package com.common.Controllers;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.common.Dao.FolderDao;
import com.common.Objects.FolderObject;

public class FolderController {
	   
	   @Autowired
	   FolderDao folderDao;
	
	  /* @RequestMapping(value = "/registerFolder", method = RequestMethod.GET)
	   public String showClassForm(Model model){  
		   ClassObject classObject = new ClassObject();
	       model.addAttribute("class", classObject);
	       return "registerClass"; 
	   } */
	
	   @RequestMapping(value = "/saveFolder", method = RequestMethod.POST)
	   public String saveClassData(@ModelAttribute("folder") FolderObject folderObject, BindingResult result){
		   Date date = new Date();  
	       Timestamp ts = new Timestamp(date.getTime());  
	       folderObject.setCreationDt(ts);
	       folderDao.saveFolderObject(folderObject);
	       return "redirect:/manageFolder"; 
	   }  
	   
	   @RequestMapping(value="/manageFolder", method = RequestMethod.GET)  
	   public ModelAndView manageFolder(){  
		   List<FolderObject> folderlist = folderDao.getAllFolders(); 
	       return new ModelAndView("manageFolder","folderlist",folderlist);  
	   }  
	  
	   @RequestMapping(value="/editFolder", method = RequestMethod.GET)  
	   public ModelAndView editFolder(@RequestParam("folderId") Integer folderId){  
		   FolderObject folderObject = findByFolderId(folderId);
	       return new ModelAndView("editFolder","folder",folderObject);  
	   }  
	   
	   
	   @RequestMapping(value="/deleteFolder", method = RequestMethod.GET)  
	   public String deleteFolder(@RequestParam("FolderId") Integer folderId,Model model){  
		   FolderObject folderObject = findByFolderId(folderId);
		   folderDao.deleteFolderObject(folderObject);
	       return "redirect:/manageFolder";//will redirect to viewemp request mapping  
	   }  
	   
	   private FolderObject findByFolderId(Integer folderId) {
		   FolderObject folderObject =  folderDao.getFolderById(folderId); 
		   return folderObject;
	   }
}
