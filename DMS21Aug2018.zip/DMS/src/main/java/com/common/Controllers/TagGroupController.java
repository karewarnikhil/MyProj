package com.common.Controllers;

import java.sql.Timestamp;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.common.Dao.ClassDao;
import com.common.Dao.ClassTagGroupDao;
import com.common.Dao.TagGrpMstDao;
import com.common.Objects.ClassTagGroup;
import com.common.Objects.TagGroup;
import com.common.Objects.UsersObject;



@Controller
public class TagGroupController {

	@Autowired
	private ClassDao classDao;
	
	@Autowired
	private TagGrpMstDao tagGroupDao;
	
	@Autowired
	private ClassTagGroupDao classTagGroupDao;
	
	@RequestMapping(value="/createTagGrp", method=RequestMethod.GET)
	public String getTagGroupForm(Model model) {
		model.addAttribute("classList", classDao.getClasses());
		model.addAttribute("tagGrpList", tagGroupDao.getAllTagGroup());
		model.addAttribute("ClassTagGroup", new ClassTagGroup());
		return "addTagGroup";
	}
	
	@RequestMapping(value="/saveTagGroup", method=RequestMethod.POST)
	public String saveTagGroup(@ModelAttribute("ClassTagGroup") ClassTagGroup classTagGroup,
			HttpServletRequest request) {
		UsersObject usersSess = (UsersObject) request.getSession().getAttribute("users");
		if(usersSess!=null) {
			
			classTagGroup.setClassId(classTagGroup.getClassId());
			classTagGroup.setCreatedBy(usersSess.getUserId());
			classTagGroup.setCreatedDate(new Timestamp(new Date().getTime()));
			
			if(classTagGroup.getTagGrpNm()==null) {
				classTagGroup.setTaggrpid(classTagGroup.getTaggrpid());
				classTagGroupDao.saveClassTagGroup(classTagGroup);
			}
			if (classTagGroup.getTaggrpid()==0) {
				TagGroup tagGroup=new TagGroup();
				tagGroup.setTagGrpNm(classTagGroup.getTagGrpNm());
				tagGroup.setCreatedBy(usersSess.getUserId());
				tagGroup.setCreatedDate(new Timestamp(new Date().getTime()));
				tagGroup.setStatus("A");
				System.out.println("tag id :"+tagGroup.getTagGrpId());
				tagGroupDao.saveTagGrp(tagGroup);
				classTagGroup.setTaggrpid(tagGroup.getTagGrpId());
				classTagGroupDao.saveClassTagGroup(classTagGroup);
			}
			return "redirect:/createTagGrp";
		}
		
		else {
			return "redirect:/login";
		}
	}
	
}
