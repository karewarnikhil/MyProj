package com.common.Controllers;

import java.io.FileOutputStream;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.Security;
import java.security.UnrecoverableKeyException;
import java.security.cert.Certificate;


import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfAnnotation;
import com.itextpdf.text.pdf.PdfAppearance;
import com.itextpdf.text.pdf.PdfFormField;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfSignatureAppearance;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.security.BouncyCastleDigest;
import com.itextpdf.text.pdf.security.DigestAlgorithms;
import com.itextpdf.text.pdf.security.ExternalDigest;
import com.itextpdf.text.pdf.security.ExternalSignature;
import com.itextpdf.text.pdf.security.MakeSignature;
import com.itextpdf.text.pdf.security.MakeSignature.CryptoStandard;
import com.itextpdf.text.pdf.security.PrivateKeySignature;

public class BiometricController {
	public static final String UNSIGNED = "E:/SpringBooks/DigitalSignature/hello_empty.pdf";
	public static final String SIGNAME = "Signature1";
 
	public static final String UNSIGNED2 = "E:/SpringBooks/DigitalSignature/hello_empty2.pdf";
	
	public static final String SRC = "E:/SpringBooks/0764574833.pdf";
	public static final String DEST = "E:/SpringBooks/DigitalSignature/field_signed%s.pdf";
	
	  public void createPdf(String filename) throws IOException, DocumentException {
	    	// step 1: Create a Document
	        Document document = new Document();
	        // step 2: Create a PdfWriter
	        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(filename));
	        // step 3: Open the Document
	        document.open();
	        // step 4: Add content
	        document.add(new Paragraph("Hello World!"));
	        // create a signature form field
	        PdfFormField field = PdfFormField.createSignature(writer);
	        field.setFieldName(SIGNAME);
	        // set the widget properties
	        field.setPage();
	        field.setWidget(new Rectangle(72, 732, 144, 780), PdfAnnotation.HIGHLIGHT_INVERT);
	        field.setFlags(PdfAnnotation.FLAGS_PRINT);
	        // add it as an annotation
	        writer.addAnnotation(field);
	        // maybe you want to define an appearance
	        PdfAppearance tp = PdfAppearance.createAppearance(writer, 72, 48);
	        tp.setColorStroke(BaseColor.BLUE);
	        tp.setColorFill(BaseColor.LIGHT_GRAY);
	        tp.rectangle(0.5f, 0.5f, 71.5f, 47.5f);
	        tp.fillStroke();
	        tp.setColorFill(BaseColor.BLUE);
	        ColumnText.showTextAligned(tp, Element.ALIGN_CENTER, new Phrase("SIGN HERE"), 36, 24, 25);
	        field.setAppearance(PdfAnnotation.APPEARANCE_NORMAL, tp);
	        // step 5: Close the Document
	        document.close();
	    }
	 
	    public void addField(String src, String dest) throws IOException, DocumentException {
	    	PdfReader reader = new PdfReader(src);
	    	PdfStamper stamper = new PdfStamper(reader, new FileOutputStream(dest));
	        // create a signature form field
	        PdfFormField field = PdfFormField.createSignature(stamper.getWriter());
	        field.setFieldName(SIGNAME);
	        // set the widget properties
	        field.setWidget(new Rectangle(72, 732, 144, 780), PdfAnnotation.HIGHLIGHT_OUTLINE);
	        field.setFlags(PdfAnnotation.FLAGS_PRINT);
	        // add the annotation
	        stamper.addAnnotation(field, 1);
	        // close the stamper
	    	stamper.close();
	    }  
	
	public static void main(String[] args) throws GeneralSecurityException, IOException, DocumentException {
		 String configName = "E:\\eTPKCS11.cfg.txt";
		   Provider provider = Security.getProvider("SunPKCS11");
		   provider = provider.configure(configName);
		   Security.addProvider(provider); 
		   
		   // Get provider KeyStore and login with PIN
		   String pin = "hem@123";
		   
		   KeyStore keyStore = null;
			try {
				keyStore = KeyStore.getInstance("PKCS11",provider);
				keyStore.load(null, pin.toCharArray());
				/* keyStore = KeyStore.getInstance("Windows-MY");
				 keyStore.load(null, null);*/
			} catch (KeyStoreException e) {
				e.printStackTrace();
				
			}
		
			
		   // Enumerate items (certificates and private keys) in the KeyStore
		   java.util.Enumeration<String> aliases = keyStore.aliases();
		  
		   String alias = null;
		  // String fileName = "2005_BookMatter_BeginningDatabasesWithPostgreS.pdf";
		   PrivateKey pk = null;
		   while (aliases.hasMoreElements()) {
		       alias = aliases.nextElement();
		   	   try {
				 pk = (PrivateKey) keyStore.getKey(alias,  pin.toCharArray());
				System.out.println("pk======="+pk);
			} catch (UnrecoverableKeyException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		       System.out.println("alias=========="+alias);
		       Certificate[] chain = keyStore.getCertificateChain(alias);
		       System.out.println("Chain====="+chain);
		       
		BiometricController app = new BiometricController();
		app.sign(UNSIGNED, SIGNAME, DEST, chain, pk, DigestAlgorithms.SHA256, provider.getName(), CryptoStandard.CMS, "Test", "Ghent");
	}
	}
	
	public void sign(String src, String name, String dest,
			Certificate[] chain, PrivateKey pk,
			String digestAlgorithm, String provider, CryptoStandard subfilter,
			String reason, String location)
					throws GeneralSecurityException, IOException, DocumentException {
        // Creating the reader and the stamper
        PdfReader reader = new PdfReader(src);
        FileOutputStream os = new FileOutputStream(dest);
        PdfStamper stamper = PdfStamper.createSignature(reader, os, '\0');
        // Creating the appearance
        PdfSignatureAppearance appearance = stamper.getSignatureAppearance();
        appearance.setReason(reason);
        appearance.setLocation(location);
        appearance.setVisibleSignature(name);
        // Creating the signature
        ExternalSignature pks = new PrivateKeySignature(pk, digestAlgorithm, provider);
        ExternalDigest digest = new BouncyCastleDigest();
        MakeSignature.signDetached(appearance, digest, pks, chain, null, null, null, 0, subfilter);
	}

}
