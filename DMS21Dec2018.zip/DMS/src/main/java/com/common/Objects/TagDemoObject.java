package com.common.Objects;

import java.io.Serializable;

public class TagDemoObject implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String tagName;
	private String tagGroup;
	private String tagType;
	private int listId;
	private String status;
	private String isMandatory;
	private int displaySeqNo;
	private int width;
	
	public TagDemoObject() {
		super();
	}

	public TagDemoObject(String tagName, String tagGroup, String tagType, int listId, String status, String isMandatory,
			int displaySeqNo, int width) {
		super();
		this.tagName = tagName;
		this.tagGroup = tagGroup;
		this.tagType = tagType;
		this.listId = listId;
		this.status = status;
		this.isMandatory = isMandatory;
		this.displaySeqNo = displaySeqNo;
		this.width = width;
	}

	public String getTagName() {
		return tagName;
	}

	public void setTagName(String tagName) {
		this.tagName = tagName;
	}

	public String getTagGroup() {
		return tagGroup;
	}

	public void setTagGroup(String tagGroup) {
		this.tagGroup = tagGroup;
	}

	public String getTagType() {
		return tagType;
	}

	public void setTagType(String tagType) {
		this.tagType = tagType;
	}

	public int getListId() {
		return listId;
	}

	public void setListId(int listId) {
		this.listId = listId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getIsMandatory() {
		return isMandatory;
	}

	public void setIsMandatory(String isMandatory) {
		this.isMandatory = isMandatory;
	}


	public int getDisplaySeqNo() {
		return displaySeqNo;
	}

	public void setDisplaySeqNo(int displaySeqNo) {
		this.displaySeqNo = displaySeqNo;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}
	
	
	
	
	
	
	
	
	

}
