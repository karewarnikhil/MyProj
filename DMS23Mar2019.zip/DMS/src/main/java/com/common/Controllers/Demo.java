package com.common.Controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfWriter;

public class Demo {
	public static final String SRC = "E:/SpringByExample.pdf";
	public static final String RESULT = "E:/SpringByExampleOutput.pdf";
	
	 public static void main(String[] args) {
         try {
        	 
        	  FileInputStream fin = new FileInputStream(new File(SRC)); 
              FileOutputStream fout = new FileOutputStream(new File(RESULT)) ; 
              int c;
              while((c = fin.read())!=-1) 
                  fout.write((char)c); 
                  fin.close(); 
                
                Document document = new Document();
                PdfWriter pdfWriter = PdfWriter.getInstance(document, fout);
                
               
                    
                String userPassword = "1234";
                String ownerPassword = "1234";

                pdfWriter.setEncryption(userPassword.getBytes(),
                             ownerPassword.getBytes(), PdfWriter.ALLOW_PRINTING,
                             PdfWriter.ENCRYPTION_AES_128);

			/*
			 * document.open();
			 * 
			 * document.add(new Paragraph("This is Password protected PDF file"));
			 * 
			 * document.close();
			 */
                fout.close();

              //  System.out.println("PDF created in >> " + pdfFilePath);

         } catch (Throwable e) {
                e.printStackTrace();
         }
  }
}
