package com.common.Controllers;

import java.security.KeyStoreException;

import org.hibernate.exception.ConstraintViolationException;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice(basePackages={"com.common"})
public class ExceptionHandler {
	
	@org.springframework.web.bind.annotation.ExceptionHandler(ConstraintViolationException.class)
	public String duplicateDataHandler(Model model) {
		model.addAttribute("error", "There is duplicate entry for same try again.");
		return "loginIn";
	}
	
	@org.springframework.web.bind.annotation.ExceptionHandler(KeyStoreException.class)
	public String keyStoreExceptionHandler(Model model) {
		model.addAttribute("error", "There is no key found.");
		return "loginIn";
	}
}
