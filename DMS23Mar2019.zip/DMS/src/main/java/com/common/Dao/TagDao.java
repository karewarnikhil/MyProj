package com.common.Dao;

import java.util.List;

import com.common.CompositeKey.TagCompositeKey;
import com.common.Objects.TagGroupObject;
import com.common.Objects.TagObject;

public interface TagDao {
	 
	 public	void saveTagObject(TagObject tagObject);

	 public List<TagObject> getAllTagObject();

	// public TagObject getTagById(Integer tagId);
	 
	 public TagObject getTagById(TagCompositeKey tagCompositeKey);
	 
	 public List<TagGroupObject> getAllTagsForFileDisplay(long rootId);
	 
	 public int getMaxValueId(long tagGrpValue);

	public List<TagObject> getTagData(long tagGrpId);

	public void updateTagObject(TagObject tagObject);
	 
}
