package com.common.Utilities;

import java.util.Map;

import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.hibernate.Session;

public class GeneralUtility {
    //code for increment and return currentVal through sp
	public static long getIdForCurrentVal(Session session,String seqName) {
		
		StoredProcedureQuery storedProcedureQuery = session.createStoredProcedureQuery("increment_CurrentVal");
		storedProcedureQuery.registerStoredProcedureParameter("p_seqName", String.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("currentVal", Integer.class, ParameterMode.OUT);
		storedProcedureQuery.setParameter("p_seqName", seqName);
		
		storedProcedureQuery.execute();
		int value = (Integer) storedProcedureQuery.getOutputParameterValue("currentVal");
		return value;
	};
	
	
	//code for pk and sk limit put after in util file
	public static String getparamValue(Session session,String pk,String sk) {
		StoredProcedureQuery storedProcedureQuery = session.createStoredProcedureQuery("getparamvalue");
		storedProcedureQuery.registerStoredProcedureParameter("pk_val", String.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("sk_val", String.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("currentval_a", String.class, ParameterMode.OUT);
		storedProcedureQuery.setParameter("pk_val", pk);
		storedProcedureQuery.setParameter("sk_val", sk);
		
		storedProcedureQuery.execute();
		String limitValue =  ((String) storedProcedureQuery.getOutputParameterValue("currentval_a"));
		//System.out.println("limitValue======="+limitValue);
		
		return limitValue;
	};
	
	
	public static <K, V> K getKey(Map<K, V> map, V value) {
		return map.entrySet()
			       .stream()
			       .filter(entry -> value.equals(entry.getValue()))
			       .map(Map.Entry::getKey)
			       .findFirst().get();
	}

}
