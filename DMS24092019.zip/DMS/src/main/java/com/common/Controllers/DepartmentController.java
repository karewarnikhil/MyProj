package com.common.Controllers;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.common.Dao.DepartmentDao;
import com.common.Objects.DepartmentObject;
import com.common.Objects.UsersObject;
import com.common.Utilities.DmsConstant;

@Controller
public class DepartmentController {
	  
	   @Autowired
	   private DepartmentDao departmentDao ;
	  
	   @RequestMapping(value = "/registerDepartment", method = RequestMethod.GET)
	   public String showDepartmentForm(Model model,HttpServletRequest request){  
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
		       model.addAttribute("department",  new DepartmentObject());
		       return "registerDepartment"; 
		   }else {
			   return "loginIn"; 
		   }
	   } 
	
	   @RequestMapping(value = "/saveDepartment", method = RequestMethod.POST)
	   public String saveDepartmentData(@ModelAttribute("department") DepartmentObject departmentObject, Model model){
		   model.addAttribute("pageNm", "registerDepartment");
		   departmentDao.saveDepartmentObject(departmentObject);
		   if(departmentObject.getStatus().equals("A")){
			   HashMap<Long, String> hashMapofDepartment =  DmsConstant.HASHMAP_OF_DEPARTMENT;
			   hashMapofDepartment.put((long)departmentObject.getDeptId(), departmentObject.getDeptNm());
	       }
		   departmentObject = new DepartmentObject();
		   model.addAttribute("department", departmentObject);
		   model.addAttribute("message", "Department Saved Successfully.");
	       return "registerDepartment"; 
	   }  
	   
	   @RequestMapping(value = "/updateDepartment", method = RequestMethod.POST)
	   public String updateDepartmentData(@ModelAttribute("department") DepartmentObject departmentObject, BindingResult result,Model model){
		   departmentDao.saveDepartmentObject(departmentObject);
		   HashMap<Long, String> hashMapofDepartment =  DmsConstant.HASHMAP_OF_DEPARTMENT;
		   if(departmentObject.getStatus().equals("A") && hashMapofDepartment.containsKey((long)departmentObject.getDeptId())){
			   hashMapofDepartment.replace((long)departmentObject.getDeptId(), departmentObject.getDeptNm());
	       }else if(departmentObject.getStatus().equals("A") && !(hashMapofDepartment.containsKey((long)departmentObject.getDeptId()))){
			   hashMapofDepartment.put((long)departmentObject.getDeptId(), departmentObject.getDeptNm());
	       } else if(departmentObject.getStatus().equals("D")){
	    	   hashMapofDepartment.remove((long)departmentObject.getDeptId());
	       }
	     //return "redirect:/manageDepartment"; 
		   model.addAttribute("message", "Department Updated Successfully.");
		   model.addAttribute("department",departmentObject);
		   return "editDepartment";
	   }  
	   
	   @RequestMapping(value="/manageDepartment", method = RequestMethod.GET)  
	   public ModelAndView manageDepartment(Model model,HttpServletRequest request) {  
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
		   List<DepartmentObject> departmentlist = departmentDao.getAllDepartments(); 
		   
			/*
			 * String SRC = "E:/separation_color.pdf"; String DEST =
			 * "E:/separation_colorSignature.pdf";
			 * 
			 * //Load the keystore that contains the digital id to use in signing KeyStore
			 * store = null; String password= "N@1234"; try { FileInputStream pkcs12Stream =
			 * new FileInputStream ("E:/NikhilKarewar.pfx"); store =
			 * KeyStore.getInstance("PKCS12"); store.load(pkcs12Stream,
			 * password.toCharArray()); pkcs12Stream.close(); } catch (FileNotFoundException
			 * e1) { // TODO Auto-generated catch block e1.printStackTrace(); } catch
			 * (KeyStoreException e1) { // TODO Auto-generated catch block
			 * e1.printStackTrace(); } catch (NoSuchAlgorithmException e1) { // TODO
			 * Auto-generated catch block e1.printStackTrace(); } catch
			 * (CertificateException e1) { // TODO Auto-generated catch block
			 * e1.printStackTrace(); } catch (IOException e1) { // TODO Auto-generated catch
			 * block e1.printStackTrace(); }
			 * 
			 * BouncyCastleProvider provider = new BouncyCastleProvider();
			 * Security.addProvider(provider);
			 * 
			 * PrivateKey pk =null; Certificate[] chain = null; try { String alias =
			 * (String)store.aliases().nextElement(); pk = (PrivateKey) store.getKey(alias,
			 * password.toCharArray()); chain = store.getCertificateChain(alias); } catch
			 * (UnrecoverableKeyException e) { // TODO Auto-generated catch block
			 * e.printStackTrace(); } catch (KeyStoreException e) { // TODO Auto-generated
			 * catch block e.printStackTrace(); } catch (NoSuchAlgorithmException e) { //
			 * TODO Auto-generated catch block e.printStackTrace(); }
			 * 
			 * DigitalSignature digitalSignature = new DigitalSignature(); try {
			 * digitalSignature.sign(SRC, String.format(DEST, 1), chain, pk,
			 * DigestAlgorithms.SHA256, provider.getName(), CryptoStandard.CMS, "Demo test",
			 * "Pune"); } catch (GeneralSecurityException e) { // TODO Auto-generated catch
			 * block e.printStackTrace(); } catch (IOException e) { // TODO Auto-generated
			 * catch block e.printStackTrace(); } catch (DocumentException e) { // TODO
			 * Auto-generated catch block e.printStackTrace(); }
			 */
	       return new ModelAndView("manageDepartment","departmentlist",departmentlist);  
	   }  else {
		   return new ModelAndView("loginIn");  
	   }
	   }
	   
	   
	   @RequestMapping(value="/editDepartment", method = RequestMethod.GET)  
	   public ModelAndView editDepartment(@RequestParam("departmentId") Integer departmentId,HttpServletRequest request){  
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
			   DepartmentObject departmentObject = findByDepartmentId(departmentId);
		       return new ModelAndView("editDepartment","department",departmentObject);  
		   }else {
			   return new ModelAndView("loginIn"); 
		   }
	   }  
	   
	   /*
	   @RequestMapping(value="/showDepartment", method = RequestMethod.GET)  
	   public ModelAndView showDepartment(@RequestParam("departmentId") Integer departmentId){  
		   DepartmentObject departmentObject = findByDepartmentId(departmentId);
		   List<DepartmentObject> departmentlist = departmentDao.getAllDepartments(); 
		   ModelAndView modelAndView = new ModelAndView();
		   modelAndView.addObject("department",departmentObject);
		   modelAndView.addObject("departmentlist",departmentlist);
		   modelAndView.setViewName("home");
	       return modelAndView;  
	   }  
	   
	 @RequestMapping(value="/deleteDepartment", method = RequestMethod.GET)  
	   public String deleteDepartment(@RequestParam("departmentId") Integer departmentId,Model model){  
		   DepartmentObject departmentObject = findByDepartmentId(departmentId);
		   departmentDao.deleteDepartmentObject(departmentObject);
	       return "redirect:/manageDepartment";//will redirect to viewemp request mapping  
	   } */ 
	   
	   private DepartmentObject findByDepartmentId(Integer departmentId) {
		   DepartmentObject departmentObject =  departmentDao.getDepartmentById(departmentId); 
		   return departmentObject;
	   }
}
