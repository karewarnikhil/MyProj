package com.common.Controllers;

import java.security.KeyStoreException;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.exception.ConstraintViolationException;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@ControllerAdvice(basePackages={"com.common"})
public class ExceptionHandler {
	
	@org.springframework.web.bind.annotation.ExceptionHandler(ConstraintViolationException.class)
	public String duplicateDataHandler(Model model,HttpServletRequest request) {
		String pageNm = (String) request.getAttribute("pageNm");
		if(pageNm.equals("registerDepartment")) {
			model.addAttribute("error", "There is duplicate entry for Department Name.");
			return "registerDepartment";
		}else if(pageNm.equals("registerDesignation")) {
			model.addAttribute("error", "There is duplicate entry for Designation Name.");
			return "registerDesignation";
		}else {
			model.addAttribute("error", "There is duplicate entry for same try again.");
			return "loginIn";
		}
	}
	
	@org.springframework.web.bind.annotation.ExceptionHandler(KeyStoreException.class)
	public String keyStoreExceptionHandler(Model model) {
		model.addAttribute("error", "There is no key found.");
		return "defaultPage";
	}
	
	
    //CommonsMultipartResolver
	@org.springframework.web.bind.annotation.ExceptionHandler(MultipartException.class)
    public String handleError2(MaxUploadSizeExceededException e, RedirectAttributes redirectAttributes) {
        redirectAttributes.addFlashAttribute("error", e.getCause().getMessage());
        return "redirect:/uploadFile";

    }
}
