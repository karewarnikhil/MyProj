package com.common.Controllers;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.util.FileCopyUtils;
import org.springframework.web.servlet.view.AbstractView;

import com.common.Objects.DepartmentObject;

import net.sf.jasperreports.engine.DefaultJasperReportsContext;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperRunManager;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.HtmlExporter;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleHtmlExporterOutput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimplePdfExporterConfiguration;
import net.sf.jasperreports.export.SimplePdfReportConfiguration;
import net.sf.jasperreports.export.SimpleXlsxReportConfiguration;


public class ReportView extends AbstractView{
	    
	    private JasperReport departmentReport;

	   
	 
	    @Override
	    protected boolean generatesDownloadContent() {
	        return true;
	    }
	    
	    @Override
	    protected void renderMergedOutputModel(Map<String, Object> model,
	            HttpServletRequest request, HttpServletResponse response) throws Exception {
	    	
	    	response.setContentType("text/html");
	    	List<DepartmentObject> departmentlist =  (List<DepartmentObject>) model.get("departmentlist");
	        //data source
	        //JRDataSource ds = getDataSource(departmentlist);
	    	JRBeanCollectionDataSource ds = new JRBeanCollectionDataSource(departmentlist);
	        //compile jrxml template and get report
	        JasperReport report = getReport();
	        //fill the report with data source objects
		
	        /* Map to hold Jasper report Parameters */
            Map<String, Object> parameters = new HashMap<String, Object>();
            parameters.put("dataSource", ds);
		 
	        JasperPrint jasperPrint = JasperFillManager.fillReport(report, parameters,new JREmptyDataSource());
		/*
		 * //export to html HtmlExporter exporter = new
		 * HtmlExporter(DefaultJasperReportsContext.getInstance());
		 * exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
		 * exporter.setExporterOutput(new
		 * SimpleHtmlExporterOutput(response.getWriter())); exporter.exportReport();
		 */
		
		
		  byte[] bytes = JasperExportManager.exportReportToPdf(jasperPrint);
		  response.setContentType("application/pdf");
		  response.setContentLength(bytes.length); 
		  // get file separator get it from java class separator .
		  response.setHeader("Content-Disposition","attachment; filename=\"Digitization Report.pdf\"");
		 
		  try { 
			  FileCopyUtils.copy(bytes, response.getOutputStream());
			  response.getOutputStream().flush(); response.getOutputStream().close(); 
		  }
		  catch (IOException ex) 
		  { ex.printStackTrace(); }
	    }
	    
	    private JRDataSource getDataSource(List<DepartmentObject> departmentlist) {
	        JRBeanCollectionDataSource ds = new JRBeanCollectionDataSource(departmentlist);
	        return ds;
	    }
	    
	    public JasperReport getReport() throws JRException {
	        InputStream stream = getClass().getResourceAsStream("/department.jrxml");
	        departmentReport = JasperCompileManager.compileReport(stream);
	        return departmentReport;
	    }
    
   
	
	
	
	

}
