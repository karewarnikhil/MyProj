package com.common.Controllers;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.common.Dao.SubDepartmentDao;
import com.common.Objects.DepartmentObject;
import com.common.Objects.SubDepartmentObject;
import com.common.Objects.UsersObject;
import com.common.Utilities.DmsConstant;

@Controller
public class SubDepartmentController {
	
	 @Autowired
	 private SubDepartmentDao subDepartmentDao ;
	
	 @RequestMapping(value = "/registerSubDepartment", method = RequestMethod.GET)
	   public String showDepartmentForm(Model model,HttpServletRequest request){  
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
		       model.addAttribute("subDepartment",  new SubDepartmentObject());
		       return "registerSubDepartment"; 
		   }else {
			   return "loginIn"; 
		   }
	   } 
	 
	 @RequestMapping(value="/manageSubDepartment", method = RequestMethod.GET)  
	   public ModelAndView manageDepartment(Model model,HttpServletRequest request) {  
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
		   List<SubDepartmentObject> subDepartmentlist = subDepartmentDao.getAllSubDepartments(); 
	       return new ModelAndView("manageSubDepartment","subDepartmentlist",subDepartmentlist);  
	   }  else {
		   return new ModelAndView("loginIn");  
	   }
	   }
	 
	 @RequestMapping(value = "/saveSubDepartment", method = RequestMethod.POST)
	   public String saveDepartmentData(@ModelAttribute("subDepartment") SubDepartmentObject subDepartmentObject, Model model){
		   subDepartmentDao.saveSubDepartmentObject(subDepartmentObject);
		   model.addAttribute("deptId", subDepartmentObject.getDeptId());
		   model.addAttribute("subDepartment", new SubDepartmentObject());
		   model.addAttribute("message", "Sub Department Saved Successfully.");
	       return "registerSubDepartment"; 
	   }  
	 
	 @RequestMapping(value="/editSubDepartment", method = RequestMethod.GET)  
	   public ModelAndView editSubDepartment(@RequestParam("subDepartmentId") Integer subDepartmentId,HttpServletRequest request){  
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
			   SubDepartmentObject subDepartmentObject = findBySubDepartmentId(subDepartmentId);
		       return new ModelAndView("editSubDepartment","subDepartment",subDepartmentObject);  
		   }else {
			   return new ModelAndView("loginIn"); 
		   }
	   }
	 
	 @RequestMapping(value = "/updateSubDepartment", method = RequestMethod.POST)
	   public String updateSubDepartment(@ModelAttribute("subDepartment") SubDepartmentObject subDepartmentObject, BindingResult result,Model model){
		   subDepartmentDao.saveSubDepartmentObject(subDepartmentObject);
		   model.addAttribute("message", "Sub Department Updated Successfully.");
		   model.addAttribute("subDepartment",subDepartmentObject);
		   return "editSubDepartment";
	   }  

	private SubDepartmentObject findBySubDepartmentId(Integer subDepartmentId) {
		SubDepartmentObject subDepartmentObject = subDepartmentDao.getSubDepartmentById(subDepartmentId);
		return subDepartmentObject;
	}  
	
	@RequestMapping(value = "/getSubDeptByDept", method = RequestMethod.POST)
	public String getSubDeptByDept(@RequestParam("deptId") long deptId,Model model,HttpServletRequest request) {
		  //check and change get it from hash map define in constant file
	    //List<ClassObject> listClassObject = classDao.getClassByDeptAndROP(deptId);
	    List<SubDepartmentObject> subDepartmentList = subDepartmentDao.getClassByDeptAndROP(deptId);
	    request.getSession().setAttribute("subDepartmentList", subDepartmentList);
	    request.getSession().setAttribute("deptId", deptId);
		return "fileDisplay";
	}

}
