package com.common.Controllers;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.common.Dao.ConfigDao;
import com.common.Dao.HintQuesDao;
import com.common.Dao.UsersDao;
import com.common.Objects.UsersObject;
import com.common.Utilities.DmsConstant;
import com.common.Utilities.GeneralUtility;

@Controller
public class UserController {

	@Autowired
	private UsersDao usersDao;

	@Autowired
	private ConfigDao configDao;

	@Autowired
	private HintQuesDao hintQuesDao;

	//Check and change code accordingly 
	@SuppressWarnings("serial")
	static final List<String> groupList = new ArrayList<String>() {
		{
			add("A");
			add("C");
			add("R");
			add("V");
			add("U");
			add("D");
		}
	};

	@RequestMapping(value = "/addUser", method = RequestMethod.GET)
	public String showform(Model model,HttpServletRequest request) {
		UsersObject usersSessionObject = (UsersObject) request.getSession().getAttribute("users");
		if (usersSessionObject != null) {
		model.addAttribute("user", new UsersObject());
		//Change and get it from hash map and put it in constant files for all following
		//model.addAttribute("departmentList", departmentDao.getAllDepartmentsForAddUser());
		//model.addAttribute("designationList", designationDao.getAllDesignationForAddUser());
		model.addAttribute("groupList", groupList);
		model.addAttribute("configList", configDao.getAllConfigsForDropDown());
		model.addAttribute("hintQuestList", hintQuesDao.getAllHintQuestObject());
		return "registration";
		}else {
			return "loginIn";
		}
	}

	//check and change logic
	@RequestMapping(value = "/saveUser", method = RequestMethod.POST)
	public String saveData(@ModelAttribute("usersObject") UsersObject usersObject, HttpServletRequest request) {
		UsersObject usersSessionObject = (UsersObject) request.getSession().getAttribute("users");
		if (usersSessionObject != null) {
			//need to remove following hardcoding of integer values
			String password = usersObject.getUserName().replace(" ", "").substring(0, 4)
					+ usersObject.getEmailId().substring(0, 2) + "#"
					+ usersObject.getMobileNo().toString().substring(8);
			usersObject.setCreationDt(new Timestamp(new Date().getTime()));
			usersObject.setUserPassword(password);
			//check this following code and try to eliminate.
			String groupName = "";
			for (String grp : usersObject.getGroupList()) {
				//System.out.println("string: " + grp);
				groupName += grp;
			}
			//usersObject.setGroupObject(groupDao.getGroupByString(groupName));
			System.out.println(usersObject.getProfileImage().length);
			 if(usersObject.getProfileImage().length  == 0) {
				  usersObject.setProfileImage(null);
			  }
			usersObject.setGroupId((GeneralUtility.getKey(DmsConstant.HASHMAP_OF_GROUP,groupName)));
			usersObject.setCreatedBy(usersSessionObject.getUserName());
			usersDao.saveUsersObject(usersObject);
			
			if(usersObject.getStatus().equals("A")){
				   HashMap<Long, String> hashMapofUser =  DmsConstant.HASHMAP_OF_USER;
				   hashMapofUser.put((long) usersObject.getUserId(), usersObject.getUserName());
			}
			
			return "redirect:/manageUsers";
		} else {
			return "redirect:/userLogin";
		}

	}

	//check and change logic
	@RequestMapping(value = "/updateUser", method = RequestMethod.POST)
	public String updateData(@ModelAttribute("user") UsersObject usersObject, HttpServletRequest request,
			@RequestParam("deptId") int deptId, @RequestParam("desgId") int desgId) {
		UsersObject usersSessionObject = (UsersObject) request.getSession().getAttribute("users");
		if (usersSessionObject != null) {
			usersObject.setUserPassword(usersObject.getUserPassword());
			//usersObject.setDepartmentObject(departmentDao.getDepartmentById(deptid));
			//usersObject.setDesignationObject(designationDao.getDesignationById(desgId));
			usersObject.setDeptId(deptId);
			usersObject.setDesgId(desgId);
			
			  System.out.println(usersObject.getMultipartFile().getSize());
			  if(usersObject.getMultipartFile().getSize() > 0) {
				  try { 
					  usersObject.setProfileImage(usersObject.getMultipartFile().getBytes());
				  } catch (IOException e) { // TODO Auto-generated catch block
				  e.printStackTrace(); 
				  }
			  }else {
				  usersObject.setProfileImage(null);
			  }
			String groupName = "";
			for (String grp : usersObject.getGroupList()) {
				groupName += grp;
			}
			
				  
			 
			//usersObject.setGroupObject(groupDao.getGroupByString(groupName));
			usersObject.setGroupId((GeneralUtility.getKey(DmsConstant.HASHMAP_OF_GROUP,groupName)));
			usersObject.setCreatedBy(usersObject.getCreatedBy());
			usersObject.setHintId(usersObject.getHintId());
			usersDao.updateUser(usersObject);
			return "redirect:/manageUsers";
		} else {
			return "redirect:/login";
		}
	}

	@RequestMapping(value = "/manageUsers", method = RequestMethod.GET)
	public String manageUser(Model model,HttpServletRequest request) {
		UsersObject usersSessionObject = (UsersObject) request.getSession().getAttribute("users");
		if (usersSessionObject != null) {
			List<UsersObject> userslist = usersDao.getAllUsers();
			model.addAttribute("usersList", userslist);
			return "manageUsers";
		}else {
			return "loginIn";
		}
	}

	@RequestMapping(value = "/editUser", method = RequestMethod.GET)
	public String editUser(@RequestParam("userId") Integer userId, Model model,HttpServletRequest request) {
		UsersObject usersSessionObject = (UsersObject) request.getSession().getAttribute("users");
		if (usersSessionObject != null) {
		UsersObject usersObject = findByUserId(userId);
		List<String> list = new ArrayList<String>();
		//String[] words = groupDao.getGroupById(findByUserId(userId).getGroupObject().getGroupId()).getGroupNm().split("");
		String[] words = DmsConstant.HASHMAP_OF_GROUP.get(usersObject.getGroupId()).split("");
		for (String charcInWords : words) {
			//System.out.println("" + s);
			list.add(charcInWords);
		}
		usersObject.setGroupList(list);
		
		if(usersObject.getProfileImage() != null) {
		byte[] encodeBase64 = Base64.getEncoder().encode(usersObject.getProfileImage());
		 //change it to error message of catch printStackTrace
		String base64Encoded = null;
		try {
			base64Encoded = new String(encodeBase64, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		 model.addAttribute("fileForDisplay", base64Encoded );
		 model.addAttribute("imageExtension", "jpg");
		}
		model.addAttribute("groupList", groupList);
		model.addAttribute("user", usersObject);
		//model.addAttribute("departmentList", departmentDao.getAllDepartments());
		//model.addAttribute("designationList", designationDao.getAllDesignation());
		model.addAttribute("configList", configDao.getAllConfigsForDropDown());
		return "editUser";// will redirect to viewemp request mapping

	}else {
		return "loginIn";
	}
	}

	/*@RequestMapping(value = "/deleteUser", method = RequestMethod.GET)
	public String deleteUser(@RequestParam("userId") Integer userId, Model model) {
		UsersObject usersObject = findByUserId(userId);
		usersDao.deleteUserObject(usersObject);
		return "redirect:/manageUsers";// will redirect to viewemp request mapping
	}
*/
	private UsersObject findByUserId(Integer userId) {
		UsersObject usersObject = usersDao.getUsersById(userId);
		return usersObject;
	}

}
