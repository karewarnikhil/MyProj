package com.common.Dao;

import java.util.List;

import com.common.Objects.ClassTagGroup;
import com.common.Objects.SubDepartmentObject;

public interface ClassTagGroupDao {
	
	public void saveClassTagGroup(ClassTagGroup classTagGroup);

	public List<SubDepartmentObject> getClassData(long tagGrpId);

}
