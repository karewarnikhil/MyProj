package com.common.Dao;

import java.util.List;

import com.common.CompositeKey.DocumentCompositeKey;
import com.common.Objects.DocumentObject;
import com.common.Objects.FileMasterObject;

public interface DocumentDao {
	
	List<DocumentObject> getAllDocuments();
    
   // DocumentObject findByFileId(long fileId);
	
	DocumentObject findByFileId(DocumentCompositeKey documentCompositeKey);
     
	/*
	 * int saveBatch(List<DocumentObject> documentListFoSave, int fileSavedCount);
	 */
    
    void save(DocumentObject documentObject);
     
    List<DocumentObject> findAllByFolderId(long folderId);
     
 /*   void deleteById(int id);*/

	List<DocumentObject> findAllByFolderIdAndUntagged(long folderId);

	DocumentObject findByFileNameAndFolderId(String originalFilename,long folderId);
	
	DocumentObject findByFileNameAndFolderIdUpdate(String originalFilename,long folderId);
	
	/*DocumentObject findByFileName(String originalFilename);*/
	
	 List<FileMasterObject> getFileMstByQuery(String sql);

	 DocumentObject getFileByFileIdAndSeqNo(long fileId, long seqNo);

     List<DocumentObject> getFileVersions(long fileId);
	
     void updateDocument(DocumentObject docObject);

	List<DocumentObject> getAllDocumentsForMultiTagging(DocumentObject documentObject);
	
	long getMaxSequenceValue(long fileId);
	
	public long checkGreaterSeqNo(long fileId);  
}
