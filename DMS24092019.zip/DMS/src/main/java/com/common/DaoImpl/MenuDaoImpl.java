package com.common.DaoImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.MenuDao;
import com.common.Objects.MenuObject;

@Repository
@Transactional
public class MenuDaoImpl implements MenuDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	//create one class for menu.and user access eliminate same present class
	public List<MenuObject> getMenuListByUserId(int userId,String lang) {
		//remove hard-code value define default value in constant file
		List<MenuObject> listOfMenu =  (List<MenuObject>) sessionFactory.getCurrentSession().createQuery(" SELECT m FROM MenuObject m, UACCObject u WHERE m.menuId = u.uACCCompositeKey.mid AND m.pageId =: pageId AND u.uACCCompositeKey.userId =:userId AND lang =:lang").setParameter("pageId", 0).setParameter("userId", userId).setParameter("lang", lang).list();
		if(listOfMenu != null){
			for(MenuObject menuObject:listOfMenu){
				getChildMenus(menuObject,userId,lang);
        }   	
		}
		return listOfMenu;
	}
	
	public void getChildMenus(MenuObject menuObject,int userId,String lang) {
		List<MenuObject> listOfSubMenu = null;
		//remove following hard-code and define in constant file . 
		if(userId>0) {
			 listOfSubMenu =  (List<MenuObject>) sessionFactory.getCurrentSession().createQuery(" SELECT m FROM MenuObject m, UACCObject u where m.menuId = u.uACCCompositeKey.mid and m.pageId =: pageId AND u.uACCCompositeKey.userId =:userId AND lang =:lang order by menuNm ").setParameter("pageId", menuObject.getMenuId()).setParameter("userId", userId).setParameter("lang", lang).list();
		}	
		else {
			 listOfSubMenu =  (List<MenuObject>) sessionFactory.getCurrentSession().createQuery(" FROM MenuObject where pageId = "+menuObject.getMenuId() + "order by menuNm").list();
		}
   		if(listOfSubMenu != null){
   			menuObject.setListOfMenu(listOfSubMenu);
   			for(MenuObject subMenuObject:listOfSubMenu){
				getChildMenus(subMenuObject,userId,lang);
   			}   	
   		}
	}

	public List<MenuObject> getMenuList() {
		//remove following hard-code and define in constant file . 
		List<MenuObject> listOfMenu =  (List<MenuObject>) sessionFactory.getCurrentSession().createQuery("FROM MenuObject WHERE pageId =:pageId").setParameter("pageId", 0).list();
		if(listOfMenu != null){
			for(MenuObject menuObject:listOfMenu){
				getChildMenus(menuObject,0,null);
        } 
		}
		return listOfMenu;
	}

}
