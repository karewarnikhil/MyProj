package com.common.DaoImpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.UsersDao;
import com.common.Objects.UsersObject;

@Repository
@Transactional
public class UsersDaoImpl implements UsersDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	public void saveUsersObject(UsersObject users) {
		sessionFactory.getCurrentSession().save(users);
	}

	public List<UsersObject> getAllUsers() {
		return sessionFactory.getCurrentSession().createQuery("from UsersObject order by userId desc").list();
	}
	
	public UsersObject getUsersById(Integer userId) {
		UsersObject usersObject = (UsersObject) sessionFactory.getCurrentSession().get(UsersObject.class,userId);
		return usersObject;
	}

	/*public void deleteUserObject(UsersObject usersObject) {
		sessionFactory.getCurrentSession().delete(usersObject);
	}*/

	public UsersObject getUsersByUserName(String emailId) {
		UsersObject usersObject = (UsersObject) sessionFactory.getCurrentSession().createQuery(" from UsersObject where emailId =: emailId").setParameter("emailId", emailId).uniqueResult();
		return usersObject;
	}
	
	public void updateUser(UsersObject usersObject) {
		sessionFactory.getCurrentSession().update(usersObject);
	}
	
	public List<UsersObject> getAllUsersForMenu() {
		//remove hard-coded values and get it from constant files
		//try to make common logic for both
		return sessionFactory.getCurrentSession().createQuery("from UsersObject where status=:status order by userName").setParameter("status", "A").list();
	}

	@Override
	public List<UsersObject> getAllUsers(long deptId) {
		return sessionFactory.getCurrentSession().createQuery(" From UsersObject where status=:status AND deptId =:deptId order by userName").setParameter("status", "A").setParameter("deptId", deptId).list();
	}

	@Override
	public Map<Long, String> getHashmapofUser() {
		 HashMap<Long, String> hashMapofUsers = new HashMap<>();
		 List<UsersObject> getAllUsers = sessionFactory.getCurrentSession().
		 createQuery(" SELECT new UsersObject (us.userId ,us.userName )FROM UsersObject us where us.status= :status order by us.userName").setParameter("status", "A").list();
				 
		  for(UsersObject usersObject:getAllUsers) {
			  hashMapofUsers.put((long)usersObject.getUserId(),usersObject.getUserName());
		  }
		return hashMapofUsers;
	}
	
	
}




