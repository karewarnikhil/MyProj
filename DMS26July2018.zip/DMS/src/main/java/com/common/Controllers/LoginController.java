package com.common.Controllers;

import java.io.Serializable;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.common.Dao.MenuDao;
import com.common.Dao.UsersDao;
import com.common.Objects.AccessObject;
import com.common.Objects.MenuObject;
import com.common.Objects.UsersObject;

@Controller
public class LoginController implements Serializable{

	
	private static final long serialVersionUID = 1L;
	public int loginCount = 0;
	
	@Autowired
	private UsersDao usersDao ;
	
	@Autowired
	private MenuDao menuDao;
	
	
	@RequestMapping(value = "/userLogin", method = RequestMethod.GET)
	   public String login() {
	       return "loginIn";
	}
	 
	       @ModelAttribute("user")
	          public UsersObject setUpUserForm() {
	          return new UsersObject();
	       }
	        // Checks if the user credentials are valid or not.
	 	    @RequestMapping(value = "/userLogin", method = RequestMethod.POST)
	 	    public String loginUser(@RequestParam("loginIdFn")String emailId, @RequestParam("passwordFn")String password, @ModelAttribute("user") UsersObject usersObject, HttpServletRequest request) {
	 	    	HttpSession session = request.getSession();
	 	    	usersObject = usersDao.getUsersByUserName(emailId);
	 	    	loginCount++;
	            if((usersObject != null) && (password.equals(usersObject.getUserPassword()))  ) {
	            	List<MenuObject> listOfMenu = (List<MenuObject>) menuDao.getMenuListByUserId(usersObject.getUserId());
	            	String groupName = usersObject.getGroupObject().getGroupNm();
	            	AccessObject accessObject = createAccessObject(groupName);
	            	usersObject.setAccessObject(accessObject);
	            	session.setAttribute("listOfMenu", listOfMenu);
	            	session.setAttribute("users", usersObject);
	            	//return "displayMenu";
	            	String mobileNo = usersObject.getMobileNo()+"";
	 	 	    	String passwordCheck = usersObject.getUserName().substring(0,4)+usersObject.getEmailId().substring(0, 2)+"#"+mobileNo.substring(0, 2);
	 	 	    	loginCount = 0;
	 	 	    	if(passwordCheck.equals(password)) {
	 	 	    		return "redirect:changePassword";
	 	 	    	}
	 	 	    	else
	            	return "home";
	            }
	            else {
	            	System.out.println("Password does not match");
	            	if(loginCount == 3) {
	            		loginCount = 0;
	            		return "logout";
	            	}
	            	else {
	            	request.setAttribute("error", "Invalid Credintial.");
	            	return "loginIn";
	            	}
	            }
	 	    }

			private AccessObject createAccessObject(String groupName) {
				AccessObject accessObject = new AccessObject();
				if(groupName.contains("A")) {
					accessObject.setAdd(true);
				}
				if(groupName.contains("C")) {
					accessObject.setChange(true);
				}
				if(groupName.contains("D")) {
					accessObject.setDownload(true);
				}
				if(groupName.contains("U")) {
					accessObject.setUpload(true);
				}
				if(groupName.contains("V")) {
					accessObject.setView(true);
				}
				if(groupName.contains("R")) {
					accessObject.setRemove(true);
				}
				return accessObject;
			}
	 	    
	 	    
	 	   @RequestMapping(value = "/userLogout", method = RequestMethod.GET)
		   public String userLogout(HttpSession session ) {
	 		   session.invalidate();
		       return "logout";
	 	   }
	 	   
	 	  @RequestMapping(value = "/home", method = RequestMethod.GET)
		   public String home(HttpSession session)  {
	 		  UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
	 		  if(usersSessionObject != null) {
	 		  return "home";
	 		  }
	 		  else
	 		  return "loginIn";	  
	 	   }
	 	  
	 	 @RequestMapping(value = "/aboutUs", method = RequestMethod.GET)
		   public String aboutUs( ) {
	 		 return "aboutUs";
	 	   }
		 
}
