package com.common.Dao;

import java.util.List;

import com.common.Objects.ClassObject;

public interface ClassDao {
	
	 public	void saveClassObject(ClassObject classObject);

	 public List<ClassObject> getAllClass();

	 public ClassObject getClassById(Integer classId);
	 
	 public void deleteClassObject(ClassObject classObject);
	 
}
