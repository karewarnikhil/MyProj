package com.common.DaoImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.FolderDao;
import com.common.Objects.FolderObject;

@Repository
@Transactional
public class FolderDaoImpl implements FolderDao{
	
	@Autowired
	private SessionFactory sessionFactory;

	public void saveFolderObject(FolderObject folderObject) {
		sessionFactory.getCurrentSession().saveOrUpdate(folderObject);
		
	}

	public List<FolderObject> getAllFolders() {
		return sessionFactory.getCurrentSession().createQuery(" FROM FolderObject").list();
	}

	public FolderObject getFolderById(Integer folderId) {
		FolderObject folderObject = (FolderObject) sessionFactory.getCurrentSession().get(FolderObject.class,folderId);
		return folderObject;
	}

	public void deleteFolderObject(FolderObject folderObject) {
		sessionFactory.getCurrentSession().delete(folderObject);
	}

}
