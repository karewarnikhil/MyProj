package com.common.Objects;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity @Table(name="foldermst")
public class FolderObject implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "folderid", updatable = false, nullable = false)
	private long folderId;
	
	@Column(name="parentid")
	private int parentId;
	
	@Column(name="rootid")
	private int rootId;
	
	@Column(name="fldrnm")
	private String folderNm;
	
	@Column(name="isinnerfolders")
	private String isInnerFolders;
	
	@Column(name="foldercnt")
	private int folderCnt;
	
	@Column(name="filecnt")
	private int fileCnt;
	
	@Column(name="atribt")
	private String atriBt;
	
	@Column(name="readonlyothdept")
	private String readOnlyOthDept;
	
	@Column(name="readonlypublic")
	private String readOnlyPublic;
	
	@Column(name="createdby")
	private int createdBy;
	
	@Column(name="creationDt")
	private Timestamp creationDt;

	public long getFolderId() {
		return folderId;
	}

	public void setFolderId(long folderId) {
		this.folderId = folderId;
	}

	public int getParentId() {
		return parentId;
	}

	public void setParentId(int parentId) {
		this.parentId = parentId;
	}

	public int getRootId() {
		return rootId;
	}

	public void setRootId(int rootId) {
		this.rootId = rootId;
	}

	public String getFolderNm() {
		return folderNm;
	}

	public void setFolderNm(String folderNm) {
		this.folderNm = folderNm;
	}

	public String getIsInnerFolders() {
		return isInnerFolders;
	}

	public void setIsInnerFolders(String isInnerFolders) {
		this.isInnerFolders = isInnerFolders;
	}

	public int getFolderCnt() {
		return folderCnt;
	}

	public void setFolderCnt(int folderCnt) {
		this.folderCnt = folderCnt;
	}

	public int getFileCnt() {
		return fileCnt;
	}

	public void setFileCnt(int fileCnt) {
		this.fileCnt = fileCnt;
	}

	public String getAtriBt() {
		return atriBt;
	}

	public void setAtriBt(String atriBt) {
		this.atriBt = atriBt;
	}

	public String getReadOnlyOthDept() {
		return readOnlyOthDept;
	}

	public void setReadOnlyOthDept(String readOnlyOthDept) {
		this.readOnlyOthDept = readOnlyOthDept;
	}

	public String getReadOnlyPublic() {
		return readOnlyPublic;
	}

	public void setReadOnlyPublic(String readOnlyPublic) {
		this.readOnlyPublic = readOnlyPublic;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreationDt() {
		return creationDt;
	}

	public void setCreationDt(Timestamp creationDt) {
		this.creationDt = creationDt;
	}

	public FolderObject() {
		super();
	}

	public FolderObject(long folderId, int parentId, int rootId, String folderNm, String isInnerFolders, int folderCnt,
			int fileCnt, String atriBt, String readOnlyOthDept, String readOnlyPublic, int createdBy,
			Timestamp creationDt) {
		super();
		this.folderId = folderId;
		this.parentId = parentId;
		this.rootId = rootId;
		this.folderNm = folderNm;
		this.isInnerFolders = isInnerFolders;
		this.folderCnt = folderCnt;
		this.fileCnt = fileCnt;
		this.atriBt = atriBt;
		this.readOnlyOthDept = readOnlyOthDept;
		this.readOnlyPublic = readOnlyPublic;
		this.createdBy = createdBy;
		this.creationDt = creationDt;
	}
	
}
