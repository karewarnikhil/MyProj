package com.common.Controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.common.Dao.UsersDao;
import com.common.Objects.UsersObject;

@Controller
public class PasswordController {
	
	@Autowired
	private UsersDao usersDao ;
	
	@RequestMapping(value = "/changePassword", method = RequestMethod.GET)
	   public String changePasswordForm() { 
	       return "changePassword"; 
	} 
	
	@RequestMapping(value = "/forgotPassword", method = RequestMethod.GET)
	   public String forgotPassword() { 
	       return "forgotPassword"; 
	} 
	
	@RequestMapping(value = "/saveChangePassword", method = RequestMethod.POST)
	   public String saveChangePassword(@RequestParam("oldPasswordFn") String oldPassword, @RequestParam("newPasswordFn") String newPassword,HttpServletRequest request) { 
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   String originalPassword = usersSessionObject.getUserPassword();
		   String originalPasswordOne = usersSessionObject.getUserPasswordOne();
		   String originalPasswordTwo = usersSessionObject.getUserPasswordTwo();
		   if( !(originalPassword.equals(oldPassword))) {
			   request.setAttribute("error", "Old password does not match.");
			  // System.out.println("old password does not match.");
			   return "changePassword"; 
		   }
		   else if((originalPassword.equals(newPassword)) || ((originalPasswordOne != null) && (originalPasswordOne.equals(newPassword))) || ((originalPasswordTwo != null) && (originalPasswordTwo.equals(newPassword) ))){
			   request.setAttribute("error", "Password must be other than last three passwords. ");
/*			   System.out.println("password must be other than last three passwords. ");
*/			   return "changePassword";
		   }
		   else { 
			    usersSessionObject.setUserPasswordTwo(originalPasswordOne);
			    usersSessionObject.setUserPasswordOne(originalPassword);
			    usersSessionObject.setUserPassword(newPassword);
			    //usersDao.saveUsersObject(usersSessionObject);
			    usersDao.updateUser(usersSessionObject);
			    request.setAttribute("message", "User password is changed");
			    //System.out.println("password is changed.");
			    //session.removeAttribute("users");
			    return "defaultPage";
			   // session.invalidate();
			   // return "loginIn"; 
		   }
	       
	} 
	
	@RequestMapping(value = "/saveForgotPassword", method = RequestMethod.POST)
	   public String saveForgotPassword(@RequestParam("emailId") String emailId, @RequestParam("newPasswordFn") String newPassword,HttpServletRequest request) { 
		
		UsersObject	usersObject = usersDao.getUsersByUserName(emailId);
        if((usersObject != null) &&  usersObject.getStatus().equals("A")) {
           String originalPassword = usersObject.getUserPassword();
 		   String originalPasswordOne = usersObject.getUserPasswordOne();
 		   String originalPasswordTwo = usersObject.getUserPasswordTwo();
 		  
 		   if((originalPassword.equals(newPassword)) || ((originalPasswordOne != null) && (originalPasswordOne.equals(newPassword))) || ((originalPasswordTwo != null) && (originalPasswordTwo.equals(newPassword) ))){
 			   request.setAttribute("error", "Password must be other than last three passwords. ");
 			   return "forgotPassword";
 		   }
 		   else { 
			    usersObject.setUserPasswordTwo(originalPasswordOne);
			    usersObject.setUserPasswordOne(originalPassword);
			    usersObject.setUserPassword(newPassword);
			   
			    usersDao.updateUser(usersObject);
			    request.setAttribute("message", "User password is reset successfully.");
			    return "loginIn";
		   }
        }
        else {
        	request.setAttribute("error", "Email Id does not exists. ");
        	return "forgotPassword";	
        	
        }
        	
	       
	} 
}