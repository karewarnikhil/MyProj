package com.common.Objects;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity @Table(name="messagemst")
public class MessageObject implements Serializable{

	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "messageId", updatable = false, nullable = false)
	private long messageId;
	
	@Column(name="messagefrom")
	private long messageFrom;
	
	@Column(name="messageto")
	private String messageTo;
	
	@Column(name="FileId")
	private String fileId;
	
	@Column(name="comment")
	private String comment;
	
	@Column(name="subject")
	private String subject;
	
	@Column(name="creationdt")
	private Timestamp creationDt;
	
	@Column(name="readstatus")
	private String readStatus;
	
	@Transient
	private List<Long> messageToList;



	


	public MessageObject(long messageId, long messageFrom, String messageTo, String fileId, String comment,
			String subject, Timestamp creationDt, String readStatus, List<Long> messageToList) {
		super();
		this.messageId = messageId;
		this.messageFrom = messageFrom;
		this.messageTo = messageTo;
		this.fileId = fileId;
		this.comment = comment;
		this.subject = subject;
		this.creationDt = creationDt;
		this.readStatus = readStatus;
		this.messageToList = messageToList;
	}




	public long getMessageId() {
		return messageId;
	}




	public void setMessageId(long messageId) {
		this.messageId = messageId;
	}




	public long getMessageFrom() {
		return messageFrom;
	}




	public void setMessageFrom(long messageFrom) {
		this.messageFrom = messageFrom;
	}




	public String getMessageTo() {
		return messageTo;
	}




	public void setMessageTo(String messageTo) {
		this.messageTo = messageTo;
	}




	public String getFileId() {
		return fileId;
	}




	public void setFileId(String fileId) {
		this.fileId = fileId;
	}




	public String getComment() {
		return comment;
	}




	public void setComment(String comment) {
		this.comment = comment;
	}




	public String getSubject() {
		return subject;
	}




	public void setSubject(String subject) {
		this.subject = subject;
	}




	public Timestamp getCreationDt() {
		return creationDt;
	}




	public void setCreationDt(Timestamp creationDt) {
		this.creationDt = creationDt;
	}




	public String getReadStatus() {
		return readStatus;
	}




	public void setReadStatus(String readStatus) {
		this.readStatus = readStatus;
	}




	public List<Long> getMessageToList() {
		return messageToList;
	}




	public void setMessageToList(List<Long> messageToList) {
		this.messageToList = messageToList;
	}

	



	



	public MessageObject() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	
	

}
