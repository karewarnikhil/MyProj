package com.common.Controllers;

import java.io.Serializable;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.common.Dao.MenuDao;
import com.common.Dao.UsersDao;
import com.common.Objects.AccessObject;
import com.common.Objects.MenuObject;
import com.common.Objects.UsersObject;
import com.common.Utilities.DmsConstant;

@Controller
public class LoginController implements Serializable{

	
	private static final long serialVersionUID = 1L;
	public int loginCount = 0;
	
	@Autowired
	private UsersDao usersDao ;
	
	@Autowired
	private MenuDao menuDao;
	
	
	
	@RequestMapping(value = "/userLogin", method = RequestMethod.GET)
	   public String login() {
	       return "loginIn";
	}
	
	@RequestMapping(value = "/changeLanguage", method = RequestMethod.GET)
	   public String changeLanguage(@RequestParam("menu")String lang,HttpServletRequest request) {
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   List<MenuObject> listOfMenu = (List<MenuObject>) menuDao.getMenuListByUserId(usersSessionObject.getUserId(),lang);
		   session.setAttribute("listOfMenu", listOfMenu);
	       return "defaultPage";
	}
	 
	       @ModelAttribute("user")
	          public UsersObject setUpUserForm() {
	          return new UsersObject();
	       }
	       
	       // Checks if the user credentials are valid or not.
	 	    @RequestMapping(value = "/userLogin", method = RequestMethod.POST)
	 	    public String loginUser(@RequestParam("emailId")String emailId, @RequestParam("passwordFn")String password, @ModelAttribute("user") UsersObject usersObject, HttpServletRequest request) {
	 	    	HttpSession session = request.getSession();
	 	    	usersObject = usersDao.getUsersByUserName(emailId);
	 	    	loginCount++;
	            if((usersObject != null) && (password.equals(usersObject.getUserPassword()) && usersObject.getStatus().equals("A"))) {
	            	List<MenuObject> listOfMenu = (List<MenuObject>) menuDao.getMenuListByUserId(usersObject.getUserId(),"EN");
	            	/*if(listOfMenu != null && listOfMenu.size() > 0) {
	            		session.setAttribute("listOfMenu", listOfMenu);
	            	}*/
	            	session.setAttribute("listOfMenu", listOfMenu);
	            	AccessObject accessObject = createAccessObject(usersObject.getGroupId());
			/*
			 * long messageCount =
			 * messageDao.getUserMessageCount(usersObject.getUserId().toString());
			 
	            	usersObject.setMessageCount(messageCount);*/
	            	usersObject.setAccessObject(accessObject);
	            	session.setAttribute("users", usersObject);
	            	//return "displayMenu";
	            	//String mobileNo = usersObject.getMobileNo()+"";
	 	 	    	String passwordCheck = usersObject.getUserName().substring(0,4)+usersObject.getEmailId().substring(0, 2)+"#"+usersObject.getMobileNo().toString().substring(8);
	 	 	    	loginCount = 0;
	 	 	    	if(passwordCheck.equalsIgnoreCase(password)) {
	 	 	    		return "redirect:changePassword";
	 	 	    	}
	 	 	    	else {
	 	 	    		return "defaultPage";
	 	 	    	}
	            }
	            else {
	            	//System.out.println("Password does not match");
	            	if(loginCount == 3) {
	            		loginCount = 0;
	            		return "logout";
	            	}
	            	else {
	            	request.setAttribute("error", "Invalid Credintial.");
	            	return "loginIn";
	            	}
	            }
	 	    }

	 	    //change following logic
			private AccessObject createAccessObject(long groupId) {
				AccessObject accessObject = new AccessObject();
				String groupName = DmsConstant.HASHMAP_OF_GROUP.get(groupId);
				if(groupName.contains("A")) {
					accessObject.setAdd(true);
				}
				if(groupName.contains("C")) {
					accessObject.setChange(true);
				}
				if(groupName.contains("D")) {
					accessObject.setDownload(true);
				}
				if(groupName.contains("U")) {
					accessObject.setUpload(true);
				}
				if(groupName.contains("V")) {
					accessObject.setView(true);
				}
				if(groupName.contains("R")) {
					accessObject.setRemove(true);
				}
				return accessObject;
			}
	 	    
	 	    
	 	   @RequestMapping(value = "/userLogout", method = RequestMethod.GET)
		   public String userLogout(HttpSession session ) {
	 		   session.invalidate();
		       return "logout";
	 	   }
	 	   
	 	  @RequestMapping(value = "/home", method = RequestMethod.GET)
		   public String home(HttpSession session)  {
	 		  UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
	 		  if(usersSessionObject != null) {
	 			  return "defaultPage";
	 		  }
	 		  else
	 			  return "loginIn";	  
	 	   }
}