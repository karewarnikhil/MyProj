package com.common.Controllers;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.common.Dao.ClassDao;
import com.common.Dao.ClassTagGroupDao;
import com.common.Dao.TagGrpDao;
import com.common.Objects.ClassTagGroup;
import com.common.Objects.TagGroupObject;
import com.common.Objects.UsersObject;
import com.common.Utilities.DmsConstant;



@Controller
public class TagGroupController {

	@Autowired
	private ClassDao classDao;
	
	@Autowired
	private TagGrpDao tagGroupDao;
	
	@Autowired
	private ClassTagGroupDao classTagGroupDao;
	
	@RequestMapping(value="/createTagGrp", method=RequestMethod.GET)
	public String getTagGroupForm(Model model,HttpServletRequest request) {
		UsersObject usersSessionObject = (UsersObject) request.getSession().getAttribute("users");
		if(usersSessionObject != null) {
			getRequiredDataForDisplay(model);
			return "addTagGroup";
		}else {
			return "loginIn";
		}
	}

	private void getRequiredDataForDisplay(Model model) {
		//Change get it from hash map defined in constant file 
		//model.addAttribute("classList", classDao.getClassesForDropDown());
		model.addAttribute("classList", classDao.getClassesForDropDown());
		//model.addAttribute("tagGrpList", tagGroupDao.getAllTagForGroupDropDown());
		model.addAttribute("classTagGroup", new ClassTagGroup());
	}
	
	//check and change logic for same code.
	@RequestMapping(value="/saveTagGroup", method=RequestMethod.POST)
	public String saveTagGroup(@ModelAttribute("ClassTagGroup") ClassTagGroup classTagGroup,HttpServletRequest request,Model model) {
		UsersObject usersSess = (UsersObject) request.getSession().getAttribute("users");
		if (usersSess != null) {
			//System.out.println(classTagGroup.getTagGrpId());
			//classTagGroup.setClassObject(classDao.getClassById(classTagGroup.getClassObject().getClassId()));
			classTagGroup.setCreatedBy(usersSess.getUserId());
			classTagGroup.setCreationDt(new Timestamp(new Date().getTime()));

			if (classTagGroup.getTagGrpNm() == null) {
				//classTagGroup.setTagGroup(tagGroupDao.getTagByTagId(classTagGroup.getTagGrpId()));
				classTagGroupDao.saveClassTagGroup(classTagGroup);
			}
			if (classTagGroup.getClassTgGrpCompositeKey().getTagGrpId()==0) {
				TagGroupObject tagGroup=new TagGroupObject();
				tagGroup.setTagGrpNm(classTagGroup.getTagGrpNm());
				tagGroup.setCreatedBy(usersSess.getUserId());
				tagGroup.setCreationDt(new Timestamp(new Date().getTime()));
				tagGroup.setStatus("A");
				//System.out.println("tag id :"+tagGroup.getTagGrpId());
				tagGroupDao.saveTagGrp(tagGroup);
				//System.out.println(tagGroup.getTagGrpId());
				if(tagGroup.getStatus().equals("A")){
					HashMap<Long, String> hashMapoftagGrp =  DmsConstant.HASHMAP_OF_TAG_GROUP;
					hashMapoftagGrp.put(tagGroup.getTagGrpId(), tagGroup.getTagGrpNm());
				}	
			   // classTagGroup.setTagGroup(tagGroupDao.getTagByTagId(tagGroup.getTagGrpId()));
				classTagGroupDao.saveClassTagGroup(classTagGroup);
			}
			
			classTagGroup = new ClassTagGroup();
			model.addAttribute("ClassTagGroup", classTagGroup);
			model.addAttribute("message", "Tag group Saved Successfully.");
			getRequiredDataForDisplay(model);
			//return "redirect:/createTagGrp";
			return "addTagGroup";
		}
		
		else {
			return "redirect:/login";
		}
	}
	
}
