package com.common.Dao;

import java.util.List;

import com.common.Objects.DepartmentReport;

public interface ReportDao {
	 public List<DepartmentReport> getDepartmentWiseReport();
}
