package com.common.DaoImpl;

import java.util.List;

import javax.persistence.Query;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.FolderDao;
import com.common.Objects.FolderObject;
import com.common.Utilities.GeneralUtility;

@Repository
@Transactional
public class FolderDaoImpl implements FolderDao{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	//eliminate one for update folder method
	
	//use one method for save 
	public void saveFolderObject(FolderObject folderObject) {
		sessionFactory.getCurrentSession().save(folderObject);
	}

	//this method is not used try to eliminate same method from dao also
	public List<FolderObject> getAllFolders() {
		return sessionFactory.getCurrentSession().createQuery(" FROM FolderObject").list();
	}
	
	//used for file upload 
	public List<FolderObject> getAllFoldersByRootId(long rootId, long deptId) {
		//remove hard-code or define values for hard-code in constant files
		List<FolderObject> listOfFolder  = sessionFactory.getCurrentSession().createQuery(" FROM FolderObject where parentId=0 AND deptid = "+deptId+ " order by folderNm").list();
		if(listOfFolder != null){
			for(FolderObject folderObject:listOfFolder){
				//System.out.println("Parent Folder Name===="+folderObject.getFolderNm());
				getChildFoldersById(folderObject);
			} 
		}	
		return listOfFolder;
	}

	public FolderObject getFolderById(long folderId) {
		FolderObject folderObject = (FolderObject) sessionFactory.getCurrentSession().get(FolderObject.class,folderId);
		return folderObject;
	}

	/*//this method is not used also eliminate from dao also
	public void deleteFolderObject(FolderObject folderObject) {
		sessionFactory.getCurrentSession().delete(folderObject);
	}
*/
	//check duplication of method and remove unnecessary.
	public void updateFolderObject(FolderObject folderObject) {
		sessionFactory.getCurrentSession().update(folderObject);
	}

	public List<FolderObject> getParentFolderList() {
		  	
		List<FolderObject> listOfFolder  = sessionFactory.getCurrentSession().createQuery("FROM FolderObject where parentId=0 order by folderNm").list();
		if(listOfFolder != null){
			for(FolderObject folderObject:listOfFolder){
				//System.out.println("Parent Folder Name===="+folderObject.getFolderNm());
				getChildFolders(folderObject);
			} 
		}	
		return listOfFolder;
	}
	
	public void getChildFolders(FolderObject folderObject) {
		List<FolderObject> listOfSubFolder  =  (List<FolderObject>)  sessionFactory.getCurrentSession().createQuery("FROM FolderObject where parentId="+folderObject.getFolderId()+"  order by folderNm").list();
   		if(listOfSubFolder != null){
   			folderObject.setListOfFolder(listOfSubFolder);
   			for(FolderObject subFolderObject:listOfSubFolder){
   				//System.out.println("child Folder Name===="+subFolderObject.getFolderNm());
   				getChildFolders(subFolderObject);
   			}   	
   		}
	}
	
	public void getChildFoldersById(FolderObject folderObject) {
		List<FolderObject> listOfSubFolder  =  (List<FolderObject>)  sessionFactory.getCurrentSession().createQuery("FROM FolderObject where parentId="+folderObject.getFolderId()+" AND deptid="+folderObject.getDeptId()+" order by folderNm").list();
   		if(listOfSubFolder != null){
   			folderObject.setListOfFolder(listOfSubFolder);
   			for(FolderObject subFolderObject:listOfSubFolder){
   				//System.out.println("child Folder Name===="+subFolderObject.getFolderNm());
   				getChildFoldersById(subFolderObject);
   			}   	
   		}
	}

	/*public List<FolderObject> getChildFolderList(long rootId) {
		return sessionFactory.getCurrentSession().createQuery("FROM FolderObject where rootId="+rootId+" order by folderId ASC ").list();
	}*/
	
	//try to make one select query for following
	public FolderObject getFolderByIdForDefault(long folderId) {
		/*SELECT 
		(SELECT COUNT(*) from filemst where atribt='A') Actv, 
		(SELECT COUNT(*) from filemst where atribt='R'),
		(SELECT COUNT(*) from filemst where atribt='H'),
		(SELECT COUNT(*) from filemst where atribt='D'),
		(SELECT COUNT(*) from filemst where atribt='O')*/
		
		long pageCount = (Long)sessionFactory.getCurrentSession().createQuery("SELECT COALESCE(sum(pageCnt),0) FROM DocumentObject where folderId="+folderId+" OR rootId="+folderId).uniqueResult();
		long a0Size = (Long)sessionFactory.getCurrentSession().createQuery("SELECT COALESCE(sum(A0),0) FROM DocumentObject where folderId="+folderId+" OR rootId="+folderId).uniqueResult();
		long a1Size = (Long)sessionFactory.getCurrentSession().createQuery("SELECT COALESCE(sum(A1),0) FROM DocumentObject where folderId="+folderId+" OR rootId="+folderId).uniqueResult();
		long a2Size = (Long)sessionFactory.getCurrentSession().createQuery("SELECT COALESCE(sum(A2),0) FROM DocumentObject where folderId="+folderId+" OR rootId="+folderId).uniqueResult();
		long a3Size = (Long)sessionFactory.getCurrentSession().createQuery("SELECT COALESCE(sum(A3),0) FROM DocumentObject where folderId="+folderId+" OR rootId="+folderId).uniqueResult();
		long a4Size = (Long)sessionFactory.getCurrentSession().createQuery("SELECT COALESCE(sum(A4),0) FROM DocumentObject where folderId="+folderId+" OR rootId="+folderId).uniqueResult();
		System.out.println(pageCount);
		long activeCount = (Long)sessionFactory.getCurrentSession().createQuery("SELECT count(*) FROM DocumentObject where atriBt='A' AND folderId="+folderId).uniqueResult();
		long deactiveCount = (Long)sessionFactory.getCurrentSession().createQuery("SELECT count(*) FROM DocumentObject where atriBt='D' AND folderId="+folderId).uniqueResult();
		long readOnlyCount = (Long)sessionFactory.getCurrentSession().createQuery("SELECT count(*) FROM DocumentObject where atriBt='R' AND folderId="+folderId).uniqueResult();
		long hiddenCount = (Long)sessionFactory.getCurrentSession().createQuery("SELECT count(*) FROM DocumentObject where atriBt='H' AND folderId="+folderId).uniqueResult();
		long checkOutCount = (Long)sessionFactory.getCurrentSession().createQuery("SELECT count(*) FROM DocumentObject where atriBt='O' AND folderId="+folderId).uniqueResult();
		 
	//	 =   sessionFactory.getCurrentSession().createQuery(" SELECT u.userName,h.creationDt FROM MenuObject m, UACCObject u where m.menuId = u.uACCCompositeKey.mid and m.pageId = "+menuObject.getMenuId()+ " AND u.uACCCompositeKey.userId = "+userId).list();

		
		FolderObject folderObject = (FolderObject) sessionFactory.getCurrentSession().get(FolderObject.class,folderId);
		
		folderObject.setActiveCount(activeCount);
		folderObject.setCheckOutCount(checkOutCount);
		folderObject.setDeactiveCount(deactiveCount);
		folderObject.setHiddenCount(hiddenCount);
		folderObject.setReadOnlyCount(readOnlyCount);
		folderObject.setPageCount(pageCount);
		folderObject.setA0Size(a0Size);
		folderObject.setA1Size(a1Size);
		folderObject.setA2Size(a2Size);
		folderObject.setA3Size(a3Size);
		folderObject.setA4Size(a4Size);
		return folderObject;
	}
	
	
	// need to check and change following code
	 public FolderObject getClassFolder(int rootid) {
			return (FolderObject) sessionFactory.getCurrentSession().createQuery("FROM FolderObject where folderId="+rootid).uniqueResult();
	 }

	    // remove following method use above method also in dao
	//check duplication of method and remove unnecessary.
		public void updateFolderName(FolderObject folder) {
			sessionFactory.getCurrentSession().update(folder);
			/*String sql = "UPDATE FolderObject set folderNm='" + folder.getFolderNm() + "',readOnlyPublic='" + folder.getReadOnlyPublic() + "',"
					+ "readOnlyOthDept='"+folder.getReadOnlyOthDept()+"',atriBt='"+folder.getAtriBt()+"',isInnerFolders='"+folder.getIsInnerFolders()+"' where folderId='"
					+ folder.getFolderId() + "'";
			Query query = sessionFactory.getCurrentSession().createQuery(sql);
			query.executeUpdate();*/
		}
		
		//check duplication of method and remove unnecessary.
		public void saveFolders(FolderObject folderObject) {
			Session session = sessionFactory.getCurrentSession();
			String seqName = "FolderId";
			long currentVal = GeneralUtility.getIdForCurrentVal(session, seqName);
			folderObject.setFolderId(currentVal);
			folderObject.setLocation(folderObject.getLocation()+"~"+currentVal);
			sessionFactory.getCurrentSession().save(folderObject);
		}
		
	/*//code for increment and return currentVal through sp
			public long getIdForCurrentVal() {
				Session session = sessionFactory.getCurrentSession();
				StoredProcedureQuery storedProcedureQuery = session.createStoredProcedureQuery("increment_CurrentVal");
				storedProcedureQuery.registerStoredProcedureParameter("p_seqName", String.class, ParameterMode.IN);
				storedProcedureQuery.registerStoredProcedureParameter("currentVal", Integer.class, ParameterMode.OUT);
				storedProcedureQuery.setParameter("p_seqName", "FolderId");
				
				storedProcedureQuery.execute();
				int folderId = (Integer) storedProcedureQuery.getOutputParameterValue("currentVal");
				//System.out.println("folderId======="+folderId);
				return folderId;
			}
*/
		
		//check following-code and try to reduce code .
		//try to use one function for both and remove call for one unnecessary method .
		public String getPath(int folderId) {
			String folderName;
			String folderPath = "";
			int x = 0;
			Query query = sessionFactory.getCurrentSession().createNamedQuery("FolderObject.getpath_location")
					.setParameter(1, folderId);
			List<?> results = query.getResultList();
			//System.out.println("ArrayList : " + results);
			while (x < results.size()-1) {
				folderName = (String) results.get(x);
				String[] words = folderName.split(",");
				if (x == 0) {
					folderPath = words[2].replace(")", "");
				} else {
					folderPath = folderPath + "/" + words[2].replace(")", "");
				}
				//System.out.println(folderPath);
				x++;
			}
			return folderPath;
		}

		public String getLocation(int folderId) {
			String folderLoc;
			String folderLocation = "";
			int x = 0;
			Query query = sessionFactory.getCurrentSession().createNamedQuery("FolderObject.getpath_location")
					.setParameter(1, folderId);
			List results = query.getResultList();
			//System.out.println("ArrayList : " + results);
			while (x < results.size()) {
				folderLoc = (String) results.get(x);
				String[] words = folderLoc.split(",");
				if (x == 0) {
					folderLocation = words[0].replace("(", "");
				} else {
					folderLocation = folderLocation + "~" + words[0].replace("(", "");
				}
				//System.out.println(folderLocation);
				x++;
			}
			return folderLocation;
		}

		@Override
		public void updateClassCount(FolderObject folderObject) {
			sessionFactory.getCurrentSession().createQuery("Update ClassObject set folderCnt = "+folderObject.getFolderCnt()+"where classNm='"+folderObject.getFolderNm()+"'").executeUpdate();
		}


}
