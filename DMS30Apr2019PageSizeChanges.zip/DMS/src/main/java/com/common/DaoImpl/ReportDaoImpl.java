package com.common.DaoImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.ReportDao;
import com.common.Objects.DepartmentReport;
import com.common.Objects.FolderObject;

@Repository
@Transactional
public class ReportDaoImpl implements ReportDao{
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public List<DepartmentReport> getDepartmentWiseReport() {
		DepartmentReport departmentReport = new DepartmentReport();
		List<FolderObject> listOfFolder  = sessionFactory.getCurrentSession().createQuery("FROM FolderObject where parentId=0 order by folderNm").list();
		if(listOfFolder != null){
			for(FolderObject folderObject:listOfFolder){
				long pageCount = (Long)sessionFactory.getCurrentSession().createQuery("SELECT COALESCE(sum(pageCnt),0) FROM DocumentObject where folderId="+folderObject.getFolderId()+" OR rootId="+folderObject.getFolderId()).uniqueResult();
				long a0Size = (Long)sessionFactory.getCurrentSession().createQuery("SELECT COALESCE(sum(A0),0) FROM DocumentObject where folderId="+folderObject.getFolderId()+" OR rootId="+folderObject.getFolderId()).uniqueResult();
				long a1Size = (Long)sessionFactory.getCurrentSession().createQuery("SELECT COALESCE(sum(A1),0) FROM DocumentObject where folderId="+folderObject.getFolderId()+" OR rootId="+folderObject.getFolderId()).uniqueResult();
				long a2Size = (Long)sessionFactory.getCurrentSession().createQuery("SELECT COALESCE(sum(A2),0) FROM DocumentObject where folderId="+folderObject.getFolderId()+" OR rootId="+folderObject.getFolderId()).uniqueResult();
				long a3Size = (Long)sessionFactory.getCurrentSession().createQuery("SELECT COALESCE(sum(A3),0) FROM DocumentObject where folderId="+folderObject.getFolderId()+" OR rootId="+folderObject.getFolderId()).uniqueResult();
				long a4Size = (Long)sessionFactory.getCurrentSession().createQuery("SELECT COALESCE(sum(A4),0) FROM DocumentObject where folderId="+folderObject.getFolderId()+" OR rootId="+folderObject.getFolderId()).uniqueResult();
				
			} 
		}	
		return null;
	}

}
