package com.common.Embeddable;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class FileIdSeqNo implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Column(name = "fileId", nullable = false)
	public long fileId;
	
	
	@Column(name = "seqNo", nullable = false)
	public long seqNo;
	
	public FileIdSeqNo() {
		
	}
	
	public FileIdSeqNo(long fileId, long seqNo) {
		super();
		this.fileId = fileId;
		this.seqNo = seqNo;
	}

	public long getFileId() {
		return fileId;
	}
	public void setFileId(long fileId) {
		this.fileId = fileId;
	}
	public long getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(long seqNo) {
		this.seqNo = seqNo;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (fileId ^ (fileId >>> 32));
		result = prime * result + (int) (seqNo ^ (seqNo >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FileIdSeqNo other = (FileIdSeqNo) obj;
		if (fileId != other.fileId)
			return false;
		if (seqNo != other.seqNo)
			return false;
		return true;
	}
}
