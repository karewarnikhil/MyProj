package com.common.Objects;

public class DepartmentReport {
	
	private String folderNm;
	
    private int pageCnt; 
    
    private int A0; 
    
    private int A1; 
    
    private int A2; 
    
    private int A3; 
    
    private int A4;

	public String getFolderNm() {
		return folderNm;
	}

	public void setFolderNm(String folderNm) {
		this.folderNm = folderNm;
	}

	public int getPageCnt() {
		return pageCnt;
	}

	public void setPageCnt(int pageCnt) {
		this.pageCnt = pageCnt;
	}

	public int getA0() {
		return A0;
	}

	public void setA0(int a0) {
		A0 = a0;
	}

	public int getA1() {
		return A1;
	}

	public void setA1(int a1) {
		A1 = a1;
	}

	public int getA2() {
		return A2;
	}

	public void setA2(int a2) {
		A2 = a2;
	}

	public int getA3() {
		return A3;
	}

	public void setA3(int a3) {
		A3 = a3;
	}

	public int getA4() {
		return A4;
	}

	public void setA4(int a4) {
		A4 = a4;
	}

	public DepartmentReport(String folderNm, int pageCnt, int a0, int a1, int a2, int a3, int a4) {
		super();
		this.folderNm = folderNm;
		this.pageCnt = pageCnt;
		A0 = a0;
		A1 = a1;
		A2 = a2;
		A3 = a3;
		A4 = a4;
	}

	public DepartmentReport() {
		super();
	} 
    
    

}
