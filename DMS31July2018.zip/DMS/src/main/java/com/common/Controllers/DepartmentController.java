package com.common.Controllers;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.common.Dao.DepartmentDao;
import com.common.Objects.DepartmentObject;

@Controller
public class DepartmentController {
	  
	   @Autowired
	   private DepartmentDao departmentDao ;
	
	   @RequestMapping(value = "/registerDepartment", method = RequestMethod.GET)
	   public String showDepartmentForm(Model model){  
		   DepartmentObject departmentObject = new DepartmentObject();
	       model.addAttribute("department", departmentObject);
	       return "registerDepartment"; 
	   } 
	
	   @RequestMapping(value = "/saveDepartment", method = RequestMethod.POST)
	   public String saveDepartmentData(@ModelAttribute("department") DepartmentObject departmentObject, BindingResult result){
		   Date date = new Date();  
	       Timestamp ts = new Timestamp(date.getTime());  
	       departmentObject.setCreationDt(ts);
		   departmentDao.saveDepartmentObject(departmentObject);
	       return "redirect:/manageDepartment"; 
	   }  
	   
	   @RequestMapping(value="/manageDepartment", method = RequestMethod.GET)  
	   public ModelAndView manageDepartment(){  
		   List<DepartmentObject> departmentlist = departmentDao.getAllDepartments(); 
	       return new ModelAndView("manageDepartment","departmentlist",departmentlist);  
	   }  
	  
	   
	   @RequestMapping(value="/editDepartment", method = RequestMethod.GET)  
	   public ModelAndView editDepartment(@RequestParam("departmentId") Integer departmentId){  
		   DepartmentObject departmentObject = findByDepartmentId(departmentId);
	       return new ModelAndView("editDepartment","department",departmentObject);  
	   }  
	   
	   @RequestMapping(value="/showDepartment", method = RequestMethod.GET)  
	   public ModelAndView showDepartment(@RequestParam("departmentId") Integer departmentId){  
		   DepartmentObject departmentObject = findByDepartmentId(departmentId);
		   List<DepartmentObject> departmentlist = departmentDao.getAllDepartments(); 
		   ModelAndView modelAndView = new ModelAndView();
		   modelAndView.addObject("department",departmentObject);
		   modelAndView.addObject("departmentlist",departmentlist);
		  modelAndView.setViewName("home");
	       return modelAndView;  
	   }  
	   
	   @RequestMapping(value="/deleteDepartment", method = RequestMethod.GET)  
	   public String deleteDepartment(@RequestParam("departmentId") Integer departmentId,Model model){  
		   DepartmentObject departmentObject = findByDepartmentId(departmentId);
		   departmentDao.deleteDepartmentObject(departmentObject);
	       return "redirect:/manageDepartment";//will redirect to viewemp request mapping  
	   }  
	   
	   private DepartmentObject findByDepartmentId(Integer departmentId) {
		   DepartmentObject departmentObject =  departmentDao.getDepartmentById(departmentId); 
		   return departmentObject;
	   }
}
