package com.common.DaoImpl;

import java.util.List;

import javax.persistence.Query;
import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.ClassDao;
import com.common.Objects.ClassObject;

@Repository
@Transactional
public class ClassDaoImpl implements ClassDao{
	
	@Autowired
	private SessionFactory sessionFactory;
    
	public void saveClassObject(ClassObject classObject) {
		sessionFactory.getCurrentSession().saveOrUpdate(classObject);
	}

	public List<ClassObject> getAllClass() {
		return sessionFactory.getCurrentSession().createQuery(" FROM ClassObject").list();
	}

	public ClassObject getClassById(Integer classId) {
		ClassObject classObject = (ClassObject) sessionFactory.getCurrentSession().get(ClassObject.class,classId);
		return classObject;
	}

	public void deleteClassObject(ClassObject classObject) {
		sessionFactory.getCurrentSession().delete(classObject);
		
	}

}
