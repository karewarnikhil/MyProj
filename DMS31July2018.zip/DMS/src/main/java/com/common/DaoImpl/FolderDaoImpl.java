package com.common.DaoImpl;

import java.util.List;

import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.FolderDao;
import com.common.Objects.FolderObject;

@Repository
@Transactional
public class FolderDaoImpl implements FolderDao{
	
	@Autowired
	private SessionFactory sessionFactory;

	public void saveFolderObject(FolderObject folderObject) {
		Session session = sessionFactory.getCurrentSession();
		StoredProcedureQuery storedProcedureQuery = session.createStoredProcedureQuery("increment_CurrentVal");
		storedProcedureQuery.registerStoredProcedureParameter("p_seqName", String.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("currentVal", Integer.class, ParameterMode.OUT);
		storedProcedureQuery.setParameter("p_seqName", "FolderId");
		
		storedProcedureQuery.execute();
		int folderId = (Integer) storedProcedureQuery.getOutputParameterValue("currentVal");
		System.out.println("folderId======="+folderId);
		folderObject.setFolderId(folderId);
		sessionFactory.getCurrentSession().saveOrUpdate(folderObject);
		
	}

	public List<FolderObject> getAllFolders() {
		return sessionFactory.getCurrentSession().createQuery(" FROM FolderObject").list();
	}

	public FolderObject getFolderById(Integer folderId) {
		FolderObject folderObject = (FolderObject) sessionFactory.getCurrentSession().get(FolderObject.class,folderId);
		return folderObject;
	}

	public void deleteFolderObject(FolderObject folderObject) {
		sessionFactory.getCurrentSession().delete(folderObject);
	}

}
