package com.common.Objects;

public class AccessObject {
	
	boolean add;
	boolean remove;
	boolean view;
	boolean upload;
	boolean download;
	boolean change;
	
	
	public AccessObject() {
		
	}
	
	public AccessObject(boolean add, boolean remove, boolean view, boolean upload, boolean download, boolean change) {
		super();
		this.add = add;
		this.remove = remove;
		this.view = view;
		this.upload = upload;
		this.download = download;
		this.change = change;
	}
	
	
	public boolean isAdd() {
		return add;
	}
	public void setAdd(boolean add) {
		this.add = add;
	}
	public boolean isRemove() {
		return remove;
	}
	public void setRemove(boolean remove) {
		this.remove = remove;
	}
	public boolean isView() {
		return view;
	}
	public void setView(boolean view) {
		this.view = view;
	}
	public boolean isUpload() {
		return upload;
	}
	public void setUpload(boolean upload) {
		this.upload = upload;
	}
	public boolean isDownload() {
		return download;
	}
	public void setDownload(boolean download) {
		this.download = download;
	}
	public boolean isChange() {
		return change;
	}
	public void setChange(boolean change) {
		this.change = change;
	}
	
}
