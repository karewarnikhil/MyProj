package com.common.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.common.Dao.UsersDao;
import com.common.Objects.UsersObject;

@Controller
public class DemoController  {
	static final long serialVersionUID = 1L;

	@Autowired
	private UsersDao usersDao ;
	
	 @RequestMapping(value="/manageUsers", method = RequestMethod.GET)  
	   public String manageUser(Model model){  
	       List<UsersObject> userslist = usersDao.getAllUsers(); 
	       model.addAttribute("usersList", userslist);
	       return "manageUsers";
	 }  
	 
	 @RequestMapping(value = "/save", method = RequestMethod.POST)
	   public String saveData(@ModelAttribute("users") UsersObject users){  
		   usersDao.saveUsersObject(users);
	       return "redirect:/manageUsers"; 
	   }  
	 
	 @RequestMapping(value = "/addUser", method = RequestMethod.GET)
	   public String showform(Model model){  
	       UsersObject usersObject = new UsersObject();
	       model.addAttribute("users", usersObject);
	       return "registration"; 
	   } 
	   
	
	  
}
