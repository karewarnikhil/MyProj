package com.common.DaoImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.FolderDao;
import com.common.Objects.FolderObject;
import com.common.Objects.MenuObject;

@Repository
@Transactional
public class FolderDaoImpl implements FolderDao{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public void saveFolderObject(FolderObject folderObject) {
		sessionFactory.getCurrentSession().save(folderObject);
	}

	public List<FolderObject> getAllFolders() {
		return sessionFactory.getCurrentSession().createQuery(" FROM FolderObject").list();
	}

	public FolderObject getFolderById(long folderId) {
		FolderObject folderObject = (FolderObject) sessionFactory.getCurrentSession().get(FolderObject.class,folderId);
		return folderObject;
	}

	public void deleteFolderObject(FolderObject folderObject) {
		sessionFactory.getCurrentSession().delete(folderObject);
	}

	public void updateFolderObject(FolderObject folderObject) {
		sessionFactory.getCurrentSession().update(folderObject);
	}

	public List<FolderObject> getParentFolderList() {
		  	
		List<FolderObject> listOfFolder  = sessionFactory.getCurrentSession().createQuery("FROM FolderObject where rootId=0").list();
		if(listOfFolder != null){
			for(FolderObject folderObject:listOfFolder){
				getChildFolder(folderObject);
			} 
		}	
		return listOfFolder;
	}
	
	public void getChildFolder(FolderObject folderObject) {
		List<FolderObject> listOfSubFolder  =  (List<FolderObject>)  sessionFactory.getCurrentSession().createQuery("FROM FolderObject where rootId="+folderObject.getFolderId()).list();
   		if(listOfSubFolder != null){
   			folderObject.setListOfFolder(listOfSubFolder);
   			for(FolderObject subFolderObject:listOfSubFolder){
   				getChildFolder(subFolderObject);
   			}   	
   		}
	}

	public List<FolderObject> getChildFolderList(long rootId) {
		return sessionFactory.getCurrentSession().createQuery("FROM FolderObject where rootId="+rootId).list();
	}

}
