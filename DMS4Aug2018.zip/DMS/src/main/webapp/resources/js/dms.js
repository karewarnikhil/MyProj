$(document).ready(function(){
		  $('.dropdown-submenu a.test').on("click", function(e){
		    $(this).next('ul').toggle();
		    e.stopPropagation();
		    e.preventDefault();
		  });
		});
		
		
 (function($){
		$('.dropdown-menu a.dropdown-toggle').on('click', function(e) {
		  if (!$(this).next().hasClass('show')) {
			$(this).parents('.dropdown-menu').first().find('.show').removeClass("show");
		  }
		  var $subMenu = $(this).next(".dropdown-menu");
		  $subMenu.toggleClass('show');

		  $(this).parents('li.nav-item.dropdown.show').on('hidden.bs.dropdown', function(e) {
			$('.dropdown-submenu .show').removeClass("show");
		  });

		  return false;
		});
	})(jQuery)

function validateForm(formObject){
	 var userId = document.getElementById("userId").value;
	 //alert(userId);
	 //alert(formObject);
	 if(userId>0){
		 var action = formObject.action; 
		 formObject.action = 'changeUACC?userId='+userId;
		 action = formObject.action ;
		 //alert(action);
		 formObject.submit();
	 }
	 else{
		 return false;
	 } 
	
 }
 
 
 function deleteRecord(formObject){
	 var userId = document.getElementById("userId").value;
	 //alert(userId);
	 //alert(formObject);
	 if(userId>0){
		 var action = formObject.action; 
		 formObject.action = 'deleteFormUACCObject?userId='+userId;
		 action = formObject.action ;
		 //alert(action);
		 formObject.submit();
	 }
	 else{
		 return false;
	 } 
	
 }
 
 
 function accessFunction(link,accessVariable){
	 //alert(accessVariable);
	 //alert(link);
	 if(accessVariable == false){
		 alert("You Dont have authorize to do this functionality.");
		 return false;
	 }
	 else{
		 window.location.href = link;
		 //alert("aaaaa");
	 } 
 }
 
 

 function whichButton(event,linkEdit,linkShow) {
	 //alert("You pressed button: " + event.button)
	 if(event.button == 0){
		 window.location.href = linkEdit;
	 }
	 if(event.button == 2){
		 window.open(''+linkShow,'mywin',
		 'left=100, top=400, screenX=200, screenY=150,width=400,height=300,toolbar=1,resizable=0');
	 }
 }
 
 function storageTypeChange(type) {
	 var storageType = type;
	 if(storageType == 'DTBS'){
		 document.getElementById('driveNm').disabled = true;
	 }
	 if(storageType == 'DISC'){
		 document.getElementById('driveNm').disabled = false;
	 }
	 
 }
 
 
 function loadSubFolders(folderId) {
	 $.ajax({
			contentType : "application/json; charset=utf-8",
			dataType : "json",
			url : "loadChildFolders",
			type : 'GET',
			data : {
				id : folderId
			},
			success : function(response) {
				alert("Folder in");
			if(response.length > 0){
		  
		    for (i = 0; i < response.length; i++) {
		    	var rootId=response[i].rootId
		    	if(folderId == rootId){
                    $(".tree11").append("<ul id=tree1'><li onClick='loadSubFolders("+response[i].folderId+"')>"+response[i].folderNm+"</li></ul>");
		    	}
             }
			}
			else{
	    		alert("Not Containing folder.");
	    	}
		    },
			error : function(res, textStatus) {
				var msg = "Unable to load Subfolder";
				alert(msg);
			}
		});
}
 
 