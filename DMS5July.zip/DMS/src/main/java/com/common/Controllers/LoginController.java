package com.common.Controllers;

import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.common.Dao.MenuDao;
import com.common.Dao.UsersDao;
import com.common.Objects.MenuObject;
import com.common.Objects.UsersObject;

@Controller
@SessionAttributes("listOfMenu")
public class LoginController {

	@Autowired
	private UsersDao usersDao ;
	
	@Autowired
	private MenuDao menuDao;
	
	@RequestMapping(value = "/login")
	   public String login(Locale local, Model model) {
		   System.out.println("Local==="+local.getLanguage());
	       return "loginIn";
	   }
	 
	       @ModelAttribute("user")
	          public UsersObject setUpUserForm() {
	          return new UsersObject();
	       }
	        // Checks if the user credentials are valid or not.
	 	    @RequestMapping(value = "/userLogin", method = RequestMethod.POST)
	 	    public String loginUser(@RequestParam("userNameFn")String userName, @RequestParam("passwordFn")String password, @ModelAttribute("user") UsersObject usersObject, Model model) {
	 	    	usersObject = usersDao.getUsersByUserName(userName);
	            if((userName.equals(usersObject.getUserName())) && (password.equals(usersObject.getUserPassword())) ) {
	            	List<MenuObject> listOfMenu = (List<MenuObject>) menuDao.getMenuListByUserId(usersObject.getUserId());
	            	model.addAttribute("listOfMenu", listOfMenu);
	            	//return "displayMenu";
	            	return "home";
	            }
	            else {
	            	return "loginIn";
	            }
	 	    }
}
