package com.common.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.common.Dao.MenuDao;
import com.common.Dao.UsersDao;
import com.common.Objects.MenuObject;
import com.common.Objects.UsersObject;

@Controller
public class MenuController {

	   @Autowired
	   private MenuDao menuDao;
	   
	   @Autowired
	   private UsersDao usersDao;
	
	   @RequestMapping(value = "/registerMenu", method = RequestMethod.GET)
	   public String showMenuForm(Model model){  
		   MenuObject menuObject = new MenuObject();
	       model.addAttribute("menu", menuObject);
	       return "registerMenu"; 
	   } 
	   
	   @RequestMapping(value="/menuAccess", method = RequestMethod.GET)  
	   public String manageMenuAccess(Model model){  
	       List<MenuObject> menulist = menuDao.getMenuList();
	       List<UsersObject> usersObjects = usersDao.getAllUsers();
	       model.addAttribute("menulist", menulist);
	       model.addAttribute("usersList", usersObjects);
	       return "menuAccess";
	   } 
	
	   
}
