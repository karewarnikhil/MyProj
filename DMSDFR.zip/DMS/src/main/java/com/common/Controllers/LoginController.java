package com.common.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.common.Dao.UsersDao;
import com.common.Objects.UsersObject;

@Controller
public class LoginController {

	@Autowired
	private UsersDao usersDao ;
	
	/* @RequestMapping(value="/userLogin", method = RequestMethod.POST)  
	   public String loginUser(Model model){  
	      
	      return "";
	 }  */
	 
	 
	        // Checks if the user credentials are valid or not.
	 	    @RequestMapping(value = "/userLogin", method = RequestMethod.POST)
	 	    public String loginUser(@RequestParam("userNameFn")String userName, @RequestParam("passwordFn")String password) {
	        
	            UsersObject usersObject = usersDao.getUsersByUserName(userName);
	            if((userName.equals(usersObject.getUserName())) && (password.equals(usersObject.getUserPassword())) ) {
	            	
	            	return "home";
	            }
	            
	            else {
	            	return "login";
	            }
	 	    }
}
