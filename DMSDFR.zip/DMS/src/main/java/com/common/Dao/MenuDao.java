package com.common.Dao;

import java.util.List;

import com.common.Objects.MenuObject;

public interface MenuDao {
	 public List<MenuObject> getMenuObject(int userId);

}
