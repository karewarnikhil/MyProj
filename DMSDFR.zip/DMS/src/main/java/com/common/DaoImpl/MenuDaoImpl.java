package com.common.DaoImpl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.MenuDao;
import com.common.Objects.MenuObject;

@Repository
@Transactional
public class MenuDaoImpl implements MenuDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	public List<MenuObject> getMenuObject(int userId) {
		ArrayList<MenuObject> arrayListOfMenu;
		arrayListOfMenu =  (ArrayList<MenuObject>) sessionFactory.getCurrentSession().createQuery("from MenuObject m INNER JOIN uacc u ON m.mid = u.mid and u.pid=0 and u.userId = "+userId).list();
		
		if(arrayListOfMenu != null){
			ArrayList<MenuObject> arrayListOfSubMenu;
			for(int i=0;i<arrayListOfMenu.size();i++){
           		MenuObject menuObject = arrayListOfMenu.get(i);
           		arrayListOfSubMenu =  (ArrayList<MenuObject>) sessionFactory.getCurrentSession().createQuery("from MenuObject m INNER JOIN uacc u ON m.mid = u.mid and u.pid=0 and u.userId = "+userId).list();
           		menuObject.getArrayListOfMenu();
        }   	
		}
           	
		return arrayListOfMenu;
	}

}
