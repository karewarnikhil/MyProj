package com.common.Objects;

import java.util.ArrayList;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity @Table(name="menu")
public class MenuObject {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "mid", updatable = false, nullable = false)
	private int menuId;
	
	@Column(name="pid")
	private int pageId;
	
	@Column(name="menunm")
	private String MenuNm;
	
	@Column(name="pagenm")
	private String pageName;
	
	@Column(name="status")
	private String status;
	
	private ArrayList<MenuObject> arrayListOfMenu;

	public int getMenuId() {
		return menuId;
	}

	public void setMenuId(int menuId) {
		this.menuId = menuId;
	}

	public int getPageId() {
		return pageId;
	}

	public void setPageId(int pageId) {
		this.pageId = pageId;
	}

	public String getMenuNm() {
		return MenuNm;
	}

	public void setMenuNm(String menuNm) {
		MenuNm = menuNm;
	}

	public String getPageName() {
		return pageName;
	}

	public void setPageName(String pageName) {
		this.pageName = pageName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public ArrayList<MenuObject> getArrayListOfMenu() {
		return arrayListOfMenu;
	}

	public void setArrayListOfMenu(ArrayList<MenuObject> arrayListOfMenu) {
		this.arrayListOfMenu = arrayListOfMenu;
	}
	
	
	
	
	
}
