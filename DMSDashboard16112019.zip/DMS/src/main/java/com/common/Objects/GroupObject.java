package com.common.Objects;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity @Table(name="groupmst")
public class GroupObject implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "groupId", updatable = false, nullable = false)
	private  int groupId ;
	
	@Column(name="grpNm")
	private  String groupNm ;
	
	@Column(name="shrtNm")
	private  String shortNm ;
	
	
	@Column(name="creationDt")
	private  Timestamp creationDt ;
	
	@Column(name="status")
	private  String status ;
	
	

	public GroupObject() {
		super();
	}

	public GroupObject(int groupId, String groupNm, String shortNm, Timestamp creationDt, String status) {
		super();
		this.groupId = groupId;
		this.groupNm = groupNm;
		this.shortNm = shortNm;
		this.creationDt = creationDt;
		this.status = status;
	}

	public int getGroupId() {
		return groupId;
	}

	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}

	public String getGroupNm() {
		return groupNm;
	}

	public void setGroupNm(String groupNm) {
		this.groupNm = groupNm;
	}

	public String getShortNm() {
		return shortNm;
	}

	public void setShortNm(String shortNm) {
		this.shortNm = shortNm;
	}

	public Timestamp getCreationDt() {
		return creationDt;
	}

	public void setCreationDt(Timestamp creationDt) {
		this.creationDt = creationDt;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
}
