package com.common.Objects;

import java.util.List;

public class TagReportObject {
	
    private  Long fileId;
	
	private List<String> listOfTagData;
	
	public Long getFileId() {
		return fileId;
	}

	public void setFileId(Long fileId) {
		this.fileId = fileId;
	}

	public List<String> getListOfTagData() {
		return listOfTagData;
	}

	public void setListOfTagData(List<String> listOfTagData) {
		this.listOfTagData = listOfTagData;
	}

	public TagReportObject() {
		super();
	}

	public TagReportObject(Long fileId, List<String> listOfTagData) {
		super();
		this.fileId = fileId;
		this.listOfTagData = listOfTagData;
	}
	
	
	

}
