package com.common.DaoImpl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.ClassDao;
import com.common.Dao.FolderDao;
import com.common.Objects.ClassObject;
import com.common.Objects.FolderObject;
import com.common.Utilities.GeneralUtility;

@Repository
@Transactional
public class ClassDaoImpl implements ClassDao{
	
	@Autowired
	private SessionFactory sessionFactory;
	 
	@Autowired 
	FolderDao folderDao;
	

    
	public void saveClassObject(ClassObject classObject,FolderObject folderObject) {
		Session session = sessionFactory.getCurrentSession();
		 //Id used for folderId and classId
		String seqNm = "FolderId";
		long currentVal = GeneralUtility.getIdForCurrentVal(session,seqNm);
		classObject.setClassId(currentVal);
		folderObject.setFolderId(currentVal);
		FolderObject parentFolderObject = folderDao.getFolderById(0);
		folderObject.setFolderPath(parentFolderObject.getFolderPath()+"/"+folderObject.getFolderNm());
		folderObject.setLocation(parentFolderObject.getLocation()+"~"+folderObject.getFolderId());
		folderDao.saveFolderObject(folderObject);
		session.save(classObject);
	}
	

	public List<ClassObject> getAllClass(int userlevel,long deptId) {
		//try to change logic
		if(userlevel > 0)
			return sessionFactory.getCurrentSession().createQuery(" FROM ClassObject where deptid="+deptId+" order by classId desc").list();
		else
			return sessionFactory.getCurrentSession().createQuery(" FROM ClassObject order by classId desc").list();
	}

	public ClassObject getClassById(long classId) {
		ClassObject classObject = (ClassObject) sessionFactory.getCurrentSession().get(ClassObject.class,classId);
		return classObject;
	}

	/*public void deleteClassObject(ClassObject classObject) {
		sessionFactory.getCurrentSession().delete(classObject);
	}*/

	public void updateClassObject(ClassObject classObject) {
		FolderObject folderObject = folderDao.getFolderById(classObject.getClassId());
		folderObject.setFolderId(classObject.getClassId());
		folderObject.setFolderNm(classObject.getClassNm());
		folderObject.setReadOnlyOthDept(classObject.getReadOnlyOthDept());
		folderObject.setReadOnlyPublic(classObject.getReadOnlyPublic());
		folderObject.setIsInnerFolders(classObject.getIsInnerFolders());
		folderObject.setAtriBt(classObject.getAtriBt());
		
		//try to use one session factory for following code and one transactional roll back.
		folderDao.updateFolderObject(folderObject);
		sessionFactory.getCurrentSession().update(classObject);
	}
	
	//check and remove method not used also from dao
	 public List<ClassObject> getClasses() {
		return sessionFactory.getCurrentSession().createQuery(" FROM ClassObject").list();
	}

	@Override
	public List<ClassObject> getClassByDeptAndROP(long userDeptId) {
		/* CriteriaQuery<ClassObject> criteriaQuery = sessionFactory.getCurrentSession().getCriteriaBuilder().createQuery(ClassObject.class);
		 criteriaQuery.from(ClassObject.class).;
		List<ClassObject> listA = sessionFactory.getCurrentSession().createCriteria(ClassObject.class);
		
		CriteriaBuilder builder = sessionFactory.getCurrentSession().getCriteriaBuilder();
		CriteriaQuery<ClassObject> criteriaQuery = builder.createQuery(ClassObject.class);
        Root<ClassObject> root = criteriaQuery.from(ClassObject.class);
        criteriaQuery.select(root).where(builder.equal(root.get("deptid"), userDeptId));
        criteriaQuery.select(root).where(builder.equal(root.get("readOnlyPublic"), "Y"));
        
        Query<Department> q=session.createQuery(query);
        Department department=q.getSingleResult();
        System.out.println(department.getName());
        return listA;*/
		//check other solution defined in hibernate remove following tru to avoid memory leak of following .
		List<ClassObject> listA, listB;
		listA = sessionFactory.getCurrentSession().createQuery(" FROM ClassObject where deptid="+userDeptId).list();
		listB = sessionFactory.getCurrentSession().createQuery(" FROM ClassObject where (readOnlyPublic='Y' or readOnlyOthDept='Y')and deptid!="+userDeptId).list();
		List<ClassObject> union = new ArrayList<ClassObject>();
		union.addAll( listA );
		union.addAll( listB );
		return union;
		
	}

	@Override
	public Object getClassesForDropDown() {
		//status bit comes from constants file remove hard code
		return sessionFactory.getCurrentSession().createQuery(" FROM ClassObject where atriBt='A' order by classNm ").list();
	}

	/*@Override
	public ClassObject getClassByName(String classNm) {
		ClassObject classObject = (ClassObject) sessionFactory.getCurrentSession().createQuery("FROM ClassObject where classNm='"+classNm+"'");
		return classObject;
	}*/
	 
	

}
