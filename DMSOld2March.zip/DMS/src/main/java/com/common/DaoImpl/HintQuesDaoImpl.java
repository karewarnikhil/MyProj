package com.common.DaoImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.HintQuesDao;
import com.common.Objects.HintQuestObject;
@Repository
@Transactional
public class HintQuesDaoImpl implements HintQuesDao{
	
	//try to eliminate and put it in utility or common
	@Autowired
	private SessionFactory sessionFactory;
	
	public List<HintQuestObject> getAllHintQuestObject() {
		return sessionFactory.getCurrentSession().createQuery(" FROM HintQuestObject  ").list();
	}

}
