package com.common.DaoImpl;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.HisFolderDao;
import com.common.Objects.HisFolder;

@Repository
@Transactional
public class HisFolderDaoImpl implements HisFolderDao{

	//try to eliminate and put it in utility or common

	@Autowired
	private SessionFactory sessionFactory;
	
	//eliminate this class make one common class for all types of history methods 
	public void saveHistory(HisFolder hisFolder) {
		sessionFactory.getCurrentSession().saveOrUpdate(hisFolder);
	}

}
