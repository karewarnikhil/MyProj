package com.common.Objects;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Type;

import com.common.CompositeKey.DocumentCompositeKey;

@Entity @Table(name="FileMst")
public class DocumentObject implements Serializable{
	
	private static final long serialVersionUID = 1L;

	   /* @Id
	    @Column(name="fileid",updatable = false, nullable = false)
	    private long fileId; 
	   
	    @Column(name="Seqno") 
	    private long seqNo; 
	    
	    @Column(name = "folderid")
	    private long folderId;
	    @ManyToOne(targetEntity = FolderObject.class, fetch = FetchType.EAGER)
		@JoinColumn(nullable = false, name = "folderid")
		private FolderObject folderObject;

	    
	    @Column(name = "rootid")
	    private long rootId;
	    
	    @Column(name="filenm")
	    private String fileName;
	    
	    @Type(type = "org.hibernate.type.BinaryType")
	    @Column(name="filecontents")
	    private byte[] fileContent;
	     
	    @Column(name="FileExtn")
	    private String fileExtn;
	    
	    @Column(name="Atribt")
		private String atriBt;
	    
	    @Column(name="CreatedBy")
		private long createdBy;
	    
	    @Column(name="CreationDt")
		private Timestamp creationDt;
	     
	    @Column(name="modifiedby")
		private long modifiedBy;
	   
	    @Column(name="ModificationDt")
		private Timestamp modificationDt;
	   
	    @Column(name="PageCnt") 
	    private int pageCnt; 
	    
	    @Column(name="FilePath")
	    private String filePath;
	    
	    @Column(name="FileLocation")
	    private String fileLocation;
	    
	    @Column(name="TagStatus")
	    private String tagStatus;
	   
	    @Column(name="TagDtEntry")
		private Timestamp tagEntryDt;
	    
	    @Transient
	    private String extensionIcon;
	    
	    
		public String getExtensionIcon() {
			return extensionIcon;
		}

		public void setExtensionIcon(String extensionIcon) {
			this.extensionIcon = extensionIcon;
		}

		public DocumentObject() {
			super();
		}

		public DocumentObject(long fileId, long seqNo, FolderObject folderObject, long rootId, String fileName, byte[] fileContent,
				String fileExtn, String atriBt, long createdBy, Timestamp creationDt, long modifiedBy,
				Timestamp modificationDt, int pageCnt, String filePath, String fileLocation, String tagStatus,
				Timestamp tagEntryDt, String extensionIcon) {
			super();
			this.fileId = fileId;
			this.seqNo = seqNo;
			//this.folderId = folderId;
			this.folderObject = folderObject;
			this.rootId = rootId;
			this.fileName = fileName;
			this.fileContent = fileContent;
			this.fileExtn = fileExtn;
			this.atriBt = atriBt;
			this.createdBy = createdBy;
			this.creationDt = creationDt;
			this.modifiedBy = modifiedBy;
			this.modificationDt = modificationDt;
			this.pageCnt = pageCnt;
			this.filePath = filePath;
			this.fileLocation = fileLocation;
			this.tagStatus = tagStatus;
			this.tagEntryDt = tagEntryDt;
			this.extensionIcon = extensionIcon;
		}

		public DocumentObject(long fileId, long seqNo, FolderObject folderObject, long rootId, String fileName, String fileExtn,
				String atriBt, long createdBy) {
			super();
			this.fileId = fileId;
			this.seqNo = seqNo;
			this.folderObject = folderObject;
			//this.folderId = folderId;
			this.rootId = rootId;
			this.fileName = fileName;
			this.fileExtn = fileExtn;
			this.atriBt = atriBt;
			this.createdBy = createdBy;
		}

		public long getFileId() {
			return fileId;
		}

		public long getSeqNo() {
			return seqNo;
		}

		public void setSeqNo(long seqNo) {
			this.seqNo = seqNo;
		}

		public long getFolderId() {
			return folderId;
		}

		public void setFolderId(long folderId) {
			this.folderId = folderId;
		}
		
		

		public long getRootId() {
			return rootId;
		}

		public FolderObject getFolderObject() {
			return folderObject;
		}

		public void setFolderObject(FolderObject folderObject) {
			this.folderObject = folderObject;
		}

		public void setRootId(long rootId) {
			this.rootId = rootId;
		}

		public String getFileName() {
			return fileName;
		}

		public void setFileName(String fileName) {
			this.fileName = fileName;
		}

		public byte[] getFileContent() {
			return fileContent;
		}

		public void setFileContent(byte[] fileContent) {
			this.fileContent = fileContent;
		}

		public String getFileExtn() {
			return fileExtn;
		}

		public void setFileExtn(String fileExtn) {
			this.fileExtn = fileExtn;
		}

		public String getAtriBt() {
			return atriBt;
		}

		public void setAtriBt(String atriBt) {
			this.atriBt = atriBt;
		}

		public long getCreatedBy() {
			return createdBy;
		}

		public void setCreatedBy(long createdBy) {
			this.createdBy = createdBy;
		}

		public Timestamp getCreationDt() {
			return creationDt;
		}

		public void setCreationDt(Timestamp creationDt) {
			this.creationDt = creationDt;
		}

		public long getModifiedBy() {
			return modifiedBy;
		}

		public void setModifiedBy(long modifiedBy) {
			this.modifiedBy = modifiedBy;
		}

		public Timestamp getModificationDt() {
			return modificationDt;
		}

		public void setModificationDt(Timestamp modificationDt) {
			this.modificationDt = modificationDt;
		}

		public int getPageCnt() {
			return pageCnt;
		}

		public void setPageCnt(int pageCnt) {
			this.pageCnt = pageCnt;
		}

		public String getFilePath() {
			return filePath;
		}

		public void setFilePath(String filePath) {
			this.filePath = filePath;
		}

		public String getFileLocation() {
			return fileLocation;
		}

		public void setFileLocation(String fileLocation) {
			this.fileLocation = fileLocation;
		}

		public String getTagStatus() {
			return tagStatus;
		}

		public void setTagStatus(String tagStatus) {
			this.tagStatus = tagStatus;
		}

		public Timestamp getTagEntryDt() {
			return tagEntryDt;
		}

		public void setTagEntryDt(Timestamp tagEntryDt) {
			this.tagEntryDt = tagEntryDt;
		}

		public static long getSerialversionuid() {
			return serialVersionUID;
		}

		public void setFileId(long fileId) {
			this.fileId = fileId;
		}
*/

	

   /* @Id
    @Column(name="fileid",updatable = false, nullable = false)
    private long fileId; 
   
    @Column(name="Seqno") 
    private long seqNo; */
	
	@EmbeddedId
	private DocumentCompositeKey documentCompositeKey;
    
    @Column(name = "folderid")
    private long folderId;
    
    @Column(name = "rootid")
    private long rootId;
    
    @Column(name="filenm")
    private String fileName;
    
    @Lob
    @Type(type = "org.hibernate.type.BinaryType")
    @Column(name="filecontents")
    private byte[] fileContent;
     
    @Column(name="FileExtn")
    private String fileExtn;
    
    @Column(name="Atribt")
	private String atriBt;
    
	@JoinColumn(name="createdby", referencedColumnName="userId")
	/* UsersObject usersObject; */
	private long createdBy;
    
    @Column(name="CreationDt")
	private Timestamp creationDt;
     
    @Column(name="modifiedby")
	private long modifiedBy;
   
    @Column(name="ModificationDt")
	private Timestamp modificationDt;
   
    @Column(name="PageCnt") 
    private int pageCnt; 
    
    @Column(name="FilePath")
    private String filePath;
    
    @Column(name="FileLocation")
    private String fileLocation;
    
    @Column(name="TagStatus")
    private String tagStatus;
   
    @Column(name="TagDtEntry")
	private Timestamp tagEntryDt;
    
    @Column(name = "VerType")
	private String verType;
	
	@Column(name = "VerNo")
	private int verNo;
	
	@Column(name = "VerId")
	private int verId;
    
    @Transient
    private String extensionIcon;
    
    
	

	public DocumentObject() {
		super();
	}

	/*public DocumentObject(long fileId, long seqNo, long folderId, long rootId, String fileName, byte[] fileContent,
			String fileExtn, String atriBt, long createdBy, Timestamp creationDt, long modifiedBy,
			Timestamp modificationDt, int pageCnt, String filePath, String fileLocation, String tagStatus,
			Timestamp tagEntryDt, String verType, int verNo, int verId, String extensionIcon) {
		super();
		this.fileId = fileId;
		this.seqNo = seqNo;
		this.folderId = folderId;
		this.rootId = rootId;
		this.fileName = fileName;
		this.fileContent = fileContent;
		this.fileExtn = fileExtn;
		this.atriBt = atriBt;
		this.createdBy = createdBy;
		this.creationDt = creationDt;
		this.modifiedBy = modifiedBy;
		this.modificationDt = modificationDt;
		this.pageCnt = pageCnt;
		this.filePath = filePath;
		this.fileLocation = fileLocation;
		this.tagStatus = tagStatus;
		this.tagEntryDt = tagEntryDt;
		this.verType = verType;
		this.verNo = verNo;
		this.verId = verId;
		this.extensionIcon = extensionIcon;
	}

	public DocumentObject(long fileId, long seqNo, long folderId, long rootId, String fileName, String fileExtn,
			String atriBt, long createdBy, String tagStatus) {
		super();
		this.fileId = fileId;
		this.seqNo = seqNo;
		this.folderId = folderId;
		this.rootId = rootId;
		this.fileName = fileName;
		this.fileExtn = fileExtn;
		this.atriBt = atriBt;
		this.createdBy = createdBy;
		this.tagStatus = tagStatus;
		this.creationDt = creationDt;
	}
*/
	public String getVerType() {
		return verType;
	}

	public void setVerType(String verType) {
		this.verType = verType;
	}

	public int getVerNo() {
		return verNo;
	}

	public void setVerNo(int verNo) {
		this.verNo = verNo;
	}

	public int getVerId() {
		return verId;
	}

	public void setVerId(int verId) {
		this.verId = verId;
	}

	/*public long getFileId() {
		return fileId;
	}

	public long getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(long seqNo) {
		this.seqNo = seqNo;
	}
	
	public void setFileId(long fileId) {
		this.fileId = fileId;
	}*/

	public long getFolderId() {
		return folderId;
	}

	public void setFolderId(long folderId) {
		this.folderId = folderId;
	}

	public long getRootId() {
		return rootId;
	}

	public void setRootId(long rootId) {
		this.rootId = rootId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public byte[] getFileContent() {
		return fileContent;
	}

	public void setFileContent(byte[] fileContent) {
		this.fileContent = fileContent;
	}

	public String getFileExtn() {
		return fileExtn;
	}

	public void setFileExtn(String fileExtn) {
		this.fileExtn = fileExtn;
	}

	public String getAtriBt() {
		return atriBt;
	}

	public void setAtriBt(String atriBt) {
		this.atriBt = atriBt;
	}

	public long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}
	
	

	public Timestamp getCreationDt() {
		return creationDt;
	}
	
	public void setCreationDt(Timestamp creationDt) {
		this.creationDt = creationDt;
	}

	/*
	 * public UsersObject getUsersObject() { return usersObject; }
	 * 
	 * public void setUsersObject(UsersObject usersObject) { this.usersObject =
	 * usersObject; }
	 */


	public long getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(long modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Timestamp getModificationDt() {
		return modificationDt;
	}

	public void setModificationDt(Timestamp modificationDt) {
		this.modificationDt = modificationDt;
	}

	public int getPageCnt() {
		return pageCnt;
	}

	public void setPageCnt(int pageCnt) {
		this.pageCnt = pageCnt;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getFileLocation() {
		return fileLocation;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}

	public String getTagStatus() {
		return tagStatus;
	}

	public void setTagStatus(String tagStatus) {
		this.tagStatus = tagStatus;
	}

	public Timestamp getTagEntryDt() {
		return tagEntryDt;
	}

	public void setTagEntryDt(Timestamp tagEntryDt) {
		this.tagEntryDt = tagEntryDt;
	}
	
	public String getExtensionIcon() {
		return extensionIcon;
	}

	public void setExtensionIcon(String extensionIcon) {
		this.extensionIcon = extensionIcon;
	}

	public DocumentCompositeKey getDocumentCompositeKey() {
		return documentCompositeKey;
	}

	public void setDocumentCompositeKey(DocumentCompositeKey documentCompositeKey) {
		this.documentCompositeKey = documentCompositeKey;
	}


	public DocumentObject(DocumentCompositeKey documentCompositeKey, long folderId, long rootId, String fileName,
			byte[] fileContent, String fileExtn, String atriBt, long createdBy, Timestamp creationDt, long modifiedBy,
			Timestamp modificationDt, int pageCnt, String filePath, String fileLocation, String tagStatus,
			Timestamp tagEntryDt, String verType, int verNo, int verId, String extensionIcon) {
		super();
		this.documentCompositeKey = documentCompositeKey;
		this.folderId = folderId;
		this.rootId = rootId;
		this.fileName = fileName;
		this.fileContent = fileContent;
		this.fileExtn = fileExtn;
		this.atriBt = atriBt;
		this.createdBy = createdBy;
		this.creationDt = creationDt;
		this.modifiedBy = modifiedBy;
		this.modificationDt = modificationDt;
		this.pageCnt = pageCnt;
		this.filePath = filePath;
		this.fileLocation = fileLocation;
		this.tagStatus = tagStatus;
		this.tagEntryDt = tagEntryDt;
		this.verType = verType;
		this.verNo = verNo;
		this.verId = verId;
		this.extensionIcon = extensionIcon;
	}

	public DocumentObject(DocumentCompositeKey documentCompositeKey, long folderId, long rootId, String fileName,
			String fileExtn, String atriBt, long userId, String tagStatus) {
		super();
		this.documentCompositeKey = documentCompositeKey;
		this.folderId = folderId;
		this.rootId = rootId;
		this.fileName = fileName;
		this.fileExtn = fileExtn;
		this.atriBt = atriBt;
		this.createdBy = userId;
		this.tagStatus = tagStatus;
	}
	
	

	

	

		
		
		
		

		
        
		
		

		

}
