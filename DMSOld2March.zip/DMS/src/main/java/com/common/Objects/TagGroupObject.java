package com.common.Objects;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity 
@Table(name="TagGrpMst")
public class TagGroupObject implements Serializable{

	private static final long serialVersionUID = 1L;
	
    @Id
    @Column(name = "tagGrpId", updatable = false, nullable = false)
	private long tagGrpId;
	
	@Column(name="taggrpnm")
	private String tagGrpNm;
	
	@Column(name="createdby")
	private int createdBy;
	
	@Column(name="creationDt")
	private  Timestamp creationDt ;
	
	@Column(name="status")
	private String status;
	
	@Transient
    private long fileId;

	

	public TagGroupObject() {
		super();
	}

	

	

	public TagGroupObject(long tagGrpId, String tagGrpNm, int createdBy, Timestamp creationDt, String status,
			long fileId) {
		super();
		this.tagGrpId = tagGrpId;
		this.tagGrpNm = tagGrpNm;
		this.createdBy = createdBy;
		this.creationDt = creationDt;
		this.status = status;
		this.fileId = fileId;
	}





	public long getTagGrpId() {
		return tagGrpId;
	}

	public void setTagGrpId(long tagGrpId) {
		this.tagGrpId = tagGrpId;
	}

	public String getTagGrpNm() {
		return tagGrpNm;
	}

	public void setTagGrpNm(String tagGrpNm) {
		this.tagGrpNm = tagGrpNm;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}


	public Timestamp getCreationDt() {
		return creationDt;
	}

	public void setCreationDt(Timestamp creationDt) {
		this.creationDt = creationDt;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public long getFileId() {
		return fileId;
	}

	public void setFileId(long fileId) {
		this.fileId = fileId;
	}
    
	
	
}
