package com.common.Controllers;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.common.Dao.ClassDao;
import com.common.Dao.DepartmentDao;
import com.common.Objects.ClassObject;
import com.common.Objects.DepartmentObject;
import com.common.Objects.FolderObject;
import com.common.Objects.UsersObject;

@Controller
public class ClassController {
	   
	   @Autowired
	   ClassDao classDao;
	   
	   @Autowired 
	   DepartmentDao departmentDao;
	   
	   public FolderObject folderObject;
	   
	   //check following requirement of new FolderObject in constructor
	   public ClassController() {
		super();
		folderObject = new FolderObject();
	   }

	@RequestMapping(value = "/registerClass", method = RequestMethod.GET)
	   public String showClassForm(Model model){  
		   ClassObject classObject = new ClassObject();
		   //change logic comes from hash map and defined in constant file.
		   List<DepartmentObject> departmentList = departmentDao.getAllDepartmentsForAddUser();
	       model.addAttribute("class", classObject);
	       model.addAttribute("departmentList",departmentList);
	       return "registerClass"; 
	   } 
	
	   @RequestMapping(value = "/saveClass", method = RequestMethod.POST)
	   public String saveClassData(@ModelAttribute("class") ClassObject classObject, BindingResult result, HttpServletRequest request,Model model){
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
	       Timestamp ts = new Timestamp(new Date().getTime());  
	       classObject.setCreationDt(ts);
	       classObject.setCreatedBy(usersSessionObject.getUserId());
	       //remove hardCoding
	       classObject.setAtriBt("A");
	       folderObject = creatingAndSavingFolderObject(classObject,usersSessionObject);
	       classDao.saveClassObject(classObject,folderObject);
	       //return "redirect:/manageClass"; 
	       
	       classObject = new ClassObject();
		   model.addAttribute("class", classObject);
		   model.addAttribute("message", "Class Saved Successfully.");
	       return "registerClass";
	   }  
	   
	   @RequestMapping(value = "/updateClass", method = RequestMethod.POST)
	   public String updateClassData(@ModelAttribute("class") ClassObject classObject, BindingResult result,Model model){
	       classDao.updateClassObject(classObject);
	       model.addAttribute("message", "Class Updated Successfully.");
		   model.addAttribute("class",classObject);
	       return "editClass";
	       //return "redirect:/manageClass"; 
	   }  
	   
	   private FolderObject creatingAndSavingFolderObject(ClassObject classObject,UsersObject usersObject) {
		   folderObject.setFolderNm(classObject.getClassNm());
		   //remove following hardCoding
		   folderObject.setParentId(0);
		   folderObject.setRootId(0);
		   folderObject.setUsersObject(usersObject);
		  // folderObject.setCreatedBy(classObject.getCreatedBy());
		   folderObject.setCreationDt(classObject.getCreationDt());
		   folderObject.setDepartmentObject(classObject.getDepartmentObject());
		   folderObject.setIsInnerFolders(classObject.getIsInnerFolders());
		   folderObject.setAtriBt(classObject.getAtriBt());
		   
		   folderObject.setReadOnlyOthDept(classObject.getReadOnlyOthDept());
		   folderObject.setReadOnlyPublic(classObject.getReadOnlyPublic());
		return folderObject;
	   }

	   @RequestMapping(value="/manageClass", method = RequestMethod.GET)  
	   public ModelAndView manageClass(HttpServletRequest request){  
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   List<ClassObject> classlist = classDao.getAllClass(usersSessionObject.getUserlevel(),usersSessionObject.getDepartmentObject().getDeptId()); 
		  // System.out.println("classlist===="+classlist.size());
	       return new ModelAndView("manageClass","classlist",classlist);  
	   }  
	  
	   @RequestMapping(value="/editClass", method = RequestMethod.GET)  
	   public ModelAndView editClass(@RequestParam("classId") long classId,Model model){  
		   ClassObject classObject = findByClassId(classId);
	       return new ModelAndView("editClass","class",classObject);  
	   }  
	   
	   
	 /*  @RequestMapping(value="/deleteClass", method = RequestMethod.GET)  
	   public String deleteDepartment(@RequestParam("classId") long classId,Model model){  
		   ClassObject classObject = findByClassId(classId);
		   classDao.deleteClassObject(classObject);
	       return "redirect:/manageClass";//will redirect to viewemp request mapping  
	   }  */
	   
	   private ClassObject findByClassId(long classId) {
		   ClassObject classObject =  classDao.getClassById(classId); 
		   return classObject;
	   }
}
