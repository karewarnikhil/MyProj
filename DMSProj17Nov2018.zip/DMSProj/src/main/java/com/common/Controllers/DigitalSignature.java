package com.common.Controllers;

import java.lang.reflect.Constructor;
import java.security.KeyStore;
import java.security.Provider;
import java.security.Security;
import java.util.Enumeration;

/**
 * This samples demonstrates using a hardware token to apply a digital signature to a document, using PKCS#11.
 * Java has some support for PKCS#11 through its SunPKCS11 class, in JDK 1.6.0.  The class takes a configuration
 * file that points to the native library that works with the hardware token.
 * 
 * @author Qoppa Software
 *
 */
public class DigitalSignature 
{
	public static void main (String [] args)
	{
		try 
		{
			// Get constructor to the Sun PKCS11 provider
			Class<?> pkcs11Class = Class.forName("sun.security.pkcs11.SunPKCS11");
			Constructor<?> construct = pkcs11Class.getConstructor(new Class[] {String.class});

			// Construct the provider
			String configName = "pkcs11.cfg";
			Provider p = (Provider)construct.newInstance(new Object[] {configName});
			Security.addProvider(p);

			// Create key store
			KeyStore ks = KeyStore.getInstance("PKCS11");
			ks.load(null, "tokenpwd".toCharArray());

			// Get the alias of the first entry in the keystore
			Enumeration<?> aliases = ks.aliases();
			if (aliases.hasMoreElements() == false)
			{
				System.out.println ("No digital IDs found in token.");
				System.exit(-1);
			}
			String idAlias = (String)aliases.nextElement();

			/*// Load PDF document with jPDFSecure
			PDFSecure pdf = new PDFSecure ("input.pdf", null);
			
			// Add a signature field to the document
			SignatureField signField = pdf.addSignatureField(0, "SignHere", new Rectangle2D.Double(180, 72, 200, 60));
			
			// Create signature information from the keystore
			SigningInformation signingInfo = new SigningInformation(ks, idAlias, "");
			
			// Sign and save the document
			pdf.signDocument(signField, signingInfo);
			pdf.saveDocument("signed.pdf");*/
		}
		catch (Throwable t)
		{
			t.printStackTrace();
		}
	}
	
	
	
	
/*	String userFile = "C:/results/test.pdf";
    String userFile_signed = "C:/results/test_signed.pdf";

    String pkcs11Config = "name=eToken\nlibrary=C:\\Windows\\System32\\eps2003csp11.dll";
    java.io.ByteArrayInputStream pkcs11ConfigStream = new java.io.ByteArrayInputStream(pkcs11Config.getBytes());
    sun.security.pkcs11.SunPKCS11 providerPKCS11 = new sun.security.pkcs11.SunPKCS11(pkcs11ConfigStream);
    java.security.Security.addProvider(providerPKCS11);

    // Get provider KeyStore and login with PIN
    String pin = "12345678";
    java.security.KeyStore keyStore = java.security.KeyStore.getInstance("PKCS11", providerPKCS11);
    keyStore.load(null, pin.toCharArray());

    // Enumerate items (certificates and private keys) in the KeyStore
    java.util.Enumeration<String> aliases = keyStore.aliases();
    String alias = null;
    while (aliases.hasMoreElements()) {
        alias = aliases.nextElement();
        System.out.println(alias);
    }

     PrivateKey pk = (PrivateKey)keyStore.getKey(alias, "12345678".toCharArray());
        Certificate[] chain = keyStore.getCertificateChain(alias);
        OcspClient ocspClient = new OcspClientBouncyCastle();
        TSAClient tsaClient = null;
        for (int i = 0; i < chain.length; i++) {
            X509Certificate cert = (X509Certificate)chain[i];
            String tsaUrl = CertificateUtil.getTSAURL(cert);
            if (tsaUrl != null) {
                tsaClient = new TSAClientBouncyCastle(tsaUrl);
                break;
            }
        }
        List<CrlClient> crlList = new ArrayList<CrlClient>();
        crlList.add(new CrlClientOnline(chain));
        Test t = new Test();
        t.sign(userFile, userFile_signed, chain, pk, DigestAlgorithms.SHA256, providerPKCS11.getName(),
                     CryptoStandard.CMS, "Test", "Signature", crlList, ocspClient, tsaClient, 0);
}
public void sign(String src, String dest,
        Certificate[] chain, PrivateKey pk,
        String digestAlgorithm, String provider, CryptoStandard subfilter,
        String reason, String location,
        Collection<CrlClient> crlList,
        OcspClient ocspClient,
        TSAClient tsaClient,
        int estimatedSize)
                throws GeneralSecurityException, IOException, DocumentException {
    // Creating the reader and the stamper
    PdfReader reader = new PdfReader(src);
    FileOutputStream os = new FileOutputStream(dest);
    PdfStamper stamper = PdfStamper.createSignature(reader, os, '\0');
    // Creating the appearance
    PdfSignatureAppearance appearance = stamper.getSignatureAppearance();
    appearance.setReason(reason);
    appearance.setLocation(location);
    appearance.setVisibleSignature(new Rectangle(100, 100, 200, 200), 1, "sig");
    // Creating the signature
    ExternalSignature pks = new PrivateKeySignature(pk, digestAlgorithm, provider);
    ExternalDigest digest = new BouncyCastleDigest();
    MakeSignature.signDetached(appearance, digest, pks, chain, crlList, ocspClient, tsaClient, estimatedSize, subfilter);
}*/
	
	
	
	
	
	/*try {
        String pkcs11Config = "name=GemPC" + "\n" + "library=C:/WINDOWS/system32/pteidpkcs11.dll";
        ByteArrayInputStream configStream = new ByteArrayInputStream(pkcs11Config.getBytes());
        Provider pkcs11Provider = new sun.security.pkcs11.SunPKCS11(configStream);

        Security.addProvider(pkcs11Provider);
        CallbackHandler cmdLineHdlr = new DialogCallbackHandler();

        KeyStore.Builder builder = KeyStore.Builder.newInstance("PKCS11", pkcs11Provider,
                new KeyStore.CallbackHandlerProtection(cmdLineHdlr));

        KeyStore ks = builder.getKeyStore();

        PdfReader pdf = new PdfReader(filePath);
        FileOutputStream fos = new FileOutputStream(dest);
        PdfStamper stp = PdfStamper.createSignature(pdf, fos, '\0');
        PdfSignatureAppearance sap = stp.getSignatureAppearance();
        sap.setReason("I'm the author");

        String alias = (String) ks.aliases().nextElement();

        PrivateKey pk = (PrivateKey) ks.getKey("CITIZEN SIGNATURE CERTIFICATE", null);
        Certificate chain = ks.getCertificate(alias);

        X509Certificate x509 = (X509Certificate) chain;
        x509.checkValidity();

        ExternalSignature es = new PrivateKeySignature(pk, "SHA-1", "BC");
        ExternalDigest digest = new BouncyCastleDigest();
        Certificate[] certs = new Certificate[1];
        certs[0] = chain;

        MakeSignature.signDetached(sap, digest, es, certs, null, null, null, 0, CryptoStandard.CMS);
        return dest;
    } catch (CertificateExpiredException | CertificateNotYetValidException ex) {
        Logger.getLogger(Signer.class.getName()).log(Level.SEVERE, null, ex);
        return null;
    }
    
    
    
    
    
    
    import com.lowagie.text.pdf.*;
import com.lowagie.text.Rectangle;
//import com.lowagie.text.pdf.pdfSignatureAppearance;
//import com.lowagie.text.pdf.pdfStamper;
import java.security.*;
import java.io.*;
import java.awt.*;
import java.security.cert.*;
import java.lang.*;
 
import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.cert.CertPath;
import java.security.cert.CertificateFactory;
import java.util.ArrayList;
import java.util.List;
 
 
 
public class pdfsign1{
  public static void main(String args[]) {
try {
KeyStore ks = KeyStore.getInstance("pkcs12");
ks.load(new FileInputStream("my_private_key.pfx"), "my_password".toCharArray());
String alias = (String)ks.aliases().nextElement();
PrivateKey key = (PrivateKey)ks.getKey(alias, "my_password".toCharArray());
[b]Certificate[] chain = ks.getCertificateChain(alias);[/b]
PdfReader reader = new PdfReader("original.pdf");
FileOutputStream fout = new FileOutputStream("signed.pdf");
PdfStamper stp = PdfStamper.createSignature(reader, fout, '\0');
PdfSignatureAppearance sap = stp.getSignatureAppearance();
//sap.setCrypto(key, chain, null, PdfSignatureAppearance.WINCER_SIGNED);
sap.setReason("I'm the author");
sap.setLocation("Lisbon");
// comment next line to have an invisible signature
sap.setVisibleSignature(new Rectangle(100, 100, 200, 200), 1, null);
stp.close();
  }
catch(Exception e) {}
}
}


import com.lowagie.text.pdf.*;
import com.lowagie.text.Rectangle;
import java.security.*;
import java.io.*;
import java.awt.*;
import java.lang.*;
import javax.net.ssl.*;
import javax.net.ssl.KeyManager;
import javax.naming.*;
import javax.naming.Context;
 
public class pdfsign1{
  public static void main(String args[]) throws IOException{
try {
//KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509"); 
//KeyStore ks = KeyStore.getInstance("pkcs12");
//ks.load(new FileInputStream("D:\\pdf\\pdf2\\digital\\my_private_key.pfx"), "my_password".toCharArray());
//kmf.init(ks, "my_password".toCharArray());
 
SSLContext ctx=SSLContext.getInstance("SSL");
KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509"); 
KeyStore ks = KeyStore.getInstance("pkcs12");
ks.load(new FileInputStream("c:\\excel\\my_private_key.pfx"), "my_password".toCharArray());
kmf.init(ks, "my_password".toCharArray());
ctx.init(kmf.getKeyManagers(),null,null);
 
//initSSLContext(kmf.getKeyManagers());
//KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
//ks.load(new FileInputStream("keystore.ks"), "my_password".toCharArray());
String alias = (String)ks.aliases().nextElement();
PrivateKey key = (PrivateKey)ks.getKey(alias,"my_password".toCharArray());
java.security.cert.Certificate[] chain = ks.getCertificateChain(alias);
PdfReader reader = new PdfReader("original.pdf");
FileOutputStream fout = new FileOutputStream("signed.pdf");
PdfStamper stp = PdfStamper.createSignature(reader, fout, '\0');
PdfSignatureAppearance sap = stp.getSignatureAppearance();
//sap.setCrypto(key, chain, null, PdfSignatureAppearance.WINCER_SIGNED);
sap.setCrypto(key, chain, null, PdfSignatureAppearance.SELF_SIGNED);
sap.setReason("I'm the author");
sap.setLocation("Lisbon");
// comment next line to have an invisible signature
sap.setVisibleSignature(new Rectangle(100, 100, 200, 200), 1, null);
stp.close();
  }
catch(Exception e) {e.printStackTrace();}
}
}




    
  
    */
	
	
	
	
	
	

}