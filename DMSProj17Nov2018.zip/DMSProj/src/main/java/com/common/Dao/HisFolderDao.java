package com.common.Dao;

import com.common.Objects.HisFolder;

public interface HisFolderDao {
  public void saveHistory(HisFolder hisFolder);
}
