package com.common.DaoImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.UsersDao;
import com.common.Objects.UsersObject;

@Repository
@Transactional
public class UsersDaoImpl implements UsersDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	public void saveUsersObject(UsersObject users) {
		sessionFactory.getCurrentSession().save(users);
	}

	public List<UsersObject> getAllUsers() {
		return sessionFactory.getCurrentSession().createQuery("from UsersObject order by userId desc").list();
	}
	
	public UsersObject getUsersById(Integer userId) {
		UsersObject usersObject = (UsersObject) sessionFactory.getCurrentSession().get(UsersObject.class,userId);
		return usersObject;
	}

	/*public void deleteUserObject(UsersObject usersObject) {
		sessionFactory.getCurrentSession().delete(usersObject);
	}*/

	public UsersObject getUsersByUserName(String emailId) {
		UsersObject usersObject = (UsersObject) sessionFactory.getCurrentSession().createQuery(" from UsersObject where emailId = '"+emailId+"'").uniqueResult();
		return usersObject;
	}
	
	public void updateUser(UsersObject usersObject) {
		sessionFactory.getCurrentSession().update(usersObject);
	}
	
	public List<UsersObject> getAllUsersForMenu() {
		//remove hard-coded values and get it from constant files
		//try to make common logic for both
		return sessionFactory.getCurrentSession().createQuery("from UsersObject where status='A' order by userName").list();
	}
	
}




