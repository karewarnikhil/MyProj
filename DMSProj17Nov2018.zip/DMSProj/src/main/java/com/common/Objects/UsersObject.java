package com.common.Objects;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
//check following code for session values
@Component
@Scope("session")
@Entity @Table(name="usermst")
public class UsersObject implements Serializable{



	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "userId", updatable = false, nullable = false)
	private  int userId ;
	
	@Column(name="emailId")
	private  String emailId ;
	
	@Column(name="username")
	private  String userName ;
	
	
	@Column(name="address")
	private  String address ;
	
	@Column(name="mobno")
	private BigDecimal mobileNo ;
	
	@Column(name="userlevel")
	private  int userlevel ;
	
	@Column(name="hintid")
	private  int hintId ;

    @OneToOne(targetEntity = DepartmentObject.class, fetch = FetchType.EAGER)
    @JoinColumn(nullable = false, name = "deptid")
    private DepartmentObject departmentObject;
    
	
	@OneToOne(targetEntity = DesignationObject.class, fetch = FetchType.EAGER)
    @JoinColumn(nullable = false, name = "desgid")
	private DesignationObject designationObject;
	
	@OneToOne(targetEntity = GroupObject.class, fetch = FetchType.EAGER)
    @JoinColumn(nullable = false, name = "groupId")
	private GroupObject groupObject;
	
	@Column(name="createdby")
	private  String createdBy ;
	
	@Column(name="upw1")
	private  String userPassword ;
	
	@Column(name="upw2")
	private  String userPasswordOne ;
	
	@Column(name="upw3")
	private  String userPasswordTwo ;
	
	@Column(name="hintans")
	private  String hintAnswer ;
	
	@Column(name="status")
	private  String status = "A";
	
	@Column(name="creationDt")
	private Timestamp creationDt;
	
	@Transient
	private List<String> groupList;
	
    @Transient
    private AccessObject accessObject;
    
	
	public UsersObject(int userId, String emailId, String userName, String address, BigDecimal mobileNo, int userlevel,
			int hintId, DepartmentObject departmentObject, DesignationObject designationObject, GroupObject groupObject,
			String createdBy, String userPassword, String userPasswordOne, String userPasswordTwo, String hintAnswer,
			String status, Timestamp creationDt, List<String> groupList, AccessObject accessObject) {
		super();
		this.userId = userId;
		this.emailId = emailId;
		this.userName = userName;
		this.address = address;
		this.mobileNo = mobileNo;
		this.userlevel = userlevel;
		this.hintId = hintId;
		this.departmentObject = departmentObject;
		this.designationObject = designationObject;
		this.groupObject = groupObject;
		this.createdBy = createdBy;
		this.userPassword = userPassword;
		this.userPasswordOne = userPasswordOne;
		this.userPasswordTwo = userPasswordTwo;
		this.hintAnswer = hintAnswer;
		this.status = status;
		this.creationDt = creationDt;
		this.groupList = groupList;
		this.accessObject = accessObject;
	}

	public UsersObject(){
    	super();
    }

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public BigDecimal getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(BigDecimal mobileNo) {
		this.mobileNo = mobileNo;
	}

	public int getUserlevel() {
		return userlevel;
	}

	public void setUserlevel(int userlevel) {
		this.userlevel = userlevel;
	}

	public int getHintId() {
		return hintId;
	}

	public void setHintId(int hintId) {
		this.hintId = hintId;
	}

	public DepartmentObject getDepartmentObject() {
		return departmentObject;
	}

	public void setDepartmentObject(DepartmentObject departmentObject) {
		this.departmentObject = departmentObject;
	}

	public DesignationObject getDesignationObject() {
		return designationObject;
	}

	public void setDesignationObject(DesignationObject designationObject) {
		this.designationObject = designationObject;
	}

	public GroupObject getGroupObject() {
		return groupObject;
	}

	public void setGroupObject(GroupObject groupObject) {
		this.groupObject = groupObject;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getHintAnswer() {
		return hintAnswer;
	}

	public void setHintAnswer(String hintAnswer) {
		this.hintAnswer = hintAnswer;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getCreationDt() {
		return creationDt;
	}
	
	
	public void setCreationDt(Timestamp creationDt) {
		this.creationDt = creationDt;
	}

	public String getUserPasswordOne() {
		return userPasswordOne;
	}

	public void setUserPasswordOne(String userPasswordOne) {
		this.userPasswordOne = userPasswordOne;
	}

	public String getUserPasswordTwo() {
		return userPasswordTwo;
	}

	public void setUserPasswordTwo(String userPasswordTwo) {
		this.userPasswordTwo = userPasswordTwo;
	}

	public AccessObject getAccessObject() {
		return accessObject;
	}

	public void setAccessObject(AccessObject accessObject) {
		this.accessObject = accessObject;
	}

	public List<String> getGroupList() {
		return groupList;
	}

	public void setGroupList(List<String> groupList) {
		this.groupList = groupList;
	}
	
	
	
	
	
}	

	