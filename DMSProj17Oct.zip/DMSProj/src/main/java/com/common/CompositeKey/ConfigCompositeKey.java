package com.common.CompositeKey;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ConfigCompositeKey implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Column(name="pk")
	private  String pk ;
	
	
	@Column(name="sk")
	private  String sk ;


	public String getPk() {
		return pk;
	}


	public void setPk(String pk) {
		this.pk = pk;
	}


	public String getSk() {
		return sk;
	}


	public void setSk(String sk) {
		this.sk = sk;
	}


	public ConfigCompositeKey(String pk, String sk) {
		super();
		this.pk = pk;
		this.sk = sk;
	}


	public ConfigCompositeKey() {
		super();
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((pk == null) ? 0 : pk.hashCode());
		result = prime * result + ((sk == null) ? 0 : sk.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ConfigCompositeKey other = (ConfigCompositeKey) obj;
		if (pk == null) {
			if (other.pk != null)
				return false;
		} else if (!pk.equals(other.pk))
			return false;
		if (sk == null) {
			if (other.sk != null)
				return false;
		} else if (!sk.equals(other.sk))
			return false;
		return true;
	}
	
	
	
	

}
