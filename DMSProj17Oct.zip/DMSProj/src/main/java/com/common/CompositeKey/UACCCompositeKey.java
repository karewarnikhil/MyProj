package com.common.CompositeKey;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class UACCCompositeKey implements Serializable{
	
	
	private static final long serialVersionUID = 1L;

	@Column(name="userid")
	private int userId;
	
	@Column(name="mid")
	private int mid;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getMid() {
		return mid;
	}

	public void setMid(int mid) {
		this.mid = mid;
	}

	public UACCCompositeKey(int userId, int mid) {
		super();
		this.userId = userId;
		this.mid = mid;
	}

	public UACCCompositeKey() {
		super();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + mid;
		result = prime * result + userId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UACCCompositeKey other = (UACCCompositeKey) obj;
		if (mid != other.mid)
			return false;
		if (userId != other.userId)
			return false;
		return true;
	}
	
	
	
	
}
