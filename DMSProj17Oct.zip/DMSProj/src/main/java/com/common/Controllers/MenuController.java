package com.common.Controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.common.Dao.UsersDao;
import com.common.Objects.MenuObject;
import com.common.Objects.UsersObject;

@Controller
public class MenuController {

	   
	   
	   @Autowired
	   private UsersDao usersDao;
	
	   @RequestMapping(value = "/registerMenu", method = RequestMethod.GET)
	   public String showMenuForm(Model model){  
		   MenuObject menuObject = new MenuObject();
	       model.addAttribute("menu", menuObject);
	       return "registerMenu"; 
	   } 
	   
	   @RequestMapping(value="/menuAccess", method = RequestMethod.GET)  
	   public String manageMenuAccess(Model model, HttpServletRequest request){  
		   HttpSession session = request.getSession();
	       List<UsersObject> usersList = usersDao.getAllUsersForMenu();
	       session.setAttribute("usersList", usersList);
	       return "menuAccess";
	   } 
	   
	   @RequestMapping(value="/deleteFormUACC", method = RequestMethod.GET)  
	   public String deleteMenuAccess(HttpServletRequest request){  
		   HttpSession session = request.getSession();
	       List<UsersObject> usersList = usersDao.getAllUsers();
	       session.setAttribute("usersList", usersList);
	       return "menuAccessDelete";
	   } 
	
	   
}
