package com.common.Controllers;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.common.Dao.ConfigDao;
import com.common.Dao.DepartmentDao;
import com.common.Dao.DesignationDao;
import com.common.Dao.GroupDao;
import com.common.Dao.HintQuesDao;
import com.common.Dao.UsersDao;
import com.common.Objects.UsersObject;

@Controller
public class UserController {

	@Autowired
	private UsersDao usersDao;

	@Autowired
	private DepartmentDao departmentDao;

	@Autowired
	private DesignationDao designationDao;

	@Autowired
	private GroupDao groupDao;

	@Autowired
	private ConfigDao configDao;

	@Autowired
	private HintQuesDao hintQuesDao;

	@SuppressWarnings("serial")
	static final List<String> groupList = new ArrayList<String>() {
		{
			add("A");
			add("C");
			add("R");
			add("V");
			add("U");
			add("D");
		}
	};

	@RequestMapping(value = "/addUser", method = RequestMethod.GET)
	public String showform(Model model) {
		model.addAttribute("user", new UsersObject());
		model.addAttribute("departmentList", departmentDao.getAllDepartmentsForAddUser());
		model.addAttribute("designationList", designationDao.getAllDesignationForAddUser());
		model.addAttribute("groupList", groupList);
		model.addAttribute("configList", configDao.getAllConfigsForDropDown());
		model.addAttribute("hintQuestList", hintQuesDao.getAllHintQuestObject());
		return "registration";
	}

	@RequestMapping(value = "/saveUser", method = RequestMethod.POST)
	public String saveData(@ModelAttribute("usersObject") UsersObject usersObject, HttpServletRequest request) {
		UsersObject usersSessionObject = (UsersObject) request.getSession().getAttribute("users");
		if (usersSessionObject != null) {
			//need to remove following hardcoding of integer values
			String password = usersObject.getUserName().replace(" ", "").substring(0, 4)
					+ usersObject.getEmailId().substring(0, 2) + "#"
					+ usersObject.getMobileNo().toString().substring(8);
			usersObject.setCreationDt(new Timestamp(new Date().getTime()));
			usersObject.setUserPassword(password);
			//check this following code and try to eliminate.
			String groupName = "";
			for (String grp : usersObject.getGroupList()) {
				//System.out.println("string: " + grp);
				groupName += grp;
			}
			usersObject.setGroupObject(groupDao.getGroupByString(groupName));
			usersObject.setCreatedBy(usersSessionObject.getUserName());
			usersDao.saveUsersObject(usersObject);
			/*EmailObject emailObject = new EmailObject();
			String link = "<a href='http://localhost:8080/DMS/changePassword'>Click here for change Password.</a>";
			String message = "Hello dear user" + usersObject.getUserlevel()
					+ "you are registered with us successfully.</br>";
			message += "Your temporary password for login is " + usersObject.getUserPassword() + "</br>";
			message += "And link for change password is </br>";
			message += link;
			emailObject.setFrom("admin@test.com");
			emailObject.setTo(usersObject.getUserName());
			emailObject.setSubject("Change your password for login.");
			emailObject.setMessage(message);*/
		//	System.out.println("message body  is." + emailObject.getMessage());
			//System.out.println("link is." + link);
			return "redirect:/manageUsers";
		} else {
			return "redirect:/userLogin";
		}

	}

	@RequestMapping(value = "/updateUser", method = RequestMethod.POST)
	public String updateData(@ModelAttribute("user") UsersObject usersObject, HttpServletRequest request,
			@RequestParam("deptId") int deptid, @RequestParam("desgId") int desgId) {
		UsersObject usersSessionObject = (UsersObject) request.getSession().getAttribute("users");
		if (usersSessionObject != null) {
			usersObject.setUserPassword(usersObject.getUserPassword());
			usersObject.setDepartmentObject(departmentDao.getDepartmentById(deptid));
			usersObject.setDesignationObject(designationDao.getDesignationById(desgId));
			String groupName = "";
			for (String grp : usersObject.getGroupList()) {
				groupName += grp;
			}
			usersObject.setGroupObject(groupDao.getGroupByString(groupName));
			usersObject.setCreatedBy(usersObject.getCreatedBy());
			usersObject.setHintId(usersObject.getHintId());
			usersDao.updateUser(usersObject);
			return "redirect:/manageUsers";
		} else {
			return "redirect:/login";
		}
	}

	@RequestMapping(value = "/manageUsers", method = RequestMethod.GET)
	public String manageUser(Model model) {
		List<UsersObject> userslist = usersDao.getAllUsers();
		model.addAttribute("usersList", userslist);
		return "manageUsers";
	}

	@RequestMapping(value = "/editUser", method = RequestMethod.GET)
	public String editUser(@RequestParam("userId") Integer userId, Model model) {
		UsersObject usersObject = findByUserId(userId);
		List<String> list = new ArrayList<String>();
		String[] words = groupDao.getGroupById(findByUserId(userId).getGroupObject().getGroupId()).getGroupNm().split("");
		for (String charcInWords : words) {
			//System.out.println("" + s);
			list.add(charcInWords);
		}
		usersObject.setGroupList(list);
		model.addAttribute("groupList", groupList);
		model.addAttribute("user", usersObject);
		model.addAttribute("departmentList", departmentDao.getAllDepartments());
		model.addAttribute("designationList", designationDao.getAllDesignation());
		model.addAttribute("configList", configDao.getAllConfigsForDropDown());
		return "editUser";// will redirect to viewemp request mapping

	}

	/*@RequestMapping(value = "/deleteUser", method = RequestMethod.GET)
	public String deleteUser(@RequestParam("userId") Integer userId, Model model) {
		UsersObject usersObject = findByUserId(userId);
		usersDao.deleteUserObject(usersObject);
		return "redirect:/manageUsers";// will redirect to viewemp request mapping
	}
*/
	private UsersObject findByUserId(Integer userId) {
		UsersObject usersObject = usersDao.getUsersById(userId);
		return usersObject;
	}

}
