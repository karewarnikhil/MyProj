package com.common.DaoImpl;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.ClassTagGroupDao;
import com.common.Objects.ClassTagGroup;

@Repository
@Transactional
//remove  this unwanted class
public class ClassTagGroupDaoImpl implements ClassTagGroupDao {

	@Autowired
	private SessionFactory sessionFactory;
    
	//add in tagGrpoupDaoImple 
	public void saveClassTagGroup(ClassTagGroup classTagGroup) {
		sessionFactory.getCurrentSession().save(classTagGroup);
	}
	

}
