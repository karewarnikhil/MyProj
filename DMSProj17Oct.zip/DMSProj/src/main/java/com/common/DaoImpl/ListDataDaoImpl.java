package com.common.DaoImpl;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.common.Dao.ListDataDao;
import com.common.Objects.ListDataObj;


@Repository
@Transactional
public class ListDataDaoImpl implements ListDataDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	public List<ListDataObj> getAllListData() {
		return sessionFactory.getCurrentSession().createQuery("FROM ListDataObj").list();
	}

	//try to make one metod for save and update 
	public void save(ListDataObj listDataObj) {
		sessionFactory.getCurrentSession().save(listDataObj);
		//sessionFactory.getCurrentSession().saveOrUpdate(listDataObj);
	}

	//try to make one common function for all and put it into utility
	public int getMaxId(int listId) {
		Query qry=sessionFactory.getCurrentSession().createQuery("select COALESCE(MAX(listNo), 0) from ListDataObj where listid="+listId);
		int count= (Integer) ((org.hibernate.query.Query) qry).uniqueResult();
		 //System.out.println(""+count);
		 return count+1;
	}

	public ListDataObj getListDataById(int listId) {
		return (ListDataObj) sessionFactory.getCurrentSession().createQuery("FROM ListDataObj where listid="+listId).uniqueResult();
	}

	public void update(ListDataObj listDataObj) {
		sessionFactory.getCurrentSession().update(listDataObj);
	}

	
	public ListDataObj getListDataByListValue(String str) {
		return (ListDataObj) sessionFactory.getCurrentSession().createQuery("FROM ListDataObj where listValue='"+str+"'").uniqueResult();
	}

	
	public List<ListDataObj> getListDataByListId(long listId) {
		List<ListDataObj> listOfDataObj = (List<ListDataObj>) sessionFactory.getCurrentSession().createQuery("FROM ListDataObj where listId="+listId).list();
		return listOfDataObj;
	}
	 
}
