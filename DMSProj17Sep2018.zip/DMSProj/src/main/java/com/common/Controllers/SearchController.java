package com.common.Controllers;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.common.Dao.ClassDao;
import com.common.Dao.DepartmentDao;
import com.common.Dao.DocumentDao;
import com.common.Dao.FileTgDataDao;
import com.common.Dao.ListDataDao;
import com.common.Dao.SearchConditionDao;
import com.common.Dao.TagGrpDao;
import com.common.Objects.DocumentObject;
import com.common.Objects.FileMasterObject;
import com.common.Objects.FileTagsDataObject;
import com.common.Objects.ListDataObj;
import com.common.Objects.SearchConditionObject;
import com.common.Objects.SearchCriteria;
import com.common.Objects.TagObject;
import com.common.Objects.UsersObject;

@Controller
public class SearchController implements Serializable {

	private static final long serialVersionUID = 1L;

	@Autowired
	ServletContext context;

	@Autowired
	private TagGrpDao tagGrpDao;

	@Autowired
	private DepartmentDao departmentDao;

	@Autowired
	private ClassDao classDao;

	@Autowired
	private ListDataDao listDataDao;

	@Autowired
	private DocumentDao documentDao;
	
	@Autowired
	private FileTgDataDao fileTgDataDao;
	
	@Autowired
	private SearchConditionDao searchConditionDao;

	@RequestMapping(value = "/getTagNames", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<TagObject> getTagNames(@RequestParam("classId") long classId) {
		List<TagObject> listTagObject = tagGrpDao.getTagByClassId(classId);
		return listTagObject;
	}

	@RequestMapping(value = "/getSearchCondition", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<SearchConditionObject> getSearchCondition(@RequestParam("tagId") int tagId,
			@RequestParam("taggrpId") int taggrpId) {
		List<SearchConditionObject> searchConditionObject = searchConditionDao.getSerachByTagNm(tagId, taggrpId);
		return searchConditionObject;
	}

	@RequestMapping(value = "/getListDataObje", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<ListDataObj> getListData(@RequestParam("listId") int listId) {
		List<ListDataObj> listDataObject = listDataDao.getListDataByListId(listId);
		return listDataObject;
	}

	@RequestMapping(value = "/searchByValuesProperties", method = RequestMethod.GET)
	public String getSearchForm(Model model, HttpServletRequest request) {
		UsersObject usersSess = (UsersObject) request.getSession().getAttribute("users");
		List<SearchCriteria> listSearchCriteria = new ArrayList<SearchCriteria>();
		request.getSession().removeAttribute("listSearchCriteria");
		if (usersSess != null) {
			model.addAttribute("classList", classDao.getClassByDeptAndROP(usersSess.getDepartmentObject().getDeptId()));
			model.addAttribute("departmentList", departmentDao.getAllDepartments());
			request.getSession().setAttribute("listSearchCriteria", listSearchCriteria);
			return "searchByValuesProperties";
		} else {
			return "redirect:/login";
		}
	}

	@RequestMapping(value = "/addCriteria", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<SearchCriteria> getSearchCondition(@RequestParam("selectedTag") String selectedTag,
			@RequestParam("srNo") int srNo, @RequestParam("backData") String backData,
			@RequestParam("values") String values, @RequestParam("queryCondition") String queryCondition,
			@RequestParam("tagId") int tagId, @RequestParam("tagGrpId") int tagGrpId,
			@RequestParam("query1") String query1, HttpServletRequest request, Model model) {
		boolean recordExist = false;
		List<SearchCriteria> list = (List<SearchCriteria>) request.getSession().getAttribute("listSearchCriteria");
		if (list.size() == 0) {
			SearchCriteria searchCriteria = new SearchCriteria();
			searchCriteria.setTagId(tagId);
			searchCriteria.setTagGrpId(tagGrpId);
			searchCriteria.setSrNo(srNo);
			searchCriteria.setTagName(selectedTag);
			searchCriteria.setValues(values);
			searchCriteria.setCondition(backData);
			searchCriteria.setCriteria(queryCondition);
			searchCriteria.setQuery1(query1);
			list.add(searchCriteria);
		} else {
			for (SearchCriteria searchCriteria1 : list) {
				if ((searchCriteria1.getTagId() == tagId) && (searchCriteria1.getTagGrpId() == tagGrpId)) {
					recordExist = true;
					model.addAttribute("alert", "Search condition is already included in search criteria");
					System.out.println("Search condition is already included in search criteria");
					break;
				}
			}
			if (recordExist == false) {
				SearchCriteria searchCriteria = new SearchCriteria();
				searchCriteria.setTagId(tagId);
				searchCriteria.setTagGrpId(tagGrpId);
				searchCriteria.setSrNo(srNo);
				searchCriteria.setTagName(selectedTag);
				searchCriteria.setValues(values);
				searchCriteria.setCondition(backData);
				searchCriteria.setCriteria(queryCondition);
				searchCriteria.setQuery1(query1);
				list.add(searchCriteria);
				recordExist = false;
			}
		}
		return list;
	}

	@RequestMapping(value = "/removeSearchCriteria", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<SearchCriteria> removeSearchCriteria(@RequestParam("srNo") int srNo,
			HttpServletRequest request) {
		List<SearchCriteria> listSearchCriteria = (List<SearchCriteria>) request.getSession()
				.getAttribute("listSearchCriteria");
		for (SearchCriteria sObj : listSearchCriteria) {
			if (sObj.getSrNo() == srNo) {
				listSearchCriteria.remove(sObj);
				break;
			}
		}
		return listSearchCriteria;
	}

	@RequestMapping(value = "/getSessionList", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<SearchCriteria> getSessionList(HttpServletRequest request) {
		List<SearchCriteria> listSearchCriteria = (List<SearchCriteria>) request.getSession()
				.getAttribute("listSearchCriteria");
		return listSearchCriteria;
	}

	@RequestMapping(value = "/getFileMst", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<FileMasterObject> getFileMst(@RequestParam("queryBuilder") String queryBuilder,
			HttpServletRequest request) {
		List<FileMasterObject> documentObjectlist = documentDao.getFileMstByQuery(queryBuilder);
		request.getSession().setAttribute("documentObjectlist", documentObjectlist);
		return documentObjectlist;
	}

	@RequestMapping(value = "/searchViewer", method = RequestMethod.GET)
	public String searchViewer(Model model, @RequestParam("fileId") String fileIdSeqNo, HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		UsersObject usersSessionObject = (UsersObject) request.getSession().getAttribute("users");

		String[] fileIdSeqNo1 = fileIdSeqNo.split("~");
		int fileId = Integer.parseInt(fileIdSeqNo1[0]);
		int seqNo = Integer.parseInt(fileIdSeqNo1[1]);
		DocumentObject documentObject = documentDao.getFileByFileIdAndSeqNo(fileId, seqNo);
		List<DocumentObject> seqNodocumentObject = documentDao.getFileVersions(fileId);

		DateFormat df = new SimpleDateFormat("ddMMyyyyHHmmss");
		String reportDate = df.format(Calendar.getInstance().getTime());

		String fileName = usersSessionObject.getUserName() + "~" + reportDate + "~"
				+ documentObject.getFileName().trim().replaceAll(" ", "");
		String filePath = context.getRealPath("/")+"resources\\upload\\"+fileName;

		File file = new File(filePath);
		OutputStream out = new FileOutputStream(filePath);
		out.write(documentObject.getFileContent());
		out.close();
		file.deleteOnExit();

		model.addAttribute("fileName", fileName);
		request.getSession().setAttribute("documentObject", documentObject);
		model.addAttribute("seqNodocumentObject", seqNodocumentObject);
		model.addAttribute("documentObjectData", documentObject);

		return "searchViewer";
	}

	@RequestMapping(value = "/nextPreviousFile", method = RequestMethod.GET)
	public String nextPreviousFile(Model model, @RequestParam("fileId") String fileIdSeqNo, HttpServletRequest request,
			HttpServletResponse response) throws IOException {

		List<FileMasterObject> folderObjectSessionList = (List<FileMasterObject>) request.getSession()
				.getAttribute("documentObjectlist");
		String[] fileIdSeqNo1 = fileIdSeqNo.split("~");
		int fileId = Integer.parseInt(fileIdSeqNo1[0]);
		int seqNo = Integer.parseInt(fileIdSeqNo1[1]);
		String nextPrevoius = fileIdSeqNo1[2];

		int objIndex, nextfileId, nextseqNo;
		for (FileMasterObject Obj : folderObjectSessionList) {
			if (Obj.getFileId() == fileId && Obj.getSeqNo() == seqNo) {
				objIndex = folderObjectSessionList.indexOf(Obj);
				if (objIndex != 0 && nextPrevoius.equals("P")) {
					objIndex = objIndex - 1;
					nextfileId = (int) Obj.getFileId();
					nextseqNo = (int) Obj.getSeqNo();
					getAllData(request, model, nextfileId, nextseqNo, fileId);
				} else if (objIndex == 0 && nextPrevoius.equals("P")) {
					model.addAttribute("docObj1", "Hard");
					model.addAttribute("fileIdSeqNo", fileId + "~" + seqNo);
				} else if (objIndex != 0 && nextPrevoius.equals("N")) {
					objIndex = objIndex + 1;
					if (objIndex > (folderObjectSessionList.size() - 1)) {
						model.addAttribute("docObj1", "Hard");
						model.addAttribute("fileIdSeqNo", fileId + "~" + seqNo);
					} else {
						nextfileId = (int) Obj.getFileId();
						nextseqNo = (int) Obj.getSeqNo();
						getAllData(request, model, nextfileId, nextseqNo, fileId);
					}
				} else if (objIndex == 0 && nextPrevoius.equals("N")) {
					objIndex = objIndex + 1;
					if (objIndex > (folderObjectSessionList.size() - 1)) {
						model.addAttribute("docObj1", "Hard");
						model.addAttribute("fileIdSeqNo", fileId + "~" + seqNo);
					} else {
						nextfileId = (int) Obj.getFileId();
						nextseqNo = (int) Obj.getSeqNo();
						getAllData(request, model, nextfileId, nextseqNo, fileId);
					}
				}
			}
		}
		return "searchViewer";
	}

	public void getAllData(HttpServletRequest request, Model model, int nextfileId, int nextseqNo, int fileId)
			throws IOException {
		UsersObject usersSessionObject = (UsersObject) request.getSession().getAttribute("users");
		DocumentObject documentObject = documentDao.getFileByFileIdAndSeqNo(nextfileId, nextseqNo);
		List<DocumentObject> seqNodocumentObject = documentDao.getFileVersions(fileId);
		DateFormat df = new SimpleDateFormat("ddMMyyyyHHmmss");
		Date today = Calendar.getInstance().getTime();
		String reportDate = df.format(today);
		String fileName = usersSessionObject.getUserName() + "~" + reportDate + "~"
				+ documentObject.getFileName().trim().replaceAll(" ", "");
		String filePath = context.getRealPath("/") + "resources\\temp_files\\" + fileName;
		File file = new File(filePath);
		OutputStream out = new FileOutputStream(filePath);
		out.write(documentObject.getFileContent());
		out.close();
		file.deleteOnExit();
		model.addAttribute("seqNodocumentObject", seqNodocumentObject);
		model.addAttribute("fileName", fileName);
		model.addAttribute("documentObjectData", documentObject);
	}

	@RequestMapping(value = "/downloadFile", method = RequestMethod.GET)
	public void downloadFile(@RequestParam("fileId") String fileIdSeqNo, HttpServletResponse response) {
		String[] fileIdSeqNo1 = fileIdSeqNo.split("~");
		int fileId = Integer.parseInt(fileIdSeqNo1[0]);
		int seqNo = Integer.parseInt(fileIdSeqNo1[1]);
		DocumentObject documentObject = documentDao.getFileByFileIdAndSeqNo(fileId, seqNo);
		response.setContentType(documentObject.getFileExtn());
		response.setContentLength(documentObject.getFileContent().length);
		response.setHeader("Content-Disposition", "attachment; filename=\"" + documentObject.getFileName() + "\"");
		try {
			FileCopyUtils.copy(documentObject.getFileContent(), response.getOutputStream());
			response.getOutputStream().flush();
			response.getOutputStream().close();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
	@RequestMapping(value="/getFileTagsData", method = RequestMethod.GET,produces = "application/json" )
	public @ResponseBody List<FileTagsDataObject> getFileTagsData(@RequestParam("fileId") int fileId){
		List<FileTagsDataObject> tagDataList = fileTgDataDao.getTagData(fileId);
		return tagDataList;
	}
	
	@RequestMapping(value="/getCheckOutFile",method=RequestMethod.GET,produces="application/json")
	public @ResponseBody DocumentObject getCheckOutFile(@RequestParam("fileId") String fileIdSeqNo) {
		String[] fileIdSeqNo1 = fileIdSeqNo.split("~");
		int fileId = Integer.parseInt(fileIdSeqNo1[0]);
		int seqNo = Integer.parseInt(fileIdSeqNo1[1]);
		DocumentObject docObj=documentDao.getFileByFileIdAndSeqNo(fileId,seqNo);
		return docObj;
	}
	@RequestMapping(value="/updatecheckOut", method=RequestMethod.POST)
	public String checkOutFile(HttpServletRequest request) {
		int fileId=Integer.parseInt(request.getParameter("fileId"));
		int seqNo=Integer.parseInt(request.getParameter("seqNo"));
		DocumentObject docObj=documentDao.getFileByFileIdAndSeqNo(fileId,seqNo);
		docObj.setAtriBt(request.getParameter("atribt"));
		documentDao.updateCheckOut(docObj);
		System.out.println("Update Successfully");
		return "redirect:/searchViewer?fileId="+fileId+"~"+seqNo;
	}
}
