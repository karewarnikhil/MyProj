package com.common.Dao;

import java.util.List;

import com.common.Objects.DocumentObject;
import com.common.Objects.FileMasterObject;

public interface DocumentDao {
	
	List<DocumentObject> getAllDocuments();
    
    DocumentObject findByFileId(long fileId);
     
    void save(DocumentObject documentObject);
     
    List<DocumentObject> findAllByFolderId(long folderId);
     
    void deleteById(int id);

	List<DocumentObject> findAllByFolderIdAndUntagged(long folderId);

	DocumentObject findByFileNameAndFolderId(String originalFilename,long folderId);
	
	public List<FileMasterObject> getFileMstByQuery(String sql);

	public DocumentObject getFileByFileIdAndSeqNo(int fileId, int seqNo);

	public List<DocumentObject> getFileVersions(int fileId);
	
	public void updateCheckOut(DocumentObject docObject);
}
