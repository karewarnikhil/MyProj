package com.common.DaoImpl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.ParameterMode;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.hibernate.type.TimestampType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.DocumentDao;
import com.common.Objects.DocumentObject;
import com.common.Objects.FileMasterObject;

@Repository
@Transactional
public class DocumentDaoImpl implements DocumentDao{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public long getIdForCurrentVal() {
		Session session = sessionFactory.getCurrentSession();
		StoredProcedureQuery storedProcedureQuery = session.createStoredProcedureQuery("increment_CurrentVal");
		storedProcedureQuery.registerStoredProcedureParameter("p_seqName", String.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("currentVal", Integer.class, ParameterMode.OUT);
		storedProcedureQuery.setParameter("p_seqName", "file_Id");
		
		storedProcedureQuery.execute();
		int fileId = (Integer) storedProcedureQuery.getOutputParameterValue("currentVal");
		System.out.println("folderId======="+fileId);
		return fileId;
	};
	
	//code for pk and sk limit put after in util file
	public String getparamValue() {
		Session session = sessionFactory.getCurrentSession();
		StoredProcedureQuery storedProcedureQuery = session.createStoredProcedureQuery("getparamvalue");
		storedProcedureQuery.registerStoredProcedureParameter("pk_val", String.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("sk_val", String.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("currentval_a", String.class, ParameterMode.OUT);
		storedProcedureQuery.setParameter("pk_val", "FLT");
		storedProcedureQuery.setParameter("sk_val", "LIMT");
		
		storedProcedureQuery.execute();
		String limitValue =  ((String) storedProcedureQuery.getOutputParameterValue("currentval_a"));
		System.out.println("limitValue======="+limitValue);
		
		return limitValue;
	};
	
	
	//code for increment and return currentVal through sp
		public long getPathForFolder() {
			Session session = sessionFactory.getCurrentSession();
			StoredProcedureQuery storedProcedureQuery = session.createStoredProcedureQuery("getpath_location");
			storedProcedureQuery.registerStoredProcedureParameter("currentVal", Long.class, ParameterMode.IN);
			storedProcedureQuery.registerStoredProcedureParameter("", String.class, ParameterMode.OUT);
			storedProcedureQuery.setParameter("p_seqName", "FolderId");
			
			storedProcedureQuery.execute();
			int folderId = (Integer) storedProcedureQuery.getOutputParameterValue("currentVal");
			System.out.println("folderId======="+folderId);
			return folderId;
		};
	
	@SuppressWarnings("deprecation")
	public List<DocumentObject> getAllDocuments() {
		//return sessionFactory.getCurrentSession().createSQLQuery(" SELECT d.fileId,d.seqNo,d.folderId,d.rootId,d.fileName,d.fileExtn,d.atriBt,d.createdBy FROM DocumentObject d ").addEntity(DocumentObject.class).list();
		//SELECT new org.thoughts.on.java.model.AuthorValue(a.id, a.firstName, a.lastName) FROM Author a
		return sessionFactory.getCurrentSession().createQuery(" SELECT new DocumentObject(d.fileId,d.seqNo,d.folderId,d.rootId,d.fileName,d.fileExtn,d.atriBt,d.createdBy) FROM DocumentObject d ").list();
	}

	
	public void save(DocumentObject documentObject) {
		 //Id used for fileId
		long currentVal = getIdForCurrentVal();
		documentObject.setFileId(currentVal);
		sessionFactory.getCurrentSession().saveOrUpdate(documentObject);
	}

	public List<DocumentObject> findAllByUserId(int userId) {
		return sessionFactory.getCurrentSession().createQuery(" FROM DocumentObject where userId="+userId).list();
	}

	public void deleteById(int id) {
		// TODO Auto-generated method stub
		
	}


	public DocumentObject findByFileId(long fileId) {
		DocumentObject documentObject = (DocumentObject) sessionFactory.getCurrentSession().get(DocumentObject.class,fileId);
		return documentObject;
	}


	public List<DocumentObject> findAllByFolderId(long folderId) {
		return sessionFactory.getCurrentSession().createQuery(" SELECT new DocumentObject(d.fileId,d.seqNo,d.folderId,d.rootId,d.fileName,d.fileExtn,d.atriBt,d.createdBy) FROM DocumentObject d where d.folderId="+folderId).list();
	}

	public List<FileMasterObject> getFileMstByQuery(String sql) {
		List<FileMasterObject> listFileMasterObject = new ArrayList<FileMasterObject>();
		Query qry = sessionFactory.getCurrentSession().createSQLQuery(sql).addScalar("fileid", new LongType())
				.addScalar("seqNo", new LongType()).addScalar("filenm", new StringType())
				.addScalar("creationDt", new TimestampType()).addScalar("fldrnm", new StringType())
				.addScalar("createdby", new StringType()).addScalar("rootid", new LongType())
				.addScalar("folderid", new LongType()).addScalar("atribt", new StringType());
		List<Object[]> rows = qry.getResultList();
		for (Object row[] : rows) {
			FileMasterObject fileMasterObject = new FileMasterObject();
			fileMasterObject.setFileId((long) row[0]);
			fileMasterObject.setSeqNo((long) row[1]);
			fileMasterObject.setFileName(row[2].toString());
			fileMasterObject.setCreationDt(row[3].toString());
			fileMasterObject.setFolderNm(row[4].toString());
			fileMasterObject.setCreatedBy(row[5].toString());
			fileMasterObject.setRootId((long) row[6]);
			fileMasterObject.setFolderId((long) row[7]);
			fileMasterObject.setAtriBt(row[8].toString());
			listFileMasterObject.add(fileMasterObject);
		}
		return listFileMasterObject;
	}

	public DocumentObject getFileByFileIdAndSeqNo(int fileId, int seqNo) {
		DocumentObject documentObject = (DocumentObject) sessionFactory.getCurrentSession()
				.createQuery("From DocumentObject where fileId=" + fileId + " and seqNo=" + seqNo).uniqueResult();
		return documentObject;
	}

	public List<DocumentObject> getFileVersions(int fileId) {
		List<DocumentObject> seqNodocumentObject = (List<DocumentObject>) sessionFactory.getCurrentSession()
				.createQuery("from DocumentObject where fileId=" + fileId + " order by seqNo desc").list();
		return seqNodocumentObject;
	}

	@Override
	public void updateCheckOut(DocumentObject docObject) {
		sessionFactory.getCurrentSession().update(docObject);
	}

	public List<DocumentObject> findAllByFolderIdAndUntagged(long folderId) {
		//int paramValue = (Integer.parseInt(getparamValue())) ;
		return sessionFactory.getCurrentSession().createQuery(" FROM DocumentObject where folderId="+folderId+" AND tagStatus='N'").list();
	}

	public DocumentObject findByFileNameAndFolderId(String originalFilename,long folderId) {
		DocumentObject documentObject = (DocumentObject) sessionFactory.getCurrentSession().createQuery("FROM DocumentObject where folderId = "+folderId+"AND fileName='"+originalFilename+"'").uniqueResult();
		return documentObject;
	}
	
	

}
