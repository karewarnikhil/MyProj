package com.common.Objects;

import java.io.Serializable;

public class FileTagsDataObject implements Serializable{
	
	private static final long serialVersionUID = 1L;

	private String tagNm;
	private String tagData;
	private String tagGrpName;
	
	public FileTagsDataObject() {
		
	}

	public FileTagsDataObject(String tagNm, String tagData,String tagGrpName) {
		super();
		this.tagNm = tagNm;
		this.tagData = tagData;
		this.tagGrpName=tagGrpName;
	}

	public String getTagNm() {
		return tagNm;
	}

	public void setTagNm(String tagNm) {
		this.tagNm = tagNm;
	}

	public String getTagData() {
		return tagData;
	}

	public void setTagData(String tagData) {
		this.tagData = tagData;
	}

	public String getTagGrpName() {
		return tagGrpName;
	}

	public void setTagGrpName(String tagGrpName) {
		this.tagGrpName = tagGrpName;
	}
	
}
