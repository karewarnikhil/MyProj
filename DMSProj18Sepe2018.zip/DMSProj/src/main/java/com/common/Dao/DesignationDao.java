package com.common.Dao;

import java.util.List;

import com.common.Objects.DesignationObject;

public interface DesignationDao {
	 
	 public	void saveDesignationObject(DesignationObject designationObject);

	 public List<DesignationObject> getAllDesignation();

	 public DesignationObject getDesignationById(Integer designationId);
	 
	 //public UsersObject getUsersByUserName(String userName);

	 public void deleteDesignationObject(DesignationObject designationObject);

}
