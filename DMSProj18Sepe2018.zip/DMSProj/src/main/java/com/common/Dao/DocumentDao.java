package com.common.Dao;

import java.util.List;

import com.common.Objects.DocumentObject;
import com.common.Objects.FileMasterObject;

public interface DocumentDao {
	
	List<DocumentObject> getAllDocuments();
    
    DocumentObject findByFileId(long fileId);
     
    void save(DocumentObject documentObject);
     
    List<DocumentObject> findAllByFolderId(long folderId);
     
    void deleteById(int id);

	List<DocumentObject> findAllByFolderIdAndUntagged(long folderId);

	DocumentObject findByFileNameAndFolderId(String originalFilename,long folderId);
	
	 List<FileMasterObject> getFileMstByQuery(String sql);

	 DocumentObject getFileByFileIdAndSeqNo(int fileId, int seqNo);

     List<DocumentObject> getFileVersions(int fileId);
	
	 void updateCheckOut(DocumentObject docObject);

	List<DocumentObject> getAllDocumentsForMultiTagging(DocumentObject documentObject);
}
