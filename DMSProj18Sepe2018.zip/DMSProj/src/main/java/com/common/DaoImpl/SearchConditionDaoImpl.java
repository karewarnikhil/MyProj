package com.common.DaoImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.SearchConditionDao;
import com.common.Objects.SearchConditionObject;

@Repository
@Transactional
public class SearchConditionDaoImpl implements SearchConditionDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public List<SearchConditionObject> getSerachByTagNm(int tagId,int tagGrpId) {
		String sql="FROM SearchConditionObject sC where sC.tagtypeId IN(select distinct tO.tagTypeObject.tagTypeId from TagObject tO where tO.tagId="+tagId+" and tO.tagGroup.tagGrpId="+tagGrpId+") order by sC.frontData";
		return sessionFactory.getCurrentSession().createQuery(sql).list();
	}

}
