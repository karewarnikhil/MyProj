package com.common.DaoImpl;

import java.util.List;

import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.TagGrpDao;
import com.common.Objects.TagGroupObject;
import com.common.Objects.TagObject;
import com.common.Objects.TagTypeObject;

@Repository
@Transactional
public class TagGrpDaoImpl implements TagGrpDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	public long getIdForCurrentVal() {
	Session session = sessionFactory.getCurrentSession();
	StoredProcedureQuery storedProcedureQuery = session.createStoredProcedureQuery("increment_CurrentVal");
	storedProcedureQuery.registerStoredProcedureParameter("p_seqName", String.class, ParameterMode.IN);
	storedProcedureQuery.registerStoredProcedureParameter("currentVal", Integer.class, ParameterMode.OUT);
	storedProcedureQuery.setParameter("p_seqName", "tagGrpId");
	
	storedProcedureQuery.execute();
	int tagGrpId = (Integer) storedProcedureQuery.getOutputParameterValue("currentVal");
	System.out.println("TagGrpId======="+tagGrpId);
	return tagGrpId;
};

	public List<TagGroupObject> getAllTagGroup() {
		return sessionFactory.getCurrentSession().createQuery(" FROM TagGroupObject ").list();
	}
	
	public void saveTagGrp(TagGroupObject tagGroup) {
		long currentVal = getIdForCurrentVal();
		tagGroup.setTagGrpId(currentVal);
		System.out.println("Tag Group Id: "+tagGroup.getTagGrpId());
		sessionFactory.getCurrentSession().save(tagGroup);
	}

	@Override
	public List<TagTypeObject> getAllTagTypeObject() {
		return sessionFactory.getCurrentSession().createQuery(" FROM TagTypeObject ").list();
	}
	
	
	@Override
	public List<TagObject> getTagByClassId(long classId) {
		String sql="FROM TagObject tO where tO.tagGroup.tagGrpId IN(select distinct cG.tagGroup from ClassTagGroup cG where cG.classObject.classId="+classId+")order by tO.tagGroup.tagGrpId,tO.tagId";
		return sessionFactory.getCurrentSession().createQuery(sql).list();
	}
	@Override
	public TagGroupObject getTagByTagId(long tagGrpId) {
		return (TagGroupObject) sessionFactory.getCurrentSession().createQuery(" FROM TagGroupObject where taggrpid="+tagGrpId).uniqueResult();
	}

}
