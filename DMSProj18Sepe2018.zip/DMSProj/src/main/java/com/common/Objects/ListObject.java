package com.common.Objects;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ListMSt")
public class ListObject implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "listId", updatable = false, nullable = false)
	private int listId;

	@Column(name = "listName")
	private String listName;

	@Column(name = "createdby")
	private int createdBy;

	@Column(name = "creationdatetime")
	private Timestamp createdDate;

	@Column(name = "status")
	private String status;

	public ListObject() {
		super();
	}

	public ListObject(int listId, String listName, int createdBy, Timestamp createdDate, String status) {
		super();
		this.listId = listId;
		this.listName = listName;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.status = status;
	}

	public int getListId() {
		return listId;
	}

	public void setListId(int listId) {
		this.listId = listId;
	}

	public String getListName() {
		return listName;
	}

	public void setListName(String listName) {
		this.listName = listName;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
