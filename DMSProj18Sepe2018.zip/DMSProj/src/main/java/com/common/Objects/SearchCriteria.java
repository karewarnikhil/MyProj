package com.common.Objects;

import java.io.Serializable;

public class SearchCriteria implements Serializable{
	
	private static final long serialVersionUID = 1L;

	private int tagId;
	private int tagGrpId;
	private int srNo;
	private String tagName;
	private String criteria;
	private String values;
	private String condition;
	private String query1;
	
	public SearchCriteria() {
		
	}
	public SearchCriteria(int tagId,int tagGrpId,int srNo, String tagName, String criteria, String values, String condition,
			String query1) {
		super();
		this.tagId=tagId;
		this.tagGrpId=tagGrpId;
		this.srNo = srNo;
		this.tagName = tagName;
		this.criteria = criteria;
		this.values = values;
		this.condition = condition;
		this.query1 = query1;
	}
	public int getTagId() {
		return tagId;
	}
	public void setTagId(int tagId) {
		this.tagId = tagId;
	}
	public int getTagGrpId() {
		return tagGrpId;
	}
	public void setTagGrpId(int tagGrpId) {
		this.tagGrpId = tagGrpId;
	}
	public int getSrNo() {
		return srNo;
	}
	public void setSrNo(int srNo) {
		this.srNo = srNo;
	}
	public String getTagName() {
		return tagName;
	}
	public void setTagName(String tagName) {
		this.tagName = tagName;
	}
	public String getCriteria() {
		return criteria;
	}
	public void setCriteria(String criteria) {
		this.criteria = criteria;
	}
	public String getValues() {
		return values;
	}
	public void setValues(String values) {
		this.values = values;
	}
	public String getCondition() {
		return condition;
	}
	public void setCondition(String condition) {
		this.condition = condition;
	}
	public String getQuery1() {
		return query1;
	}
	public void setQuery1(String query1) {
		this.query1 = query1;
	}
	
	
}
