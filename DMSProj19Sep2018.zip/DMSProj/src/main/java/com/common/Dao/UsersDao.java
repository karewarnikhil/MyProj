package com.common.Dao;

import java.util.List;

import com.common.Objects.UsersObject;

public interface UsersDao {

 public	void saveUsersObject(UsersObject users);
 
 public void updateUser(UsersObject usersObject);

 public List<UsersObject> getAllUsers();

 public UsersObject getUsersById(Integer userId);
 
 public UsersObject getUsersByUserName(String userName);

 public void deleteUserObject(UsersObject usersObject);
	

}
