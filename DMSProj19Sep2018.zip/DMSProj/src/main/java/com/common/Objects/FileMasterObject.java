package com.common.Objects;

import java.io.Serializable;

public class FileMasterObject implements Serializable {
	private static final long serialVersionUID = 1L;
	private long fileId;
	private long seqNo;
	private String fileName;
	private String creationDt;
	private String folderNm;
	private String createdBy;
	private long rootId;
	private long folderId;
	private String atriBt;

	public FileMasterObject() {

	}

	public FileMasterObject(long fileId, long seqNo, String fileName, String creationDt, String folderNm,
			String createdBy, long rootId, long folderId, String atriBt) {
		super();
		this.fileId = fileId;
		this.seqNo = seqNo;
		this.fileName = fileName;
		this.folderNm = folderNm;
		this.creationDt = creationDt;
		this.createdBy = createdBy;
		this.rootId = rootId;
		this.folderId = folderId;
		this.atriBt = atriBt;
	}

	public long getFileId() {
		return fileId;
	}

	public void setFileId(long fileId) {
		this.fileId = fileId;
	}

	public long getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(long seqNo) {
		this.seqNo = seqNo;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getCreationDt() {
		return creationDt;
	}

	public void setCreationDt(String creationDt) {
		this.creationDt = creationDt;
	}

	public String getFolderNm() {
		return folderNm;
	}

	public void setFolderNm(String folderNm) {
		this.folderNm = folderNm;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public long getRootId() {
		return rootId;
	}

	public void setRootId(long rootId) {
		this.rootId = rootId;
	}

	public long getFolderId() {
		return folderId;
	}

	public void setFolderId(long folderId) {
		this.folderId = folderId;
	}

	public String getAtriBt() {
		return atriBt;
	}

	public void setAtriBt(String atriBt) {
		this.atriBt = atriBt;
	}

}
