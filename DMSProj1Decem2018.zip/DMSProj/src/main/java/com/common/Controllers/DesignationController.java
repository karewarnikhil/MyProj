package com.common.Controllers;

import java.io.FileOutputStream;
import java.io.IOException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.Provider;
import java.security.PublicKey;
import java.security.Security;
import java.security.Signature;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.common.Dao.DesignationDao;
import com.common.Objects.DesignationObject;




@Controller
public class DesignationController {
	  
	   @Autowired
	   private DesignationDao designationDao ;
	   
	   @Autowired
		ServletContext context;
	
	   @RequestMapping(value = "/registerDesignation", method = RequestMethod.GET)
	   public String showDesignationForm(Model model){  
		 DesignationObject designationObject = new DesignationObject();
	     model.addAttribute("designation", designationObject);
	     return "registerDesignation"; 
	   } 
	   
	   @RequestMapping(value = "/saveDesignation", method = RequestMethod.POST)
	   public String saveDesignationData(@ModelAttribute("designation") DesignationObject designationObject,Model model){  
	       Timestamp ts = new Timestamp(new Date().getTime());  
	       designationObject.setCreationDt(ts);
		   designationDao.saveDesignationObject(designationObject);
		  
		   designationObject = new DesignationObject();
		   model.addAttribute("designation", designationObject);
		   model.addAttribute("message", "Designation Saved Successfully.");
		   return "registerDesignation";
	      // return "redirect:/manageDesignation"; 
	   }  
	   
	   @RequestMapping(value = "/updateDesignation", method = RequestMethod.POST)
	   public String updateDesignationData(@ModelAttribute("designation") DesignationObject designationObject,Model model){  
		   designationDao.saveDesignationObject(designationObject);
		   model.addAttribute("message", "Designation Updated Successfully.");
		   model.addAttribute("designation",designationObject);
		   return "editDesignation";
	       //return "redirect:/manageDesignation"; 
	   }  
	   
	   @RequestMapping(value="/manageDesignation", method = RequestMethod.GET)  
	   public String manageDesignation(Model model) throws NoSuchAlgorithmException, CertificateException, IOException, KeyStoreException{  
		   
		   /*String configName = "/opt/bar/cfg/pkcs11.cfg";
		   Provider p = new sun.security.pkcs11.SunPKCS11();
		   System.out.println(p.getName());
		   Security.addProvider(p);*/
		 
		  // String configName = "E:\\eTPKCS11.cfg.txt";
		   Provider provider = Security.getProvider("SunMSCAPI");
		  // provider = provider.configure(configName);
		   System.out.println(provider.getName());
		   Security.addProvider(provider); 
		   
		   // Get provider KeyStore and login with PIN
		   String pin = "hem@123";
		  // java.security.KeyStore keyStore = java.security.KeyStore.getInstance("PKCS11", providerPKCS11);
		   
		   Security.addProvider(provider);
		   KeyStore keyStore = null;
			try {
				/*keyStore = KeyStore.getInstance("PKCS11",provider);
				keyStore.load(null, pin.toCharArray());*/
				 keyStore = KeyStore.getInstance("Windows-MY");
				 keyStore.load(null, null);
			} catch (KeyStoreException e) {
				e.printStackTrace();
				
			}
		  
			
		   // Enumerate items (certificates and private keys) in the KeyStore
		   java.util.Enumeration<String> aliases = keyStore.aliases();
		  
		   String alias = null;
		   String fileName = "2005_BookMatter_BeginningDatabasesWithPostgreS.pdf";
		   while (aliases.hasMoreElements()) {
		       alias = aliases.nextElement();
		       System.out.println("alias=========="+alias);
		       Certificate[] chain = keyStore.getCertificateChain(alias);
		       
		       System.out.println("Chain====="+chain);
		       //Print certificate
               X509Certificate cert = (X509Certificate)keyStore.getCertificate(alias);
               PublicKey pk = cert.getPublicKey(); 
               
               System.out.println("Public Key..........."+pk);
             
               Signature signature = Signature.getInstance(cert.getSigAlgName());
               FileOutputStream sigfos = new FileOutputStream(fileName);
               sigfos.write(cert.getSignature());
               sigfos.close();
               /*try {
            	  signature.initVerify(pk);
            	 
			} catch (InvalidKeyException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
               System.out.println("Certificate: " + cert);
               System.out.println("Signature======================: "+ signature);
		  }
		   
		   
	       List<DesignationObject> designationlist = designationDao.getAllDesignation(); 
	       model.addAttribute("designationList", designationlist);
	       return "manageDesignation";
	   }  
	   
	   @RequestMapping(value="/editDesignation", method = RequestMethod.GET)  
	   public String editDesignation(@RequestParam("designationId") Integer designationId,Model model){  
		   DesignationObject designationObject = findByDesignationId(designationId);
	       model.addAttribute("designation", designationObject);
	       return "editDesignation";//will redirect to viewemp request mapping  
	   }  
	   
	 /*  @RequestMapping(value="/deleteDesignation", method = RequestMethod.GET)  
	   public String deleteDesignation(@RequestParam("designationId") Integer designationId,Model model){  
		   DesignationObject designationObject = findByDesignationId(designationId);
		   designationDao.deleteDesignationObject(designationObject);
	       return "redirect:/manageDesignation";//will redirect to viewemp request mapping  
	   }  */
	   
	   private DesignationObject findByDesignationId(Integer designationId) {
		   DesignationObject designationObject =  designationDao.getDesignationById(designationId);
		   return designationObject;
	   }
}
