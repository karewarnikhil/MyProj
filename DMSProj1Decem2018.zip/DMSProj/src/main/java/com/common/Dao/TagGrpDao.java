package com.common.Dao;

import java.util.List;

import com.common.Objects.TagGroupObject;
import com.common.Objects.TagObject;
import com.common.Objects.TagTypeObject;

public interface TagGrpDao {

	
	/*public List<TagGroupObject> getAllTagGroup();*/
	
	public void saveTagGrp(TagGroupObject tagGroup);
	
	/*public List<TagTypeObject> getAllTagTypeObject();*/
	
	//Put it in tagDao 
	
	public List<TagObject> getTagByClassId(long classId);

	public TagGroupObject getTagByTagId(long tagGrpId);

	public Object getAllTagForGroupDropDown();
	
	public List<TagTypeObject> getAllTagTypeObjectForDropDown();
	
}
