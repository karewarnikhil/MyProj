package com.common.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity @Table(name="hintquestionmst")
public class HintQuestObject {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "hintId", updatable = false, nullable = false)
	private  int hintId ;
	
	@Column(name="hintquestion")
	private  String hintquestion ;

	public HintQuestObject(int hintId, String hintquestion) {
		super();
		this.hintId = hintId;
		this.hintquestion = hintquestion;
	}
	
	public HintQuestObject() {
		
	}

	public int getHintId() {
		return hintId;
	}

	public void setHintId(int hintId) {
		this.hintId = hintId;
	}

	public String getHintquestion() {
		return hintquestion;
	}

	public void setHintquestion(String hintquestion) {
		this.hintquestion = hintquestion;
	}
	
	
	
}
