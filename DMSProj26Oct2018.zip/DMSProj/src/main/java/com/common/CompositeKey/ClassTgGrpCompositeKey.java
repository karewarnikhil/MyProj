package com.common.CompositeKey;

import javax.persistence.Id;

public class ClassTgGrpCompositeKey {
	@Id
	private int classId;
	
	@Id
	private long tagGrpId;
}
