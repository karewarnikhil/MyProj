package com.common.Controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.common.CompositeKey.TagCompositeKey;
import com.common.Dao.ListDao;
import com.common.Dao.TagDao;
import com.common.Dao.TagGrpDao;
import com.common.Objects.TagDemoObject;
import com.common.Objects.TagObject;
import com.common.Objects.UsersObject;

@Controller
public class TagController {
	
	 @Autowired
	 private TagDao tagDao ;
	 
	 @Autowired
	 private TagGrpDao tagGrpDao ;
	 
	 @Autowired
	 private ListDao listDao;
	 
	 
	   @RequestMapping(value = "/registerTag", method = RequestMethod.GET)
	   public String showTagForm(Model model){  
		   TagObject tagObject = new TagObject();
	       model.addAttribute("tagObject", tagObject);
	       model.addAttribute("tagGroupList",tagGrpDao.getAllTagForGroupDropDown());
	       model.addAttribute("listObjectlist",listDao.getAllListForDropdown());
	       model.addAttribute("tagTypeList",tagGrpDao.getAllTagTypeObjectForDropDown());
	       return "registerTag"; 
	   } 
	  /* @RequestMapping(value = "/registerTagOne", method = RequestMethod.GET)
	   public String showTagFormOne(Model model,@ModelAttribute("tagObject") TagObject tagObject){  
		   TagObject tagObject2 = new TagObject();
		   tagObject2.setTagGroup(tagObject.getTagGroup());
		   model.addAttribute("tagObject", tagObject2);
	       model.addAttribute("tagGroupList",tagGrpDao.getAllTagGroup());
	       model.addAttribute("listObjectlist",listDao.getAllList());
	       model.addAttribute("tagTypeList",tagGrpDao.getAllTagTypeObject());
	       return "registerTag"; 
	   } */
	
	 @RequestMapping(value = "/saveTag", method = RequestMethod.POST)
	   public String saveTagData(@ModelAttribute("tagObject") TagObject tagObject, BindingResult result, HttpServletRequest request,Model model){
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   Date date = new Date();  
	       Timestamp ts = new Timestamp(date.getTime());  
	       tagObject.setCreationDt(ts);
	       int maxValue =  tagDao.getMaxValueId(tagObject.getTagCompositeKey().getTagGrpId());
	       tagObject.getTagCompositeKey().setTagId(maxValue);
	       tagObject.setCreatedBy(usersSessionObject.getUserId());
	       tagDao.saveTagObject(tagObject);
	       return "redirect:/registerTag"; 
	   }  
	 
	
	   @RequestMapping(value = "/updateTag", method = RequestMethod.POST)
	   public String updateTagData(@ModelAttribute("tagObject") TagObject tagObject, BindingResult result,HttpServletRequest request){
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   tagObject.setCreatedBy(usersSessionObject.getUserId());
		   tagDao.updateTagObject(tagObject);
	       return "redirect:/manageTag"; 
	   }  
	   
	   @RequestMapping(value="/manageTag", method = RequestMethod.GET)  
	   public ModelAndView manageTag(){  
		   List<TagObject> taglist = tagDao.getAllTagObject();
		   /*for(TagObject tagObject:taglist) {
			   System.out.println(tagObject.getTagNm());
		   }*/
	       return new ModelAndView("manageTag","taglist",taglist);  
	   } 
	   
	   @RequestMapping(value="/editTag", method = RequestMethod.GET)  
	   public String editTag(@RequestParam("tagId") Integer tagId,@RequestParam("tagGrpId") Long tagGrpId, Model model){  
		   TagCompositeKey tagCompositeKey = new TagCompositeKey();
		   tagCompositeKey.setTagGrpId(tagGrpId);
		   tagCompositeKey.setTagId(tagId);
		   TagObject tagObject = findByTagId(tagCompositeKey);
		   
		   TagDemoObject tagDemoObject = new TagDemoObject(tagObject.getTagNm(), tagObject.getTagNm(), tagObject.getTagTypeObject().getTagTypeDesc(), 0, tagObject.getStatus(), tagObject.getIsMandatory(), tagObject.getDispSeqNo(), tagObject.getWidth());
		  // TagDataObject tagDataObject = new TagDataObject();
		 
			try {
				FileOutputStream fo = new FileOutputStream(new File("tagDemoOne.txt"));
				ObjectOutputStream os = new ObjectOutputStream(fo);

				// Write objects to file
				os.writeObject(tagDemoObject);
				//o.writeObject(p2);

				os.close();
				fo.close();

				FileInputStream fi = new FileInputStream(new File("tagDemoOne.txt"));
				ObjectInputStream oi = new ObjectInputStream(fi);

				// Read objects
				
				//TagDemoObject pr1 = (TagDemoObject) oi.readObject();
				//TagDemoObject pr2 = (TagDemoObject) oi.readObject();
				
				//	TagDemoObject  pr1 = (TagDemoObject)oi.readObject();

				//System.out.println("TagName=="+pr1.getTagName()+"TagGroup=="+pr1.getTagGroup()+" TagType=="+pr1.getTagType()+" ListId=="+pr1.getIsMandatory()+"Status=="+pr1.getStatus());
				//System.out.println(pr2.toString());

				oi.close();
				fi.close();

			} catch (FileNotFoundException e) {
				//System.out.println("File not found");
			} catch (IOException e) {
				//System.out.println("Error initializing stream");
			} 
		   model.addAttribute("tagObject", tagObject);
		   return "editTag";
	   }  
	   
	   
	   @RequestMapping(value = "/createTags", method = RequestMethod.GET)
	   public String createTags(HttpSession session)  {
 		  UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
 		  if(usersSessionObject != null) {
 			  return "defaultPageForTags";
 		  }
 		  else
 			  return "loginIn";	  
 	   }
	  
	   private TagObject findByTagId(TagCompositeKey tagCompositeKey) {
		   TagObject tagObject =  tagDao.getTagById(tagCompositeKey); 
		   return tagObject;
	   }

}
