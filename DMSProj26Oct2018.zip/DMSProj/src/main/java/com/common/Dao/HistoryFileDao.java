package com.common.Dao;

import com.common.Objects.HistoryFileObject;

public interface HistoryFileDao {

	public void saveHisFile(HistoryFileObject historyFileObject);
}
