package com.common.Objects;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity @Table(name="classmst")
public class ClassObject implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "classid", updatable = false, nullable = false)
	private long classId;
	
	@OneToOne(targetEntity = DepartmentObject.class, fetch = FetchType.EAGER)
    @JoinColumn(nullable = false, name = "deptid")
    private DepartmentObject departmentObject;
	
	@Column(name="classnm")
	private String classNm;
	
	@Column(name="isinnerfolders")
	private String isInnerFolders;
	
	@Column(name="foldercnt")
	private int folderCnt;
	
	@Column(name="filecnt")
	private int fileCnt;
	
	@Column(name="storagetype")
	private String storageType;
	
	@Column(name="drivenm")
	private String driveNm;
	
	@Column(name="atribt")
	private String atriBt;
	
	@Column(name="readonlyothdept")
	private String readOnlyOthDept;
	
	@Column(name="readonlypublic")
	private String readOnlyPublic;
	
	@Column(name="allowDownload")
	private String allowDownload;
	
	@Column(name="createdby")
	private int createdBy;
	
	@Column(name="creationDt")
	private Timestamp creationDt;
	
	@Transient
	private List<ClassObject> classList;

	public long getClassId() {
		return classId;
	}

	public void setClassId(long classId) {
		this.classId = classId;
	}
	
	public DepartmentObject getDepartmentObject() {
		return departmentObject;
	}

	public void setDepartmentObject(DepartmentObject departmentObject) {
		this.departmentObject = departmentObject;
	}

	public String getClassNm() {
		return classNm;
	}

	public void setClassNm(String classNm) {
		this.classNm = classNm;
	}

	public String getIsInnerFolders() {
		return isInnerFolders;
	}

	public void setIsInnerFolders(String isInnerFolders) {
		this.isInnerFolders = isInnerFolders;
	}

	public int getFolderCnt() {
		return folderCnt;
	}

	public void setFolderCnt(int folderCnt) {
		this.folderCnt = folderCnt;
	}

	public int getFileCnt() {
		return fileCnt;
	}

	public void setFileCnt(int fileCnt) {
		this.fileCnt = fileCnt;
	}

	public String getStorageType() {
		return storageType;
	}

	public void setStorageType(String storageType) {
		this.storageType = storageType;
	}

	public String getDriveNm() {
		return driveNm;
	}

	public void setDriveNm(String driveNm) {
		this.driveNm = driveNm;
	}

	public String getAtriBt() {
		return atriBt;
	}

	public void setAtriBt(String atriBt) {
		this.atriBt = atriBt;
	}

	public String getReadOnlyOthDept() {
		return readOnlyOthDept;
	}

	public void setReadOnlyOthDept(String readOnlyOthDept) {
		this.readOnlyOthDept = readOnlyOthDept;
	}

	public String getReadOnlyPublic() {
		return readOnlyPublic;
	}

	public void setReadOnlyPublic(String readOnlyPublic) {
		this.readOnlyPublic = readOnlyPublic;
	}

	public String getAllowDownload() {
		return allowDownload;
	}

	public void setAllowDownload(String allowDownload) {
		this.allowDownload = allowDownload;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreationDt() {
		return creationDt;
	}

	public void setCreationDt(Timestamp creationDt) {
		this.creationDt = creationDt;
	}

	public List<ClassObject> getClassList() {
		return classList;
	}

	public void setClassList(List<ClassObject> classList) {
		this.classList = classList;
	}

	public ClassObject() {
		super();
	}

	public ClassObject(long classId, DepartmentObject departmentObject, String classNm, String isInnerFolders, int folderCnt, int fileCnt,
			String storageType, String driveNm, String atriBt, String readOnlyOthDept, String readOnlyPublic,
			String allowDownload, int createdBy, Timestamp creationDt,List<ClassObject> classList) {
		super();
		this.classId = classId;
		
		this.classNm = classNm;
		this.isInnerFolders = isInnerFolders;
		this.folderCnt = folderCnt;
		this.fileCnt = fileCnt;
		this.storageType = storageType;
		this.driveNm = driveNm;
		this.atriBt = atriBt;
		this.readOnlyOthDept = readOnlyOthDept;
		this.readOnlyPublic = readOnlyPublic;
		this.allowDownload = allowDownload;
		this.createdBy = createdBy;
		this.creationDt = creationDt;
		this.classList=classList;
	}
	
	
	
	
	
	
	
	
	
}
