package com.common.Objects;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

public class FileBucket {
	
	private List<MultipartFile> listOfMultipartFile;
	private String version;
	private MultipartFile multipartFile;
	private String folderPath;
	

	public List<MultipartFile> getListOfMultipartFile() {
		return listOfMultipartFile;
	}

	public void setListOfMultipartFile(List<MultipartFile> listOfMultipartFile) {
		this.listOfMultipartFile = listOfMultipartFile;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public MultipartFile getMultipartFile() {
		return multipartFile;
	}

	public void setMultipartFile(MultipartFile multipartFile) {
		this.multipartFile = multipartFile;
	}

	public String getFolderPath() {
		return folderPath;
	}

	public void setFolderPath(String folderPath) {
		this.folderPath = folderPath;
	}
	
	

	
	
	
	
	
	

}
