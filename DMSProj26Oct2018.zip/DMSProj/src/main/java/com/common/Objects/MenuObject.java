package com.common.Objects;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity @Table(name="menu")
public class MenuObject implements Serializable{
	
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "mid", updatable = false, nullable = false)
	private int menuId;
	
	@Column(name="pid")
	private int pageId;
	
	@Column(name="menunm")
	private String menuNm;
	
	@Column(name="pagenm")
	private String pageName;
	
	@Column(name="status")
	private String status;
	
	@Transient
	private List<MenuObject> listOfMenu;
	
	
	
	public MenuObject() {
		
	}
	
	public MenuObject(int menuId, int pageId, String menuNm, String pageName, String status, List<MenuObject> listOfMenu) {
		this.menuId = menuId;
		this.pageId = pageId;
		this.menuNm = menuNm;
		this.pageName = pageName;
		this.status = status;
		this.listOfMenu = listOfMenu;
	}

	public int getMenuId() {
		return menuId;
	}

	public void setMenuId(int menuId) {
		this.menuId = menuId;
	}

	public int getPageId() {
		return pageId;
	}

	public void setPageId(int pageId) {
		this.pageId = pageId;
	}


	public String getMenuNm() {
		return menuNm;
	}

	public void setMenuNm(String menuNm) {
		this.menuNm = menuNm;
	}

	public String getPageName() {
		return pageName;
	}

	public void setPageName(String pageName) {
		this.pageName = pageName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<MenuObject> getListOfMenu() {
		return listOfMenu;
	}

	public void setListOfMenu(List<MenuObject> listOfMenu) {
		this.listOfMenu = listOfMenu;
	}

	
	
	
	
	
	
}
