package com.common.CompositeKey;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ListDataCompositeKey implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Column(name = "listid")
	private int listId;

	@Column(name = "listno")
	private int listNo;

	public int getListId() {
		return listId;
	}

	public void setListId(int listId) {
		this.listId = listId;
	}

	public int getListNo() {
		return listNo;
	}

	public void setListNo(int listNo) {
		this.listNo = listNo;
	}

	public ListDataCompositeKey(int listId, int listNo) {
		super();
		this.listId = listId;
		this.listNo = listNo;
	}

	public ListDataCompositeKey() {
		super();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + listId;
		result = prime * result + listNo;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ListDataCompositeKey other = (ListDataCompositeKey) obj;
		if (listId != other.listId)
			return false;
		if (listNo != other.listNo)
			return false;
		return true;
	}
	
	
	
	
}
