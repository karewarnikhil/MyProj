package com.common.Controllers;

public class UserController2 {
	
	/*@Autowired
	private UsersDao usersDao ;
	
	@Autowired
	private DepartmentDao departmentDao;  
	
	@Autowired
	private DesignationDao designationDao;
	
	@Autowired
    private GroupDao groupDao;
	
    @Autowired
	private ConfigDao configDao;

    @Autowired
	private HintQuesDao hintQuesDao;
    
    @SuppressWarnings("serial")
	static final List<String> groupList =  new ArrayList<String>() {
		{
			add("A");
			add("C");
			add("R");
			add("V");
			add("U");
			add("D");
		}
	};
    
	
	@RequestMapping(value = "/addUser", method = RequestMethod.GET)
	   public String showform(Model model){  
	       UsersObject usersObject = new UsersObject();
	       List<DepartmentObject> departmentList = departmentDao.getAllDepartments();
	       List<DesignationObject> designationList = designationDao.getAllDesignation();
	       //List<GroupObject> groupList = groupDao.getAllGroupObject();
	       List<ConfigObject> configList = configDao.getAllConfigs();
	       List<HintQuestObject> hintQuestList = hintQuesDao.getAllHintQuestObject();
	       model.addAttribute("user", usersObject);
	       model.addAttribute("departmentList",departmentList);
	       model.addAttribute("designationList",designationList);
	       model.addAttribute("groupList",groupList);
	       model.addAttribute("configList",configList);
	       model.addAttribute("hintQuestList",hintQuestList);
	       return "registration"; 
	 } 
	
	 @RequestMapping(value = "/saveUser", method = RequestMethod.POST)
	   public String saveData(@ModelAttribute("usersObject") UsersObject usersObject, HttpServletRequest request){ 
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   Date date = new Date();  
	       Timestamp ts = new Timestamp(date.getTime());    
		   usersObject.setCreationDt(ts);
		   String mobileNo = usersObject.getMobileNo()+"";
		   String userPassword = usersObject.getUserName().substring(0,4)+usersObject.getEmailId().substring(0, 2)+"#"+mobileNo.substring(0, 2);
		   
		   String groupName = "";
			for (String groupNm : usersObject.getGroupList()) {
				System.out.println("string: " + groupNm);
				groupName += groupNm;
			}
			usersObject.setGroupObject(groupDao.getGroupByString(groupName));
			
		   usersObject.setUserPassword(userPassword);
		   if(usersSessionObject != null)
			   usersObject.setCreatedBy(usersSessionObject.getUserName());
		   else
			   usersObject.setCreatedBy(usersObject.getUserName());
		   usersDao.saveUsersObject(usersObject);
		   
		   EmailObject emailObject = new EmailObject();
		   String link =  "<a href='http://localhost:8080/DMS/changePassword'>Click here for change Password.</a>";
		   String message = "Hello dear user"+usersObject.getUserlevel()+"you are registered with us successfully.</br>";
		   message+= "Your temporary password for login is "+ usersObject.getUserPassword()+"</br>";
		   message+= "And link for change password is </br>";
		   message+= link;
		   emailObject.setFrom("admin@test.com");
		   emailObject.setTo(usersObject.getUserName());
		   emailObject.setSubject("Change your password for login.");
		   emailObject.setMessage(message);
		   System.out.println("message body  is."+emailObject.getMessage());
		   System.out.println("link is."+link);
	       return "redirect:/manageUsers"; 
	 }  
	 
	 @RequestMapping(value = "/updateUser", method = RequestMethod.POST)
	   public String updateData(@ModelAttribute("usersObject") UsersObject usersObject){ 
		   usersDao.saveUsersObject(usersObject);
	       return "redirect:/manageUsers"; 
	 }  
	
	 @RequestMapping(value="/manageUsers", method = RequestMethod.GET)  
	   public String manageUser(Model model){  
	       List<UsersObject> userslist = usersDao.getAllUsers(); 
	       model.addAttribute("usersList", userslist);
	       return "manageUsers";
	 }  
	 
	 @RequestMapping(value="/editUser", method = RequestMethod.GET)  
	   public String editUser(@RequestParam("userId") Integer userId,Model model){  
	       UsersObject usersObject = findByUserId(userId);
	       
	       List<String> list = new ArrayList<String>();
			String[] words = groupDao.getGroupById(usersObject.getGroupObject().getGroupId()).getGroupNm().split("");
			for (String s : words) {
				list.add(s);
			}
			
		   usersObject.setGroupList(list);
	       List<DepartmentObject> departmentList = departmentDao.getAllDepartments();
	       List<DesignationObject> designationList = designationDao.getAllDesignation();
	       List<ConfigObject> configList = configDao.getAllConfigs();
	       
	       model.addAttribute("groupList",groupList);
	       model.addAttribute("departmentList",departmentList);
	       model.addAttribute("designationList",designationList);
	       model.addAttribute("configList",configList);
	       model.addAttribute("user", usersObject);
	       return "editUser";//will redirect to viewemp request mapping  
	 }  
	   
	   @RequestMapping(value="/deleteUser", method = RequestMethod.GET)  
	   public String deleteUser(@RequestParam("userId") Integer userId,Model model){  
		   UsersObject usersObject = findByUserId(userId);
		   usersDao.deleteUserObject(usersObject);
	       return "redirect:/manageUsers";//will redirect to viewemp request mapping  
	   }  
	   
	   private UsersObject findByUserId(Integer userId) {
		   UsersObject usersObject =  usersDao.getUsersById(userId); 
		   return usersObject;
	   }*/
	 
	 
}
