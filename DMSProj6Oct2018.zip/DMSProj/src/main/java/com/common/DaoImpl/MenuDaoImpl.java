package com.common.DaoImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.MenuDao;
import com.common.Objects.MenuObject;

@Repository
@Transactional
public class MenuDaoImpl implements MenuDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	public List<MenuObject> getMenuListByUserId(int userId) {
		
		List<MenuObject> listOfMenu =  (List<MenuObject>) sessionFactory.getCurrentSession().createQuery(" SELECT m FROM MenuObject m, UACCObject u WHERE m.menuId = u.uACCCompositeKey.mid AND m.pageId = 0 and u.uACCCompositeKey.userId = "+ userId).list();
		if(listOfMenu != null){
			for(MenuObject menuObject:listOfMenu){
				getChildMenus(menuObject,userId);
        }   	
		}
		return listOfMenu;
	}
	
	public void getChildMenus(MenuObject menuObject,int userId) {
		List<MenuObject> listOfSubMenu = null;
		if(userId>0) {
			 listOfSubMenu =  (List<MenuObject>) sessionFactory.getCurrentSession().createQuery(" SELECT m FROM MenuObject m, UACCObject u where m.menuId = u.uACCCompositeKey.mid and m.pageId = "+menuObject.getMenuId()+ " AND u.uACCCompositeKey.userId = "+userId).list();
		}	
		else {
			 listOfSubMenu =  (List<MenuObject>) sessionFactory.getCurrentSession().createQuery(" FROM MenuObject where pageId = "+menuObject.getMenuId()).list();
		}
   		if(listOfSubMenu != null){
   			menuObject.setListOfMenu(listOfSubMenu);
   			for(MenuObject subMenuObject:listOfSubMenu){
				getChildMenus(subMenuObject,userId);
   			}   	
   		}
	}

	public List<MenuObject> getMenuList() {
		List<MenuObject> listOfMenu =  (List<MenuObject>) sessionFactory.getCurrentSession().createQuery("FROM MenuObject WHERE pageId = 0").list();
		if(listOfMenu != null){
			for(MenuObject menuObject:listOfMenu){
				getChildMenus(menuObject,0);
        } 
		}
		return listOfMenu;
	}

}
