package com.common.Objects;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;


@Entity
@Table(name = "listData")
public class ListDataObj implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@OneToOne(targetEntity = ListObject.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "listid", nullable = false)
	private ListObject listObj;

	/*@Column(name = "listid")
	private int listId;*/
	
	
	@Id
	@Column(name = "listno")
	private int listNo;

	@Column(name = "listvalue")
	private String listValue;

	@Column(name = "createdby")
	private int createdBy;

	@Column(name = "creationdt")
	private Timestamp creationDate;

	@Column(name = "status")
	private String status;
	
	@Transient
	private String listValueTemp;

	public ListDataObj() {
	}

	
    
	/*public ListObject getListObj() {
		return listObj;
	}

	public void setListObj(ListObject listObj) {
		this.listObj = listObj;
	}*/

	



	public int getListNo() {
		return listNo;
	}

	public ListDataObj(ListObject listObj, int listNo, String listValue, int createdBy, Timestamp creationDate,
			String status, String listValueTemp) {
		super();
		this.listObj = listObj;
		this.listNo = listNo;
		this.listValue = listValue;
		this.createdBy = createdBy;
		this.creationDate = creationDate;
		this.status = status;
		this.listValueTemp = listValueTemp;
	}



	public void setListNo(int listNo) {
		this.listNo = listNo;
	}

	public String getListValue() {
		return listValue;
	}

	public void setListValue(String listValue) {
		this.listValue = listValue;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = creationDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getListValueTemp() {
		return listValueTemp;
	}

	public void setListValueTemp(String listValueTemp) {
		this.listValueTemp = listValueTemp;
	}



	public ListObject getListObj() {
		return listObj;
	}



	public void setListObj(ListObject listObj) {
		this.listObj = listObj;
	}



	
	

	
}
