package com.common.Objects;

import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.common.CompositeKey.TagCompositeKey;

@Entity  @Table(name="tagmst")
public class TagObject {
	
	/*
	@OneToOne(targetEntity = TagGroupObject.class, fetch = FetchType.EAGER)
    @JoinColumn(nullable = false, name = "TagGrpId")
    private TagGroupObject tagGroup;
	
	@Id
	@Column(name="TagId", nullable = false)
	private  int tagId ;*/
	
	@Column(name="TagNm")
	private String tagNm;
	
	@EmbeddedId
    private TagCompositeKey tagCompositeKey;
	
	@OneToOne(targetEntity = TagTypeObject.class, fetch = FetchType.EAGER)
    @JoinColumn(nullable = false,updatable = false, name = "TagTypeId")
    private TagTypeObject tagTypeObject;
	
	@Column(name="width")
	private  int width;
	
	@Column(name="IsMandatory")
	private String isMandatory;
	
	@OneToOne(targetEntity = ListObject.class, fetch = FetchType.EAGER)
    @JoinColumn(nullable = false,updatable = false, name = "ListId")
    private ListObject listObject;
	
	@Column(name="DispSeqNo")
	private  int dispSeqNo ;
	
	@Column(name="createdby")
	private  long createdBy ;
	
	@Column(name="creationdt")
	private Timestamp creationDt;
	
	@Column(name="status")
	private String status;
	
	@Transient
	private List<ListDataObj> listDataObjs;


	/*public TagGroupObject getTagGroup() {
		return tagGroup;
	}

	public void setTagGroup(TagGroupObject tagGroup) {
		this.tagGroup = tagGroup;
	}*/



	public TagObject() {
		super();
	}

	public String getTagNm() {
		return tagNm;
	}

	public void setTagNm(String tagNm) {
		this.tagNm = tagNm;
	}

	public TagCompositeKey getTagCompositeKey() {
		return tagCompositeKey;
	}

	public void setTagCompositeKey(TagCompositeKey tagCompositeKey) {
		this.tagCompositeKey = tagCompositeKey;
	}

	public TagTypeObject getTagTypeObject() {
		return tagTypeObject;
	}

	public void setTagTypeObject(TagTypeObject tagTypeObject) {
		this.tagTypeObject = tagTypeObject;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public String getIsMandatory() {
		return isMandatory;
	}

	public void setIsMandatory(String isMandatory) {
		this.isMandatory = isMandatory;
	}

	public ListObject getListObject() {
		return listObject;
	}

	public void setListObject(ListObject listObject) {
		this.listObject = listObject;
	}

	public int getDispSeqNo() {
		return dispSeqNo;
	}

	public void setDispSeqNo(int dispSeqNo) {
		this.dispSeqNo = dispSeqNo;
	}

	public long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreationDt() {
		return creationDt;
	}

	public void setCreationDt(Timestamp creationDt) {
		this.creationDt = creationDt;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<ListDataObj> getListDataObjs() {
		return listDataObjs;
	}

	public void setListDataObjs(List<ListDataObj> listDataObjs) {
		this.listDataObjs = listDataObjs;
	}

	public TagObject(String tagNm, TagCompositeKey tagCompositeKey, TagTypeObject tagTypeObject, int width,
			String isMandatory, ListObject listObject, int dispSeqNo, long createdBy, Timestamp creationDt,
			String status, List<ListDataObj> listDataObjs) {
		super();
		this.tagNm = tagNm;
		this.tagCompositeKey = tagCompositeKey;
		this.tagTypeObject = tagTypeObject;
		this.width = width;
		this.isMandatory = isMandatory;
		this.listObject = listObject;
		this.dispSeqNo = dispSeqNo;
		this.createdBy = createdBy;
		this.creationDt = creationDt;
		this.status = status;
		this.listDataObjs = listDataObjs;
	}

	

}
