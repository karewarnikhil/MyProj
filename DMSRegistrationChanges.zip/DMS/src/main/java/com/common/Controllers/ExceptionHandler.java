package com.common.Controllers;

import java.io.FileNotFoundException;
import java.security.KeyStoreException;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.exception.ConstraintViolationException;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@ControllerAdvice(basePackages={"com.common"})
public class ExceptionHandler {
	
	@org.springframework.web.bind.annotation.ExceptionHandler(ConstraintViolationException.class)
	public String duplicateDataHandler(Model model,HttpServletRequest request,RedirectAttributes redirectAttributes) {
		    String page = "defaultPage";
		    String error = "There is duplicate entry for same please try again.";
		    
		    System.out.println(request.getRequestURL());
		   
		    if(request.getRequestURL().toString().contains("saveDepartment")) {
		    	error = "There is duplicate entry for department please try again.";
		    	redirectAttributes.addFlashAttribute("error", error);
		    	page = "redirect:registerDepartment";
		    	return page;
		    }else if(request.getRequestURL().toString().contains("updateDepartment")) {
		    	System.out.println(request.getRequestURL());
		    	error = "There is duplicate entry for department please try again.";
		    	redirectAttributes.addFlashAttribute("error", error);
		    	page = "redirect:manageDepartment";
		    	return page;
		    }else if(request.getRequestURL().toString().contains("saveDesignation")) {
		    	error = "There is duplicate entry for designation please try again.";
		    	redirectAttributes.addFlashAttribute("error", error);
		    	page = "redirect:registerDesignation";
		    	return page;
		    }else if(request.getRequestURL().toString().contains("updateDesignation")) {
		    	System.out.println(request.getRequestURL());
		    	error = "There is duplicate entry for designation please try again.";
		    	redirectAttributes.addFlashAttribute("error", error);
		    	page = "redirect:manageDesignation";
		    	return page;
		    }else if(request.getRequestURL().toString().contains("saveList")) {
		    	error = "There is duplicate entry for list value please try again.";
		    	redirectAttributes.addFlashAttribute("error", error);
		    	page = "redirect:createList";
		    	return page;
		    }else if(request.getRequestURL().toString().contains("updateList")) {
		    	System.out.println(request.getRequestURL());
		    	error = "There is duplicate entry for list value please try again.";
		    	redirectAttributes.addFlashAttribute("error", error);
		    	page = "redirect:createList";
		    	return page;
		    }else if(request.getRequestURL().toString().contains("saveTagGroup")) {
		    	System.out.println(request.getRequestURL());
		    	error = "There is duplicate entry for tag group please try again.";
		    	redirectAttributes.addFlashAttribute("error", error);
		    	page = "redirect:createTagGrp";
		    	return page;
		    }else if(request.getRequestURL().toString().contains("saveUser")) {
		    	System.out.println(request.getRequestURL());
		    	error = "There is duplicate entry for Email Id please try again.";
		    	redirectAttributes.addFlashAttribute("error", error);
		    	page = "redirect:addUser";
		    	return page;
		    }else if(request.getRequestURL().toString().contains("updateUser")) {
		    	System.out.println(request.getRequestURL());
		    	error = "There is duplicate entry for Email Id please try again.";
		    	redirectAttributes.addFlashAttribute("error", error);
		    	page = "redirect:manageUsers";
		    	return page;
		    }
		    else {
		    	model.addAttribute("error", error);
		    	return page;
		    }
	}
	
	@org.springframework.web.bind.annotation.ExceptionHandler(KeyStoreException.class)
	public String keyStoreExceptionHandler(Model model) {
		model.addAttribute("error", "There is no key found.");
		return "defaultPage";
	}
	
	@org.springframework.web.bind.annotation.ExceptionHandler(FileNotFoundException.class)
	public String keyStoreFileExceptionHandler(Model model) {
		model.addAttribute("error", "There is no key found.");
		return "defaultPage";
	}
	 
	@org.springframework.web.bind.annotation.ExceptionHandler(NullPointerException.class)
	  public String errorInForm(Model model,HttpServletRequest request,RedirectAttributes redirectAttributes){ 
		  String page = "defaultPage";
		  String error = "There is error in process please try again.";
		  System.out.println(request.getRequestURL());
		  model.addAttribute("error", error);
		  return page; 
	  }
	
	
	/*
	 * @org.springframework.web.bind.annotation.ExceptionHandler(
	 * IllegalArgumentException.class) public String illegaleArgumentException(Model
	 * model,HttpServletRequest request,RedirectAttributes redirectAttributes){
	 * String page = "defaultPage"; String error =
	 * "There is error in process please try again.";
	 * System.out.println(request.getRequestURL()); model.addAttribute("error",
	 * error); return page; }
	 */
	
	
	
    //CommonsMultipartResolver
	@org.springframework.web.bind.annotation.ExceptionHandler(MultipartException.class)
    public String handleError2(MaxUploadSizeExceededException e, RedirectAttributes redirectAttributes) {
        redirectAttributes.addFlashAttribute("error", e.getCause().getMessage());
        return "redirect:/uploadFile";

    }
}
