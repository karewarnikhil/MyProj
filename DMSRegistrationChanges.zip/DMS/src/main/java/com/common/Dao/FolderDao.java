package com.common.Dao;

import java.util.List;
import java.util.Map;

import com.common.Objects.FolderObject;
import com.common.Objects.InfoObject;

public interface FolderDao {
	 
	 public	void saveFolderObject(FolderObject folderObject);
	 
	 public	void saveRootFolderObject(FolderObject folderObject);
	 
	 public	void updateFolderObject(FolderObject folderObject);

	 public List<FolderObject> getAllFolders();

	 public FolderObject getFolderById(long folderId);
	 
	 public FolderObject getFolderByIdForDefault(long folderId);
	 
	/* public void deleteFolderObject(FolderObject folderObject);*/
	 
	 public List<FolderObject> getParentFolderList();
	 
	/* public List<FolderObject> getChildFolderList(long rootId);*/
	 
	 public List<FolderObject> getAllFoldersByRootId(long rootId,long deptId);
	 
	 public FolderObject getClassFolder(int rootId);
	 
	 public void updateFolderName(FolderObject folderObject);
	 
	 public void saveFolders(FolderObject folderObject);
	 
	 public String getPath(int folderId);

	 public String getLocation(int folderId);
	 
	/* public void updateClassCount(FolderObject folderObject); */

	public List<FolderObject> getRootFolderList();
	
	public InfoObject getInfoObject();
	
	public Map<Long,String> getHashmapofFolderObject();
	
    public List<List<Map<Object, Object>>> getCanvasjsChartData(); 
}
