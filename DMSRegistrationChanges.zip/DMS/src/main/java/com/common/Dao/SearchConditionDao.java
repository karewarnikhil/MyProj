package com.common.Dao;

import java.util.List;

import com.common.Objects.SearchConditionObject;

public interface SearchConditionDao {

	public List<SearchConditionObject> getSerachByTagNm(int tagId,int tagGrpId);
}
