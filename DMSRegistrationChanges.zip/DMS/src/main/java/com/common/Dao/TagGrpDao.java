package com.common.Dao;

import java.util.HashMap;
import java.util.List;

import com.common.Objects.TagGroupObject;
import com.common.Objects.TagObject;

public interface TagGrpDao {

	
	
	public void saveTagGrp(TagGroupObject tagGroup);
	
	public HashMap<Long, String> getHashmapofTagGrpObject();

	public HashMap<Long, String> getHashmapofTagTypeObject();
	
	//Put it in tagDao 
	
	public List<TagObject> getTagByClassId(long classId);

	public TagGroupObject getTagByTagId(long tagGrpId);

	
	
}
