package com.common.Objects;

import java.io.Serializable;

public class DepartmentReport implements Serializable{
	
	
	private static final long serialVersionUID = 1L;

	private String folderNm;
	
	private String fileName;
	
	private String departmentNm;
	
    private String creationFromDt;
	
	private String creationToDt;
	
	private long fileCnt; 
	
    private long pageCnt; 
    
    private long a0Size; 
    
    private long a1Size; 
    
    private long a2Size; 
    
    private long a3Size; 
    
    private long a4Size;

	public String getFolderNm() {
		return folderNm;
	}

	public void setFolderNm(String folderNm) {
		this.folderNm = folderNm;
	}

	public long getPageCnt() {
		return pageCnt;
	}

	public void setPageCnt(long pageCnt) {
		this.pageCnt = pageCnt;
	}

	public long getA0Size() {
		return a0Size;
	}

	public void setA0Size(long a0Size) {
		this.a0Size = a0Size;
	}

	public long getA1Size() {
		return a1Size;
	}

	public void setA1Size(long a1Size) {
		this.a1Size = a1Size;
	}

	public long getA2Size() {
		return a2Size;
	}

	public void setA2Size(long a2Size) {
		this.a2Size = a2Size;
	}

	public long getA3Size() {
		return a3Size;
	}

	public void setA3Size(long a3Size) {
		this.a3Size = a3Size;
	}

	public long getA4Size() {
		return a4Size;
	}

	public void setA4Size(long a4Size) {
		this.a4Size = a4Size;
	}
	
	public long getFileCnt() {
		return fileCnt;
	}

	public void setFileCnt(long fileCnt) {
		this.fileCnt = fileCnt;
	}
	
	public String getDepartmentNm() {
		return departmentNm;
	}

	public void setDepartmentNm(String departmentNm) {
		this.departmentNm = departmentNm;
	}

	public String getCreationFromDt() {
		return creationFromDt;
	}

	public void setCreationFromDt(String creationFromDt) {
		this.creationFromDt = creationFromDt;
	}

	public String getCreationToDt() {
		return creationToDt;
	}

	public void setCreationToDt(String creationToDt) {
		this.creationToDt = creationToDt;
	}
	
	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public DepartmentReport() {
		super();
	}

	public DepartmentReport(String folderNm, String fileName, String departmentNm, String creationFromDt,
			String creationToDt, long fileCnt, long pageCnt, long a0Size, long a1Size, long a2Size, long a3Size,
			long a4Size) {
		super();
		this.folderNm = folderNm;
		this.fileName = fileName;
		this.departmentNm = departmentNm;
		this.creationFromDt = creationFromDt;
		this.creationToDt = creationToDt;
		this.fileCnt = fileCnt;
		this.pageCnt = pageCnt;
		this.a0Size = a0Size;
		this.a1Size = a1Size;
		this.a2Size = a2Size;
		this.a3Size = a3Size;
		this.a4Size = a4Size;
	}
	
	

	

	
	
	
	
	

	
}
