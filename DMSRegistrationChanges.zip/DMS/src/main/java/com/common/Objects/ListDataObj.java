package com.common.Objects;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

import com.common.CompositeKey.ListDataCompositeKey;


@Entity
@Table(name = "listData")
public class ListDataObj implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
    private ListDataCompositeKey listDataCompositeKey;
    
	@Column(name = "listvalue")
	private String listValue;

	@Column(name = "createdby")
	private int createdBy;
    
	@CreationTimestamp
	@Column(name = "creationdt")
	private Timestamp creationDt;

	@Column(name = "status")
	private String status;

	public ListDataCompositeKey getListDataCompositeKey() {
		return listDataCompositeKey;
	}

	public void setListDataCompositeKey(ListDataCompositeKey listDataCompositeKey) {
		this.listDataCompositeKey = listDataCompositeKey;
	}

	public String getListValue() {
		return listValue;
	}

	public void setListValue(String listValue) {
		this.listValue = listValue;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreationDt() {
		return creationDt;
	}

	public void setCreationDt(Timestamp creationDt) {
		this.creationDt = creationDt;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public ListDataObj() {
		super();
	}

	public ListDataObj(ListDataCompositeKey listDataCompositeKey, String listValue, int createdBy, Timestamp creationDt,
			String status) {
		super();
		this.listDataCompositeKey = listDataCompositeKey;
		this.listValue = listValue;
		this.createdBy = createdBy;
		this.creationDt = creationDt;
		this.status = status;
	}



	



	
	

	
}
