package com.common.CompositeKey;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ClassTgGrpCompositeKey implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "classId", nullable = false)
	private long classId;
	
	@Column(name = "tagGrpId", nullable = false)
	private long tagGrpId;

	public long getClassId() {
		return classId;
	}

	public void setClassId(long classId) {
		this.classId = classId;
	}

	public long getTagGrpId() {
		return tagGrpId;
	}

	public void setTagGrpId(long tagGrpId) {
		this.tagGrpId = tagGrpId;
	}

	

	public ClassTgGrpCompositeKey() {
		super();
	}

	public ClassTgGrpCompositeKey(long classId, long tagGrpId) {
		super();
		this.classId = classId;
		this.tagGrpId = tagGrpId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (classId ^ (classId >>> 32));
		result = prime * result + (int) (tagGrpId ^ (tagGrpId >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ClassTgGrpCompositeKey other = (ClassTgGrpCompositeKey) obj;
		if (classId != other.classId)
			return false;
		if (tagGrpId != other.tagGrpId)
			return false;
		return true;
	}

    

	
	
	
	
	
	
	
	
	
	
	
}
