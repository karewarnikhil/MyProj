package com.common.CompositeKey;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class UACCCompositeKey implements Serializable{
	
	
	private static final long serialVersionUID = 1L;

	@Column(name="userid")
	private int userId;
	
	@Column(name="mid")
	private int mid;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getMid() {
		return mid;
	}

	public void setMid(int mid) {
		this.mid = mid;
	}

	public UACCCompositeKey(int userId, int mid) {
		super();
		this.userId = userId;
		this.mid = mid;
	}

	public UACCCompositeKey() {
		super();
	}

	//try to implement other hash code logic other than default
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		//check what values comes when operation is perform check it through debugging
		result = prime * result + mid;
		result = prime * result + userId;
		return result;
	}

	//try to implement other equals method logic other than default
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		//change following logic other than default from hash-code based values.
		UACCCompositeKey other = (UACCCompositeKey) obj;
		if (mid != other.mid)
			return false;
		if (userId != other.userId)
			return false;
		return true;
	}
	
	
	
	
}
