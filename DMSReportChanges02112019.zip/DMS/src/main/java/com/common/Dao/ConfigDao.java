package com.common.Dao;

import java.util.List;

import com.common.Objects.ConfigObject;

public interface ConfigDao {
	
	public List<ConfigObject> getAllConfigs();
	
	public void saveConfigObject(ConfigObject configObject);
	
	public ConfigObject getConfigById(String sk);
	
	/*public void deleteLevel(String pk, String sk);*/
	
	public List<ConfigObject> getAllConfigsForDropDown();
	
}
