package com.common.Objects;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.common.Embeddable.FileIdSeqNo;

@Entity
@Table(name = "hisfilemst")
public class HistoryFileObject implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "histId", updatable = false, nullable = false)
	private long histId;

	@Embedded
	@AttributeOverrides({ @AttributeOverride(name = "fileId", column = @Column(name = "fileId", nullable = false)),
    @AttributeOverride(name = "seqNo", column = @Column(name = "seqNo", nullable = false)) })
	public FileIdSeqNo id;

	@Column(name = "FileNm")
	private String fileNm;

	@Column(name = "Atribt")
	private String atribt;

	@Column(name = "remark")
	private String remark;

	@Column(name = "CreatedBy")
	private long CreatedBy;

	@Column(name = "CreationDt")
	private Timestamp CreationDt;

	public HistoryFileObject() {

	}

	public HistoryFileObject(long histId, FileIdSeqNo id, String fileNm, String atribt, String remark, long createdBy,
			Timestamp creationDt) {
		super();
		this.histId = histId;
		this.id = id;
		this.fileNm = fileNm;
		this.atribt = atribt;
		this.remark = remark;
		this.CreatedBy = createdBy;
		this.CreationDt = creationDt;

	}

	public long getHistId() {
		return histId;
	}

	public void setHistId(long histId) {
		this.histId = histId;
	}

	public FileIdSeqNo getId() {
		return id;
	}

	public void setId(FileIdSeqNo id) {
		this.id = id;
	}

	public String getFileNm() {
		return fileNm;
	}

	public void setFileNm(String fileNm) {
		this.fileNm = fileNm;
	}

	public String getAtribt() {
		return atribt;
	}

	public void setAtribt(String atribt) {
		this.atribt = atribt;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public long getCreatedBy() {
		return CreatedBy;
	}

	public void setCreatedBy(long createdBy) {
		CreatedBy = createdBy;
	}

	public Timestamp getCreationDt() {
		return CreationDt;
	}

	public void setCreationDt(Timestamp creationDt) {
		CreationDt = creationDt;
	}

}
