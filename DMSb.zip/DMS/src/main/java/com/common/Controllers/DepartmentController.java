package com.common.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.common.Dao.DepartmentDao;
import com.common.Objects.DepartmentObject;

public class DepartmentController {
	  
	   @Autowired
	   private DepartmentDao departmentDao ;
	
	   @RequestMapping(value = "/registerDepartment", method = RequestMethod.GET)
	   public String showDepartmentForm(Model model){  
		   DepartmentObject departmentObject = new DepartmentObject();
	       model.addAttribute("department", departmentObject);
	       return "registerDepartment"; 
	   } 
	
	   @RequestMapping(value = "/saveDepartment", method = RequestMethod.POST)
	   public String saveDepartmentData(@ModelAttribute("department") DepartmentObject departmentObject){  
		   departmentDao.saveDepartmentObject(departmentObject);
	       return "redirect:/manageDepartment"; 
	   }  
	   
	   @RequestMapping(value="/manageDepartment", method = RequestMethod.GET)  
	   public String manageDepartment(Model model){  
	       List<DepartmentObject> departmentlist = departmentDao.getAllDepartments(); 
	       model.addAttribute("departmentlist", departmentlist);
	       return "manageDepartment";
	   } 
	   
	   
	   @RequestMapping(value="/editDepartment", method = RequestMethod.GET)  
	   public String editDepartment(@RequestParam("userId") Integer departmentId,Model model){  
		   DepartmentObject departmentObject = findByDepartmentId(departmentId);
	       model.addAttribute("department", departmentObject);
	       return "editDepartment";//will redirect to viewemp request mapping  
	   }  
	   
	   @RequestMapping(value="/deleteDepartment", method = RequestMethod.GET)  
	   public String deleteDepartment(@RequestParam("departmentId") Integer departmentId,Model model){  
		   DepartmentObject departmentObject = findByDepartmentId(departmentId);
		   departmentDao.deleteDepartmentObject(departmentObject);
	       return "redirect:/manageDepartment";//will redirect to viewemp request mapping  
	   }  
	   
	   private DepartmentObject findByDepartmentId(Integer departmentId) {
		   DepartmentObject departmentObject =  departmentDao.getDepartmentById(departmentId); 
		   return departmentObject;
	   }
}
