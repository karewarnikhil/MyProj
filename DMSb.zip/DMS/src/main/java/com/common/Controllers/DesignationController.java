package com.common.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.common.Dao.DesignationDao;
import com.common.Objects.DesignationObject;

public class DesignationController {
	  
	   @Autowired
	   private DesignationDao designationDao ;
	
	   @RequestMapping(value = "/registerDesignation", method = RequestMethod.GET)
	   public String showDesignationForm(Model model){  
		 DesignationObject designationObject = new DesignationObject();
	     model.addAttribute("designation", designationObject);
	     return "registerDesignation"; 
	   } 
	   
	   @RequestMapping(value = "/saveDesignation", method = RequestMethod.POST)
	   public String saveDesignationData(@ModelAttribute("designation") DesignationObject designationObject){  
		   designationDao.saveDesignationObject(designationObject);
	       return "redirect:/manageDesignation"; 
	   }  
	   
	   @RequestMapping(value="/manageDesignation", method = RequestMethod.GET)  
	   public String manageDesignation(Model model){  
	       List<DesignationObject> designationlist = designationDao.getAllDesignation(); 
	       model.addAttribute("designationList", designationlist);
	       return "manageDesignation";
	   }  
	   
	   @RequestMapping(value="/editDesignation", method = RequestMethod.GET)  
	   public String editDesignation(@RequestParam("designationId") Integer designationId,Model model){  
		   DesignationObject designationObject = findByDesignationId(designationId);
	       model.addAttribute("designation", designationObject);
	       return "editDesignation";//will redirect to viewemp request mapping  
	   }  
	   
	   @RequestMapping(value="/deleteDesignation", method = RequestMethod.GET)  
	   public String deleteDesignation(@RequestParam("designationId") Integer designationId,Model model){  
		   DesignationObject designationObject = findByDesignationId(designationId);
		   designationDao.deleteDesignationObject(designationObject);
	       return "redirect:/manageDesignation";//will redirect to viewemp request mapping  
	   }  
	   
	   private DesignationObject findByDesignationId(Integer designationId) {
		   DesignationObject designationObject =  designationDao.getDesignationById(designationId);
		   return designationObject;
	   }
}
