package com.common.DaoImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.MenuDao;
import com.common.Objects.MenuObject;

@Repository
@Transactional
public class MenuDaoImpl implements MenuDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	public List<MenuObject> getMenuObject(int userId) {
		
		List<MenuObject> listOfMenu =  (List<MenuObject>) sessionFactory.getCurrentSession().createQuery(" SELECT m FROM MenuObject m, UACCObject u WHERE m.menuId = u.mid AND m.pageId = 0 and u.userId = "+ userId).list();
		System.out.println(listOfMenu.size());
		for(MenuObject menuObject:listOfMenu){
			//System.out.println("Menu Name==="+ menuObject.getMenuNm());
       	}
		
		if(listOfMenu != null){
			for(MenuObject menuObject:listOfMenu){
				List<MenuObject> listOfSubMenu =  (List<MenuObject>) sessionFactory.getCurrentSession().createQuery(" SELECT m FROM MenuObject m, UACCObject u where m.menuId = u.mid and m.pageId = "+menuObject.getMenuId()+ " AND u.userId = "+userId).list();
				System.out.println(listOfSubMenu.size());
				for(MenuObject subMenuObject:listOfMenu){
					//System.out.println("Menu Name==="+ subMenuObject.getMenuNm());
		       	}
           		if(listOfSubMenu != null){
           			menuObject.setListOfMenu(listOfSubMenu);
           		}
        }   	
		}
           	
		return listOfMenu;
	}

}
