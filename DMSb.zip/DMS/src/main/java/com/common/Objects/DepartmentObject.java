package com.common.Objects;

import java.sql.Timestamp;

public class DepartmentObject{
	private  int deptId ;
	private  String deptNm ;
	private  String shrtNm;
	private Timestamp creationDt;
	private String status;
	
	public int getDeptId() {
		return deptId;
	}
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}
	public String getDeptNm() {
		return deptNm;
	}
	public void setDeptNm(String deptNm) {
		this.deptNm = deptNm;
	}
	public String getShrtNm() {
		return shrtNm;
	}
	public void setShrtNm(String shrtNm) {
		this.shrtNm = shrtNm;
	}
	public Timestamp getCreationDt() {
		return creationDt;
	}
	public void setCreationDt(Timestamp creationDt) {
		this.creationDt = creationDt;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	
}
