function show_sidebar(){
document.getElementById('sidebar').style.visibility="visible";
}
function hide_sidebar(){
document.getElementById('sidebar').style.visibility="hidden";
}
function openNav() {
    document.getElementById("mySidenav").style.width = "15%";
}
function closeNav() {
    document.getElementById("mySidenav").style.width = "0%";
}