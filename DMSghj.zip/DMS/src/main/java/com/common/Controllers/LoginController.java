package com.common.Controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.common.Dao.MenuDao;
import com.common.Dao.UsersDao;
import com.common.Objects.MenuObject;
import com.common.Objects.UsersObject;

@Controller
public class LoginController {

	@Autowired
	private UsersDao usersDao ;
	
	@Autowired
	private MenuDao menuDao;
	
	/* @RequestMapping(value="/userLogin", method = RequestMethod.POST)  
	   public String loginUser(Model model){  
	      
	      return "";
	 }  */
	 
	 
	        // Checks if the user credentials are valid or not.
	 	    @RequestMapping(value = "/userLogin", method = RequestMethod.POST)
	 	    public String loginUser(@RequestParam("userNameFn")String userName, @RequestParam("passwordFn")String password) {
	 	    	
	            UsersObject usersObject = usersDao.getUsersByUserName(userName);
	            List<MenuObject> listOfMenu = usersObject.getListOfMenu();
	            if((userName.equals(usersObject.getUserName())) && (password.equals(usersObject.getUserPassword())) ) {
	            	listOfMenu = (List<MenuObject>) menuDao.getMenuObject(usersObject.getUserId());
	            	System.out.println(listOfMenu.size());
	            	String abc="";
	            	for(MenuObject menuObject:listOfMenu){
	        			System.out.println("Menu Name==="+ menuObject.getMenuNm());
	               	}
	            	usersObject.setListOfMenu(listOfMenu);
	            	return "home";
	            }
	            
	            else {
	            	return "login";
	            }
	 	    }
}
