package com.common.DaoImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.MenuDao;
import com.common.Objects.MenuObject;

@Repository
@Transactional
public class MenuDaoImpl implements MenuDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	public List<MenuObject> getMenuObject(int userId) {
		
		//Query q = sessionFactory.getCurrentSession().createQuery(" SELECT m.menuId, m.pageId, m.MenuNm, m.pageName, m.status FROM MenuObject m, UACCObject u where m.menuId = u.mid and m.pageId = 0 and u.userId = "+userId);
		//List<MenuObject> listOfMenu= q.list();
		
		/*
		List<MenuObject> listOfMenu =  (List<MenuObject>) sessionFactory.getCurrentSession().createQuery(" select m.menuId, m.pageId, m.MenuNm, m.pageName, m.status FROM MenuObject m , UACCObject u WHERE m.menuId = u.mid AND m.pageId = 0 ").list();
		for(MenuObject menuObject:listOfMenu){
			System.out.println("Menu Name==="+ menuObject.getMenuNm());
       	}
		//List<MenuObject> listOfMenu =  (List<MenuObject>) sessionFactory.getCurrentSession().createQuery(" SELECT m.menuId, m.pageId, m.MenuNm, m.pageName, m.status FROM MenuObject m INNER JOIN UACCObject u ON m.menuId = u.mid where m.pageId = 0 and u.userId = "+userId).list();
		System.out.println(listOfMenu.size());
		if(listOfMenu != null){
			for(MenuObject menuObject:listOfMenu){
           		//MenuObject menuObject = (MenuObject) listOfMenu.get(i);
           	    // for sub menus
				List<MenuObject> listOfSubMenu;
				listOfSubMenu =  (ArrayList<MenuObject>) sessionFactory.getCurrentSession().createQuery(" SELECT m.menuId, m.pageId, m.MenuNm, m.pageName, m.status FROM MenuObject m, UACCObject u where m.menuId = u.mid and m.pageId = "+menuObject.getMenuId()+ "and u.userId = "+userId).list();
           		if(listOfSubMenu != null){
           			menuObject.setListOfMenu(listOfSubMenu);
           		}
        }   	
		}*/
           	
		return sessionFactory.getCurrentSession().createQuery(" select m.menuId, m.pageId, m.MenuNm, m.pageName, m.status FROM MenuObject m , UACCObject u WHERE m.menuId = u.mid AND m.pageId = 0 AND u.userId = 1").list();
	}

}
