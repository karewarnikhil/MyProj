package com.common.Objects;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity @Table(name="menu")
public class MenuObject {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "mid", updatable = false, nullable = false)
	private int menuId;
	
	@Column(name="pid")
	private int pageId;
	
	@Column(name="menunm")
	private String MenuNm;
	
	@Column(name="pagenm")
	private String pageName;
	
	@Column(name="status")
	private String status;
	
	@Transient
	private List<MenuObject> listOfMenu;
	
	
	
	public MenuObject() {
		
	}
	
	public MenuObject(int menuId, int pageId, String MenuNm, String pageName, String status, List<MenuObject> listOfMenu) {
		this.menuId = menuId;
		this.pageId = pageId;
		this.MenuNm = MenuNm;
		this.pageName = pageName;
		this.status = status;
		this.listOfMenu = listOfMenu;
	}

	public int getMenuId() {
		return menuId;
	}

	public void setMenuId(int menuId) {
		this.menuId = menuId;
	}

	public int getPageId() {
		return pageId;
	}

	public void setPageId(int pageId) {
		this.pageId = pageId;
	}

	public String getMenuNm() {
		return MenuNm;
	}

	public void setMenuNm(String menuNm) {
		MenuNm = menuNm;
	}

	public String getPageName() {
		return pageName;
	}

	public void setPageName(String pageName) {
		this.pageName = pageName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<MenuObject> getListOfMenu() {
		return listOfMenu;
	}

	public void setListOfMenu(List<MenuObject> listOfMenu) {
		this.listOfMenu = listOfMenu;
	}

	
	
	
	
	
	
}
