package com.common.Controllers;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfContentByte;

public class Demo {

	/*
	 * public static void main(String[] args) { try { String pdfFilePath =
	 * "E:/demoPassword.pdf";
	 * 
	 * OutputStream fos = new FileOutputStream(new File(pdfFilePath)); Document
	 * document = new Document(); PdfWriter pdfWriter =
	 * PdfWriter.getInstance(document, fos);
	 * 
	 * String userPassword = "1234"; String ownerPassword = "1234";
	 * 
	 * pdfWriter.setEncryption(userPassword.getBytes(), ownerPassword.getBytes(),
	 * PdfWriter.ALLOW_PRINTING, PdfWriter.ENCRYPTION_AES_128);
	 * 
	 * document.open();
	 * 
	 * document.add(new Paragraph("This is Password protected PDF file"));
	 * 
	 * document.close(); fos.close();
	 * 
	 * System.out.println("PDF created in >> " + pdfFilePath);
	 * 
	 * } catch (Throwable e) { e.printStackTrace(); } }
	 */
	
	
	 public static final String RESULT

     = "E:/output";



/**

* Creates a PDF document.

* @param filename the path to the new PDF document

* @throws    DocumentException 

* @throws    IOException

*/

 public void createPdf(String filename) throws IOException, DocumentException {

		/*
		 * // step 1
		 * 
		 * Document document = new Document();
		 * 
		 * // step 2 OutputStream fos = new FileOutputStream(new File(filename));
		 * PdfWriter writer = PdfWriter.getInstance(document,fos);
		 */
     
     BufferedImage img = null;
     File f = null;
     
     f = new File("E:/Penguins.jpg");
     img = ImageIO.read(f);
     
     int height = img.getHeight();
     int width = img.getWidth();
     
     for(int y=0; y < height; y++) {
    	 for(int x=0; x < width; x++) {
    		 int p = img.getRGB(y, x);
    		 	int a = (p>>24)&0xff;
    		 	int r = (p>>16)&0xff;
    		 	int g = (p>>8)&0xff;
    		 	int b = p&0xff;
    		 	
    		 	int avg = (r+g+b)/3;
    		 	
    		 	p = (a<<24) | (avg<<16) | (avg<<8) | avg;
    		 	
    		 	img.setRGB(x, y, p);
    	 }
     }
     
     f = new File(RESULT);
     ImageIO.write(img, "jpg", f);
     // step 3
      
		/*
		 * document.open();
		 * 
		 * // step 4
		 * 
		 * PdfContentByte canvas = writer.getDirectContentUnder();
		 * 
		 * PdfSpotColor psc_g = new PdfSpotColor(
		 * 
		 * "iTextSpotColorGray", new GrayColor(0.9f));
		 * 
		 * 
		 * PdfSpotColor psc_rgb = new PdfSpotColor(
		 * 
		 * "iTextSpotColorRGB", new BaseColor(0x64, 0x95, 0xed));
		 * 
		 * PdfSpotColor psc_cmyk = new PdfSpotColor(
		 * 
		 * "iTextSpotColorCMYK", new CMYKColor(0.3f, .9f, .3f, .1f));
		 */



		
		/*
		 * colorRectangle(canvas, new SpotColor(psc_g, 0.5f), 36, 770, 36, 36);
		 * 
		 * colorRectangle(canvas, new SpotColor(psc_rgb, 0.1f), 90, 770, 36, 36);
		 * 
		 * colorRectangle(canvas, new SpotColor(psc_rgb, 0.2f), 144, 770, 36, 36);
		 * 
		 * colorRectangle(canvas, new SpotColor(psc_rgb, 0.3f), 198, 770, 36, 36);
		 * 
		 * colorRectangle(canvas, new SpotColor(psc_rgb, 0.4f), 252, 770, 36, 36);
		 * 
		 * colorRectangle(canvas, new SpotColor(psc_rgb, 0.5f), 306, 770, 36, 36);
		 * 
		 * colorRectangle(canvas, new SpotColor(psc_rgb, 0.6f), 360, 770, 36, 36);
		 * 
		 * colorRectangle(canvas, new SpotColor(psc_rgb, 0.7f), 416, 770, 36, 36);
		 * 
		 * colorRectangle(canvas, new SpotColor(psc_cmyk, 0.25f), 470, 770, 36, 36);
		 */

     

		
		/*
		 * canvas.setColorFill(psc_g, 0.5f);
		 * 
		 * canvas.rectangle(36, 716, 36, 36);
		 * 
		 * canvas.fillStroke();
		 */

		/*
		 * canvas.setColorFill(psc_g, 0.9f);
		 * 
		 * canvas.rectangle(90, 716, 36, 36);
		 * 
		 * canvas.fillStroke();
		 */

		/*
		 * canvas.setColorFill(psc_rgb, 0.5f);
		 * 
		 * canvas.rectangle(144, 716, 36, 36);
		 * 
		 * canvas.fillStroke();
		 */
    // canvas.setColorFill(psc_rgb, 0.9f);

   //  canvas.rectangle(198, 716, 36, 36);

   //  canvas.fillStroke();

		/*
		 * canvas.setColorFill(psc_cmyk, 0.5f);
		 * 
		 * canvas.rectangle(252, 716, 36, 36);
		 * 
		 * canvas.fillStroke();
		 */

    // canvas.setColorFill(psc_cmyk, 0.9f);

  //   canvas.rectangle(306, 716, 36, 36);

  //   canvas.fillStroke();



     // step 5

     //document.close();

 }
 

 public static void main(String[] args) throws IOException, DocumentException {

		/* new Demo().createPdf(RESULT); */
	 
	 BufferedImage img = null;
     File f = null;
     
     f = new File("E:/Chrysanthemum.jpg");
     img = ImageIO.read(f);
     
     colorIntoGrayScale(img,f);
     
     colorIntoSepia(img,f);
     
     negativeImage(img,f); 
     
     colorIntoRGBRED(img,f); 

     colorToRGBGreen(img,f); 
 
     colorToRGBBlue(img,f); 

 }


private static void colorToRGBBlue(BufferedImage img,File f) {
	// get width and height 
	     int width = img.getWidth(); 
	     int height = img.getHeight(); 
	
	     // convert to blue image 
	     for (int y = 0; y < height; y++) 
	     { 
	         for (int x = 0; x < width; x++) 
	         { 
	             int p = img.getRGB(x,y); 
	
	             int a = (p>>24)&0xff; 
	             int b = p&0xff; 
	
	             // set new RGB 
	             // keeping the b value same as in original 
	             // image and setting r and g as 0. 
	             p = (a<<24) | (0<<16) | (0<<8) | b; 
	
	             img.setRGB(x, y, p); 
	         } 
	     }
	     System.out.println("Color Mode"+img.getColorModel());
	     f = new File(RESULT+"rgbBlue2.jpg");
	     try {
	 		ImageIO.write(img, "jpg", f);
	 	} catch (IOException e) {
	 		// TODO Auto-generated catch block
	 		e.printStackTrace();
	 	}
}


private static void colorToRGBGreen(BufferedImage img,File f) {
	// get width and height 
	     int width = img.getWidth(); 
	     int height = img.getHeight(); 
	
	     // convert to green image 
	     for (int y = 0; y < height; y++) 
	     { 
	         for (int x = 0; x < width; x++) 
	         { 
	             int p = img.getRGB(x,y); 
	
	             int a = (p>>24)&0xff; 
	             int g = (p>>8)&0xff; 
	
	             // set new RGB 
	             // keeping the g value same as in original 
	             // image and setting r and b as 0. 
	             p = (a<<24) | (0<<16) | (g<<8) | 0; 
	
	             img.setRGB(x, y, p); 
	         } 
	     } 
	
	     System.out.println("Color Mode"+img.getColorModel());
	     f = new File(RESULT+"rgbGreen2.jpg");
	     try {
	 		ImageIO.write(img, "jpg", f);
	 	} catch (IOException e) {
	 		// TODO Auto-generated catch block
	 		e.printStackTrace();
	 	}
}


private static void colorIntoRGBRED(BufferedImage img,File f) {
	// get width and height 
    int width = img.getWidth(); 
    int height = img.getHeight(); 

    // convert to red image 
    for (int y = 0; y < height; y++) 
    { 
        for (int x = 0; x < width; x++) 
        { 
            int p = img.getRGB(x,y); 

            int a = (p>>24)&0xff; 
            int r = (p>>16)&0xff; 

            // set new RGB 
            // keeping the r value same as in original 
            // image and setting g and b as 0. 
            p = (a<<24) | (r<<16) | (0<<8) | 0; 

            img.setRGB(x, y, p); 
        } 
    } 
    
    System.out.println("Color Mode"+img.getColorModel());
    f = new File(RESULT+"rgbRed2.jpg");
    try {
		ImageIO.write(img, "jpg", f);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

}


private static void negativeImage(BufferedImage img,File f) {
	// Get image width and height 
     int width = img.getWidth(); 
     int height = img.getHeight(); 

     // Convert to negative 
     for (int y = 0; y < height; y++) 
     { 
         for (int x = 0; x < width; x++) 
         { 
             int p = img.getRGB(x,y); 
             int a = (p>>24)&0xff; 
             int r = (p>>16)&0xff; 
             int g = (p>>8)&0xff; 
             int b = p&0xff; 

             //subtract RGB from 255 
             r = 255 - r; 
             g = 255 - g; 
             b = 255 - b; 

             //set new RGB value 
             p = (a<<24) | (r<<16) | (g<<8) | b; 
             img.setRGB(x, y, p); 
         } 
     }
     
     System.out.println("Color Mode"+img.getColorModel());
     f = new File(RESULT+"negative2.jpg");
     try {
 		ImageIO.write(img, "jpg", f);
 	} catch (IOException e) {
 		// TODO Auto-generated catch block
 		e.printStackTrace();
 	}
}


private static void colorIntoSepia(BufferedImage img,File f) {
	//get width and height of the image
	     int width = img.getWidth();
	     int height = img.getHeight();
	
	     //convert to sepia
	     for(int y = 0; y < height; y++){
	       for(int x = 0; x < width; x++){
	         int p = img.getRGB(x,y);
	
	         int a = (p>>24)&0xff;
	         int r = (p>>16)&0xff;
	         int g = (p>>8)&0xff;
	         int b = p&0xff;
	
	         //calculate tr, tg, tb
	         int tr = (int)(0.393*r + 0.769*g + 0.189*b);
	         int tg = (int)(0.349*r + 0.686*g + 0.168*b);
	         int tb = (int)(0.272*r + 0.534*g + 0.131*b);
	
	         //check condition
	         if(tr > 255){
	           r = 255;
	         }else{
	           r = tr;
	         }
	
	         if(tg > 255){
	           g = 255;
	         }else{
	           g = tg;
	         }
	
	         if(tb > 255){
	           b = 255;
	         }else{
	           b = tb;
	         }
	
	         //set new RGB value
	         p = (a<<24) | (r<<16) | (g<<8) | b;
	
	         img.setRGB(x, y, p);
	       }
	     }
	     
	     System.out.println("Color Mode"+img.getColorModel());
	     f = new File(RESULT+"specia2.jpg");
	     try {
	 		ImageIO.write(img, "jpg", f);
	 	} catch (IOException e) {
	 		// TODO Auto-generated catch block
	 		e.printStackTrace();
	 	}
}


private static void colorIntoGrayScale(BufferedImage img,File f) {
	int height = img.getHeight();
     int width = img.getWidth();
     
     for(int y=0; y < height; y++) {
    	 for(int x=0; x < width; x++) {
    		 int p = img.getRGB(x,y);
    		 	int a = (p>>24)&0xff;
    		 	int r = (p>>16)&0xff;
    		 	int g = (p>>8)&0xff;
    		 	int b = p&0xff;
    		 	
    		 	int avg = (r+g+b)/3;
    		 	
    		 	p = (a<<24) | (avg<<16) | (avg<<8) | avg;
    		 	
    		 	img.setRGB(x, y, p);
    	 }
     }
     
     System.out.println("Color Mode"+img.getColorModel());
     f = new File(RESULT+"GrayScale2.jpg");
     try {
 		ImageIO.write(img, "jpg", f);
 	} catch (IOException e) {
 		// TODO Auto-generated catch block
 		e.printStackTrace();
 	}
}
 
 public void colorRectangle(PdfContentByte canvas,

	        BaseColor color, float x, float y, float width, float height) {

	        canvas.saveState();

	        canvas.setColorFill(color);

	        canvas.rectangle(x, y, width, height);

	        canvas.fillStroke();

	        canvas.restoreState();

	    }


}

