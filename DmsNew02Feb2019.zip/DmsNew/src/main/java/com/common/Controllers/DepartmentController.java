package com.common.Controllers;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.common.Dao.DepartmentDao;
import com.common.Objects.DepartmentObject;
import com.common.Objects.UsersObject;
import com.common.Utilities.DmsConstant;

@Controller
public class DepartmentController {
	  
	   @Autowired
	   private DepartmentDao departmentDao ;
	   
	   
	   @RequestMapping(value = "/registerDepartment", method = RequestMethod.GET)
	   public String showDepartmentForm(Model model,HttpServletRequest request){  
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
		       model.addAttribute("department",  new DepartmentObject());
		       return "registerDepartment"; 
		   }else {
			   return "loginIn"; 
		   }
	   } 
	
	   @RequestMapping(value = "/saveDepartment", method = RequestMethod.POST)
	   public String saveDepartmentData(@ModelAttribute("department") DepartmentObject departmentObject, Model model){
		
		   departmentDao.saveDepartmentObject(departmentObject);
		  
		   HashMap<Long, String> hashMapofDepartment =  DmsConstant.HASHMAP_OF_DEPARTMENT;
		   hashMapofDepartment.put((long)departmentObject.getDeptId(), departmentObject.getDeptNm());
		 
		   departmentObject = new DepartmentObject();
		   model.addAttribute("department", departmentObject);
		   model.addAttribute("message", "Department Saved Successfully.");
	       return "registerDepartment"; 
	   }  
	   
	   @RequestMapping(value = "/updateDepartment", method = RequestMethod.POST)
	   public String updateDepartmentData(@ModelAttribute("department") DepartmentObject departmentObject, BindingResult result,Model model){
		   departmentDao.saveDepartmentObject(departmentObject);
	     //return "redirect:/manageDepartment"; 
		   model.addAttribute("message", "Department Updated Successfully.");
		   model.addAttribute("department",departmentObject);
		   return "editDepartment";
	   }  
	   
	   @RequestMapping(value="/manageDepartment", method = RequestMethod.GET)  
	   public ModelAndView manageDepartment(Model model,HttpServletRequest request) {  
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
			   List<DepartmentObject> departmentlist = departmentDao.getAllDepartments(); 
		       return new ModelAndView("manageDepartment","departmentlist",departmentlist);  
	   }  else {
		   return new ModelAndView("loginIn");  
	   }
	   }
	  
	   
	   @RequestMapping(value="/editDepartment", method = RequestMethod.GET)  
	   public ModelAndView editDepartment(@RequestParam("departmentId") Integer departmentId,HttpServletRequest request,Model model){  
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
			   DepartmentObject departmentObject = findByDepartmentId(departmentId);
		       return new ModelAndView("editDepartment","department",departmentObject);  
		   }else {
			   return new ModelAndView("loginIn"); 
		   }
	   }  
	   
	   /*
	 @RequestMapping(value="/deleteDepartment", method = RequestMethod.GET)  
	   public String deleteDepartment(@RequestParam("departmentId") Integer departmentId,Model model){  
		   DepartmentObject departmentObject = findByDepartmentId(departmentId);
		   departmentDao.deleteDepartmentObject(departmentObject);
	       return "redirect:/manageDepartment";//will redirect to viewemp request mapping  
	   } */ 
	   
	   private DepartmentObject findByDepartmentId(Integer departmentId) {
		   DepartmentObject departmentObject =  departmentDao.getDepartmentById(departmentId); 
		   return departmentObject;
	   }
}
