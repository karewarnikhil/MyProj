package com.common.Controllers;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.common.Dao.ClassDao;
import com.common.Dao.ClassTagGroupDao;
import com.common.Dao.TagGrpDao;
import com.common.Objects.ClassTagGroup;
import com.common.Objects.TagGroupObject;
import com.common.Objects.UsersObject;
import com.common.Utilities.DmsConstant;



@Controller
public class TagGroupController {

	@Autowired
	private ClassDao classDao;
	
	@Autowired
	private TagGrpDao tagGroupDao;
	
	@Autowired
	private ClassTagGroupDao classTagGroupDao;
	
	@RequestMapping(value="/createTagGrp", method=RequestMethod.GET)
	public String getTagGroupForm(Model model,HttpServletRequest request) {
		UsersObject usersSessionObject = (UsersObject) request.getSession().getAttribute("users");
		if(usersSessionObject != null) {
			model.addAttribute("classList", classDao.getClassesForDropDown());
			model.addAttribute("ClassTagGroup", new ClassTagGroup());
			return "addTagGroup";
		}else {
			return "loginIn";
		}
	}

	//check and change logic for same code.
	@RequestMapping(value="/saveTagGroup", method=RequestMethod.POST)
	public String saveTagGroup(@ModelAttribute("ClassTagGroup") ClassTagGroup classTagGroup,HttpServletRequest request,Model model) {
		UsersObject usersSess = (UsersObject) request.getSession().getAttribute("users");
		if (usersSess != null) {
			classTagGroup.setCreatedBy(usersSess.getUserId());
			classTagGroup.setCreationDt(new Timestamp(new Date().getTime()));

			if (classTagGroup.getTagGrpNm() == null) {
				classTagGroupDao.saveClassTagGroup(classTagGroup);
			}
			if (classTagGroup.getClassTgGrpCompositeKey().getTagGrpId()==0) {
				TagGroupObject tagGroup=new TagGroupObject();
				tagGroup.setTagGrpNm(classTagGroup.getTagGrpNm());
				tagGroup.setCreatedBy(usersSess.getUserId());
				tagGroup.setStatus("A");
				//put in transaction saving
				tagGroupDao.saveTagGrp(tagGroup);
				
				HashMap<Long, String> hashMapofTagGrp =  DmsConstant.HASHMAP_OF_TAG_GROUP;
				hashMapofTagGrp.put(tagGroup.getTagGrpId(), tagGroup.getTagGrpNm());
				
			    classTagGroup.getClassTgGrpCompositeKey().setTagGrpId(tagGroup.getTagGrpId());
				classTagGroupDao.saveClassTagGroup(classTagGroup);
			}
			
			
			model.addAttribute("classList", classDao.getClassesForDropDown());
			model.addAttribute("ClassTagGroup", new ClassTagGroup());
			model.addAttribute("message", "Tag group Saved Successfully.");
			//return "redirect:/createTagGrp";
			return "addTagGroup";
		}
		
		else {
			return "redirect:/login";
		}
	}
	
}
