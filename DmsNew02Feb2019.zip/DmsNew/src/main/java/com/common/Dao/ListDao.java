package com.common.Dao;

import java.util.List;

import com.common.Objects.ListObject;;

public interface ListDao {
  
	public void saveListObject(ListObject list);

	public List<ListObject> getAllList();

	public ListObject getListObjById(int listId);

	//change it to static hashmap afterwards
	public List<ListObject> getAllListForDropdown();
}
