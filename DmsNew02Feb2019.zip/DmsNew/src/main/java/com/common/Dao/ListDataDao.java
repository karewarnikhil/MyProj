package com.common.Dao;

import java.util.List;

import com.common.Objects.ListDataObj;

public interface ListDataDao {

	public List<ListDataObj> getAllListData();

	public void saveListDataObj(ListDataObj listDataObj);

	public int getMaxId(int listId);

	public ListDataObj getListDataById(int listId);
	
	public void update(ListDataObj listDataObj);

	public ListDataObj getListDataByListValue(String str);

	public List<ListDataObj> getListDataByListId(long id);
}
