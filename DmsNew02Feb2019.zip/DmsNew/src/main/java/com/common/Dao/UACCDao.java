package com.common.Dao;

import java.util.List;

import com.common.Objects.UACCObject;

public interface UACCDao {
	
	public	void saveUACCObject(UACCObject uaccObject);
	
	public List<UACCObject> getUACCListByUserId(int userId);
	
	/*public void deleteUACCObject(UACCObject uaccObject);
	*/
	public void deleteUACCObjectByUserId(long  userId);

	/*public UACCObject getUACCById(Integer menuId, Integer userId);*/
}
