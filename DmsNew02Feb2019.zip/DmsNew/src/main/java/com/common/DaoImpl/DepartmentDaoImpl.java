package com.common.DaoImpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.DepartmentDao;
import com.common.Objects.DepartmentObject;

@Repository
@Transactional
public class DepartmentDaoImpl implements DepartmentDao{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	
	public void saveDepartmentObject(DepartmentObject departmentObject) {
		sessionFactory.getCurrentSession().saveOrUpdate(departmentObject);
	}

	public List<DepartmentObject> getAllDepartments() {
		return sessionFactory.getCurrentSession().createQuery(" FROM DepartmentObject order by deptId desc").list();
	}
	

	public DepartmentObject getDepartmentById(Integer departmentId) {
		DepartmentObject departmentObject = (DepartmentObject) sessionFactory.getCurrentSession().get(DepartmentObject.class,departmentId);
		return departmentObject;
	}

	@Override
	public Map<Long, String> getHashmapofDepartmentObject() {
		HashMap<Long, String> hashMapofDepartment = new HashMap<>();
		
		  List<DepartmentObject> getAllDepartments = sessionFactory.getCurrentSession().
		  createQuery(" SELECT new DepartmentObject (dp.deptId ,dp.deptNm )FROM DepartmentObject dp where dp.status= :status order by dp.deptNm").setParameter("status", "A").list();
		 
		  for(DepartmentObject departmentObject:getAllDepartments) {
			  hashMapofDepartment.put((long)departmentObject.getDeptId(),departmentObject.getDeptNm());
		  }
		 
		
		/*
		 * Session session = sessionFactory.getCurrentSession();
		 * 
		 * 
		 * CriteriaBuilder cb = session.getCriteriaBuilder();
		 * javax.persistence.criteria.CriteriaQuery<DepartmentObject> query =
		 * cb.createQuery(DepartmentObject.class); Root<DepartmentObject>
		 * departmentObjectlist = query.from(DepartmentObject.class);
		 * query.multiselect(departmentObjectlist.<Integer>get("deptId"),
		 * departmentObjectlist.<String>get("deptNm"));
		 * 
		 * TypedQuery<DepartmentObject> typedQuery = session.createQuery(query);
		 * List<DepartmentObject> getAllDepartments = typedQuery.getResultList();
		 * 
		 * for(DepartmentObject departmentObject:getAllDepartments) {
		 * hashMapofDepartment.put((long)departmentObject.getDeptId(),
		 * departmentObject.getDeptNm()); }
		 */
		 
		
		hashMapofDepartment.values().stream().forEach(System.out::println);
		return hashMapofDepartment;
	}

	/*public void deleteDepartmentObject(DepartmentObject departmentObject) {
		sessionFactory.getCurrentSession().delete(departmentObject);
	}*/

}
