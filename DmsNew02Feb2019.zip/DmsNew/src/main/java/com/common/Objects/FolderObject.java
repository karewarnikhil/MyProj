package com.common.Objects;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.CreationTimestamp;

@NamedNativeQueries(value = {
@NamedNativeQuery(name = "FolderObject.getpath_location", query = "select cast(getpath_location(?) as text)") })
@Entity
@Table(name = "foldermst")
public class FolderObject implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "folderid", updatable = false, nullable = false)
	private long folderId;
	
	@JoinColumn(name="deptId", referencedColumnName="deptId")
	private long deptId;

	@Column(name = "parentid")
	private int parentId;

	@Column(name = "rootid")
	private int rootId;

	@Column(name = "fldrnm")
	private String folderNm;

	@Column(name = "isinnerfolders")
	private String isInnerFolders;

	@Column(name = "foldercnt")
	private int folderCnt;

	@Column(name = "filecnt")
	private int fileCnt;

	@Column(name = "atribt")
	private String atriBt;

	@Column(name = "readonlyothdept")
	private String readOnlyOthDept;

	@Column(name = "readonlypublic")
	private String readOnlyPublic;

	
	@JoinColumn(name="createdby", referencedColumnName="userId")
	private int createdBy;

	@CreationTimestamp
	@Column(name = "creationDt")
	private Timestamp creationDt;

	@Column(name = "folderPath")
	private String folderPath;
    
	//need to check afterwards
	@Column(name = "location")
	private String location;

	//need to check afterwards
	@Column(name = "rmk")
	private String rmk;

	@Transient
	private List<FolderObject> listOfFolder;

	@Transient
	private long activeCount;

	@Transient
	private long deactiveCount;

	@Transient
	private long readOnlyCount;

	@Transient
	private long hiddenCount;

	@Transient
	private long checkOutCount;
	
	@Transient
	private String modifiedBy;
	
	@Transient
	private Timestamp modificationDt;
	

	public long getFolderId() {
		return folderId;
	}

	public void setFolderId(long folderId) {
		this.folderId = folderId;
	}

	public long getDeptId() {
		return deptId;
	}

	public void setDeptId(long deptId) {
		this.deptId = deptId;
	}

	public int getParentId() {
		return parentId;
	}

	public void setParentId(int parentId) {
		this.parentId = parentId;
	}

	public int getRootId() {
		return rootId;
	}

	public void setRootId(int rootId) {
		this.rootId = rootId;
	}

	public String getFolderNm() {
		return folderNm;
	}

	public void setFolderNm(String folderNm) {
		this.folderNm = folderNm;
	}

	public String getIsInnerFolders() {
		return isInnerFolders;
	}

	public void setIsInnerFolders(String isInnerFolders) {
		this.isInnerFolders = isInnerFolders;
	}

	public int getFolderCnt() {
		return folderCnt;
	}

	public void setFolderCnt(int folderCnt) {
		this.folderCnt = folderCnt;
	}

	public int getFileCnt() {
		return fileCnt;
	}

	public void setFileCnt(int fileCnt) {
		this.fileCnt = fileCnt;
	}

	public String getAtriBt() {
		return atriBt;
	}

	public void setAtriBt(String atriBt) {
		this.atriBt = atriBt;
	}

	public String getReadOnlyOthDept() {
		return readOnlyOthDept;
	}

	public void setReadOnlyOthDept(String readOnlyOthDept) {
		this.readOnlyOthDept = readOnlyOthDept;
	}

	public String getReadOnlyPublic() {
		return readOnlyPublic;
	}

	public void setReadOnlyPublic(String readOnlyPublic) {
		this.readOnlyPublic = readOnlyPublic;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreationDt() {
		return creationDt;
	}

	public void setCreationDt(Timestamp creationDt) {
		this.creationDt = creationDt;
	}

	public String getFolderPath() {
		return folderPath;
	}

	public void setFolderPath(String folderPath) {
		this.folderPath = folderPath;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getRmk() {
		return rmk;
	}

	public void setRmk(String rmk) {
		this.rmk = rmk;
	}

	public List<FolderObject> getListOfFolder() {
		return listOfFolder;
	}

	public void setListOfFolder(List<FolderObject> listOfFolder) {
		this.listOfFolder = listOfFolder;
	}

	public long getActiveCount() {
		return activeCount;
	}

	public void setActiveCount(long activeCount) {
		this.activeCount = activeCount;
	}

	public long getDeactiveCount() {
		return deactiveCount;
	}

	public void setDeactiveCount(long deactiveCount) {
		this.deactiveCount = deactiveCount;
	}

	public long getReadOnlyCount() {
		return readOnlyCount;
	}

	public void setReadOnlyCount(long readOnlyCount) {
		this.readOnlyCount = readOnlyCount;
	}

	public long getHiddenCount() {
		return hiddenCount;
	}

	public void setHiddenCount(long hiddenCount) {
		this.hiddenCount = hiddenCount;
	}

	public long getCheckOutCount() {
		return checkOutCount;
	}

	public void setCheckOutCount(long checkOutCount) {
		this.checkOutCount = checkOutCount;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Timestamp getModificationDt() {
		return modificationDt;
	}

	public void setModificationDt(Timestamp modificationDt) {
		this.modificationDt = modificationDt;
	}

	public FolderObject() {
		super();
	}
	
	

	public FolderObject(long folderId, int parentId, int rootId, String folderNm) {
		super();
		this.folderId = folderId;
		this.parentId = parentId;
		this.rootId = rootId;
		this.folderNm = folderNm;
	}

	public FolderObject(long folderId, long deptId, int parentId, int rootId, String folderNm, String isInnerFolders,
			int folderCnt, int fileCnt, String atriBt, String readOnlyOthDept, String readOnlyPublic, int createdBy,
			Timestamp creationDt, String folderPath, String location, String rmk, List<FolderObject> listOfFolder,
			long activeCount, long deactiveCount, long readOnlyCount, long hiddenCount, long checkOutCount,
			String modifiedBy, Timestamp modificationDt) {
		super();
		this.folderId = folderId;
		this.deptId = deptId;
		this.parentId = parentId;
		this.rootId = rootId;
		this.folderNm = folderNm;
		this.isInnerFolders = isInnerFolders;
		this.folderCnt = folderCnt;
		this.fileCnt = fileCnt;
		this.atriBt = atriBt;
		this.readOnlyOthDept = readOnlyOthDept;
		this.readOnlyPublic = readOnlyPublic;
		this.createdBy = createdBy;
		this.creationDt = creationDt;
		this.folderPath = folderPath;
		this.location = location;
		this.rmk = rmk;
		this.listOfFolder = listOfFolder;
		this.activeCount = activeCount;
		this.deactiveCount = deactiveCount;
		this.readOnlyCount = readOnlyCount;
		this.hiddenCount = hiddenCount;
		this.checkOutCount = checkOutCount;
		this.modifiedBy = modifiedBy;
		this.modificationDt = modificationDt;
	}






	
	

}
