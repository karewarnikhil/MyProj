package com.common.DaoImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.ListDao;
import com.common.Objects.ListObject;
import com.common.Utilities.GeneralUtility;

@Repository
@Transactional
public class ListDaoImpl implements ListDao {

	@Autowired
	private SessionFactory sessionFactory;

    //change method name
	//change method to saveOrUpdate 
	public void saveListObject(ListObject listObject) {
		Session session = sessionFactory.getCurrentSession();
		//remove and comes from constant file
		//String seqName = "listId";
		if(listObject.getListId() == 0) {
			Integer currentVal = (int) GeneralUtility.getIdForCurrentVal(session, "listId");
			listObject.setListId(currentVal);
		}
		
		session.saveOrUpdate(listObject);
	}

	public List<ListObject> getAllList() {
		//remove hard-code and comes from constant file or else define values
		return sessionFactory.getCurrentSession().createQuery("FROM ListObject where listId > :listId order by listId asc").setParameter("listId", 0).list();
	}
	
	public ListObject getListObjById(int listId) {
		return (ListObject) sessionFactory.getCurrentSession().get(ListObject.class,listId);
	}

	public List<ListObject> getAllListForDropdown() {
		//remove hard-code and comes from constant file
		return sessionFactory.getCurrentSession().createQuery("FROM ListObject where listId > :listId AND status = :status order by listName").setParameter("listId", 0).setParameter("status", "A").list();
	}
}
