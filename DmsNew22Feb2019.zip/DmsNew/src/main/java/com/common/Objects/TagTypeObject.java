package com.common.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity @Table(name="TagTypemst")
public class TagTypeObject {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "TagTypeId", updatable = false, nullable = false)
	private  int tagTypeId ;
	
	@Column(name="TagTypeDesc",unique=true)
	private  String tagTypeDesc ;
	
	@Column(name="TagTypeShrtDesc")
	private  String tagTypeShrtDesc;
	
	@Column(name="status")
	private String status;

	public int getTagTypeId() {
		return tagTypeId;
	}

	public void setTagTypeId(int tagTypeId) {
		this.tagTypeId = tagTypeId;
	}

	public String getTagTypeDesc() {
		return tagTypeDesc;
	}

	public void setTagTypeDesc(String tagTypeDesc) {
		this.tagTypeDesc = tagTypeDesc;
	}

	public String getTagTypeShrtDesc() {
		return tagTypeShrtDesc;
	}

	public void setTagTypeShrtDesc(String tagTypeShrtDesc) {
		this.tagTypeShrtDesc = tagTypeShrtDesc;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
    
	public TagTypeObject() {
		super();
	}
	
	public TagTypeObject(int tagTypeId, String tagTypeDesc, String tagTypeShrtDesc, String status) {
		super();
		this.tagTypeId = tagTypeId;
		this.tagTypeDesc = tagTypeDesc;
		this.tagTypeShrtDesc = tagTypeShrtDesc;
		this.status = status;
	}

	
	
	

}
