package com.common.CompositeKey;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class TagCompositeKey implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Column(name="TagGrpId")
	private  long tagGrpId ;
	
	@Column(name="TagId")
	private  int tagId ;

	public long getTagGrpId() {
		return tagGrpId;
	}

	public void setTagGrpId(long tagGrpId) {
		this.tagGrpId = tagGrpId;
	}

	public int getTagId() {
		return tagId;
	}

	public void setTagId(int tagId) {
		this.tagId = tagId;
	}

	public TagCompositeKey() {
		super();
	}

	public TagCompositeKey(long tagGrpId, int tagId) {
		super();
		this.tagGrpId = tagGrpId;
		this.tagId = tagId;
	}

	//try to implement other hash code logic other than default
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		//check what values comes when operation is perform check it through debugging
		result = prime * result + (int) (tagGrpId ^ (tagGrpId >>> 32));
		result = prime * result + tagId;
		return result;
	}

	
	//try to implement other hash code logic other than default
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TagCompositeKey other = (TagCompositeKey) obj;
		if (tagGrpId != other.tagGrpId)
			return false;
		if (tagId != other.tagId)
			return false;
		return true;
	}
	
	
	
	
	
	
	
}
