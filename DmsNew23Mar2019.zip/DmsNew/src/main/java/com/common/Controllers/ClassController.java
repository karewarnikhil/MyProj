package com.common.Controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.common.Dao.ClassDao;
import com.common.Dao.DepartmentDao;
import com.common.Objects.ClassObject;
import com.common.Objects.FolderObject;
import com.common.Objects.UsersObject;

@Controller
public class ClassController {
	   
	   @Autowired
	   ClassDao classDao;
	   
	   @Autowired 
	   DepartmentDao departmentDao;
	   
	  @RequestMapping(value = "/registerClass", method = RequestMethod.GET)
	   public String showClassForm(Model model,HttpServletRequest request){  
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
		       model.addAttribute("class", new ClassObject());
		       return "registerClass"; 
		   }else {
			   return "loginIn"; 
		   }
	   } 
	
	   @RequestMapping(value = "/saveClass", method = RequestMethod.POST)
	   public String saveClassData(@ModelAttribute("class") ClassObject classObject, HttpServletRequest request,Model model){
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
		       classObject.setCreatedBy(usersSessionObject.getUserId());
		       FolderObject folderObject = new FolderObject();
		       //remove hardCoding
		       classObject.setAtriBt("A");
		       creatingAndSavingFolderObject(classObject,folderObject);
		       classDao.saveClassObject(classObject,folderObject);
		       //return "redirect:/manageClass"; 
			   model.addAttribute("class", new ClassObject());
			   model.addAttribute("message", "Class Saved Successfully.");
		       return "registerClass";
		   }else {
			   return "loginIn"; 
		   }
	   }  
	   
	   @RequestMapping(value = "/updateClass", method = RequestMethod.POST)
	   public String updateClassData(@ModelAttribute("class") ClassObject classObject,Model model,HttpServletRequest request){
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
		       classDao.updateClassObject(classObject);
		       model.addAttribute("message", "Class Updated Successfully.");
			   model.addAttribute("class",classObject);
		       return "editClass";
		   }else {
			   return "loginIn"; 
		   }
		   
	       //return "redirect:/manageClass"; 
	   }  
	   
	   private void creatingAndSavingFolderObject(ClassObject classObject,FolderObject folderObject) {
		   folderObject.setFolderNm(classObject.getClassNm());
		   //remove following hardCoding
		   folderObject.setParentId(0);
		   folderObject.setRootId(0);
		   folderObject.setCreatedBy(classObject.getCreatedBy());
		   folderObject.setCreationDt(classObject.getCreationDt());
		   folderObject.setDeptId(classObject.getDeptId());
		   folderObject.setIsInnerFolders(classObject.getIsInnerFolders());
		   folderObject.setAtriBt(classObject.getAtriBt());
		   folderObject.setReadOnlyOthDept(classObject.getReadOnlyOthDept());
		   folderObject.setReadOnlyPublic(classObject.getReadOnlyPublic());
		
	   }

	   @RequestMapping(value="/manageClass", method = RequestMethod.GET)  
	   public ModelAndView manageClass(HttpServletRequest request){  
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
			   List<ClassObject> classlist = classDao.getAllClass(usersSessionObject.getUserlevel(),usersSessionObject.getDeptId()); 
		       return new ModelAndView("manageClass","classlist",classlist);  
		   }else {
			   return new ModelAndView("loginIn");  
		   }
	   }  
	  
	   @RequestMapping(value="/editClass", method = RequestMethod.GET)  
	   public ModelAndView editClass(@RequestParam("classId") long classId,Model model,HttpServletRequest request){  
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
			   ClassObject classObject = findByClassId(classId);
		       return new ModelAndView("editClass","class",classObject);  
		   }else {
			   return new ModelAndView("loginIn");  
		   }
	   }  
	
	   
	   private ClassObject findByClassId(long classId) {
		   ClassObject classObject =  classDao.getClassById(classId); 
		   return classObject;
	   }
}
