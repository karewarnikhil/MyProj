package com.common.Controllers;

import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.common.Dao.DesignationDao;
import com.common.Objects.DesignationObject;
import com.common.Objects.UsersObject;
import com.common.Utilities.DmsConstant;

@Controller
public class DesignationController {
	
	  
	   @Autowired
	   private DesignationDao designationDao ;
	   
	   @Autowired
	   ServletContext context;
	
	   @RequestMapping(value = "/registerDesignation", method = RequestMethod.GET)
	   public String showDesignationForm(Model model){  
	     model.addAttribute("designation", new DesignationObject());
	     return "registerDesignation"; 
	   } 
	   
	   @RequestMapping(value = "/saveDesignation", method = RequestMethod.POST)
	   public String saveDesignationData(@ModelAttribute("designation") DesignationObject designationObject,Model model){  
		
		   designationDao.saveDesignationObject(designationObject);
		  
		   HashMap<Long, String> hashMapofDesignation =  DmsConstant.HASHMAP_OF_DESIGNATION;
		   hashMapofDesignation.put((long) designationObject.getDesgId(), designationObject.getDesgNm());
		   
		  
		   model.addAttribute("designation",new DesignationObject());
		   model.addAttribute("message", "Designation Saved Successfully.");
		   return "registerDesignation";
	      // return "redirect:/manageDesignation"; 
	   }  
	   
	   @RequestMapping(value = "/updateDesignation", method = RequestMethod.POST)
	   public String updateDesignationData(@ModelAttribute("designation") DesignationObject designationObject,Model model){  
		  
		   designationDao.saveDesignationObject(designationObject);
		   model.addAttribute("message", "Designation Updated Successfully.");
		   model.addAttribute("designation",designationObject);
		   return "editDesignation";
	       //return "redirect:/manageDesignation"; 
	   }  
	   
	   @RequestMapping(value="/manageDesignation", method = RequestMethod.GET)  
	   public String manageDesignation(Model model,HttpServletRequest request) {
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
		       List<DesignationObject> designationlist = designationDao.getAllDesignation(); 
		       model.addAttribute("designationList", designationlist);
		       return "manageDesignation";
		   }else {
		   return "loginIn";
		   }
	   }  
	   
	   @RequestMapping(value="/editDesignation", method = RequestMethod.GET)  
	   public String editDesignation(@RequestParam("designationId") Integer designationId,Model model,HttpServletRequest request){  
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
			   DesignationObject designationObject = findByDesignationId(designationId);
		       model.addAttribute("designation", designationObject);
		       return "editDesignation";//will redirect to viewemp request mapping  
		   }else {
			   return "loginIn";
		   }
		   
	   }  
	   
	 /*  @RequestMapping(value="/deleteDesignation", method = RequestMethod.GET)  
	   public String deleteDesignation(@RequestParam("designationId") Integer designationId,Model model){  
		   DesignationObject designationObject = findByDesignationId(designationId);
		   designationDao.deleteDesignationObject(designationObject);
	       return "redirect:/manageDesignation";//will redirect to viewemp request mapping  
	   }  */
	   
	   private DesignationObject findByDesignationId(Integer designationId) {
		   DesignationObject designationObject =  designationDao.getDesignationById(designationId);
		   return designationObject;
	   }
}
