package com.common.Controllers;

import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice(basePackages={"com.common"})
public class ExceptionHandler {
	
	
	/*
	 * @org.springframework.web.bind.annotation.ExceptionHandler(RuntimeException.
	 * class) public String duplicateDataHandler(Model model) {
	 * model.addAttribute("error",
	 * "There is went something wrong try again for same."); return "loginIn"; }
	 */
	 
	
}
