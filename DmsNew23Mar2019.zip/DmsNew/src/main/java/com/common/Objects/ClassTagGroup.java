package com.common.Objects;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.common.CompositeKey.ClassTgGrpCompositeKey;

@Entity 
@Table(name="classtaggrp")
public class ClassTagGroup implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
    private ClassTgGrpCompositeKey classTgGrpCompositeKey;
	
	@Column(name = "createdby")
	private int createdBy;
	
	@Column(name="creationDt")
	private  Timestamp creationDt ;
	
	//check need of both
	@Transient
	private String tagGrpNm;

	/*
	 * @Transient private int tagGrpId;
	 */
	
	public ClassTagGroup() {
		
	}
	
	public ClassTgGrpCompositeKey getClassTgGrpCompositeKey() {
		return classTgGrpCompositeKey;
	}

	public void setClassTgGrpCompositeKey(ClassTgGrpCompositeKey classTgGrpCompositeKey) {
		this.classTgGrpCompositeKey = classTgGrpCompositeKey;
	}

	public int getCreatedBy() {
		return createdBy;
	}


	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}


	public Timestamp getCreationDt() {
		return creationDt;
	}


	public void setCreationDt(Timestamp creationDt) {
		this.creationDt = creationDt;
	}


	public String getTagGrpNm() {
		return tagGrpNm;
	}


	public void setTagGrpNm(String tagGrpNm) {
		this.tagGrpNm = tagGrpNm;
	}

	public ClassTagGroup(ClassTgGrpCompositeKey classTgGrpCompositeKey, int createdBy, Timestamp creationDt,
			String tagGrpNm) {
		super();
		this.classTgGrpCompositeKey = classTgGrpCompositeKey;
		this.createdBy = createdBy;
		this.creationDt = creationDt;
		this.tagGrpNm = tagGrpNm;
	}


//	public int getTagGrpId() {
//		return tagGrpId;
//	}
//
//
//	public void setTagGrpId(int tagGrpId) {
//		this.tagGrpId = tagGrpId;
//	}
//	
	

	

	
	

	
}
