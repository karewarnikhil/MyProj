package com.common.Controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.common.Dao.MenuDao;
import com.common.Dao.UsersDao;
import com.common.Objects.MenuObject;
import com.common.Objects.UsersObject;

@Controller
public class MenuController {

	   
	   
	   @Autowired
	   private UsersDao usersDao;
	   
	   @Autowired
	   private MenuDao menuDao;
	
	   @RequestMapping(value = "/manageMenu", method = RequestMethod.GET)
	   public String manageMenu(Model model,HttpServletRequest request){  
		   UsersObject usersSessionObject = (UsersObject) request.getSession().getAttribute("users");
	 	   if(usersSessionObject != null) {
			   List<MenuObject> listOfMenu = (List<MenuObject>) menuDao.getMenuList();
			   model.addAttribute("listOfMenuForDt", listOfMenu);
	       return "manageMenu"; 
	 	   }else {
	 		   return "loginIn";
	 	   }
	   } 
	   
	   
	   @RequestMapping(value = "/registerMenu", method = RequestMethod.GET)
	   public String registerMenu(Model model,HttpServletRequest request){  
		   UsersObject usersSessionObject = (UsersObject) request.getSession().getAttribute("users");
	 	   if(usersSessionObject != null) {
			   //List<MenuObject> listOfMenu = (List<MenuObject>) menuDao.getMenuList();
			  // model.addAttribute("listOfMenu", listOfMenu);
			   model.addAttribute("menuObject", new MenuObject());
	       return "registerMenu"; 
	 	   }else {
	 		   return "loginIn";
	 	   }
	   } 
	   
	   @RequestMapping(value="/menuAccess", method = RequestMethod.GET)  
	   public String manageMenuAccess(Model model, HttpServletRequest request){  
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) request.getSession().getAttribute("users");
	 	   if(usersSessionObject != null) {
		   //change get it from hash map define in constant file
	       List<UsersObject> usersList = usersDao.getAllUsersForMenu();
	       model.addAttribute("backPage", "home");
	       session.setAttribute("usersList", usersList);
	       return "menuAccess";
	 	   }else {
	 		   return "loginIn";
	 	   }
	   } 
	   
	   //check and try to eliminate code.
	   @RequestMapping(value="/deleteFormUACC", method = RequestMethod.GET)  
	   public String deleteMenuAccess(HttpServletRequest request){  
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) request.getSession().getAttribute("users");
	 	   if(usersSessionObject != null) {
		   //change get it from hash map define in constant file
	       List<UsersObject> usersList = usersDao.getAllUsers();
	       session.setAttribute("usersList", usersList);
	       return "menuAccessDelete";
	 	   }else {
	 		   return "loginIn";
	 	   }
	   } 
	
	   
}
