package com.common.Controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.common.Dao.BranchDao;
import com.common.Dao.RackDao;
import com.common.Objects.RackObject;
import com.common.Objects.UsersObject;

@Controller
public class RackController {
	
	
	@Autowired
	BranchDao branchDao;
	
	@Autowired
	RackDao rackDao;

	@RequestMapping(value = "/manageRack", method = RequestMethod.GET)
    public ModelAndView manageDepartment(Model model,HttpServletRequest request) {  
	   HttpSession session = request.getSession();
	   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
	   if(usersSessionObject != null) {
		   List<RackObject> rackList = rackDao.getAllRacks();
		   return new ModelAndView("manageRack","rackList",rackList);  
	   }  else {
		   return new ModelAndView("loginIn");  
	   }
    } 
	
	@RequestMapping(value = "/registerRack", method = RequestMethod.GET)
	   public String showRackForm(Model model,HttpServletRequest request){  
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
			   //List<BranchObject> branchList = branchDao.getBranchList();
			  // model.addAttribute("branchList", branchList);
		       model.addAttribute("rack",  new RackObject());
		       return "registerRack"; 
		   }else {
			   return "loginIn"; 
		   }
	   } 
	
	@RequestMapping(value = "/saveRack", method = RequestMethod.POST)
	public String saveList(@ModelAttribute("rackObject") RackObject rackObject, Model model, HttpServletRequest request) {
		UsersObject usersObject = (UsersObject) request.getSession().getAttribute("users");
		if (usersObject != null) {
			RackObject rackObjectOne = rackDao.getRackByBranchId(rackObject.getBranchId(),rackObject.getRackNo());
			if(rackObjectOne != null && rackObject.getRackNo().equals(rackObjectOne.getRackNo())) {
				model.addAttribute("error", "Rack Number already exists.");
				model.addAttribute("rack", rackObject);
				return "registerRack";
			}else {
				rackDao.saveRackObject(rackObject);
				model.addAttribute("message", "Rack Number added successfully.");
				model.addAttribute("rackObject", new RackObject());
				model.addAttribute("rackList",rackDao.getAllRacks());
				return "manageRack";
			}
			
		}else {
			return "loginIn";
		}
		
	}
	
	@RequestMapping(value="/editRack", method = RequestMethod.GET)  
	   public ModelAndView editRack(@RequestParam("rackId") Integer rackId,HttpServletRequest request){  
		   HttpSession session = request.getSession();
		   request.setAttribute("rackId", rackId);
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
			   RackObject rackObject = findByRackId(rackId);
		       return new ModelAndView("editRack","rack",rackObject);  
		   }else {
			   return new ModelAndView("loginIn"); 
		   }
	   }  
	
	@RequestMapping(value = "/updateRack", method = RequestMethod.POST)
	   public String updateBranch(@ModelAttribute("rack") RackObject rackObject, BindingResult result,Model model,HttpServletRequest request){
		   HttpSession session = request.getSession();
		   UsersObject usersSessionObject = (UsersObject) session.getAttribute("users");
		   if(usersSessionObject != null) {
			   RackObject rackObjectOne = rackDao.getRackByBranchId(rackObject.getBranchId(),rackObject.getRackNo());
				if(rackObjectOne != null && rackObjectOne.getRackId() != rackObject.getRackId() && rackObject.getRackNo().equals(rackObjectOne.getRackNo())) {
					model.addAttribute("error", "Rack Number already exists.");
					model.addAttribute("rack", rackObject);
					return "editRack";
				}
				else {
					rackDao.saveRackObject(rackObject);
					model.addAttribute("message", "Rack Updated Successfully.");
					model.addAttribute("rack",rackObject);
					 return "editRack";
				}
				/*
				 * HashMap<Long, String> hashMapofDepartment =
				 * DmsConstant.HASHMAP_OF_DEPARTMENT;
				 * if(departmentObject.getStatus().equals("A") &&
				 * hashMapofDepartment.containsKey((long)departmentObject.getDeptId())){
				 * hashMapofDepartment.replace((long)departmentObject.getDeptId(),
				 * departmentObject.getDeptNm()); }else
				 * if(departmentObject.getStatus().equals("A") &&
				 * !(hashMapofDepartment.containsKey((long)departmentObject.getDeptId()))){
				 * hashMapofDepartment.put((long)departmentObject.getDeptId(),
				 * departmentObject.getDeptNm()); } else
				 * if(departmentObject.getStatus().equals("D")){
				 * hashMapofDepartment.remove((long)departmentObject.getDeptId()); }
				 */
		     //return "redirect:/manageDepartment"; 
		   }else {
			   return "loginIn"; 
		   }
	   }  
	
	@RequestMapping(value = "/getRackDropDown", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<RackObject> getRackDropDown(@RequestParam("branchId") long branchId) {
	    List<RackObject> rackList = rackDao.getRackDropDown(branchId);
		return rackList;
	}
	
	 private RackObject findByRackId(Integer rackId) {
		   RackObject rackObject =  rackDao.getRackById(rackId); 
		   return rackObject;
	 }

}
