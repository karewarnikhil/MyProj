package com.common.Dao;

public interface CanvasDao {
	
	
}
