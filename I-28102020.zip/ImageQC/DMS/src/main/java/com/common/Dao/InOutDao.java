package com.common.Dao;

import java.util.List;

import com.common.Objects.DocumentObject;
import com.common.Objects.ReportSearchObject;

public interface InOutDao {

	List<DocumentObject> getFilesWithFileNm(ReportSearchObject reportSearchObject);
}
