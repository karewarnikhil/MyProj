package com.common.Dao;

import java.util.List;

import com.common.Objects.MessageObject;

public interface MessageDao {
	
	public	void saveMessageObject(MessageObject messageObject);
	
	public List<MessageObject> getMessages(String userId);
	
	public MessageObject getMessageById(long messageId);
	
	public long getUserMessageCount(String userId);
	
}
