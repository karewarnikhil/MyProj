package com.common.DaoImpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.DesignationDao;
import com.common.Objects.DesignationObject;


@Repository
@Transactional
public class DesignationDaoImpl implements DesignationDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	
	public void saveDesignationObject(DesignationObject designationObject) {
		sessionFactory.getCurrentSession().saveOrUpdate(designationObject);
	}


	public List<DesignationObject> getAllDesignation() {
		return sessionFactory.getCurrentSession().createQuery(" FROM DesignationObject order by desgId desc").list();
	}
	
	
	public DesignationObject getDesignationById(Integer designationId) {
		DesignationObject designationObject = (DesignationObject) sessionFactory.getCurrentSession().get(DesignationObject.class,designationId);
		return designationObject;
	}

	/*
	 * //need to delete this method also from dao public void
	 * deleteDesignationObject(DesignationObject designationObject) {
	 * sessionFactory.getCurrentSession().delete(designationObject); }
	 */


	@Override
	public Map<Long, String> getHashmapofDesignationObject() {
		HashMap<Long, String> hashMapofDesignation = new HashMap<>();
		List<DesignationObject> getAllDesignation = sessionFactory.getCurrentSession().createQuery("SELECT new DesignationObject (dg.desgId,dg.desgNm) FROM DesignationObject dg where dg.desgId > 0 AND dg.status = :status order by dg.desgNm ").setParameter("status", "A").list();
		
		for(DesignationObject designationObject:getAllDesignation) {
			hashMapofDesignation.put((long)designationObject.getDesgId(), designationObject.getDesgNm());
		}
		hashMapofDesignation.values().stream().forEach(System.out::println);
		return hashMapofDesignation;
	}

}
