package com.common.DaoImpl;

import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.common.Dao.SubDepartmentDao;
import com.common.Objects.SubDepartmentObject;

@Repository
@Transactional
public class SubDepartmentDaoImpl implements SubDepartmentDao{
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void saveSubDepartmentObject(SubDepartmentObject subDepartmentObject) {
		sessionFactory.getCurrentSession().saveOrUpdate(subDepartmentObject);
		
	}
	
	@Override
	public void updateSubDepartmentObject(SubDepartmentObject subDepartmentObject) {
		sessionFactory.getCurrentSession().update(subDepartmentObject);
		
	}

	@Override
	public List<SubDepartmentObject> getAllSubDepartments() {
		return sessionFactory.getCurrentSession().createQuery(" FROM SubDepartmentObject order by subDeptId desc").list();
	}

	@Override
	public SubDepartmentObject getSubDepartmentById(Integer subDepartmentId) {
		System.out.println(subDepartmentId);
		SubDepartmentObject subDepartmentObject = (SubDepartmentObject) sessionFactory.getCurrentSession().get(SubDepartmentObject.class,subDepartmentId);
		return subDepartmentObject;
	}

	/*
	@Override
	public Map<Long, String> getHashmapofSubDepartmentObject() {
		// TODO Auto-generated method stub
		return null;
	}*/

	@Override
	public List<SubDepartmentObject> getSubDeptForDropDownByDeptId(long deptId) {
		return sessionFactory.getCurrentSession().createQuery(" FROM SubDepartmentObject where status=:status And deptid=:deptId order by subDeptNm ").setParameter("status", "A").setParameter("deptId", deptId).list();

	}

	@Override
	public List<SubDepartmentObject> getClassByDeptAndROP(long deptId) {
		List<SubDepartmentObject> subDeptList = sessionFactory.getCurrentSession().createQuery(" FROM SubDepartmentObject where deptId = :deptId") .setParameter("deptId", deptId).list();
		 // listB = sessionFactory.getCurrentSession(). createQuery(" FROM ClassObject where (readOnlyPublic= :status or readOnlyOthDept= :status)and deptId!= :deptId" ).setParameter("status", "Y").setParameter("deptId", userDeptId).list();
		return subDeptList;
	}

	@Override
	public SubDepartmentObject getSubDeptByDeptId(SubDepartmentObject subDepartmentObject) {
		SubDepartmentObject subDepartmentObjectCheck = (SubDepartmentObject)sessionFactory.getCurrentSession().createQuery(" FROM SubDepartmentObject where deptId = :deptId and subDeptNm = :subDeptNm").setParameter("deptId", subDepartmentObject.getDeptId()).setParameter("subDeptNm", subDepartmentObject.getSubDeptNm()).uniqueResult();
		return subDepartmentObjectCheck;
	}
	
	

}
