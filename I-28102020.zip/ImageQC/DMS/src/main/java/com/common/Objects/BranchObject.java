package com.common.Objects;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

@Entity @Table(name="branchmst")
public class BranchObject implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "branchId", updatable = false, nullable = false)
	private  Integer branchId;
	
	@Column(name="branchNm",unique=true)
	private  String branchNm ;
	
	@Column(name="branchAddress")
	private  String branchAddress;
	
	@CreationTimestamp
	@Column(name="creationDt")
	private Timestamp creationDt;
	
	@Column(name="status")
	private String status;

	public Integer getBranchId() {
		return branchId;
	}

	public void setBranchId(Integer branchId) {
		this.branchId = branchId;
	}

	public String getBranchNm() {
		return branchNm;
	}

	public void setBranchNm(String branchNm) {
		this.branchNm = branchNm;
	}

	public String getBranchAddress() {
		return branchAddress;
	}

	public void setBranchAddress(String branchAddress) {
		this.branchAddress = branchAddress;
	}

	public Timestamp getCreationDt() {
		return creationDt;
	}

	public void setCreationDt(Timestamp creationDt) {
		this.creationDt = creationDt;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public BranchObject() {
		super();
	}

	public BranchObject(Integer branchId, String branchNm, String branchAddress, Timestamp creationDt, String status) {
		super();
		this.branchId = branchId;
		this.branchNm = branchNm;
		this.branchAddress = branchAddress;
		this.creationDt = creationDt;
		this.status = status;
	}

	public BranchObject(Integer branchId, String branchNm) {
		super();
		this.branchId = branchId;
		this.branchNm = branchNm;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((branchId == null) ? 0 : branchId.hashCode());
		result = prime * result + ((branchNm == null) ? 0 : branchNm.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BranchObject other = (BranchObject) obj;
		if (branchId == null) {
			if (other.branchId != null)
				return false;
		} else if (!branchId.equals(other.branchId))
			return false;
		if (branchNm == null) {
			if (other.branchNm != null)
				return false;
		} else if (!branchNm.equals(other.branchNm))
			return false;
		return true;
	}
	
	
	
	
	
}
