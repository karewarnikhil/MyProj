package com.common.Objects;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

@Entity @Table(name="compartMst")
public class CompartmentObject {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "compartId", updatable = false, nullable = false)
	private Integer compartId;

	@Column(name = "compNo")
	private String compNo;
	
	@JoinColumn(name="branchId", referencedColumnName="branchId")
	private Integer branchId;
	
	@JoinColumn(name="rackId", referencedColumnName="rackId")
	private Integer rackId;
	
	@JoinColumn(name="shelfId", referencedColumnName="shelfId")
	private Integer shelfId;
	
	@Column(name="status")
	private String status;
		
	@CreationTimestamp
	@Column(name="creationDt")
	private Timestamp creationDt;
	
	public Integer getCompartId() {
		return compartId;
	}

	public void setCompartId(Integer compartId) {
		this.compartId = compartId;
	}

	public String getCompNo() {
		return compNo;
	}

	public void setCompNo(String compNo) {
		this.compNo = compNo;
	}

	public Integer getBranchId() {
		return branchId;
	}

	public void setBranchId(Integer branchId) {
		this.branchId = branchId;
	}

	public Integer getRackId() {
		return rackId;
	}

	public void setRackId(Integer rackId) {
		this.rackId = rackId;
	}

	public Integer getShelfId() {
		return shelfId;
	}

	public void setShelfId(Integer shelfId) {
		this.shelfId = shelfId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getCreationDt() {
		return creationDt;
	}

	public void setCreationDt(Timestamp creationDt) {
		this.creationDt = creationDt;
	}
	
	public CompartmentObject(Integer compartId, String compNo, Integer branchId, Integer rackId, Integer shelfId,
			String status, Timestamp creationDt) {
		super();
		this.compartId = compartId;
		this.compNo = compNo;
		this.branchId = branchId;
		this.rackId = rackId;
		this.shelfId = shelfId;
		this.status = status;
		this.creationDt = creationDt;
	}

	public CompartmentObject() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
