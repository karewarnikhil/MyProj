package com.common.Objects;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name = "HisFolderMst")
public class HisFolderObject implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "HisId", updatable = false, nullable = false)
	private int hisId;
    
	//need to convert to composite foreign key
	@Column(name = "folderId")
	private long folderId;

	@Column(name = "foldernm")
	private String folderNm;

	@Column(name = "IsInnerFolder")
	private String isInnerFolder;

	@Column(name = "atriBt")
	private String atriBt;

	@Column(name = "readOnlyOthDept")
	private String readOnlyOthDept;

	@Column(name = "readOnlyPublic")
	private String readOnlyPublic;

	@Column(name = "createdBy")
	private int createdBy;

	@CreationTimestamp
	@Column(name = "creationDt")
	private Timestamp creationDt;

	public HisFolderObject() {

	}

	public HisFolderObject(int hisId, long folderId, String folderNm, String isInnerFolder, String atriBt,
			String readOnlyOthDept, String readOnlyPublic, int createdBy, Timestamp creationDt) {
		super();
		this.hisId = hisId;
		this.folderId = folderId;
		this.folderNm = folderNm;
		this.isInnerFolder = isInnerFolder;
		this.atriBt = atriBt;
		this.readOnlyOthDept = readOnlyOthDept;
		this.readOnlyPublic = readOnlyPublic;
		this.createdBy = createdBy;
		this.creationDt = creationDt;
	}

	public int getHisId() {
		return hisId;
	}

	public void setHisId(int hisId) {
		this.hisId = hisId;
	}

	public long getFolderId() {
		return folderId;
	}

	public void setFolderId(long folderId) {
		this.folderId = folderId;
	}

	public String getFolderNm() {
		return folderNm;
	}

	public void setFolderNm(String folderNm) {
		this.folderNm = folderNm;
	}

	public String getIsInnerFolder() {
		return isInnerFolder;
	}

	public void setIsInnerFolder(String isInnerFolder) {
		this.isInnerFolder = isInnerFolder;
	}

	public String getAtriBt() {
		return atriBt;
	}

	public void setAtriBt(String atriBt) {
		this.atriBt = atriBt;
	}

	public String getReadOnlyOthDept() {
		return readOnlyOthDept;
	}

	public void setReadOnlyOthDept(String readOnlyOthDept) {
		this.readOnlyOthDept = readOnlyOthDept;
	}

	public String getReadOnlyPublic() {
		return readOnlyPublic;
	}

	public void setReadOnlyPublic(String readOnlyPublic) {
		this.readOnlyPublic = readOnlyPublic;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreationDt() {
		return creationDt;
	}

	public void setCreationDt(Timestamp creationDt) {
		this.creationDt = creationDt;
	}

	

}
