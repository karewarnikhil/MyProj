package com.common.Objects;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

@Entity @Table(name="rackmst")
public class RackObject {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "rackId", updatable = false, nullable = false)
	private Integer rackId;

	@Column(name = "rackNo")
	private String rackNo;

	@JoinColumn(name="branchId", referencedColumnName="branchId")
	private Integer branchId;
	
	@CreationTimestamp
	@Column(name="creationDt")
	private Timestamp creationDt;
	
	@Column(name="status")
	private String status;
	
	public Integer getRackId() {
		return rackId;
	}

	public void setRackId(Integer rackId) {
		this.rackId = rackId;
	}

	public String getRackNo() {
		return rackNo;
	}

	public void setRackNo(String rackNo) {
		this.rackNo = rackNo;
	}

	public Integer getBranchId() {
		return branchId;
	}

	public void setBranchId(Integer branchId) {
		this.branchId = branchId;
	}

	public Timestamp getCreationDt() {
		return creationDt;
	}

	public void setCreationDt(Timestamp creationDt) {
		this.creationDt = creationDt;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public RackObject() {
		super();
	}

	public RackObject(Integer rackId, String rackNo) {
		super();
		this.rackId = rackId;
		this.rackNo = rackNo;
	}

	public RackObject(Integer rackId, String rackNo, Integer branchId, Timestamp creationDt, String status) {
		super();
		this.rackId = rackId;
		this.rackNo = rackNo;
		this.branchId = branchId;
		this.creationDt = creationDt;
		this.status = status;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((rackId == null) ? 0 : rackId.hashCode());
		result = prime * result + ((rackNo == null) ? 0 : rackNo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RackObject other = (RackObject) obj;
		if (rackId == null) {
			if (other.rackId != null)
				return false;
		} else if (!rackId.equals(other.rackId))
			return false;
		if (rackNo == null) {
			if (other.rackNo != null)
				return false;
		} else if (!rackNo.equals(other.rackNo))
			return false;
		return true;
	}
	
	
	
	

}
