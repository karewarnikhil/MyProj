package com.common.Objects;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="searchcondition")
public class SearchConditionObject implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "srNo", updatable = false, nullable = false)
	private int srNo;

	@Column(name = "tagtypeid")
	private int tagtypeId;

	@Column(name = "frontdata")
	private String frontData;

	@Column(name = "backdata")
	private String backData;

	public SearchConditionObject() {
		super();
	}

	public SearchConditionObject(int srNo, int tagtypeId, String frontData, String backData) {
		super();
		this.srNo = srNo;
		this.tagtypeId = tagtypeId;
		this.frontData = frontData;
		this.backData = backData;
	}

	public int getSrNo() {
		return srNo;
	}

	public void setSrNo(int srNo) {
		this.srNo = srNo;
	}

	public int getTagtypeId() {
		return tagtypeId;
	}

	public void setTagtypeId(int tagtypeId) {
		this.tagtypeId = tagtypeId;
	}

	public String getFrontData() {
		return frontData;
	}

	public void setFrontData(String frontData) {
		this.frontData = frontData;
	}

	public String getBackData() {
		return backData;
	}

	public void setBackData(String backData) {
		this.backData = backData;
	}
	
}
