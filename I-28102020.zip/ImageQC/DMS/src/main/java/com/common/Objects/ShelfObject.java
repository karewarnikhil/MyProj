package com.common.Objects;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

@Entity @Table(name="shelfmst")
public class ShelfObject {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "shelfId", updatable = false, nullable = false)
	private int shelfId;

	@Column(name = "shelfNo")
	private String shelfNo;
	
	@JoinColumn(name="branchId", referencedColumnName="branchId")
	private int branchId;
	
	@JoinColumn(name="rackId", referencedColumnName="rackId")
	private int rackId;
	
	@Column(name="status")
	private String status;
	
	
	@CreationTimestamp
	@Column(name="creationDt")
	private Timestamp creationDt;

	public int getShelfId() {
		return shelfId;
	}

	public void setShelfId(int shelfId) {
		this.shelfId = shelfId;
	}

	public String getShelfNo() {
		return shelfNo;
	}

	public void setShelfNo(String shelfNo) {
		this.shelfNo = shelfNo;
	}

	public int getRackId() {
		return rackId;
	}

	public void setRackId(int rackId) {
		this.rackId = rackId;
	}
	
	public int getBranchId() {
		return branchId;
	}

	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	public Timestamp getCreationDt() {
		return creationDt;
	}

	public void setCreationDt(Timestamp creationDt) {
		this.creationDt = creationDt;
	}

	public ShelfObject() {
		super();
	}

	public ShelfObject(int shelfId, String shelfNo, int branchId, int rackId, String status, Timestamp creationDt) {
		super();
		this.shelfId = shelfId;
		this.shelfNo = shelfNo;
		this.branchId = branchId;
		this.rackId = rackId;
		this.status = status;
		this.creationDt = creationDt;
	}

	public ShelfObject(int shelfId, String shelfNo) {
		super();
		this.shelfId = shelfId;
		this.shelfNo = shelfNo;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + shelfId;
		result = prime * result + ((shelfNo == null) ? 0 : shelfNo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ShelfObject other = (ShelfObject) obj;
		if (shelfId != other.shelfId)
			return false;
		if (shelfNo == null) {
			if (other.shelfNo != null)
				return false;
		} else if (!shelfNo.equals(other.shelfNo))
			return false;
		return true;
	}
	
	

	
}
