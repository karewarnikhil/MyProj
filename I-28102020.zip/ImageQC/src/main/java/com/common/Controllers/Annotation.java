package com.common.Controllers;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;

public class Annotation {
    
	public static final String SRC = "E:/PdftoImage/1000000237.pdf";
    public static final String DEST = "E:/PdftoImage/textHighLightText.pdf";
    
	public static void main(String[] args) {
		
		
		//text annotation.
		
		/*
		 * File file = new File(SRC); file.getParentFile().mkdirs(); try { new
		 * Annotation().createPdf(DEST); } catch (IOException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); }
		 */
		 
	        
	    //highlight pdf
		
		  File file = new File(DEST); 
		  file.getParentFile().mkdirs();
		  
		  try { 
			  	new Annotation().manipulatePdf(SRC, DEST); 
		  } catch (java.io.IOException e) {
			  // TODO Auto-generated catch block 
			  e.printStackTrace();
		  } catch (DocumentException e) { 
		   // TODO Auto-generated  catch block
		  e.printStackTrace(); }
		 
		
		// text markup annotation.
		
		/*
		 * File file = new File(DEST); file.getParentFile().mkdirs(); try { new
		 * Annotation().createPdf(DEST); } catch (IOException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); }
		 */
		 
		
	}
	
	//highlight text
	
	  public void manipulatePdf(String src, String dest) throws IOException,  DocumentException, IOException { 
		  PdfReader reader; 
		  PdfStamper stamper = null;
	  
		  reader = new PdfReader(src); 
		  stamper = new PdfStamper(reader, new FileOutputStream(dest)); 
	 
		  PdfContentByte canvas = stamper.getUnderContent(1);
	  
		  canvas.saveState(); 
		  canvas.setColorFill(BaseColor.RED); 
		  canvas.rectangle(100,786,100, 16); 
		  canvas.fill(); 
		  canvas.restoreState(); 
		  stamper.close();
		  reader.close(); 
	  }
	 
	 
	
	//text annotation
	
	/*
	 * public void createPdf(String dest) throws IOException {
	 * 
	 * //Initialize PDF document PdfDocument pdf = new PdfDocument(new
	 * PdfWriter(dest));
	 * 
	 * 
	 * //Initialize document Document document = new Document(pdf); document.add(new
	 * Paragraph("The example of text annotation.")); //Create text annotation
	 * PdfAnnotation ann = new PdfTextAnnotation(new Rectangle(20, 800, 0, 0))
	 * .setOpen(true) .setColor(ColorConstants.GREEN) .setTitle(new
	 * PdfString("iText"))
	 * .setContents("With iText, you can truly take your documentation needs to the next level."
	 * ); pdf.getFirstPage().addAnnotation(ann);
	 * 
	 * //Close document document.close();
	 * 
	 * }
	 */
	 
	
	

	//text markup annotation
	
	/*
	 * public void createPdf(String dest) throws IOException {
	 * 
	 * //Initialize PDF document PdfDocument pdf = new PdfDocument(new
	 * PdfWriter(dest));
	 * 
	 * 
	 * //Initialize document Document document = new Document(pdf); Paragraph p =
	 * new Paragraph("The example of text markup annotation.");
	 * document.showTextAligned(p, 20, 795, 1, TextAlignment.LEFT,
	 * VerticalAlignment.MIDDLE, 0);
	 * 
	 * //Create text markup annotation PdfAnnotation ann =
	 * PdfTextMarkupAnnotation.createHighLight(new Rectangle(105, 790, 64, 10), new
	 * float[]{169, 790, 105, 790, 169, 800, 105, 800})
	 * .setColor(ColorConstants.YELLOW) .setTitle(new PdfString("Hello!"))
	 * .setContents(new PdfString("I'm a popup.")) .setTitle(new PdfString("Hello"))
	 * .setRectangle(new PdfArray(new float[]{100, 600, 200, 100}));
	 * pdf.getFirstPage().addAnnotation(ann);
	 * 
	 * //Close document document.close();
	 * 
	 * }
	 */
	 

}
