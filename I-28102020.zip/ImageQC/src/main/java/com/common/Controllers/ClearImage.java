package com.common.Controllers;

import java.io.File;
import java.util.Scanner;

import ClearImageJNI.CiException;
import ClearImageJNI.CiServer;
import ClearImageJNI.EBorderExtractAlgorithm;
import ClearImageJNI.EBorderExtractFlags;
import ClearImageJNI.EFileFormat;
import ClearImageJNI.ICiImage;
import ClearImageJNI.ICiRepair;
import ClearImageJNI.ICiServer;

public class ClearImage {
	
	protected static ICiServer Ci = null;
	protected static ICiImage Image = null;
	protected static boolean useFullIo = true;

	
	  public static void main(String[] args) {
	  
		/*
		 * String fileIn = "E:/ClearImage/"; String fileOut = "E:/ClearImageOutput/";
		 */
	  System.out.println("Please enter folder path for input files.");
	  Scanner in = new Scanner(System.in);
      String fileIn = in.nextLine();
      
      File directory = new File(fileIn); //get all the files from a directory
	  File[] fList = directory.listFiles();
	  
	  System.out.println("Number of files in folders:"+fList.length);
      
     
      String fileOut = fileIn+"/OutputFiles/";
	 
	  ClearImage clearImage = new  ClearImage();
	  
	  //ICiRepair iCiRepair; 
	  try { 
	  CiServer objCi = new CiServer(); 
	  Ci = objCi.getICiServer();
	   for (File file : fList)
	   {   
		   if (file.isFile()){
			   clearImage.repair_image(fileIn+file.getName(), 1, fileOut+file.getName()); 
			   System.out.println("Completed File Name:"+file.getName());
	       }else if(file.isDirectory()) {
	    	   
	       }
	  }
	  
	   System.out.println("Total process completed successfully:");
	  } catch (CiException e) { // TODO Auto-generated catch block
	  e.printStackTrace(); }
	 
	  
	  
	/*
	 * try { // Create ClearImage Server CiServer objCi = new CiServer(); ICiServer
	 * Ci = objCi.getICiServer(); // Display version and licensing information
	 * 
	 * System.out.println("ClearImage ver " + Ci.getVerMajor() + "." +
	 * Ci.getVerMinor() + "." + Ci.getVerRelease() + "  " +
	 * Ci.gtem.out.println(Ci.getInfo(EInfoType.ciModulesList, 0));
	 * 
	 * } catch (Exception ex) { System.out.println(); ex.printStackTrace();
	 * etInfo(EInfoType.fromInt(6748), 0)); Sys }
	 */
	  
	  
	  }
	 

	void RepairPage(ICiRepair repair) {
		try {
			/*
			 * repair.BorderExtract(EBorderExtractFlags.ciBexBorderDeskewCrop,
			 * EBorderExtractAlgorithm.ciBeaFaster); // Deskew and crop based on black
			 * border repair.CleanNoiseExt (new
			 * ECleanNoiseFlags(ECleanNoiseFlags.ciCnxBlackNoise,ECleanNoiseFlags.
			 * ciCnxWhiteNoise,ECleanNoiseFlags.ciCnxMarginsNoise), 10, 10, 10, 10);// Clean
			 * black and white noise
			 * 
			 * repair.CleanNoise(10); // Clean black noise of 3 pixels
			 * //repair.AutoDeskew(); //repair.ClearBackground(0);
			 * repair.RemovePunchHoles();
			 * repair.DeleteLines(ELineDirection.ciLineVertAndHorz, EBoolean.ciFalse);
			 * //repair.AdvancedBinarize(0, 0 , 0); // Convert to bitonal an image with
			 * complex background patterns
			 * 
			 * 
			 * //repair.ClearBackground(arg0);
			 * 
		     
			 * repair.SmoothCharacters(ESmoothType.ciSmoothDarkenEdges); repair.AutoCrop(3,
			 * 3, 3, 3); // Crop to 10 pixels on each side to bitonal
			 * //repair.ReconstructLines(ELineDirection.ciLineVertAndHorz);
			 */
			//repair.AutoCrop(-250,-100,-400,-200);
			//
		//	repair.AutoRegister(300,300);
			repair.BorderExtract(EBorderExtractFlags.ciBexBorderDeskewCrop, EBorderExtractAlgorithm.ciBeaCleaner);
		    repair.AutoCrop(-10,-10,-10,-10);
		   //repair.ClearBackground(3);
		//	repair.AdvancedBinarize(10, 10, 10);
			//repair.AutoInvertImage(-10);
		//	System.out.println("BorderExtract  ");
			// repair.setPLineCurvature(ELineCurvature.ciCurvHigh);
		// repair.CleanNoise(10);
	   //  repair.CleanNoiseExt(new ECleanNoiseFlags (ECleanNoiseFlags.ciCnxBlackNoise,ECleanNoiseFlags.ciCnxWhiteNoise,ECleanNoiseFlags.ciCnxMarginsNoise), 10,10,10,10);
		//System.out.println("CleanNoiseExt  ");
			// repair.setPMinLineLength(100);
			// repair.setPMaxLineGap(5);
	    // repair.RemovePunchHoles();
		//	System.out.println("RemovePunchHoles  ");
			//repair.DeleteLines(ELineDirection.ciLineVertAndHorz, EBoolean.ciFalse);
		  //  repair.RemoveHalftone(); 
		//	System.out.println("DeleteLines");
			repair.AutoDeskew();
			
		//	System.out.println("AutoDeskew");
			repair.AutoRotate();
			// System.out.println("AutoRotate ");
			
		//	System.out.println("AutoCrop");
			//repair.SmoothCharacters(ESmoothType.ciSmoothDarkenEdges);
		  // repair.ClearBackground(200);
		} catch (CiException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	protected static void initCi() throws Exception {
		CiServer objCi = new CiServer();
		Ci = objCi.getICiServer();
		// serverInformation("");
		Image = Ci.CreateImage();
	}

	void repair_image(String fileName, int page, String fileOut) {
		try {
			ICiRepair repair = Ci.CreateRepair();
			repair.getImage().Open(fileName, page);
			RepairPage(repair);
			repair.getImage().SaveAs(fileOut, EFileFormat.ciEXT);
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally { // Collect garbage periodically to release JNI-managed // objects
			System.gc();
		}
	}


}
