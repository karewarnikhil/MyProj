package com.common.Controllers;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import ClearImageJNI.CiException;
import ClearImageJNI.CiServer;
import ClearImageJNI.FBarcodeType;
import ClearImageJNI.ICiBarcode;
import ClearImageJNI.ICiBarcodePro;
import ClearImageJNI.ICiImage;
import ClearImageJNI.ICiServer;

public class CreatePdf extends JFrame implements ActionListener
{
	/**
	 * 
	 */
	protected static ICiServer Ci = null;
	protected static ICiImage Image = null;
	protected static boolean useFullIo = true;
	 
	private static final long serialVersionUID = 1L;
	JFrame jf,jf1;
	JTextField t1,t2,t3,t4,t5,tr,tq;
	JLabel l1,l2,l3,l4,l5,l6;
	JButton b0,b1,b2;
	Font f;
	JProgressBar jProgressBar;
	JPanel jPanel;
  
	

	DefaultTableModel model = new DefaultTableModel();
    JTable tabGrid = new JTable(model);
    JScrollPane scrlPane = new JScrollPane(tabGrid);

    public  CreatePdf()
	{
		jf=new JFrame();
		f = new Font("Times New Roman",Font.BOLD,20);
		jf.setLayout(null);

	    l6=new JLabel("CREATE PDF");
	    l6.setFont(new Font("Times New Roman",Font.BOLD,25));
	    l6.setBounds(320,50,300,40);l6.setForeground(Color.blue);
	    jf.add(l6);

		l1= new JLabel("Folder Path :");
		//l1.setFont(f);
		l1.setBounds(150,120,130,25);
	    jf.add(l1);

		t1=new JTextField(20);
		t1.setBounds(320,120,300,25);t1.setToolTipText("Enter Folder Path");
		jf.add(t1);

		/*
		 * l2 = new JLabel("Left Size Crop :"); //l2.setFont(f);
		 * l2.setBounds(150,160,170,25); jf.add(l2);
		 * 
		 * t2=new JTextField(20);
		 * t2.setBounds(320,160,100,25);t2.setToolTipText("Enter Left Size For Crop");
		 * jf.add(t2);
		 * 
		 * l3 = new JLabel("Right Size Crop :"); //l3.setFont(f);
		 * l3.setBounds(150,200,170,25); jf.add(l3);
		 * 
		 * t3=new JTextField(20);
		 * t3.setBounds(320,200,100,25);t3.setToolTipText("Enter Right Size For Crop");
		 * jf.add(t3);
		 * 
		 * l4 = new JLabel("Top Size Crop :"); //l4.setFont(f);
		 * l4.setBounds(150,240,170,25); jf.add(l4);
		 * 
		 * t4=new JTextField(20);
		 * t4.setBounds(320,240,100,25);t4.setToolTipText("Enter Top Size For Crop");
		 * jf.add(t4);
		 * 
		 * l5 = new JLabel("Bottom Size Crop :"); //l5.setFont(f);
		 * l5.setBounds(150,280,170,25); jf.add(l5);
		 * 
		 * t5=new JTextField(20);
		 * t5.setBounds(320,280,100,25);t5.setToolTipText("Enter Bottom Size For Crop");
		 * jf.add(t5);
		 */

	    b0 = new JButton("Save",new ImageIcon("images//save.png"));
        b0.setBounds(150,330,110,35);b0.setToolTipText("click to save create pdf");
		jf.add(b0);b0.addActionListener(this);

		b1 = new JButton("Clear",new ImageIcon("images//clear.png"));
		b1.setBounds(300,330,110,35);b1.setToolTipText("click to clear all textfilds");
	    jf.add(b1); b1.addActionListener(this);
	    
	    b2 = new JButton("Close",new ImageIcon("images//clear.png"));
		b2.setBounds(450,330,110,35);b2.setToolTipText("click to Close Window");
	    jf.add(b2); b2.addActionListener(this);
	    
	    jProgressBar = new JProgressBar(); 
	    jProgressBar.setMinimum(10);
	    jProgressBar.setStringPainted(true); 
	    jProgressBar.setForeground(Color.BLUE);
	    jProgressBar.setBounds(150,100,300,40);
	    
		/*
		 * jf1 = new JFrame(); jf1.setLayout(null); jf1.setTitle("Progress Bar");
		 * jf1.setSize(500,400); jf1.add(jProgressBar);
		 * jf1.getContentPane().setBackground(Color.WHITE); jf1.add(l6);
		 * jf1.setVisible(true);
		 */
	    
	    
	    jf.setTitle("CREATE PDF");
	    jf.setSize(900,500);
		jf.setLocation(20,20);
		jf.setResizable(false);
	    jf.getContentPane().setBackground(Color.WHITE);
		 //jf.setContentPane(new JLabel(new ImageIcon("E:\\HomeImages\\01.jpg")));
	    jf.setVisible(true);
     
	}

public void actionPerformed(ActionEvent ae)
	{
	if(ae.getSource()==b0)
	 {
	 	    String fileIn = t1.getText();
	       //	String leftCrop = t2.getText();
	       	//String rightCrop = t3.getText();
	       	//String topCrop = t4.getText();
	       	//String bottomCrop = t5.getText();

	    	if((((t1.getText()).equals(""))))
	        {
		    JOptionPane.showMessageDialog(this,"* Detail are Missing !","Warning!!!",JOptionPane.WARNING_MESSAGE);
	        }
			else
			{
			  try
			  	 {
				  File directory = new File(fileIn); //get all the files from a directory
				 // File[] fList = directory.listFiles();
				//  System.out.println("Number of files in folders:"+fList.length);
			      
			      CiServer objCi;
			     
					try {
						objCi = new CiServer();
						ICiServer Ci = objCi.getICiServer();
						ICiBarcodePro reader = Ci.CreateBarcodePro();
					    reader.setType(new FBarcodeType(FBarcodeType.cibfCode39, FBarcodeType.cibfCode128 , FBarcodeType.cibfCode93, FBarcodeType.cibfEan13, FBarcodeType.cibfCodabar));
						
						  System.out.println("Number of files in folders:"+directory.listFiles().length);
					      for (File file : directory.listFiles()) {
					    	  reader.getImage().Open(file.getPath(), 1);
							  reader.Find(0);
				              for (int i = 1; i <= reader.getBarcodes().getCount(); i++) {
				            	  System.out.println(reader.getBarcodes().getItem(i));
								  ICiBarcode iCiBarcode = reader.getBarcodes().getItem(i);
								  System.out.println(iCiBarcode.getType());
								  System.out.println(iCiBarcode.getText()); 
				              }
					      }
						
					} catch (CiException e) {
						e.printStackTrace();
					} 				
				 
				 int reply=JOptionPane.showConfirmDialog(null,"Create Pdf Operation Done Successfully.Do you want continue more?","Done Create Pdf",JOptionPane.YES_NO_OPTION);
	             if (reply == JOptionPane.YES_OPTION)
	   			{
	   		       jf.setVisible(false);
	   		       new CreatePdf();
	   		    }
	   		  else if (reply == JOptionPane.NO_OPTION)
	   			{
	   			  jf.setVisible(false);
		        }
	          }
  catch(Exception e)
  {
    System.out.println(e);
    JOptionPane.showMessageDialog(null,"Error:"+e);
  }
 }
}
  else if(ae.getSource()==b1)
     {//clear
          t1.setText("");
          t2.setText("");
          t3.setText("");
          t4.setText("");
          t5.setText("");
      }
    else if(ae.getSource()==b2)
    {
    	jf.setVisible(false);
	}
 }
	/*
	 * public static void main(String args[]) { new AutoCrop(); }
	 */

}

