package com.common.Controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;




public class FileCategorize {
	
	public static String  EXCELFILEPATH = "E:\\BookCategorization\\Kavya.xlsx";
	public static String destinationPath = "C:\\ThaneData\\Demo";

	public static void main(String[] args) {
		readFilesAndFolders();
	}
	
	 public static void readFilesAndFolders() {
		 
		 String directoryPath = "D:\\ThaneDataUpload\\9-OUTPUT\\9-REMAINING";
		 File folder = new File(directoryPath);
		
		try {
			FileInputStream excelFile = new FileInputStream(new File(EXCELFILEPATH));
			XSSFWorkbook workbook = new XSSFWorkbook(excelFile);
			XSSFSheet datatypeSheet = workbook.getSheetAt(0);
			Iterator<Row> iterator = datatypeSheet.iterator();
   
			 while (iterator.hasNext()) {
        		 Row currentRow = iterator.next();
        		
                 Iterator<Cell> cellIterator = currentRow.iterator();
                
                 Cell currentCell = cellIterator.next();
                 String subject = currentRow.getCell(1).getStringCellValue();
                 
                  System.out.println("subject===="+currentRow.getCell(0).getStringCellValue());
			        for (File file : folder.listFiles()) {
			        	 System.out.println(file.getName());
			        	 System.out.println(file.getName().trim().equals(currentCell.getStringCellValue().trim()+".pdf") && subject.equals("AD"));
			             if(file.isFile() && (file.isHidden() == false)) {
			            	 if(file.getName().trim().equals(currentCell.getStringCellValue().trim()+".pdf") && subject.equals("AD")) {
			            		System.out.println("File Name..."+file.getName().equals(currentCell.getStringCellValue()+".pdf"));
			            		//file.delete();
			            		String sourcePath = directoryPath+"\\"+file.getName();
			            		String destPath = null;
			            		destPath = destinationPath+"\\"+file.getName();
			            		System.out.println(destPath);
			            		 copyFile(sourcePath,destPath);
			            		 System.out.println("Files Copied SucceessFully");
			            		
			            	 }
			            	 
			        }
			    }
			 }
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }
	 
	 
	 public static void copyFile(String from, String to) throws IOException{
	       File src = new File(from);
	       File dest = new File(to);
	       FileUtils.copyFile(src, dest);
	    }
}