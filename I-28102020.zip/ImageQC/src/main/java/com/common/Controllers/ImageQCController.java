package com.common.Controllers;

import java.io.File;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import ClearImageJNI.CiServer;
import ClearImageJNI.EFileFormat;
import ClearImageJNI.ICiRepair;
import ClearImageJNI.ICiServer;

@Controller
public class ImageQCController {
	
	     @RequestMapping(value = "/home", method = RequestMethod.GET)
	     public String home(HttpServletRequest request)  {
			  return "loginIn";
		 }
	     
	     @RequestMapping(value ="/defaultPage", method = RequestMethod.GET)
			public ModelAndView getDefaultPage(HttpServletRequest request) {
				  return new ModelAndView("defaultPage");  
		 }
	     
	     @RequestMapping(value ="/autoRotate", method = RequestMethod.GET)
			public ModelAndView autoRotate(HttpServletRequest request) {
				  return new ModelAndView("autoRotate");  
		 }
	     
	     @RequestMapping(value ="/autoDeskew", method = RequestMethod.GET)
			public ModelAndView autoDeskew(HttpServletRequest request) {
				  return new ModelAndView("autoDeskew");  
		 }
	     
	     @RequestMapping(value ="/autoCrop", method = RequestMethod.GET)
			public ModelAndView autoCrop(HttpServletRequest request) {
				  return new ModelAndView("autoCrop");  
		 }
	     
	     @RequestMapping(value ="/removeHalfTone", method = RequestMethod.GET)
			public ModelAndView removeHalfTone(HttpServletRequest request) {
				  return new ModelAndView("removeHalfTone");  
		 }
	     
	     @RequestMapping(value ="/removePunchHole", method = RequestMethod.GET)
			public ModelAndView removePunchHole(HttpServletRequest request) {
				  return new ModelAndView("removePunchHoles");  
		 }
	     
	     @RequestMapping(value ="/cleanBorders", method = RequestMethod.GET)
			public ModelAndView cleanBorders(HttpServletRequest request) {
				  return new ModelAndView("cleanBorders");  
		 }
	     
	     @RequestMapping(value ="/smoothCharacter", method = RequestMethod.GET)
			public ModelAndView smoothCharacter(HttpServletRequest request) {
				  return new ModelAndView("smoothCharacters");  
		 }
	     
	     @RequestMapping(value ="/removeBackGround", method = RequestMethod.GET)
			public ModelAndView removeBackGround(HttpServletRequest request) {
				  return new ModelAndView("removeBackground");  
		 }
	     
	     @RequestMapping(value ="/removeLines", method = RequestMethod.GET)
			public ModelAndView removeLines(HttpServletRequest request) {
				  return new ModelAndView("removeLines");  
		 }
	     
	     
}
