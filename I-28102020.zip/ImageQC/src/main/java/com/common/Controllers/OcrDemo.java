package com.common.Controllers;


import java.io.File;
import java.util.ArrayList;
import java.util.List;

import net.sourceforge.tess4j.ITesseract;
import net.sourceforge.tess4j.ITesseract.RenderedFormat;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;

public class OcrDemo {

	public static void main(String[] args) {
		
		Tesseract tesseract = new Tesseract(); 
        try { 
              String input = "E:\\Nikhil\\1966- 1965- Vividha\\1966- 1965- Vividha_Page_005_Image_0001.jpg";
              String output = "E:\\Nikhil\\1966- 1965- Vividha\\1966- 1965- Vividha_Page_005_Image_0001Op";
              //  File file = new File(input);
             //  String inputTif = input.replaceAll(".jpg", ".tif");
             //   File fileTif = new File("E:\\Khopoli\\Demo\\Ocr\\1966- 1965- Vividha_Page_001_Image_0001.jpg");
             //    file.renameTo(fileTif);
        	//String input = "E:\\Khopoli\\Demo\\Ocr\\Image 4.jpeg";
            //String output = "E:\\Khopoli\\Demo\\Ocr\\Image 4AOutput";
            
            tesseract.setDatapath("E:\\workspaceNikhil\\DMS\\src\\main\\tessdata"); 
            // BufferedImage bim;
            //  String text = null;
			/*
			 * try { bim = ImageIO.read(new File(input)); text = tesseract.doOCR(bim); }
			 * catch (IOException e) { // TODO Auto-generated catch block
			 * e.printStackTrace(); }
			 */
           
            tesseract.setLanguage("mar");
           // tesseract.createDocuments("E:\\Khopoli\\Demo\\Sample\\image0000116B.tif", "E:\\Khopoli\\Demo\\Sample\\image0000116B", );
            //tesseract.setOcrEngineMode(2);
            // the path of your tess data folder 
            // inside the extracted file 
           // PdfUtilities.convertPdf2Tiff(input);
            String text = tesseract.doOCR(new File(input)); 
            List<ITesseract.RenderedFormat> renderFormat = new ArrayList<>();
            renderFormat.add(RenderedFormat.PDF);
            
           
            tesseract.createDocuments(input, output , renderFormat);    
            //tesseract.createDocumentsWithResults(input, output, renderFormat, 1);
            // path of your image file 
            System.out.print(text); 
        } 
        catch (TesseractException e) { 
            e.printStackTrace(); 
        } 

	}

}
