package com.common.Controllers;

import java.io.File;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import ClearImageJNI.EBoolean;
import ClearImageJNI.EBorderExtractAlgorithm;
import ClearImageJNI.EBorderExtractFlags;
import ClearImageJNI.EFileFormat;
import ClearImageJNI.ELineDirection;
import ClearImageJNI.ESmoothType;
import ClearImageJNI.ICiRepair;

@Controller
public class OperationController {
	  
	   @RequestMapping(value = "/saveAutoCrop", method = RequestMethod.POST)
	   public String saveAutoCrop(Model model,@RequestParam("fileIn") String fileIn,
			   @RequestParam("leftCrop") int leftCrop,
			   @RequestParam("rightCrop") int rightCrop,
			   @RequestParam("topCrop") int topCrop,
			   @RequestParam("bottomCrop") int bottomCrop){
	    
		  File directory = new File(fileIn); //get all the files from a directory
		  File[] fList = directory.listFiles();
		 //System.out.println("Number of files in folders:"+fList.length);
	      String fileOut = fileIn+"OutputFiles"+File.separator;
		 try {
			    ICiRepair repair = StartInit.Ci.CreateRepair();
			    for (File file : fList)
				   {   
					   if (file.isFile()){
							repair.getImage().Open(fileIn+file.getName(), 1);
							repair.AutoCrop(-(leftCrop),-(topCrop),-(rightCrop),-(bottomCrop));
							repair.getImage().SaveAs(fileOut+file.getName(), EFileFormat.ciEXT);
						    System.out.println("Completed File Name:"+file.getName()); 
				       }else if(file.isDirectory()) {
				    	   
				       }
				  }
			} catch (Exception ex) {
				ex.printStackTrace();
			} 
		   model.addAttribute("message", "Auto Crop Operation Done Successfully.");
	       return "defaultPage"; 
	   }  
	   
	   @RequestMapping(value = "/saveAutoDeskew", method = RequestMethod.POST)
	   public String saveAutoDeskew(Model model,@RequestParam("fileIn") String fileIn){
			 
	    
		  File directory = new File(fileIn); //get all the files from a directory
		  File[] fList = directory.listFiles();
	      String fileOut = fileIn+"OutputFiles"+File.separator;
		 try {
			    
			    ICiRepair repair = StartInit.Ci.CreateRepair();
			    for (File file : fList)
				   {   
					   if (file.isFile()){
							repair.getImage().Open(fileIn+file.getName(), 1);
							repair.AutoDeskew();
							repair.getImage().SaveAs(fileOut+file.getName(), EFileFormat.ciEXT);
						    System.out.println("Completed File Name:"+file.getName());
				       }else if(file.isDirectory()) {
				    	   
				       }
				  }
			} catch (Exception ex) {
				ex.printStackTrace();
			} 
		   model.addAttribute("message", "Auto Deskew Operation Done Successfully.");
	       return "defaultPage"; 
	   }  
	   
	   @RequestMapping(value = "/saveAutoRotate", method = RequestMethod.POST)
	   public String saveAutoRotate(Model model,@RequestParam("fileIn") String fileIn){
			 
	    
		  File directory = new File(fileIn); //get all the files from a directory
		  File[] fList = directory.listFiles();
		 
	      String fileOut = fileIn+"OutputFiles"+File.separator;
		 try {
			    
			    ICiRepair repair = StartInit.Ci.CreateRepair();
			    for (File file : fList)
				   {   
					   if (file.isFile()){
							repair.getImage().Open(fileIn+file.getName(), 1);
							repair.AutoRotate();
							repair.getImage().SaveAs(fileOut+file.getName(), EFileFormat.ciEXT);
						    System.out.println("Completed File Name:"+file.getName());
				       }else if(file.isDirectory()) {
				    	   
				       }
				  }
			} catch (Exception ex) {
				ex.printStackTrace();
			} 
		   model.addAttribute("message", "Auto Rotate Operation Done Successfully.");
	       return "defaultPage"; 
	   }  
	   
	   @RequestMapping(value = "/saveHalfTone", method = RequestMethod.POST)
	   public String saveHalfTone(Model model,@RequestParam("fileIn") String fileIn){
			 
	    
		  File directory = new File(fileIn); //get all the files from a directory
		  File[] fList = directory.listFiles();
		 
	      String fileOut = fileIn+"OutputFiles"+File.separator;
		 try {
			    
			    ICiRepair repair = StartInit.Ci.CreateRepair();
			    for (File file : fList)
				   {   
					   if (file.isFile()){
							repair.getImage().Open(fileIn+file.getName(), 1);
							repair.RemoveHalftone();
							repair.getImage().SaveAs(fileOut+file.getName(), EFileFormat.ciEXT);
						    System.out.println("Completed File Name:"+file.getName());
				       }else if(file.isDirectory()) {
				    	   
				       }
				  }
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		   model.addAttribute("message", "Remove HalfTone Operation Done Successfully.");
	       return "defaultPage"; 
	   }  
	   
	   @RequestMapping(value = "/savePunchHoles", method = RequestMethod.POST)
	   public String savePunchHoles(Model model,@RequestParam("fileIn") String fileIn){
			 
	    
		  File directory = new File(fileIn); //get all the files from a directory
		  File[] fList = directory.listFiles();
		
	      String fileOut = fileIn+"OutputFiles"+File.separator;
		 try {
			    
			    ICiRepair repair = StartInit.Ci.CreateRepair();
			    for (File file : fList)
				   {   
					   if (file.isFile()){
							repair.getImage().Open(fileIn+file.getName(), 1);
							repair.RemovePunchHoles();
							repair.getImage().SaveAs(fileOut+file.getName(), EFileFormat.ciEXT);
						    System.out.println("Completed File Name:"+file.getName());
				       }else if(file.isDirectory()) {
				    	   
				       }
				  }
			} catch (Exception ex) {
				ex.printStackTrace();
			} 
		   model.addAttribute("message", "Remove Punch Hole Operation Done Successfully.");
	       return "defaultPage"; 
	   }  
	   
	   @RequestMapping(value = "/saveCleanBorders", method = RequestMethod.POST)
	   public String saveCleanBorders(Model model,@RequestParam("fileIn") String fileIn){
	    
		  File directory = new File(fileIn); //get all the files from a directory
		  File[] fList = directory.listFiles();
		
	      String fileOut = fileIn+"OutputFiles"+File.separator;
		 try {
			    
			    ICiRepair repair = StartInit.Ci.CreateRepair();
			    for (File file : fList)
				   {   
					   if (file.isFile()){
							repair.getImage().Open(fileIn+file.getName(), 1);
							repair.BorderExtract(EBorderExtractFlags.ciBexBorder, EBorderExtractAlgorithm.ciBeaCleaner);
							repair.getImage().SaveAs(fileOut+file.getName(), EFileFormat.ciEXT);
						    System.out.println("Completed File Name:"+file.getName());
				       }else if(file.isDirectory()) {
				    	   
				       }
				  }
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		   model.addAttribute("message", "Clean Border Operation Done Successfully.");
	       return "defaultPage"; 
	   }  
	   
	   
	   @RequestMapping(value = "/saveSmoothChars", method = RequestMethod.POST)
	   public String saveSmoothChars(Model model,@RequestParam("fileIn") String fileIn){
	    
		  File directory = new File(fileIn); //get all the files from a directory
		  File[] fList = directory.listFiles();
		  
	      String fileOut = fileIn+"OutputFiles"+File.separator;
		 try {
			    
			    ICiRepair repair = StartInit.Ci.CreateRepair();
			    for (File file : fList)
				   {   
					   if (file.isFile()){
							repair.getImage().Open(fileIn+file.getName(), 1);
							repair.SmoothCharacters(ESmoothType.ciSmoothDarkenEdges);
							repair.getImage().SaveAs(fileOut+file.getName(), EFileFormat.ciEXT);
						    System.out.println("Completed File Name:"+file.getName());
				       }else if(file.isDirectory()) {
				    	   
				       }
				  }
			} catch (Exception ex) {
				ex.printStackTrace();
			} 
		   model.addAttribute("message", "Smooth Char Repair Operation Done Successfully.");
	       return "defaultPage"; 
	   }  
	   
	   
	   @RequestMapping(value = "/saveRemoveBackGround", method = RequestMethod.POST)
	   public String saveRemoveBackGround(Model model,@RequestParam("fileIn") String fileIn){
	    
		  File directory = new File(fileIn); //get all the files from a directory
		  File[] fList = directory.listFiles();
		 
	      String fileOut = fileIn+"OutputFiles"+File.separator;
		 try {
			    
			    ICiRepair repair = StartInit.Ci.CreateRepair();
			    for (File file : fList)
				   {   
					   if (file.isFile()){
							repair.getImage().Open(fileIn+file.getName(), 1);
							repair.ClearBackground(20);
							repair.getImage().SaveAs(fileOut+file.getName(), EFileFormat.ciEXT);
						    System.out.println("Completed File Name:"+file.getName());
				       }else if(file.isDirectory()) {
				    	   
				       }
				  }
			} catch (Exception ex) {
				ex.printStackTrace();
			} 
		   model.addAttribute("message", "Remove Background Operation Done Successfully.");
	       return "defaultPage"; 
	   }  
		
	   
	   @RequestMapping(value = "/saveRemoveLines", method = RequestMethod.POST)
	   public String saveRemoveLines(Model model,@RequestParam("fileIn") String fileIn){
	    
		  File directory = new File(fileIn); //get all the files from a directory
		  File[] fList = directory.listFiles();
		
	      String fileOut = fileIn+"OutputFiles"+File.separator;
		 try {
			    
			    ICiRepair repair = StartInit.Ci.CreateRepair();
			    for (File file : fList)
				   {   
					   if (file.isFile()){
							repair.getImage().Open(fileIn+file.getName(), 1);
							repair.DeleteLines(ELineDirection.ciLineVertAndHorz, EBoolean.ciFalse);
							repair.getImage().SaveAs(fileOut+file.getName(), EFileFormat.ciEXT);
						    System.out.println("Completed File Name:"+file.getName());
				       }else if(file.isDirectory()) {
				    	   
				       }
				  }
			} catch (Exception ex) {
				ex.printStackTrace();
			} 
		   model.addAttribute("message", "Remove Lines Operation Done Successfully.");
	       return "defaultPage"; 
	   }  
		
 

}
