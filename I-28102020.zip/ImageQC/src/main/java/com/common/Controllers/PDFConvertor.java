package com.common.Controllers;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.imageio.ImageIO;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.tools.imageio.ImageIOUtil;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.GrayColor;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;

public class PDFConvertor {
	public static final String SRC = "E:/java Data/FolderMove/Testing/DemoTest";
	public static final String RESULT = "E:/java Data/FolderMove/Testing/DemoTest/TEST 1.pdf";
	public static final String DESTGRAY = "E:/java Data/FolderMove/Testing/DemoTest/OutputGray.pdf";
	public static final String DESTBLACK= "E:/java Data/FolderMove/Testing/DemoTest/OutputBlack.pdf";

	public static void main(String[] args) throws FileNotFoundException, DocumentException {
		try {
			new PDFConvertor().generateImageFromPDF(RESULT);
		} catch (InvalidPasswordException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private void createPdf(String result2) throws FileNotFoundException, DocumentException {
		 
		 OutputStream fos = new FileOutputStream(new File(result2));
         Document document = new Document();
         PdfWriter pdfWriter = PdfWriter.getInstance(document, fos);
         
         System.out.println("pdfWriter==="+pdfWriter.getCurrentPageNumber());
         document.open();
         
         
         
         //PdfContentByte canvas = pdfWriter.getDirectContentUnder();
         //PdfSpotColor psc_g = new PdfSpotColor("iTextSpotColorGray", new GrayColor(0.9f));
         
         
         //colorRectangle(canvas, new SpotColor(psc_g, 0.5f), 1f, 1f, document.getPageSize().getWidth(),document.getPageSize().getHeight());
         
         document.close();
		
	}
	
	public void colorRectangle(PdfContentByte canvas,

	        BaseColor color, float x, float y, float width, float height) {

	        canvas.saveState();

	        canvas.setColorFill(color);

	        canvas.rectangle(x, y, width, height);
	        //canvas.add(canvas);

	        canvas.fillStroke();

	        canvas.restoreState();

   }
	
	
	void invert(File source, File target) throws IOException, DocumentException
	{
	    PdfReader reader = new PdfReader(source.getPath());
	    OutputStream os = new FileOutputStream(target);
	    PdfStamper stamper = new PdfStamper(reader, os);
	    invert(stamper);
	    stamper.close();
	    os.close();
	}

	void invert(PdfStamper stamper)
	{
	    for (int i = stamper.getReader().getNumberOfPages(); i>0; i--)
	    {
	        invertPage(stamper, i);
	    }
	}

	void invertPage(PdfStamper stamper, int page)
	{
	    Rectangle rect = stamper.getReader().getPageSize(page);
	    PdfContentByte cb = stamper.getOverContent(page);
	 
	    cb.setColorFill(new GrayColor(1.0f));
	    cb.rectangle(rect.getLeft(), rect.getBottom(), rect.getWidth(), rect.getHeight());
	    cb.fill();

	    cb = stamper.getUnderContent(page);
	    cb.setColorFill(new GrayColor(1.0f));
	    cb.rectangle(rect.getLeft(), rect.getBottom(), rect.getWidth(), rect.getHeight());
	    cb.fill();
	}
	
	private void generateImageFromPDF(String filename) throws InvalidPasswordException, IOException, DocumentException {
	    PDDocument document = PDDocument.load(new File(filename));
	    
	    Document documentGrayOutput = new Document();
	    FileOutputStream fos = new FileOutputStream(DESTGRAY);
	    PdfWriter writer = PdfWriter.getInstance(documentGrayOutput, fos);
	    
	    Document documentBlackOutput = new Document();
	    FileOutputStream fosBlack = new FileOutputStream(DESTBLACK);
	    PdfWriter writerBlack = PdfWriter.getInstance(documentBlackOutput, fosBlack);
	    
	    PDFRenderer pdfRenderer = new PDFRenderer(document);
	    
	    
	    writer.open();
	    documentGrayOutput.open();
	    
	    writerBlack.open();
	    documentBlackOutput.open();
	    
	    String imagePath = null;
	    BufferedImage bufferedImage = null;
        File fileGray = null;
        File fileBlack = null;
        Image imageInstance = null;
	    
	    for (int page = 0; page < document.getNumberOfPages(); ++page) {
	    	 
	    BufferedImage bim = pdfRenderer.renderImageWithDPI(page, 300, ImageType.GRAY);
	       
	       
	       // PDRectangle cropBox = document.getPage(page).getCropBox();
	       // PDRectangle dimension = cropBox.createRetranslatedRectangle();
	       
	        imagePath = SRC +"imageGray-" + page + ".jpg";
	        System.out.println(imagePath);
	        ImageIOUtil.writeImage(bim, imagePath, 300);
	       
	        
	        
	        
	        fileGray = new File(imagePath);
	        bufferedImage = ImageIO.read(fileGray);
	        
	       // colorIntoGrayScale(bufferedImage,fileGray);
	        imageInstance = Image.getInstance(imagePath);
	        
	        imageInstance.setAbsolutePosition(0, 0);

	      //  System.out.println("widthGray=="+documentGrayOutput.getPageSize().getWidth()+" "+"heightGray=="+documentGrayOutput.getPageSize().getHeight());
	        imageInstance.scaleAbsolute(documentGrayOutput.getPageSize().getWidth(), documentGrayOutput.getPageSize().getHeight());
	        documentGrayOutput.add(imageInstance);
	        documentGrayOutput.newPage();
	       
	        
	        BufferedImage bim2 = pdfRenderer.renderImageWithDPI(page, 300, ImageType.BINARY);
	        
	        imagePath = SRC +"imageBlack-" + page + ".jpg";
	        System.out.println(imagePath);
	        ImageIOUtil.writeImage(bim2, imagePath, 300);
	        
	       
	        
	        fileBlack = new File(imagePath);
	        bufferedImage = ImageIO.read(fileBlack);
	       // System.out.println("width=="+bufferedImage.getWidth()+" "+"height=="+bufferedImage.getHeight());
	        
	       // colorToBlackAndWhite(bufferedImage,fileBlack);
	        imageInstance = Image.getInstance(imagePath);
	       
	        imageInstance.setAbsolutePosition(0, 0);
			
	        System.out.println("width=="+documentBlackOutput.getPageSize().getWidth()+" "+"height=="+documentBlackOutput.getPageSize().getHeight());
	        imageInstance.scaleAbsolute(documentBlackOutput.getPageSize().getWidth(),documentBlackOutput.getPageSize().getHeight());
	        imageInstance.setBackgroundColor(null);
	        documentBlackOutput.add(imageInstance);
	        documentBlackOutput.newPage();
	       
	       
	        fileGray.delete();
	    	fileBlack.delete();
	    }
	    document.close();
	    
	    documentGrayOutput.close();
	    writer.close();
	    
	    documentBlackOutput.close();
	    writerBlack.close();
	}
	
	private static void colorIntoGrayScale(BufferedImage img,File f) {
		 int height = img.getHeight();
	     int width = img.getWidth();
	     
	     for(int y=0; y < height; y++) {
	    	 for(int x=0; x < width; x++) {
	    		 int p = img.getRGB(x,y);
	    		 //System.out.println(p);
	    		 	int a = (p>>24)&0xff;
	    		 	int r = (p>>16)&0xff;
	    		 	int g = (p>>8)&0xff;
	    		 	int b = p&0xff;
	    		 	
	    		 	int avg = (r+g+b)/3;
	    		 	
	    		 	p = (a<<24) | (avg<<16) | (avg<<8) | avg;
	    		 	
	    		 	img.setRGB(x, y, p);
	    	 }
	     }
	     
	   //  System.out.println("Color Mode"+img.getColorModel());
	    // f = new File(RESULT+"GrayScale2.jpg");
	     try {
	 		ImageIO.write(img, "jpg", f);
	 	} catch (IOException e) {
	 		// TODO Auto-generated catch block
	 		e.printStackTrace();
	 	}
	}
	
	private static void colorToBlackAndWhite(BufferedImage image, File file) {
	     
		try {
			image = ImageIO.read(file);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	      BufferedImage result = new BufferedImage(
	              image.getWidth(),
	              image.getHeight(),
	              BufferedImage.TYPE_BYTE_BINARY);

	      Graphics2D graphic = result.createGraphics();
	      graphic.drawImage(image, 0, 0, Color.BLACK, null);
	      graphic.dispose();

	     // File output = new File("E:/BlackWhite.jpg");
	      try {
	    	
			ImageIO.write(result, "png", file);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  
		
	}
	/*
	 * private static void generatePDFFromImage(String filename) throws
	 * DocumentException, MalformedURLException, IOException { Document document =
	 * new Document(); String input = filename + "." + extension; String output =
	 * "src/output/" + extension + ".pdf"; FileOutputStream fos = new
	 * FileOutputStream(output);
	 * 
	 * PdfWriter writer = PdfWriter.getInstance(document, fos); writer.open();
	 * document.open(); document.add(Image.getInstance((new URL(input))));
	 * document.close(); writer.close(); }
	 */


}































