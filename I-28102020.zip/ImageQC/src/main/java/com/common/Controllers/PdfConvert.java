package com.common.Controllers;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.tools.imageio.ImageIOUtil;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfWriter;

public class PdfConvert {
    
	public static final String SRC = "E:/PdftoImage/";
	public static final String RESULT = "E:/PdftoImage/testone.pdf";
	public static final String DESTGRAY = "E:/PdftoImage/OutputGray.pdf";
	public static final String DESTBLACK= "E:/PdftoImage/OutputBlack.pdf";
	public static void main(String[] args) {
		PdfConvert pdfConvert = new PdfConvert();
		try {
			pdfConvert.generateImageFromPDF(RESULT);
		} catch (InvalidPasswordException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	private void generateImageFromPDF(String filename) throws InvalidPasswordException, IOException, DocumentException {
	    PDDocument document = PDDocument.load(new File(filename));
	    
	    Document documentBlackOutput = new Document();
	    FileOutputStream fosBlack = new FileOutputStream(DESTBLACK);
	    PdfWriter writerBlack = PdfWriter.getInstance(documentBlackOutput, fosBlack);
	    
	    PDFRenderer pdfRenderer = new PDFRenderer(document);
	    
	    
	   
	    
	    writerBlack.open();
	    documentBlackOutput.open();
	    
	    String imagePath = null;
	    BufferedImage bufferedImage = null;
        File fileGray = null;
        File fileBlack = null;
        Image imageInstance = null;
	    
	    for (int page = 0; page < document.getNumberOfPages(); ++page) {
	    	//BufferedImage bim = pdfRenderer.renderImageWithDPI(page, 300, ImageType.GRAY);
	    	
	    	BufferedImage bim = pdfRenderer.renderImageWithDPI(page, 300, ImageType.GRAY);
	       
	       // PDRectangle cropBox = document.getPage(page).getCropBox();
	       // PDRectangle dimension = cropBox.createRetranslatedRectangle();
	       
	        imagePath = SRC +"imageGray-" + page + ".jpg";
	        System.out.println(imagePath);
	        ImageIOUtil.writeImage(bim, imagePath, 300);
	       
	        
	        
	        
	        fileGray = new File(imagePath);
	        bufferedImage = ImageIO.read(fileGray);
	        
	       // colorIntoGrayScale(bufferedImage,fileGray);
	        imageInstance = Image.getInstance(imagePath);
	        
	        imageInstance.setAbsolutePosition(0, 0);

	     
	       
	        
	        BufferedImage bim2 = pdfRenderer.renderImageWithDPI(page, 300, ImageType.BINARY);
	        
	        imagePath = SRC +"imageBlack-" + page + ".jpg";
	        System.out.println(imagePath);
	        ImageIOUtil.writeImage(bim2, imagePath, 300);
	        
	       
	        
	        fileBlack = new File(imagePath);
	        bufferedImage = ImageIO.read(fileBlack);
	       // System.out.println("width=="+bufferedImage.getWidth()+" "+"height=="+bufferedImage.getHeight());
	        
	       // colorToBlackAndWhite(bufferedImage,fileBlack);
	        imageInstance = Image.getInstance(imagePath);
	       
	        imageInstance.setAbsolutePosition(0, 0);
			
	        System.out.println("width=="+documentBlackOutput.getPageSize().getWidth()+" "+"height=="+documentBlackOutput.getPageSize().getHeight());
	        imageInstance.scaleAbsolute(documentBlackOutput.getPageSize().getWidth(),documentBlackOutput.getPageSize().getHeight());
	        imageInstance.setBackgroundColor(null);
	        documentBlackOutput.add(imageInstance);
	        documentBlackOutput.newPage();
	       
	       
	        fileGray.delete();
	    	fileBlack.delete();
	    }
	    document.close();
	    
	    
	    
	    
	    documentBlackOutput.close();
	    writerBlack.close();
	}

}
