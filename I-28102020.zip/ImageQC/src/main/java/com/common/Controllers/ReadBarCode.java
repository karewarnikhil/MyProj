package com.common.Controllers;

import java.io.File;

import ClearImageJNI.CiException;
import ClearImageJNI.CiServer;
import ClearImageJNI.FBarcodeType;
import ClearImageJNI.ICiBarcode;
import ClearImageJNI.ICiBarcodePro;
import ClearImageJNI.ICiServer;

public class ReadBarCode {
	public static final String DEST = "E:/PdftoImage/";
	public static void main(String[] args) {
		
		CiServer objCi;
		try {
			objCi = new CiServer();
			System.out.println(objCi);
			ICiServer Ci = objCi.getICiServer();
			ICiBarcodePro reader = Ci.CreateBarcodePro();
			System.out.println(reader);
			//reader.setType(new FBarcodeType(FBarcodeType.cibfCode39, FBarcodeType.cibfCode128 , FBarcodeType.cibfCode93, FBarcodeType.cibfEan13, FBarcodeType.cibfCodabar));
			reader.setType(new FBarcodeType(FBarcodeType.cibfCode39, FBarcodeType.cibfCode128));
			File directory = new File(DEST);
		
			System.out.println(reader.getBarcodes().getItem(0));
			for (File file : directory.listFiles()) {
					reader.getImage().Open(file.getPath(), 1);
					reader.Find(0);
				    System.out.println("File Path..."+file.getPath());
				for (int i = 1; i <= reader.getBarcodes().getCount(); i++) {
				    System.out.println("Barcode.."+reader.getBarcodes().getItem(i));
				    ICiBarcode iCiBarcode = reader.getBarcodes().getItem(i);
				    System.out.println(iCiBarcode.getType());
				    System.out.println(iCiBarcode.getText()); 
				}
			}
		} catch (CiException e) {
			e.printStackTrace();
		} 
	}

}
