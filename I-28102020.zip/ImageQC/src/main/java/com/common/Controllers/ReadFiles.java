package com.common.Controllers;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfWriter;

public class ReadFiles {

	public static void main(String[] args) {
	 //for(int i = 1000029244; i <= 1000029283; i++ ) {
		// String s = Integer.toString(i);
		 File folder = new File("E:\\java Data\\FolderMove\\Testing\\DemoTest");
		 Document  doc = null;
		 readFilesAndFolders(folder,doc);
		//}
	}
	
	
	  public static void readFilesAndFolders(File folder,Document doc) {
			  
	        for (File file : folder.listFiles()) {
	        	
	            if (file.isDirectory()) {
	            	   doc = new Document();
	   		      try {
	   				PdfWriter writer = PdfWriter.getInstance(doc, new FileOutputStream(file.getPath()+"/"+file.getName()+".pdf"));
	   				System.out.println(writer.getPageSize());
	   			} catch (FileNotFoundException e1) {
	   				// TODO Auto-generated catch block
	   				e1.printStackTrace();
	   			} catch (DocumentException e1) {
	   				// TODO Auto-generated catch block
	   				e1.printStackTrace();
	   			}
	   			    doc.open();
	            	System.out.println("directory Name..."+file.getName());
	            	readFilesAndFolders(file,doc);
	            	doc.close(); 
	            }
	           
	             if (file.isFile() && (file.isHidden() == false)) {
	            	 System.out.println( file.getName());
	           
	              System.out.println("File Name..."+file.getName());
	                try {
						 // String filename = "other-sample/src/main/resources/java.gif";
	                	  System.out.println("File Path..."+file.getPath());
	                	  if (file.getName().contains(".pdf") == false)  {
		                  Image image = Image.getInstance(file.getPath());
		                  
		                  System.out.println("width.."+image.getWidth()+"height.."+image.getHeight());
		                  
		                  double dpiSize = image.getDpiX() * 0.0138888888888889;
		                  System.out.println(dpiSize);
		                  float width = (float) (image.getWidth() / dpiSize);
		                  float height = (float) (image.getHeight() / dpiSize);
		                  System.out.println("width.."+width+"height.."+height);
		                  Rectangle pagesize = new Rectangle(width, height);
		                  pagesize.setBackgroundColor(BaseColor.WHITE);
		                  image.scaleAbsolute(width,height);
		                  image.setAbsolutePosition(0, 0);
		                  System.out.println("width.."+image.getWidth()+"height.."+image.getHeight());
		                  doc.setPageSize(pagesize);
		                  doc.newPage();
		                  doc.add(image);
	                	  }
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (DocumentException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (MalformedURLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
	            	 
	        }
	            
	    }
}
}
