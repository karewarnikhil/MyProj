package com.common.Controllers;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.graphics.image.LosslessFactory;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;

public class ReadFilesPDF {

	public static void main(String[] args) {
		
		     File folder = new File("E:\\Khopoli\\Demo\\Sampletwo");
		     PDDocument doc = new PDDocument();
		     for (File file : folder.listFiles()) {
		    	  try {
		    		 System.out.println(file.getPath());
		    		 BufferedImage bim = ImageIO.read(new File(file.getPath()));
					 PDImageXObject image = LosslessFactory.createFromImage(doc, bim);
					  
				     int originalWidth  = image.getWidth();
		             int originalHeight = image.getHeight();
		             
		             System.out.println(image.getBitsPerComponent());
			        // PDRectangle pdRectangle = new PDRectangle(originalWidth, originalHeight);
			         PDPage page = new PDPage(new PDRectangle(originalWidth , originalHeight));
					 //PDPage page = new PDPage(pdRectangle);
					
			         doc.addPage(page);
		             PDPageContentStream contents = new PDPageContentStream(doc, page);
		             contents.drawImage(image, 0, 0);
		            //float scale = 72 / 200;
		            // contents.drawImage(image, 0, 0, originalWidth * scale, originalHeight * scale );
		             contents.close();
		    	  } catch (IOException e) {
						e.printStackTrace();
			     }
				}  try {
					  System.out.println("Folder Path.........."+folder.getPath()+"/"+folder.getName()+".pdf");
					  doc.save(folder.getPath()+"/"+folder.getName()+".pdf");
					  doc.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				
		     
	}
	
	
	
}
