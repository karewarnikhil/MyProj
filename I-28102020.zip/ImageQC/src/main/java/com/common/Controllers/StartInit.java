package com.common.Controllers;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import ClearImageJNI.CiException;
import ClearImageJNI.CiServer;
import ClearImageJNI.ICiImage;
import ClearImageJNI.ICiServer;

@Component
public class StartInit {
	
	protected static ICiServer Ci = null;
	protected static ICiImage Image = null;
	protected static boolean useFullIo = true;
	
	@PostConstruct
	public void init() {
		
		;
		try {
			CiServer objCi = new CiServer();
			Ci = objCi.getICiServer();
		} catch (CiException e) {
			e.printStackTrace();
		}
	  

		
	}

	
		
	

}
