package com.common.controller;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.common.Dao.ConfigDao;
import com.common.Dao.DepartmentDao;
import com.common.Dao.DesignationDao;
import com.common.Dao.GroupDao;
import com.common.Dao.HintQuestionDao;
import com.common.Dao.UserDao;
import com.common.models.Config;
import com.common.models.Department;
import com.common.models.Designation;
import com.common.models.Group;
import com.common.models.HintQuestion;
import com.common.models.User;

@Controller
public class RegistrationController {
	@Autowired
	private DepartmentDao departmentDao;  
	
	@Autowired
	private DesignationDao designationDao;
	
    @Autowired
	private ConfigDao configDao;

    @Autowired
	private HintQuestionDao hintQuestionDao;
    
    @Autowired
    private GroupDao groupDao;
    
	 @Autowired
	 private UserDao userDao;
	 
	 @RequestMapping("register")
	  public ModelAndView loginEmployee(@ModelAttribute("user") User user) {
	        return new ModelAndView("Registration");
	    }

	@RequestMapping("registerUser")
	  public String registerUser(@ModelAttribute("user") User user, HttpSession session){
		  User userSess= (User) session.getAttribute("userObj");
		  
		  String name=user.getUserName().substring(0,4);
		  String email=user.getEmailId().substring(0, 2);
		  BigDecimal number=user.getMobNo();
		  String mobno=number.toString().substring(8);
		  String pass=name+email+"#"+mobno;
		  
		  String createdBy=userSess.getUserName();
		  
		  Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		  
		  user.setMobNo(number);
		  user.setUpw1(pass);
		  user.setUpw2(null);
		  user.setUpw3(null);
		  user.setCreatedBy(createdBy);
		  user.setCreationDate(timestamp);
		  user.setLoginStatus("A");
		  user.setOtp(null);
		  userDao.createUser(user);
		  return "Home";
	  }
	
	  @ModelAttribute("departmentList")
	  public List<Department> getDepartment() {
		  List<Department> departmentList=departmentDao.getDepartments();
	      return departmentList;
	  }
	  
	  @ModelAttribute("designationList")
	  public List<Designation> getDesignation(){
		  List<Designation> designationList=designationDao.getDesignation();
		  return designationList;
	  }
	  
      @ModelAttribute("levelList")
	  public List<Config> getLevel(){
		  List<Config> levelList= configDao.getLevel();
		  return levelList;
	  }
      
      @ModelAttribute("questionList")
      public List<HintQuestion> getQuestion(){
    	  List<HintQuestion> questionList= hintQuestionDao.getQuestions();
    	  return questionList;
      }
      @ModelAttribute("groupList")
      public List<Group> getGroup(){
    	  List<Group> groupList=groupDao.getGroup();
    	  return groupList;
      }
      
      @ModelAttribute("userList")
      public List<User> getUsers(){
    	  List<User> userList=userDao.getUsers();
    	  return userList;
      }
	  
}
