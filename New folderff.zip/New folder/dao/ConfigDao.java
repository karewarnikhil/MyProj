package com.common.Dao;

import java.util.List;

import com.common.models.Config;

public interface ConfigDao {
  
	public List<Config> getLevel();
}
