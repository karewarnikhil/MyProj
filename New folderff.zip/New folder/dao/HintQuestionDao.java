package com.common.Dao;

import java.util.List;

import com.common.models.HintQuestion;

public interface HintQuestionDao {
  public List<HintQuestion> getQuestions();
}
