package com.common.Dao;

import java.util.List;

import com.common.models.User;

public interface UserDao {
 
	public List<User> getUsers();
	public User getUser(String emailId, String upw1);
	
	public void createUser(User user);
}
