package com.common.DaoImpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.common.Dao.DesignationDao;
import com.common.models.Designation;

@Repository
@Transactional
public class DesignationDaoImpl implements DesignationDao{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public List<Designation> getDesignation(){
		return sessionFactory.getCurrentSession().createQuery("FROM Designation").list();
	}
}
