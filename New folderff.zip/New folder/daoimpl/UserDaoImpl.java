package com.common.DaoImpl;

import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.common.Dao.UserDao;
import com.common.models.User;

@Repository
@Transactional
public class UserDaoImpl implements UserDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	public List<User> getUsers(){
		return sessionFactory.getCurrentSession().createQuery("FROM User").list();
	}
	
	
	public User getUser(String emailId, String upw1) {
		return (User) sessionFactory.getCurrentSession()
				.createQuery("from User where emailid='"+emailId+"' and upw1='"+upw1+"'")
				.uniqueResult();
	}
	
	public void createUser(User user) {
		sessionFactory.getCurrentSession().save(user);
	}
	
	
}
