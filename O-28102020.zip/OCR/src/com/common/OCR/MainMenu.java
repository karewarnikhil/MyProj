package com.common.OCR;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class MainMenu extends JFrame implements ActionListener
{   /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    JFrame jf;
	JMenuBar mbar;
	JMenu m1,m2,m3,m4,m5;
	JMenuItem m1_1,m2_1,m2_2;
	JLabel l1,LogoColl;
	GridBagLayout gbl;
	

	public MainMenu()
	{
        jf=new JFrame();
     	gbl=new GridBagLayout();
		jf.setLayout(gbl);

		l1=new JLabel("WELCOME TO IMAGE OCR SYSTEM");
		l1.setFont(new Font("Times New Roman",Font.BOLD,20));
		jf.add(l1);

		mbar = new JMenuBar();
		jf.setJMenuBar(mbar);

		m1=new JMenu("OCR");
		mbar.add(m1);
		m1_1 = new JMenuItem("Pdf Ocr",new ImageIcon("images//exit.png"));
		m1.add(m1_1);
		
		m2=new JMenu("EXIT");
		mbar.add(m2);
		m2_1 = new JMenuItem("Exit",new ImageIcon("images//exit.png"));
		m2.add(m2_1);

        m1_1.addActionListener(this);
		

		m2_1.addActionListener(this);
		
		jf.setTitle("Main Menu");
		jf.setLocation(20,20);
	    jf.setSize(900,500);
	    jf.setResizable(false);
	    //jf.getContentPane().setBackground(Color.WHITE);
	    jf.setContentPane(new JLabel(new ImageIcon("src//Untitled.jpg")));
		jf.setVisible(true);

	}

	public void actionPerformed(ActionEvent ae)
	{

	    if(ae.getSource()==m1_1)
		{
		  new OcrPdf();
		}
		
		else if(ae.getSource()==m2_1)
		{
			System.exit(0);
		}
	    
  }

}
