package com.common.OCR;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.tools.imageio.ImageIOUtil;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.pdf.PdfWriter;

import net.sourceforge.tess4j.ITesseract;
import net.sourceforge.tess4j.ITesseract.RenderedFormat;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;

public class OcrPdf extends JFrame implements ActionListener{
	/**
	 * 
	 */
	 
	private static final long serialVersionUID = 1L;
	JFrame jf;
	JTextField t1,t2,t3,t4,t5,tr,tq;
	JLabel l1,l2,l3,l4,l5,l6;
	JButton b0,b1,b2;
	Font f;
	JFileChooser jf1;
	JCheckBox checkbox1,checkbox2,checkbox3,checkbox4;
  
	
	
	DefaultTableModel model = new DefaultTableModel();
    JTable tabGrid = new JTable(model);
    JScrollPane scrlPane = new JScrollPane(tabGrid);

    public  OcrPdf()
	{
		jf=new JFrame();
		f = new Font("Times New Roman",Font.BOLD,20);
		jf.setLayout(null);

	    l6=new JLabel("PDF OCR");
	    l6.setFont(new Font("Times New Roman",Font.BOLD,25));
	    l6.setBounds(320,20,300,40);l6.setForeground(Color.blue);
	    jf.add(l6);

		l1= new JLabel("Folder Path :");
		//l1.setFont(f);
		l1.setBounds(150,60,300,300);
	    jf.add(l1);

	    jf1=new JFileChooser();
	   // jf1.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
	    jf1.setBounds(320,60,450,250);jf1.setToolTipText("Enter Folder Path");
		jf.add(jf1);

		l2= new JLabel("Select Language :");
		l2.setBounds(150,320,130,25);
	    jf.add(l2);
	    
		checkbox1 = new JCheckBox("English");    
        checkbox1.setBounds(330,320,300,25);    
        jf.add(checkbox1);
        
        checkbox2 = new JCheckBox("Marathi");    
        checkbox2.setBounds(330,350,300,25);
        jf.add(checkbox2);
        
        l3= new JLabel("File Version :");
		l3.setBounds(150,400,130,25);
	    jf.add(l3);
	    
	    checkbox3 = new JCheckBox("Color");    
        checkbox3.setBounds(330,400,300,25);    
        jf.add(checkbox3);
        
        checkbox4 = new JCheckBox("Black & White");    
        checkbox4.setBounds(330,430,300,25);
        jf.add(checkbox4);
        
        
        
	    b0 = new JButton("Save",new ImageIcon("images//save.png"));
        b0.setBounds(150,500,110,35);b0.setToolTipText("click to save auto deskew operation");
		jf.add(b0);b0.addActionListener(this);

		b1 = new JButton("Clear",new ImageIcon("images//clear.png"));
		b1.setBounds(300,500,110,35);b1.setToolTipText("click to clear all textfilds");
	    jf.add(b1); b1.addActionListener(this);
	    
	    b2 = new JButton("Close",new ImageIcon("images//clear.png"));
		b2.setBounds(450,500,110,35);b2.setToolTipText("click to Close Window");
	    jf.add(b2); b2.addActionListener(this);
	    
	    jf.setTitle("PDF OCR");
	    jf.setSize(900,600);
		jf.setLocation(20,20);
		jf.setResizable(false);
		jf.getContentPane().setBackground(Color.WHITE);
	    jf.setVisible(true);
     
	}

public void actionPerformed(ActionEvent ae)
	{
	if(ae.getSource()==b0)
	 {
		 String fileIn = "";
		  try
		  	 {
			  File directory =  jf1.getCurrentDirectory();
			  fileIn = directory.getPath()+"/";
			  System.out.println(fileIn);
			  File[] fList = directory.listFiles();
			  if(checkbox3.isSelected()) {
			  
			  System.out.println("Number of files in folders:"+fList.length);
			  try { 
			  Tesseract tesseract = new Tesseract(); 
			  tesseract.setDatapath("C:\\tessdata");
			  if(checkbox1.isSelected())  
			  {  
				  tesseract.setLanguage("eng");
			  }  
			  if(checkbox2.isSelected())  
			  {  
				   tesseract.setLanguage("mar");
			  }  
			  
			  List<ITesseract.RenderedFormat> renderFormat = new ArrayList<>();
	          renderFormat.add(RenderedFormat.PDF);
			   for (File file : fList)
			   {   
				  
				   String fileName = file.getName().replaceFirst("[.][^.]+$", "");
				   tesseract.doOCR(file); 
				   System.out.println(directory.getPath()+"/"+file.getName());  
				   tesseract.createDocuments(file.getPath(), directory.getPath()+"/"+fileName+"OCR" , renderFormat);   
			   }
			   } catch (TesseractException e) { 
		            e.printStackTrace(); 
		       } 
			   System.out.println("Total process completed successfully:");
			  }
			  
			  
			  if(checkbox4.isSelected()) {
				  
				  System.out.println("Number of files in folders:"+fList.length);
				  try { 
					  Tesseract tesseract = new Tesseract(); 
					  tesseract.setDatapath("C:\\tessdata");
					  if(checkbox1.isSelected())  
					  {  
						  tesseract.setLanguage("eng");
					  }  
					  if(checkbox2.isSelected())  
					  {  
						   tesseract.setLanguage("mar");
					  }  
				  
					  List<ITesseract.RenderedFormat> renderFormat = new ArrayList<>();
					  renderFormat.add(RenderedFormat.PDF);
				  
					   for (File file : fList)
					   {   
						   String fileName = file.getName().replaceFirst("[.][^.]+$", "");
						   File fileOcr = new File(fileName+"Ocr.pdf");
						   generateImageFromPDF(file,fileOcr);
						  
						   tesseract.doOCR(fileOcr); 
						   System.out.println(directory.getPath()+"/"+"OCR");  
						   tesseract.createDocuments(fileOcr.getPath(), directory.getPath()+"/"+fileName+"OcrOutput" , renderFormat);   
					   }
					   } catch (TesseractException e) { 
				            e.printStackTrace(); 
				       } 
				   	   System.out.println("Total process completed successfully:");
			  }
			  
			  
			 
			 int reply=JOptionPane.showConfirmDialog(null,"Pdf Ocr Operation Done Successfully.Do you want continue more?","Done Pdf Ocr",JOptionPane.YES_NO_OPTION);
             if (reply == JOptionPane.YES_OPTION)
			 {
		        jf.setVisible(false);
		        new OcrPdf();
		     }
		     else if (reply == JOptionPane.NO_OPTION)
			 {
		    	 jf.setVisible(false);
	         }
       }
catch(Exception e)
{
e.printStackTrace();
System.out.println(e);
JOptionPane.showMessageDialog(null,"Error:"+e);
}

}
   if(ae.getSource()==b1)
     {//clear
          t1.setText("");
      }
    else if(ae.getSource()==b2)
    {
    	jf.setVisible(false);
	}
 }

private void generateImageFromPDF(File fileIn,File fileOut) throws InvalidPasswordException, IOException {
    PDDocument document = PDDocument.load(fileIn);
    
    Document documentBlackOutput = new Document();
    FileOutputStream fosBlack = new FileOutputStream(fileOut);
    PdfWriter writerBlack = null;
	try {
		writerBlack = PdfWriter.getInstance(documentBlackOutput, fosBlack);
	} catch (DocumentException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
    
    PDFRenderer pdfRenderer = new PDFRenderer(document);
    
    
   
    
    writerBlack.open();
    documentBlackOutput.open();
    
    String imagePath = null;
    BufferedImage bufferedImage = null;
    File fileBlack = null;
    Image imageInstance = null;
    
    for (int page = 0; page < document.getNumberOfPages(); ++page) {
    	//BufferedImage bim = pdfRenderer.renderImageWithDPI(page, 300, ImageType.GRAY);
    	
    	BufferedImage bim = pdfRenderer.renderImageWithDPI(page, 300, ImageType.GRAY);
       
       // PDRectangle cropBox = document.getPage(page).getCropBox();
       // PDRectangle dimension = cropBox.createRetranslatedRectangle();
       
        
        BufferedImage bim2 = pdfRenderer.renderImageWithDPI(page, 300, ImageType.BINARY);
        
        imagePath = fileIn.getPath() +"imageBlack-" + page + ".jpg";
        System.out.println(imagePath);
        ImageIOUtil.writeImage(bim2, imagePath, 300);
        
        fileBlack = new File(imagePath);
        bufferedImage = ImageIO.read(fileBlack);
       // System.out.println("width=="+bufferedImage.getWidth()+" "+"height=="+bufferedImage.getHeight());
        
       // colorToBlackAndWhite(bufferedImage,fileBlack);
        try {
			imageInstance = Image.getInstance(imagePath);
		} catch (BadElementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       
        imageInstance.setAbsolutePosition(0, 0);
		
        System.out.println("width=="+documentBlackOutput.getPageSize().getWidth()+" "+"height=="+documentBlackOutput.getPageSize().getHeight());
        imageInstance.scaleAbsolute(documentBlackOutput.getPageSize().getWidth(),documentBlackOutput.getPageSize().getHeight());
        imageInstance.setBackgroundColor(null);
        try {
			documentBlackOutput.add(imageInstance);
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        documentBlackOutput.newPage();
    	fileBlack.delete();
    }
    document.close();
    documentBlackOutput.close();
    writerBlack.close();
}
}
