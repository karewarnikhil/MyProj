package com.common.tagDataExport;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;



public class TagExport extends JFrame implements ActionListener{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JFrame jf,jf1;
	JTextField t1,t2,t3,t4,t5,tr,tq;
	JLabel l1,l2,l3,l4,l5,l6;
	JButton b0,b1,b2;
	Font f;
	JProgressBar jProgressBar;
	JPanel jPanel;
	
	DefaultTableModel model = new DefaultTableModel();
    JTable tabGrid = new JTable(model);
    JScrollPane scrlPane = new JScrollPane(tabGrid);
    ArrayList<String> arrayListOfHeader = new ArrayList<String>();
    Connection con;
   	PreparedStatement ps;
   	Statement stmt;
   	ResultSet rs;
	ResultSet resultSet;
   	
   	int columnCnt = 0;
	
	
	 public  TagExport()
	  {
			jf=new JFrame();
			f = new Font("Times New Roman",Font.BOLD,20);
			jf.setLayout(null);

		    l6=new JLabel("Tag Data");
		    l6.setFont(new Font("Times New Roman",Font.BOLD,25));
		    l6.setBounds(320,50,300,40);l6.setForeground(Color.blue);
		    jf.add(l6);

			l1= new JLabel("Tag Group Id :");
			//l1.setFont(f);
			l1.setBounds(150,120,130,25);
		    jf.add(l1);

			t1=new JTextField(20);
			t1.setBounds(320,120,300,25);t1.setToolTipText("Tag group Id");
			jf.add(t1);
			
			l2= new JLabel("Sub Department Id :");
			//l1.setFont(f);
			l2.setBounds(150,150,130,25);
		    jf.add(l2);

			t2=new JTextField(20);
			t2.setBounds(320,150,300,25);t1.setToolTipText("Subdepartment Id");
			jf.add(t2);

		    b0 = new JButton("Save",new ImageIcon("images//save.png"));
	        b0.setBounds(150,330,110,35);b0.setToolTipText("click to save Tag Data");
			jf.add(b0);b0.addActionListener(this);

			b1 = new JButton("Clear",new ImageIcon("images//clear.png"));
			b1.setBounds(300,330,110,35);b1.setToolTipText("click to clear all textfilds");
		    jf.add(b1); b1.addActionListener(this);
		    
		    b2 = new JButton("Close",new ImageIcon("images//clear.png"));
			b2.setBounds(450,330,110,35);b2.setToolTipText("click to Close Window");
		    jf.add(b2); b2.addActionListener(this);
		    
		    jProgressBar = new JProgressBar(); 
		    jProgressBar.setMinimum(10);
		    jProgressBar.setStringPainted(true); 
		    jProgressBar.setForeground(Color.BLUE);
		    jProgressBar.setBounds(150,100,300,40);
		    
			/*
			 * jf1 = new JFrame(); jf1.setLayout(null); jf1.setTitle("Progress Bar");
			 * jf1.setSize(500,400); jf1.add(jProgressBar);
			 * jf1.getContentPane().setBackground(Color.WHITE); jf1.add(l6);
			 * jf1.setVisible(true);
			 */
		    
		    
		    jf.setTitle("Tag Data");
		    jf.setSize(900,500);
			jf.setLocation(20,20);
			jf.setResizable(false);
		    jf.getContentPane().setBackground(Color.WHITE);
			 //jf.setContentPane(new JLabel(new ImageIcon("E:\\HomeImages\\01.jpg")));
		    jf.setVisible(true);
	     
		}
	 
	 public void actionPerformed(ActionEvent ae)
		{
		if(ae.getSource()==b0)
		 {
		 	   // String tagGrpId = t1.getText();
			    

		    	if((((t1.getText()).equals("") || (t2.getText()).equals(""))))
		        {
		    		JOptionPane.showMessageDialog(this,"* Detail are Missing !","Warning!!!",JOptionPane.WARNING_MESSAGE);
		        }
				else
				{
					int tagGrpId = Integer.parseInt(t1.getText());
					int subDeptId = Integer.parseInt(t2.getText());
					try
						{
						     
							Class.forName("org.postgresql.Driver");
						    con=DriverManager.getConnection("jdbc:postgresql://localhost:5432/PCMCDEMO","postgres","admin");
							System.out.println("Connected to database.");
							ps=con.prepareStatement("select count(*)colcnt from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME='tagdatatbl'");
						    rs=ps.executeQuery();
				    		while(rs.next())
				    		{
				    			columnCnt = rs.getInt("colcnt");
				    			System.out.println(columnCnt);
				    			System.out.println(tagGrpId);
				    		}
				    		
				    		ps=con.prepareStatement("select * from tagdatatbl limit 1 ");
						    rs=ps.executeQuery();
						    while(rs.next())
				    		{  
						    	for (int i = 2;i<=columnCnt;i++) {
							    	String coloumnName = rs.getString(i);
							    	System.out.println("coloumnName=="+coloumnName);
							    	arrayListOfHeader.add(coloumnName);
						    	}
				    		}
						    
						    ps=con.prepareStatement("select * from tagDataTbl EXCEPT (select * from tagDataTbl limit 1) ");
						    resultSet=ps.executeQuery();
				    		
						    while(resultSet.next())
				            {
						    	long fileId = 0;
						    	//TagDataobject tagDataobject = arrayListOfTagData.get(i);
						    	String fileNm = resultSet.getString(1)+".pdf";
						    	System.out.println(subDeptId);
					    		ps=con.prepareStatement("select fileId from filemst where fileNm ILike'%"+fileNm+"%' and subDeptId="+subDeptId);
						    	System.out.println(ps);
							    rs=ps.executeQuery();
							    while(rs.next()) {
							    	fileId = rs.getLong("fileId");
							    	System.out.println("fileId===="+fileId);
							    }
							    
							    if(fileId > 0) 
							    {
								    System.out.println(arrayListOfHeader.size());
								    String tagData = null;
								    String tagNm = null;
							        for (int j = 0; j < arrayListOfHeader.size(); j++)
				                    {
							        	tagData = resultSet.getString(j+2);
							        	tagNm = arrayListOfHeader.get(j);
							    		
							    		System.out.println(tagNm);
							    		ps = con.prepareStatement("select tagId from tagmst where taggrpid='"+tagGrpId+"' and tagnm='"+tagNm+"'");
							    		System.out.println(ps);
							    		rs = ps.executeQuery();
							    		
							    		
							    		int tagId = 0;
									    while(rs.next()) {
									    	tagId = rs.getInt(1);
									    	System.out.println("tagId===="+tagId);
									    	ps=con.prepareStatement("insert into filetagsdata (fileid,seqno,taggrpid,tagid,tagdata,listId,listNo,createdby,creationdt)values (?,?,?,?,?,?,?,?,?)");
									    	ps.setLong(1,fileId);
									    	ps.setInt(2,1);
									    	ps.setInt(3,tagGrpId);
									    	ps.setInt(4,tagId);
									    	ps.setString(5, tagData);
									    	ps.setInt(6, 0);
									    	ps.setInt(7, 0);
									    	ps.setInt(8, 1);
									    	Date date = new Date();  
								 	        Timestamp ts = new Timestamp(date.getTime());  
									    	ps.setTimestamp(9, ts);
									    	boolean result = ps.execute();
									    	System.out.println(result);
									    }
				                    }
			                    }
							    Date date = new Date();  
					 	        Timestamp ts = new Timestamp(date.getTime());  
						    	ps=con.prepareStatement("Update filemst set tagstatus ='Y', tagdtentry = '"+ts+ "' where fileId = "+fileId);
						    	int result = ps.executeUpdate();
						    	System.out.println(result);
						   }
				    	con.close();
				       }
				       catch(SQLException se)
				       {
				    	   System.out.println(se);
				       }
				      catch(Exception e)
				       {
				       System.out.println(e);
				       }
					   
					 try { 
						 	int reply=JOptionPane.showConfirmDialog(null,"Tagging data Done Successfully.Do you want continue more?","Done Tagging Data",JOptionPane.YES_NO_OPTION);
				            if (reply == JOptionPane.YES_OPTION)
				   			{
				   		       jf.setVisible(false);
				   		       new TagExport();
				   		    }
		   		            else if (reply == JOptionPane.NO_OPTION)
				   			{
				   			  jf.setVisible(false);
					        }
		              }
					  catch(Exception e)
					  {
					    System.out.println(e);
					    JOptionPane.showMessageDialog(null,"Error:"+e);
					  }
					}
		 	}
			 else if(ae.getSource()==b1)
			     {//clear
			          t1.setText("");
			          t2.setText("");
			      }
		    else if(ae.getSource()==b2)
		    {
		    	jf.setVisible(false);
			}
	 }
	
	public static void main(String[] args) {
		new TagExport();
	}

}
