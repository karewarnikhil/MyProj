package com.common.Impls;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.common.objects.DepartmentObj;
import com.common.objects.DesinationObject;
import com.common.objects.UsersObject;

public class DemoImpl {
	
	public ArrayList<DesinationObject> getAllDesinationObject() {
		  Connection c = null;
	      PreparedStatement ps = null;
	      String sql = null;
	      ArrayList<DesinationObject> arrayListOfDesinationObject = new ArrayList();
	      try {
	         Class.forName("org.postgresql.Driver");
	         c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/DMS","postgres", "admin");
	         sql = "select * from \"desigmst\" order by \"desgid\" desc";
	         //sql = createQuery(usersObject,sql);
	         ps = c.prepareStatement(sql);
	         System.out.println("\n \n ps=== "+ps+"\n \n");
           ResultSet rs = ps.executeQuery();	         
	         while (rs.next()) {
	        	 DesinationObject desinationObject = new DesinationObject();
	        	 desinationObject.setDesgId(rs.getInt("desgid"));
	        	 desinationObject.setDesgNm(rs.getString("desgnm"));
	        	 desinationObject.setShrtNm(rs.getString("shrtnm"));
	        	 desinationObject.setCreationDt(rs.getTimestamp("creationdt"));
	        	 desinationObject.setStatus(rs.getString("status"));
	        	 arrayListOfDesinationObject.add(desinationObject);
			}
	        
	      } catch (Exception e) {
	    	  e.printStackTrace();
	      }
	      finally {
	    	 try {
				c.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return arrayListOfDesinationObject;
		
	}
	
	
	public ArrayList<DepartmentObj> getAllDepartmentObj() {
		  Connection c = null;
	      PreparedStatement ps = null;
	      String sql = null;
	      ArrayList<DepartmentObj> arrayListOfDepartmentObj = new ArrayList();
	      try {
	         Class.forName("org.postgresql.Driver");
	         c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/DMS","postgres", "admin");
	         sql = "select * from \"desigmst\" order by \"deptid\" desc";
	         //sql = createQuery(usersObject,sql);
	         ps = c.prepareStatement(sql);
	         System.out.println("\n \n ps=== "+ps+"\n \n");
         ResultSet rs = ps.executeQuery();	         
	         while (rs.next()) {
	        	 DepartmentObj departmentObj = new DepartmentObj();
	        	 departmentObj.setDeptId(rs.getInt("deptid"));
	        	 departmentObj.setDeptNm(rs.getString("deptnm"));
	        	 departmentObj.setShrtNm(rs.getString("shrtnm"));
	        	 departmentObj.setCreationDt(rs.getTimestamp("creationdt"));
	        	 departmentObj.setStatus(rs.getString("status"));
	        	 arrayListOfDepartmentObj.add(departmentObj);
			}
	        
	      } catch (Exception e) {
	    	  e.printStackTrace();
	      }
	      finally {
	    	 try {
				c.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return arrayListOfDepartmentObj;
		
	}
}
