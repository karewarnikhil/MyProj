package com.common.objects;

import java.sql.Timestamp;

public class DesinationObject {
	private  int desgId ;
	private  String desgNm ;
	private  String shrtNm;
	private Timestamp creationDt;
	private String status;
	
	public int getDesgId() {
		return desgId;
	}
	public void setDesgId(int desgId) {
		this.desgId = desgId;
	}
	public String getDesgNm() {
		return desgNm;
	}
	public void setDesgNm(String desgNm) {
		this.desgNm = desgNm;
	}
	public String getShrtNm() {
		return shrtNm;
	}
	public void setShrtNm(String shrtNm) {
		this.shrtNm = shrtNm;
	}
	public Timestamp getCreationDt() {
		return creationDt;
	}
	public void setCreationDt(Timestamp creationDt) {
		this.creationDt = creationDt;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	

}
