package com.common.dao;

import java.util.List;

import com.common.objects.UsersObject;

public interface UsersDao {
	void add(UsersObject usersObject);
	List<UsersObject> listPersons();

}
