package com.common.service;

import java.util.List;

import com.common.objects.UsersObject;

public interface UsersService {
	void add(UsersObject usersObject);
    List<UsersObject> listUsers();
    
}
