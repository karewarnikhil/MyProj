package com.common.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.common.impl.UsersDaoImpl;
import com.common.objects.UsersObject;
import com.common.service.UsersService;
@Service
public class UsersServiceImpl implements UsersService{
	@Autowired
	private UsersDaoImpl usersDao;
	 
	@Transactional
	public void add(UsersObject usersObject) {
		usersDao.add(usersObject);
		
	}
	
	@Transactional
	public List<UsersObject> listUsers() {
		 return usersDao.listPersons();
	}

}
