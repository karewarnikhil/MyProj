package com.common.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class CalculatorController {
	
	@RequestMapping("/add")
	public ModelAndView add(
			HttpServletRequest request, HttpServletResponse response) {
		int n1 = Integer.parseInt(request.getParameter("n1"));
		int n2 = Integer.parseInt(request.getParameter("n2"));
		int sum = n1 + n2;
		ModelAndView mv = new ModelAndView();
		mv.setViewName("result");
		mv.addObject("res", sum);
		return mv;
	}
	
/*	@RequestMapping("/add/{email}")
	public ModelAndView add(
			@PathVariable(value = "email") String email,
			HttpServletRequest request, HttpServletResponse response) {
		int n1 = Integer.parseInt(request.getParameter("n1"));
		int n2 = Integer.parseInt(request.getParameter("n2"));
		int sum = n1 + n2;
		System.out.println(email);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("result.jsp");
		mv.addObject("res", sum);
		return mv;
	}*/
}
