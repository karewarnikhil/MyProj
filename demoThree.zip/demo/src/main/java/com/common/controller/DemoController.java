package com.common.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.common.impl.DemoImpl;
import com.common.objects.UsersObject;

@Controller
public class DemoController  {
	static final long serialVersionUID = 1L;
	 @Autowired  
	 DemoImpl demoImpl;//will inject dao from xml file  
	 
   @RequestMapping(value="/save", method = RequestMethod.POST)  
	private ModelAndView saveData(@ModelAttribute("UsersObject") UsersObject usersObject){
		    demoImpl.save(usersObject);  
		    ModelAndView mv = new ModelAndView();
	        mv.setViewName("registration");
	        System.out.println("You data saved successfully.");
	        return mv;//will redirect to viewemp request mapping
	}
	
	
       
	/*******
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//System.out.println("You are in do get method");
		String submit = request.getParameter("submit");
		String save = request.getParameter("save");
		String manageUsers = request.getParameter("manageUsers");
		String edit = request.getParameter("edit");
		String update = request.getParameter("updateUsers");
		String searchUsers = request.getParameter("searchUsers");
		String uploadFile = request.getParameter("uploadFile");
		String fileSize = request.getParameter("fileSize");
		
		String showDepartments = request.getParameter("showDepartments");
		String showDesignations = request.getParameter("showDesignations");
		String editDepartment = request.getParameter("editDepartment");
		String editDesignation = request.getParameter("editDesignation");
		String login = request.getParameter("login");
		String addDepartment = request.getParameter("addDepartment");
		String addDesignation = request.getParameter("addDesignation");
		String updateDepartment = request.getParameter("updateDepartment");
		String updateDesignation = request.getParameter("updateDesignation");
		String saveDepartment = request.getParameter("saveDepartment");
		String saveDesignation = request.getParameter("saveDesignation");
		
		if(submit != null)
			showMessage(request,response);
		else if(save != null)
			saveData(request,response);
		else if(manageUsers != null)
			manageUsers(request,response);
		else if(edit != null)
			editUser(request,response);
		else if(update != null)
			updateUser(request,response);
		else if(searchUsers != null)
			searchUsers(request,response);
		else if(uploadFile != null)
			uploadFile(request,response);
		else if(fileSize != null)
			fileSize(request,response);
		
		else if(showDepartments != null)
			showDepartments(request,response);
		else if(showDesignations != null)
			showDesignations(request,response);
		else if(editDepartment != null)
			editDepartment(request,response);
		else if(editDesignation != null)
			editDesignation(request,response);
		else if(login != null)
			loginUser(request,response);
		else if(addDepartment != null)
			addDepartment(request,response);
		else if(addDesignation != null)
			addDesignation(request,response);
		else if(updateDepartment != null)
			updateDepartment(request,response);
		else if(updateDesignation != null)
			updateDesignation(request,response);
		else if(saveDepartment != null)
			saveDepartment(request,response);
		else if(saveDesignation != null)
			saveDesignation(request,response);
		
		
		
	}

	private void updateDepartment(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		DepartmentObj departmentObj = (DepartmentObj) session.getAttribute("departmentObj");
		
		
		String deptNmFn = request.getParameter("deptNmFn");
		String shortNmFn = request.getParameter("shortNmFn");
		String activeFn = request.getParameter("activeFn");
		
		
		departmentObj.setDeptNm(deptNmFn);
		departmentObj.setShrtNm(shortNmFn);
		departmentObj.setStatus(activeFn);
 		
		DemoImpl demoImpl = new DemoImpl();
		demoImpl.updateDepartmentData(departmentObj);
		
		
		RequestDispatcher rd=request.getRequestDispatcher("jsp/manageDepartmentOne.jsp");  
		rd.forward(request, response);
		//response.sendRedirect("home.jsp");
		
	}
	
	private void saveDepartment(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String deptNmFn = request.getParameter("deptNmFn");
		String shortNmFn = request.getParameter("shortNmFn");
		String activeFn = request.getParameter("activeFn");
		
		
		DepartmentObj departmentObj = new DepartmentObj();
		departmentObj.setDeptNm(deptNmFn);
		departmentObj.setShrtNm(shortNmFn);
		departmentObj.setStatus(activeFn);
		
		
		//setting system date into timestamp
		Date date = new Date();  
        Timestamp ts = new Timestamp(date.getTime());  
        System.out.println(ts);           
        departmentObj.setCreationDt(ts);
        
		DemoImpl demoImpl = new DemoImpl();
		demoImpl.saveDepartmentData(departmentObj);
		
		
		showDepartments(request, response);
		//response.sendRedirect("home.jsp");
		
	}
	
	private void saveDesignation(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String desgNm = request.getParameter("desgNmFn");
		String shortNmFn = request.getParameter("shortNmFn");
		String activeFn = request.getParameter("activeFn");
		
		DesinationObject desinationObject = new DesinationObject();
		desinationObject.setDesgNm(desgNm);
		desinationObject.setShrtNm(shortNmFn);
		desinationObject.setStatus(activeFn);
		
		//setting system date into timestamp
		Date date = new Date();  
        Timestamp ts = new Timestamp(date.getTime());  
        System.out.println(ts);           
        
        desinationObject.setCreationDt(ts);
		
		//Timestamp date = 2007-12-13 00:00:00.0;
		//departmentObj.setCreationDt();
		
		DemoImpl demoImpl = new DemoImpl();
		demoImpl.saveDesignationData(desinationObject);
		
		
		showDesignations(request, response);
		//response.sendRedirect("home.jsp");
		
	}
	
private void updateDesignation(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		DesinationObject desinationObject = (DesinationObject) session.getAttribute("desinationObject");
		
		
		String desgNm = request.getParameter("desgNmFn");
		String shortNmFn = request.getParameter("shortNmFn");
		String activeFn = request.getParameter("activeFn");
		
		
		desinationObject.setDesgNm(desgNm);
		desinationObject.setShrtNm(shortNmFn);
		desinationObject.setStatus(activeFn);
 		
		DemoImpl demoImpl = new DemoImpl();
		demoImpl.updateDesignation(desinationObject);
		
		
		RequestDispatcher rd=request.getRequestDispatcher("jsp/manageDesignationOne.jsp");  
		rd.forward(request, response);
		//response.sendRedirect("home.jsp");
		
	}

	private void addDepartment(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/****
		String deptNmFn = request.getParameter("deptNmFn");
		String shortNmFn = request.getParameter("shortNmFn");
		String activeFn = request.getParameter("activeFn");
		
		
		DepartmentObj departmentObj = new DepartmentObj();
		departmentObj.setDeptNm(deptNmFn);
		departmentObj.setShrtNm(shortNmFn);
		departmentObj.setStatus(activeFn);
		
		
		//SerializationDemo serializationDemo = new SerializationDemo();
		//serializationDemo.serializationDemo(usersObject);
		
		PdfObjectDemo pdfObjectDemo = new PdfObjectDemo();
		//pdfObjectDemo.pdfFileDemo(usersObject,request,response);
		pdfObjectDemo.unequalPageSizes();
		pdfObjectDemo.changeMargin();
 		
		DemoImpl demoImpl = new DemoImpl();
		demoImpl.saveDepartmentData(departmentObj);
		
		
		RequestDispatcher rd=request.getRequestDispatcher("jsp/deptRegistrationJ.jsp");  
		rd.forward(request, response);
		//response.sendRedirect("home.jsp");
		
	}
	
	private void addDesignation(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/****
		String deptNmFn = request.getParameter("deptNmFn");
		String shortNmFn = request.getParameter("shortNmFn");
		String activeFn = request.getParameter("activeFn");
		
		
		DepartmentObj departmentObj = new DepartmentObj();
		departmentObj.setDeptNm(deptNmFn);
		departmentObj.setShrtNm(shortNmFn);
		departmentObj.setStatus(activeFn);
		
		
		//SerializationDemo serializationDemo = new SerializationDemo();
		//serializationDemo.serializationDemo(usersObject);
		
		PdfObjectDemo pdfObjectDemo = new PdfObjectDemo();
		//pdfObjectDemo.pdfFileDemo(usersObject,request,response);
		pdfObjectDemo.unequalPageSizes();
		pdfObjectDemo.changeMargin();
 		
		DemoImpl demoImpl = new DemoImpl();
		demoImpl.saveDepartmentData(departmentObj);

		
		RequestDispatcher rd=request.getRequestDispatcher("jsp/desigRegistrationJ.jsp");  
		rd.forward(request, response);
		//response.sendRedirect("home.jsp");
		
	}
	
	

	private void loginUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String fnameFn = request.getParameter("fnameFn");
		String lnameFn = request.getParameter("lnameFn");
		/****
		UsersObject usersObject = new UsersObject();
		usersObject.setFirstName(fnameFn);
		usersObject.setLastName(lnameFn);
		usersObject.setEmailId(emailIdFn);
		usersObject.setMobNo(mobileNoFn);
		usersObject.setCity(cityFn);
	
		
		
		RequestDispatcher rd=request.getRequestDispatcher("jsp/home.jsp");  
		rd.forward(request, response);
		
	}

	private void editDesignation(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		int designationIndex = Integer.parseInt(request.getParameter("designationIndex"));
		ArrayList<DesinationObject> arrayListOfDesinationObject = (ArrayList<DesinationObject>) session.getAttribute("arrayListOfDesinationObject");
		
		DesinationObject desinationObject = arrayListOfDesinationObject.get(designationIndex);
		session.setAttribute("desinationObject", desinationObject);
		RequestDispatcher rd=request.getRequestDispatcher("jsp/editDesignation.jsp");  
		rd.forward(request, response);
		
	}

	private void editDepartment(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		int departmentIndex = Integer.parseInt(request.getParameter("departmentIndex"));
		ArrayList<DepartmentObj> arrayListOfDepartmentObj = (ArrayList<DepartmentObj>) session.getAttribute("arrayListOfDepartmentObj");
		
		DepartmentObj departmentObj = arrayListOfDepartmentObj.get(departmentIndex);
		session.setAttribute("departmentObj", departmentObj);
		RequestDispatcher rd=request.getRequestDispatcher("jsp/editDepartment.jsp");  
		rd.forward(request, response);
		
	}

	private void showDesignations(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		DemoImpl demoImpl = new DemoImpl();
		HttpSession session = request.getSession();
		ArrayList<DesinationObject> arrayListOfDesinationObject = demoImpl.getAllDesinationObject();
		session.setAttribute("arrayListOfDesinationObject", arrayListOfDesinationObject);
		RequestDispatcher rd=request.getRequestDispatcher("jsp/manageDesignationOne.jsp");  
		rd.forward(request, response);
		
	}

	private void showDepartments(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		DemoImpl demoImpl = new DemoImpl();
		HttpSession session = request.getSession();
		ArrayList<DepartmentObj> arrayListOfDepartmentObj = demoImpl.getAllDepartmentObj();
		session.setAttribute("arrayListOfDepartmentObj", arrayListOfDepartmentObj);
		RequestDispatcher rd=request.getRequestDispatcher("/jsp/manageDepartmentOne.jsp");  
		rd.forward(request, response);
	}
	
	
	private static void fileSize(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	      String path = "E:\\SpringBooks";
	      File file = new File(path);
	      double folderSize = getFolderSize(file);
		 
	      double sizeMB = (double) folderSize / 1024 / 1024;
		  String s = " MB";
		  /***
		  if (sizeMB < 1) {
			sizeMB = (double) folderSize / 1024;
			s = " KB";
		  }
	
		  System.out.println("Total size" + " : " + sizeMB + s);
	      RequestDispatcher rd=request.getRequestDispatcher("jsp/index.jsp");  
		  rd.forward(request, response);
	}

	private static long getFolderSize(File folder) {
	    long length = 0;
	    File[] files = folder.listFiles();
	    System.out.println("folder count : "+files.length);
	    if (files == null || files.length == 0){
	        return length;
	    }
	    for (File file : files) {
	        if (file.isFile()) {
	            length += file.length();
	        } else {
	            length += getFolderSize(file);
	        }
	        
	        double sizeMB = (double) file.length() / 1024 / 1024;
			String s = " MB";
			/**
			if (sizeMB < 1) {
				sizeMB = (double) file.length() / 1024;
				s = " KB";
			}
		 
			  System.out.println(file.getName() + " : " + sizeMB + s);
	    }
	    return length;
	}
	
	private void uploadFile(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		        //ServletFileUpload sf = 
		        /*
		        if(ServletFileUpload.isMultipartContent(request)) {
		        try {
		        	 DiskFileItemFactory factory = new DiskFileItemFactory();
		            // sets temporary location to store files
		        	 System.out.println("tempDirValue===="+System.getProperty("java.io.tmpdir"));
		            factory.setRepository(new File(System.getProperty("java.io.tmpdir")));
		            ServletFileUpload upload = new ServletFileUpload(factory);
		            //String uploadPath = getServletContext().getRealPath("")+ File.separator + UPLOAD_DIRECTORY;
		            String uploadPath = "E:\\upload";
		            		
		            File uploadDir = new File(uploadPath);
		            if (!uploadDir.exists()) {
		                uploadDir.mkdir();
		            }
		            
					//List<FileItem>  fileItems = (List<FileItem>) new ServletFileUpload(new DiskFileItemFactory());
		            System.out.println(uploadPath);
		            RequestContext requestContext = ((RequestContext)request.getServletContext());
		            List<FileItem> formItems = upload.parseRequest( requestContext);
					for(FileItem fm:formItems) {
						System.out.println("Your uploaded file" + fm.getName());
						fm.write(new File("E:\\upload" +fm.getName()));
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
		        }
		       
		        final String UPLOAD_DIR = "upload";
				String applicationPath = request.getServletContext().getRealPath("");  
				String uploadFilePath = applicationPath + File.separator + UPLOAD_DIR;
				
				File uploadFolder = new File(uploadFilePath);
				if (!uploadFolder.exists()) {
					uploadFolder.mkdirs();
				}
				
				
				for (Part part : request.getParts()) {
					System.out.println("parts"+part.getName());
					if (part != null && part.getSize() > 0) {
						String fileName = part.getSubmittedFileName();
						//String contentType = part.getContentType();
						part.write(uploadFilePath + File.separator + fileName);
					}
				}
				
	            RequestDispatcher rd=request.getRequestDispatcher("jsp/manageUsers.jsp");  
	    		rd.forward(request, response);
   }
	


	private void searchUsers(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("You are in search user functionality.");
		HttpSession session = request.getSession();
		String fnameFn = request.getParameter("fnameFn");
		String lnameFn = request.getParameter("lnameFn");
		String emailIdFn = request.getParameter("emailIdFn");
		String cityFn = request.getParameter("cityFn");
		
		UsersSearchObj usersSearchObj = new UsersSearchObj();
		if(fnameFn != null)
			usersSearchObj.setFirstName(fnameFn);
		if(lnameFn != null)
			usersSearchObj.setLastName(lnameFn);
		if(emailIdFn != null)
			usersSearchObj.setEmailId(emailIdFn);
		if(cityFn != null)
			usersSearchObj.setCity(cityFn);
		
		DemoImpl demoImpl = new DemoImpl();
		ArrayList<UsersObject> arrayListOfUsersObj = demoImpl.searchUsers(usersSearchObj);
		session.setAttribute("arrayListOfUsersObj", arrayListOfUsersObj);
		RequestDispatcher rd=request.getRequestDispatcher("jsp/manageUsers.jsp");  
		rd.forward(request, response);
		
	}


	private void updateUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String fnameFn = request.getParameter("fnameFn");
		String lnameFn = request.getParameter("lnameFn");
		String emailIdFn = request.getParameter("emailIdFn");
		String cityFn = request.getParameter("cityFn");
		
		UsersObject usersObject = (UsersObject)request.getAttribute("usersObject");
		usersObject.setFirstName(fnameFn);
		usersObject.setLastName(lnameFn);
		usersObject.setEmailId(emailIdFn);
		usersObject.setCity(cityFn);
		
		DemoImpl demoImpl = new DemoImpl();
		demoImpl.updateUsersData(usersObject,false);
		
		String message = "Your data saved successfully";
		request.setAttribute("message",message);
		request.setAttribute("usersObject", usersObject);
		RequestDispatcher rd=request.getRequestDispatcher("jsp/dataDisplay.jsp");  
		rd.forward(request, response);
		//response.sendRedirect("home.jsp");
	}


	private void editUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		int userIndex = Integer.parseInt(request.getParameter("userIndex"));
		ArrayList<UsersObject> attribute = (ArrayList<UsersObject>) (session.getAttribute("arrayListOfUsersObj"));
		ArrayList<UsersObject> arrayListOfUsersObj = attribute;
		UsersObject usersObject = arrayListOfUsersObj.get(userIndex);
		request.setAttribute("usersObject", usersObject);
		RequestDispatcher rd=request.getRequestDispatcher("jsp/dataDisplay.jsp");  
		rd.forward(request, response);
	}


	private void manageUsers(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("You are in manage user functionality");
		DemoImpl demoImpl = new DemoImpl();
		HttpSession session = request.getSession();
		ArrayList<UsersObject> arrayListOfUsersObj = demoImpl.getAllUsers();
		session.setAttribute("arrayListOfUsersObj", arrayListOfUsersObj);
		RequestDispatcher rd=request.getRequestDispatcher("jsp/manageUsers.jsp");  
		rd.forward(request, response);
	}


	private void saveData(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String fnameFn = request.getParameter("fnameFn");
		String lnameFn = request.getParameter("lnameFn");
		String emailIdFn = request.getParameter("emailIdFn");
		String mobileNoFn = request.getParameter("mobileNoFn");
		String cityFn = request.getParameter("cityFn");
		
		UsersObject usersObject = new UsersObject();
		usersObject.setFirstName(fnameFn);
		usersObject.setLastName(lnameFn);
		usersObject.setEmailId(emailIdFn);
		usersObject.setMobNo(mobileNoFn);
		usersObject.setCity(cityFn);
		
		//SerializationDemo serializationDemo = new SerializationDemo();
		//serializationDemo.serializationDemo(usersObject);
		
		PdfObjectDemo pdfObjectDemo = new PdfObjectDemo();
		//pdfObjectDemo.pdfFileDemo(usersObject,request,response);
		pdfObjectDemo.unequalPageSizes();
		pdfObjectDemo.changeMargin();
 		
		DemoImpl demoImpl = new DemoImpl();
		demoImpl.saveUsersData(usersObject);
		
		String message = "Your data saved successfully";
		request.setAttribute("message",message);
		request.setAttribute("usersObject", usersObject);
		RequestDispatcher rd=request.getRequestDispatcher("jsp/dataDisplay.jsp");  
		rd.forward(request, response);
		//response.sendRedirect("home.jsp");
		
	}


	private void showMessage(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
	    String message = "You are submitted button successfully";
		request.setAttribute("message",message);
		RequestDispatcher rd=request.getRequestDispatcher("jsp/jsphome.jsp");  
		rd.forward(request, response);
		//response.sendRedirect("home.jsp");
	}
	
	

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("You are in do post method");
		doGet(request, response);
	}
	*****/

}
