package com.common.impl;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;

import com.common.objects.UsersObject;

public class DemoImpl {
	
	
	JdbcTemplate template;  
	  
	public void setTemplate(JdbcTemplate template) {  
	    this.template = template;  
	}  
	
	public Boolean save(final UsersObject usersObject){  
		String sql= "insert into \"usersTbl\" (\"firstName\", \"lastName\", \"emailId\", city) VALUES (?, ?, ?, ?); ";
		return template.execute(sql,new PreparedStatementCallback<Boolean>(){
			public Boolean doInPreparedStatement(PreparedStatement ps)  
		            throws SQLException, DataAccessException {  
				 ps.setString(1,usersObject.getFirstName());
		         ps.setString(2,usersObject.getLastName());
		         ps.setString(3,usersObject.getEmailId());
		         ps.setString(4,usersObject.getCity());
		         System.out.println("\n \n ps===" +ps+"\n \n");
		        return ps.execute();  
		    }  
		 });  
	}  
	
	
     /********************	
	 public String saveUsersData(UsersObject usersObject) {
	      Connection c = null;
	      PreparedStatement ps = null;
	      String sql = null;
	      try {
	         Class.forName("org.postgresql.Driver");
	         c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/testDb","postgres", "admin");
	         sql = "insert into \"usersTbl\" (\"firstName\", \"lastName\", \"emailId\", city) VALUES (?, ?, ?, ?); ";
	         //sql = createQuery(usersObject,sql);
	         ps = c.prepareStatement(sql);
	         ps.setString(1,usersObject.getFirstName());
	         ps.setString(2,usersObject.getLastName());
	         ps.setString(3,usersObject.getEmailId());
	         ps.setString(4,usersObject.getCity());
	        // ps.setInt(5, Integer.parseInt(usersObject.getMobNo()));
	         System.out.println("\n \n ps===" +ps+"\n \n");
	         ps.execute();
	      } catch (Exception e) {
	    	  e.printStackTrace();
	      }
	      finally {
	    	 try {
				c.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	      System.out.println("Records created successfully");
		return null;
	   }

	private String createQuery(UsersSearchObj usersSearchObj, String sql) {
		if(usersSearchObj != null)
			sql += " where ";
		if(" " != usersSearchObj.getFirstName() && usersSearchObj.getFirstName() != null) {
			sql += "\"firstName\" Like '%"+usersSearchObj.getFirstName()+"%'";
		}
		if(" " != usersSearchObj.getLastName() && usersSearchObj.getLastName() != null) {
			sql += " and \"lastName\" Like '%"+usersSearchObj.getLastName()+"%'";
		}
		if(" " != usersSearchObj.getEmailId() && usersSearchObj.getEmailId() != null) {
			sql += " and \"emailId\" Like '%"+usersSearchObj.getEmailId()+"%'";
		}	
		if(" " != usersSearchObj.getMobNo() && usersSearchObj.getMobNo() != null) {
			sql += " and \"mobileNo\" Like '%"+usersSearchObj.getMobNo()+"%'";
		}	
		if(" " != usersSearchObj.getCity() && usersSearchObj.getCity() != null) {
			sql += " and \"city\"  Like '%"+usersSearchObj.getCity()+"%'";
		}
		return sql;
	}
	
	

	public ArrayList<UsersObject> getAllUsers() {
		  Connection c = null;
	      PreparedStatement ps = null;
	      String sql = null;
	      ArrayList<UsersObject> arrayListOfUsersObj = new ArrayList();
	      try {
	         Class.forName("org.postgresql.Driver");
	         c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/testDb","postgres", "admin");
	         sql = "select * from \"usersTbl\" order by \"userId\" desc";
	         //sql = createQuery(usersObject,sql);
	         ps = c.prepareStatement(sql);
	         System.out.println("\n \n ps=== "+ps+"\n \n");
             ResultSet rs = ps.executeQuery();	         
	         while (rs.next()) {
	        	 UsersObject usersObject = new UsersObject();
	        	 usersObject.setUserId(rs.getInt("userId"));
				 usersObject.setFirstName(rs.getString("firstName"));
				 usersObject.setLastName(rs.getString("lastName"));
				 usersObject.setEmailId(rs.getString("emailId"));
				 usersObject.setCity(rs.getString("city"));
				 arrayListOfUsersObj.add(usersObject);
			}
	        
	      } catch (Exception e) {
	    	  e.printStackTrace();
	      }
	      finally {
	    	 try {
				c.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return arrayListOfUsersObj;
		
	}

	public void updateUsersData(UsersObject usersObject, boolean b) {
		 Connection c = null;
	      PreparedStatement ps = null;
	      String sql = null;
	      try {
	         Class.forName("org.postgresql.Driver");
	         c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/testDb","postgres", "admin");
	         sql += " UPDATE \"usersTbl\" SET \"userId\" ="+ usersObject.getUserId()+", \"firstName\" ="+usersObject.getFirstName()+", \"firstName\" ='"+usersObject.getFirstName()+"', \"lastName\" ="+usersObject.getLastName()+", \"emailId\" ="+usersObject.getEmailId()+", \"city\" ="+usersObject.getCity()+ "where \"userId\" "+usersObject.getUserId();
	         //sql += "UPDATE \"usersTbl\"" + 
	         		//"	SET \"userId\"="+usersObject.getUserId(),+" \"firstName\"=?, \"lastName\"=?, \"emailId\"=?, city=?" + 
	         		//"	WHERE userId =?;"
	         //sql = createQuery(usersObject,sql);
	         ps = c.prepareStatement(sql);
	         ps.setString(1,usersObject.getFirstName());
	         ps.setString(2,usersObject.getLastName());
	        
	        // ps.setInt(5, Integer.parseInt(usersObject.getMobNo()));
	         System.out.println("\n \n ps "+ps+"\n \n");
	         ps.execute();
	      } catch (Exception e) {
	    	  e.printStackTrace();
	      }
	      finally {
	    	 try {
				c.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	      System.out.println("Records created successfully");
		
	   }

	public ArrayList<UsersObject> searchUsers(UsersSearchObj usersSearchObj) {
		  Connection c = null;
	      PreparedStatement ps = null;
	      String sql = null;
	      ArrayList<UsersObject> arrayListOfUsersObj = new ArrayList();
	      try {
	         Class.forName("org.postgresql.Driver");
	         c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/testDb","postgres", "admin");
	         sql = "select * from \"usersTbl\"";
	         sql = createQuery(usersSearchObj,sql);
	         ps = c.prepareStatement(sql);
	         System.out.println("\n \n ps "+ps+"\n \n");
             ResultSet rs = ps.executeQuery();	         
	         while (rs.next()) {
	        	 UsersObject usersObject = new UsersObject();
	        	 usersObject.setUserId(rs.getInt("userId"));
				 usersObject.setFirstName(rs.getString("firstName"));
				 usersObject.setLastName(rs.getString("lastName"));
				 usersObject.setEmailId(rs.getString("emailId"));
				 usersObject.setCity(rs.getString("city"));
				 arrayListOfUsersObj.add(usersObject);
			}
	        
	      } catch (Exception e) {
	    	  e.printStackTrace();
	      }
	      finally {
	    	 try {
				c.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return arrayListOfUsersObj;
		
	}
	
	
	public String saveImageData(ImageObj imageObj) {
	      Connection c = null;
	      PreparedStatement ps = null;
	      String sql = null;
	      try {
	         Class.forName("org.postgresql.Driver");
	         c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/testDb","postgres", "admin");
	         sql = "insert into \"imageTbl\" (\"imageName\") VALUES (?); ";
	         //sql = createQuery(usersObject,sql);
	         ps = c.prepareStatement(sql);
	         ps.setString(1,imageObj.getImageName());
	        // ps.setInt(5, Integer.parseInt(usersObject.getMobNo()));
	         System.out.println("\n \n ps===" +ps+"\n \n");
	         ps.execute();
	      } catch (Exception e) {
	    	  e.printStackTrace();
	      }
	      finally {
	    	 try {
				c.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	      System.out.println("Records created successfully");
		return null;
	   }
	
	
	public ArrayList<DesinationObject> getAllDesinationObject() {
		  Connection c = null;
	      PreparedStatement ps = null;
	      String sql = null;
	      ArrayList<DesinationObject> arrayListOfDesinationObject = new ArrayList();
	      try {
	         Class.forName("org.postgresql.Driver");
	         c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/DMS","postgres", "admin");
	         sql = "select * from \"desigmst\" order by \"desgid\" desc";
	         //sql = createQuery(usersObject,sql);
	         ps = c.prepareStatement(sql);
	         System.out.println("\n \n ps=== "+ps+"\n \n");
         ResultSet rs = ps.executeQuery();	         
	         while (rs.next()) {
	        	 DesinationObject desinationObject = new DesinationObject();
	        	 desinationObject.setDesgId(rs.getInt("desgid"));
	        	 desinationObject.setDesgNm(rs.getString("desgnm"));
	        	 desinationObject.setShrtNm(rs.getString("shrtnm"));
	        	 desinationObject.setCreationDt(rs.getTimestamp("creationdt"));
	        	 desinationObject.setStatus(rs.getString("status"));
	        	 arrayListOfDesinationObject.add(desinationObject);
			}
	        
	      } catch (Exception e) {
	    	  e.printStackTrace();
	      }
	      finally {
	    	 try {
				c.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return arrayListOfDesinationObject;
		
	}
	
	
	public ArrayList<DepartmentObj> getAllDepartmentObj() {
		  Connection c = null;
	      PreparedStatement ps = null;
	      String sql = null;
	      ArrayList<DepartmentObj> arrayListOfDepartmentObj = new ArrayList();
	      try {
	         Class.forName("org.postgresql.Driver");
	         c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/DMS","postgres", "admin");
	         sql = "select * from \"deptmst\" order by \"deptid\" desc";
	         //sql = createQuery(usersObject,sql);
	         ps = c.prepareStatement(sql);
	         System.out.println("\n \n ps=== "+ps+"\n \n");
       ResultSet rs = ps.executeQuery();	         
	         while (rs.next()) {
	        	 DepartmentObj departmentObj = new DepartmentObj();
	        	 departmentObj.setDeptId(rs.getInt("deptid"));
	        	 departmentObj.setDeptNm(rs.getString("deptnm"));
	        	 departmentObj.setShrtNm(rs.getString("shrtnm"));
	        	 departmentObj.setCreationDt(rs.getTimestamp("creationdt"));
	        	 departmentObj.setStatus(rs.getString("status"));
	        	 arrayListOfDepartmentObj.add(departmentObj);
			}
	        
	      } catch (Exception e) {
	    	  e.printStackTrace();
	      }
	      finally {
	    	 try {
				c.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return arrayListOfDepartmentObj;
		
	}
	
	
	public void updateDepartmentData(DepartmentObj departmentObj) {
		 Connection c = null;
	      PreparedStatement ps = null;
	      String sql = "";
	      try {
	         Class.forName("org.postgresql.Driver");
	         c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/DMS","postgres", "admin");
	         sql += " UPDATE \"deptmst\" SET \"deptnm\" = '"+departmentObj.getDeptNm()+"', \"shrtnm\" ='"+departmentObj.getShrtNm()+"', \"status\" = '"+departmentObj.getStatus()+"', \"creationdt\" = '"+departmentObj.getCreationDt()+ "'where \"deptid\" ="+departmentObj.getDeptId();
	         //sql += "UPDATE \"usersTbl\"" + 
	         		//"	SET \"userId\"="+usersObject.getUserId(),+" \"firstName\"=?, \"lastName\"=?, \"emailId\"=?, city=?" + 
	         		//"	WHERE userId =?;"
	         //sql = createQuery(usersObject,sql);
	         System.out.println("\n \n ps "+sql+"\n \n");
	         ps = c.prepareStatement(sql);
	        // ps.setInt(5, Integer.parseInt(usersObject.getMobNo()));
	         System.out.println("\n \n ps "+ps+"\n \n");
	         ps.execute();
	      } catch (Exception e) {
	    	  e.printStackTrace();
	      }
	      finally {
	    	 try {
				c.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	      System.out.println("Records created successfully");
		
	   }
	
	public void updateDesignation(DesinationObject desinationObject) {
		 Connection c = null;
	      PreparedStatement ps = null;
	      String sql = "";
	      try {
	         Class.forName("org.postgresql.Driver");
	         c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/DMS","postgres", "admin");
	         sql += " UPDATE \"desigmst\" SET \"desgnm\" = '"+desinationObject.getDesgNm()+"', \"shrtnm\" ='"+desinationObject.getShrtNm()+"', \"status\" = '"+desinationObject.getStatus()+"', \"creationdt\" = '"+desinationObject.getCreationDt()+ "'where \"desgid\" ="+desinationObject.getDesgId();
	         //sql += "UPDATE \"usersTbl\"" + 
	         		//"	SET \"userId\"="+usersObject.getUserId(),+" \"firstName\"=?, \"lastName\"=?, \"emailId\"=?, city=?" + 
	         		//"	WHERE userId =?;"
	         //sql = createQuery(usersObject,sql);
	         ps = c.prepareStatement(sql);
	        // ps.setInt(5, Integer.parseInt(usersObject.getMobNo()));
	         System.out.println("\n \n ps "+ps+"\n \n");
	         ps.execute();
	      } catch (Exception e) {
	    	  e.printStackTrace();
	      }
	      finally {
	    	 try {
				c.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	      System.out.println("Records created successfully");
		
	   }
	
	public String saveDepartmentData(DepartmentObj departmentObj) {
	      Connection c = null;
	      PreparedStatement ps = null;
	      String sql = null;
	      try {
	         Class.forName("org.postgresql.Driver");
	         c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/DMS","postgres", "admin");
	         sql = "insert into \"deptmst\" (\"deptnm\", \"shrtnm\", \"status\", \"creationdt\") VALUES (?, ?, ?, ?); ";
	         //sql = createQuery(usersObject,sql);
	         ps = c.prepareStatement(sql);
	         ps.setString(1,departmentObj.getDeptNm());
	         ps.setString(2,departmentObj.getShrtNm());
	         ps.setString(3,departmentObj.getStatus());
	         ps.setTimestamp(4, departmentObj.getCreationDt());
	        // ps.setTimestamp(4,departmentObj.getCreationDt());
	        // ps.setInt(5, Integer.parseInt(usersObject.getMobNo()));
	         System.out.println("\n \n ps===" +ps+"\n \n");
	         ps.execute();
	      } catch (Exception e) {
	    	  e.printStackTrace();
	      }
	      finally {
	    	 try {
				c.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	      System.out.println("Records created successfully");
		return null;
	   }
	
	public String saveDesignationData(DesinationObject desinationObject) {
	      Connection c = null;
	      PreparedStatement ps = null;
	      String sql = null;
	      try {
	         Class.forName("org.postgresql.Driver");
	         c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/DMS","postgres", "admin");
	         sql = "insert into \"desigmst\" (\"desgnm\", \"shrtnm\", \"status\", \"creationdt\") VALUES (?, ?, ?, ?); ";
	         //sql = "insert into desigMst (desgnm, shrtnm, creationdt) VALUES (?, ?, ?)";
	         //sql = createQuery(usersObject,sql);
	         ps = c.prepareStatement(sql);
	         ps.setString(1,desinationObject.getDesgNm());
	         ps.setString(2,desinationObject.getShrtNm());
	         ps.setString(3,desinationObject.getStatus());
	         ps.setTimestamp(4, desinationObject.getCreationDt());
	         //ps.setTimestamp(4,desinationObject.getCreationDt());
	        // ps.setInt(5, Integer.parseInt(usersObject.getMobNo()));
	         System.out.println("\n \n ps===" +ps+"\n \n");
	         ps.execute();
	      } catch (Exception e) {
	    	  e.printStackTrace();
	      }
	      finally {
	    	 try {
				c.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	      System.out.println("Records created successfully");
		return null;
	   }
	   ***************/
	}




