package com.common.dao;

import java.util.List;

import com.common.objects.UsersObject;

public interface UsersDao {

 public	void saveUsersObject(UsersObject users);

 public List<UsersObject> getAllStudents();

public UsersObject getUsersById(Integer userId);

public void deleteUserObject(UsersObject usersObject);
	

}
