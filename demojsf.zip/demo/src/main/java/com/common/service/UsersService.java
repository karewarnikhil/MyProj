package com.common.service;

import java.util.List;

import com.common.objects.UsersObject;

public interface UsersService {

	public void save(UsersObject users);

	public List<UsersObject> getAllUsers();

	public UsersObject getUsersById(Integer userId);

	public void deleteUserObject(UsersObject usersObject);

	
}