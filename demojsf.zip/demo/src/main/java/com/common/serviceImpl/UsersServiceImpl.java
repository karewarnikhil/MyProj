package com.common.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.common.dao.UsersDao;
import com.common.objects.UsersObject;
import com.common.service.UsersService;

@Service
public class UsersServiceImpl implements UsersService{

	@Autowired
	private UsersDao usersDao;
	
	
	public void save(UsersObject users) {
		usersDao.saveUsersObject(users);
		
	}
	
	
	public List<UsersObject> getAllUsers() {
	    return usersDao.getAllStudents();
	}

	
	public UsersObject getUsersById(Integer userId) {
		UsersObject usersObject = usersDao.getUsersById(userId);
		return usersObject;
	}
    

	public void deleteUserObject(UsersObject usersObject) {
		usersDao.deleteUserObject(usersObject);
		
	}

	
	
	
	 
	

}
