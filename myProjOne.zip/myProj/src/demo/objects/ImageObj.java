package demo.objects;

public class ImageObj {
	private  int imageId = -1;
	private  String imageName = null;
	 
	 
	public int getImageId() {
		return imageId;
	}
	public void setImageId(int imageId) {
		this.imageId = imageId;
	}
	public String getImageName() {
		return imageName;
	}
	public void setImageName(String imageName) {
		this.imageName = imageName;
	}
	 
	 
}
