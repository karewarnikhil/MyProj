package demo.objects;

import java.awt.Desktop;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfWriter;

public class PdfObjectDemo {
	private static final String UPLOAD_DIRECTORY = "upload";
	
public void pdfFileDemo(UsersObject usersObject, HttpServletRequest request, HttpServletResponse response) {
	  //String contextPath = request.getContextPath();
	  String filename = "E:JavaInstallationFiles/itextFiles/sample.pdf";
	  String name = "sample.pdf";
	  String uploadPath = request.getServletContext().getRealPath("")
	            + File.separator + UPLOAD_DIRECTORY+File.separator+name;
	 // String appPath = request.getServletContext().getRealPath("");
	 // String savePath = appPath + File.separator + SAVE_DIR;
	 //String filename = appPath+savePath;
	  //int parameterSize = 5;
	  /****
	  PdfReader reader;
	  try {
		  Document document = new Document();
	 /* Rectangle small = new Rectangle(290,100);
      Font smallfont = new Font(FontFamily.HELVETICA, 10);
      Document document = new Document(small, 5, 5, 5, 5);
      PdfWriter writer = null;
	
		writer = PdfWriter.getInstance(document, new FileOutputStream(filename));
	
      document.open();
      PdfPTable table = new PdfPTable(2);
     
      table.setTotalWidth(new float[]{ 160, 120 });
	
      table.setLockedWidth(true);
      PdfContentByte cb = writer.getDirectContent();
      // first row
      PdfPCell cell = new PdfPCell(new Phrase("This is First page for show"));
      cell.setFixedHeight(30);
      cell.setBorder(Rectangle.NO_BORDER);
      cell.setColspan(2);
      table.addCell(cell);
      // second row
      cell = new PdfPCell(new Phrase("Some more text", smallfont));
      cell.setFixedHeight(30);
      cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
      cell.setBorder(Rectangle.NO_BORDER);
      table.addCell(cell);
      Barcode128 code128 = new Barcode128();
      code128.setCode("14785236987541");
      code128.setCodeType(Barcode128.CODE128);
      Image code128Image = code128.createImageWithBarcode(cb, null, null);
      cell = new PdfPCell(code128Image, true);
      cell.setBorder(Rectangle.NO_BORDER);
      cell.setFixedHeight(30);
      table.addCell(cell);
      // third row
      table.addCell(cell);
      cell = new PdfPCell(new Phrase("This is second page for show", smallfont));
      cell.setBorder(Rectangle.NO_BORDER);
      cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
      table.addCell(cell);
      
      Rectangle rect = new Rectangle(20, 800, 0, 0); 
      PdfAnnotation ann = new PdfAnnotation(writer, rect);
   // Setting color to the annotation 
      ann.setColor(CMYKColor.GREEN); 
      
      document.add(table);
      document.close();*/
		  
		 /* PdfWriter.getInstance(document, new FileOutputStream(new File(filename)));

          //open
          document.open();

          Paragraph p = new Paragraph();
          p.add("This is my paragraph 1");
          p.setAlignment(Element.ALIGN_CENTER);

          document.add(p);

          Paragraph p2 = new Paragraph();
          p2.add("This is my paragraph 2"); //no alignment

          document.add(p2);

          Font font = new Font();
          font.setStyle(Font.BOLD);
          font.setSize(8);

          document.add(new Paragraph("This is my paragraph 3", font));
          
          document.add(new Paragraph("Hello this is users Information"));
		    
		    // Creating a list
		      List list = new List();  
		      list.add(usersObject.getFirstName());       
		      list.add(usersObject.getLastName());      
		      list.add(usersObject.getEmailId());       
		      list.add(usersObject.getMobNo());       
		      list.add(usersObject.getCity());       
		      
		      // Adding list to the document       
		      document.add(list);

          //close
          document.close();

          System.out.println("Done");
          
          
          
          
          reader = new PdfReader(filename);

          // pageNumber = 1
          String textFromPage = PdfTextExtractor.getTextFromPage(reader, 1);

          System.out.println("textFromPage============"+textFromPage);

          reader.close();
      
		  PdfPTable table = new PdfPTable(new float[] { 4, 3, 4 });
		  table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		  table.addCell("First Name");
	      table.addCell("Last Name");
	      table.addCell("EmailId");
	      table.addCell("MobileNo");
	      //table.addCell("City");
		 // table.setHeaderRows(1);
		  PdfPCell[] cells = table.getRow(0).getCells(); 
		 
		     //cells[i].setBackgroundColor(BaseColor.GRAY);
		 
	          for (int i=1;i<=cells.length;i++){
	    	     table.addCell(usersObject.getFirstName());
	             table.addCell(usersObject.getLastName());
	             table.addCell(usersObject.getEmailId());
	             //table.addCell(usersObject.getMobNo());
	             //table.addCell(usersObject.getCity());
	          }
		  PdfWriter.getInstance(document, new FileOutputStream(filename));
		 // PdfWriter.getInstance(document, new FileOutputStream(uploadPath));
		  document.open();
	      document.add(table);
		  document.close();
		  System.out.println("Done");
		  
		  
		 Desktop.getDesktop().open(new File(filename));
		
	      
	} catch (Exception e) {
		e.printStackTrace();
	}
      ****/
	    /******
	    String contextPath = request.getContextPath();
		String filename = "E:JavaInstallationFiles/itextFiles/sample.pdf";
		int parameterSize = 5;
		Document document = new Document();
		
		try {
			PdfWriter.getInstance(document, new FileOutputStream(filename));
			
			document.open();
		      
		    document.add(new Paragraph("Hello this is users Information"));
		    
		    // Creating a list
		      List list = new List();  
		      list.add(usersObject.getFirstName());       
		      list.add(usersObject.getLastName());      
		      list.add(usersObject.getEmailId());       
		      list.add(usersObject.getMobNo());       
		      list.add(usersObject.getCity());       
		      
		      // Adding list to the document       
		      document.add(list);
		      PdfPTable table = new PdfPTable(parameterSize);
		     
		      document.add(new Paragraph("This is your user Information in tab View"));
		      PdfPCell cell = new PdfPCell(new Phrase("Some text here"));
		      cell.setFixedHeight(30);
		      cell.setBorder(Rectangle.NO_BORDER);
		      cell.setColspan(2);
		      table.setTotalWidth(new float[]{ 160, 120 });
		      table.setLockedWidth(true);
		      table.addCell("FirstName");
		      table.addCell("LastName");
		      table.addCell("EmailId");
		      table.addCell("MobileNo");
		      table.addCell("City");
		      
		      document.add(table);
		   
			// Closing the document    
			document.close();              
			System.out.println("PDF Created");    
			    
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	   
		*****/
	   
		/******
		Document document = new Document();
		//Demo code for object creation
	
		UsersObject usersObject = new UsersObject();
		usersObject.setUserId(78);
		usersObject.setFirstName("ABC");
		usersObject.setLastName("XYZ");
		usersObject.setEmailId("abc@test.com");
		usersObject.setCity("Pune");
	
		
		 try
	        {   
	            //Saving of object in a file
	            FileOutputStream file = new FileOutputStream(filename);
	            ObjectOutputStream out = new ObjectOutputStream(file);
	             
	            // Method for serialization of object
	            out.writeObject(usersObject);
	             
	            out.close();
	            file.close();
	             
	            System.out.println("Obect has been serialized");
	 
	        }
	         
	        catch(IOException ex)
	        {
	            System.out.println("IOException is caught");
	        }
		 
		 
		  UsersObject usersObjectOne = null;
		  
		  
		  try
	        {   
	            // Reading the object from a file
	            FileInputStream file = new FileInputStream(filename);
	            ObjectInputStream in = new ObjectInputStream(file);
	             
	            // Method for deserialization of object
	            usersObjectOne = (UsersObject)in.readObject();
	             
	            in.close();
	            file.close();
	             
	            System.out.println("Object has been deserialized ");
	            System.out.println(usersObjectOne.getUserId());
	            System.out.println(usersObjectOne.getFirstName());
	            System.out.println(usersObjectOne.getLastName());
	            System.out.println(usersObjectOne.getEmailId());
	            System.out.println(usersObjectOne.getMobNo());
	            System.out.println(usersObjectOne.getCity());
	        }
	        catch (Exception e) {
				e.printStackTrace();
			} 
		  	*******/
	  
	       File file = new File(filename);
           file.getParentFile().mkdirs();

           
           Document document = new Document();
           PdfWriter writer = null;
		try {
			writer = PdfWriter.getInstance(document, new FileOutputStream(filename));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
           document.open();
           Rectangle one = new Rectangle(70,140);
           Rectangle two = new Rectangle(700,400);
           
           PdfContentByte canvas = writer.getDirectContent();
           Rectangle rect = new Rectangle(36, 36, 559, 806);
           rect.setBorder(Rectangle.BOX);
           rect.setBorderWidth(2);
           canvas.rectangle(rect);
           
           document.setPageSize(one);
           document.setMargins(2, 2, 2, 2);
           document.open();
           Paragraph p = new Paragraph("Hi");
           try {
			document.add(p);
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
           
           document.setPageSize(two);
           document.setMargins(20, 20, 20, 20);
           document.newPage();
           try {
			document.add(p);
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
           document.close();
	}


	public void unequalPageSizes() {
		String filename = "E:JavaInstallationFiles/itextFiles/uneualPages.pdf";
		File file = new File(filename);
	    file.getParentFile().mkdirs();
	    
	   try {
		    Document document = new Document();
		    PdfWriter.getInstance(document, new FileOutputStream(filename));
		    Rectangle one = new Rectangle(70,140);
		    Rectangle two = new Rectangle(700,400);
		    document.open();
		    Image image = Image.getInstance("Tulips.jpg");
		    document.add(new Paragraph("Image"));
		    document.add(image);
		    
		    document.setPageSize(one);
		    document.setMargins(2, 2, 2, 2);
		 
		    Paragraph p = new Paragraph("Hi");
		    document.add(p);
		    document.setPageSize(two);
		    document.setMargins(20, 20, 20, 20);
		    document.newPage();
		    document.add(p);
		    document.close();
		   
	   }catch (Exception e) {
		e.printStackTrace();
	}
	}

	public void changeMargin() {
		String filename = "E:JavaInstallationFiles/itextFiles/changeMargin.pdf";
		File file = new File(filename);
	    file.getParentFile().mkdirs();
	    
	   try {
		    float left = 30;
	        float right = 30;
	        float top = 60;
	        float bottom = 0;
	  
	        Document document = new Document(PageSize.A4, left, right, top, bottom);
	        PdfWriter.getInstance(document, new FileOutputStream(filename));
	        document.open();
	        document.setMargins(left, right, 0, bottom);
	        for (int i = 0; i < 60; i++) {
	            document.add(new Paragraph("This is a test"));
	        }
	        document.close();
		   
	   }catch (Exception e) {
		e.printStackTrace();
	}
	}
}
