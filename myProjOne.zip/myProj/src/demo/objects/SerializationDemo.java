package demo.objects;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.imageio.stream.FileImageInputStream;

public class SerializationDemo {

	public void serializationDemo(UsersObject usersObject) {
		String filename = usersObject.getFirstName()+".txt";
		 try
	        {   
	            //Saving of object in a file
	            FileOutputStream file = new FileOutputStream(filename);
	            ObjectOutputStream out = new ObjectOutputStream(file);
	            // Method for serialization of object
	            out.writeObject(usersObject);
	            out.close();
	            file.close();
	            System.out.println("Object has been serialized");
	        }
	        catch(IOException ex)
	        {
	            System.out.println("IOException is caught");
	        }
		  UsersObject usersObjectOne = null;
		  try
	        {   
	            // Reading the object from a file
	            FileInputStream file = new FileInputStream(filename);
	            ObjectInputStream in = new ObjectInputStream(file);
	            // Method for deserialization of object
	            usersObjectOne = (UsersObject)in.readObject();
	            in.close();
	            file.close();
	            System.out.println("Object has been deserialized ");
	            System.out.println(usersObjectOne.getUserId());
	            System.out.println(usersObjectOne.getFirstName());
	            System.out.println(usersObjectOne.getLastName());
	            System.out.println(usersObjectOne.getEmailId());
	            System.out.println(usersObjectOne.getMobNo());
	            System.out.println(usersObjectOne.getCity());
	        }
	        catch (Exception e) {
				e.printStackTrace();
			} 
	}
}
