package demo.objects;

import java.io.Serializable;

import org.apache.log4j.Logger;

import demo.impls.DemoImpl;

public class UsersObject implements Serializable{
  static Logger logger = Logger.getLogger(UsersObject.class.getName());
  private  transient int userId = -1;
  private  transient String firstName = null;
  private  String lastName = null;
  private  String emailId = null;
  private  String mobNo = null;
  private  String city = null;
	
    public int getUserId() {
	return userId;
    }
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getMobNo() {
		return mobNo;
	}
	public void setMobNo(String mobNo) {
		this.mobNo = mobNo;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
    
    
}
