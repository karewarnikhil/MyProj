package org.apache.log4j;

public class Logger {

	public static Logger getLogger(String name) {
		System.out.println("You are in:"+name);
		return null;
	}

	public void debug(String string) {
		System.out.println("You are in:"+string);
	}

	public void info(String string) {
		System.out.println("You are in:"+string);
		
	}
	
	public void log(String string) {
		System.out.println("You are in:"+string);
		
	}
	

}
