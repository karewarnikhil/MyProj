package org.apache.log4j;

public class LoggerExample {

	static Logger log = Logger.getLogger(LoggerExample.class.getName());
	public static void main(String[] args) {
		
		log.debug("Hello this is an debug message");
	    log.info("Hello this is an info message");
	}

}
