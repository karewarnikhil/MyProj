package com.common.servlets;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.common.objects.UsersObject;

@Controller
public class DemoServlet  {
	
	@RequestMapping(value="/addUser")
	public String addStudent(Model model)  {
		UsersObject usersObject = new UsersObject();
		model.addAttribute("usersObject",usersObject);
		
		return "registration";
	}
	
	
}
